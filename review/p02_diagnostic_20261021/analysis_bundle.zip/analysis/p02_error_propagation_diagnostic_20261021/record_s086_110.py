"""Manual review of25 more Hotpot trajectories and their local reference texts."""
from prepare_inventory import write
from pathlib import Path
notes={
86:'Frozen Galatinus sometimesattributedinventorJehovah supports child. Goal asks whomtermrefersto (GodIsrael), but repeats inventor/term instead, nonresponsive; effective rewrite correctly asks referentJehovah, so goalreader missed requestedattribute',
87:'Frozen OwsleyStanley engineer/chemist and albumrecording withBabcock support truepartialrecorderanswers. Goal rewrite inserts Owsley asrecordingagent while still askingWhichengineer didOwsleyrecord, corrupts subject/object relation',
88:'Actual child1 tenreadertexts onlyawarddefinitions/ceremonyheaders, no intersectingwinnernamed, reasonableabstention. Frozen Kittawards/IfThenYorkeyKittGreif support remaininganswers',
89:'Frozen ShadiLebaneseAshleyCole and AshleyLAGalaxyMLS match answers, no2026teamupdates',
90:'Frozen KentBaerUNLV and SamBoydStadium match answers at materialtime',
91:'Frozen CrawfordForbes1995 and familylawattorneyKateMcQuean support complete answers',
92:'A1PetersburgRussia and goal largestcountry match native. Malformed D2 largestlargest gives no attribute; answer arbitraryGreenlandisland is truthfulbackground but doesnot answer actual location-category task. Goal rewrite replaces requestedunknowncategory withfalseislandlocation confirmation, RF/RT fail',
93:'Frozen specific60000sqftlab isBigelowEastBoothbayMaine, not WoodsHoleMass. Bothanswers wrongidentifiedcampus; rewrite useswrongcampusfromA1 faithfully but targetinvalid',
94:'Frozen Utnequarterly/NYReportmonthly supports all QA and morefrequentNYReport',
95:'Frozen KontinenFinnish/OudinAmerican supports all QA',
96:'Frozen Vestfold/Telemark borderlists support intersectionBuskerud. Raw goalproposal rejected and originalquestion retained; effective RF/RT correct',
97:'Frozen Stoltenberg explicitly formermanagingeditor2004-2012; fullA1/goal presentemployment assertion contradicts recordedendedrole even though magazineidentityAARPcorrect. No2026lookup needed; temporaltenseerror inheritedfrom originalquestion also flagged separately',
98:'Frozen CMIcommission and YECbelief six24hourdays/lessthan10000years supports reportedbelief (notassertingthisasscience). Ordinary answersgive relativecreationweek rather thanabsoluteage, validpartialtemporalanswer; goal includes requestedage',
99:'Frozen Kennedybrothers and TrueCompassTed14Sept2009 support full QA',
100:'Frozen scoreThomasNewman and manyfilmscores supports full QA',
101:'Frozen JaclynScottStappCreed2004 supports facts. Malformed D2 formerfrontmanofspouse answered by correctingrelation tospousehimselffrontman; rewrite copies upstreambadwording, no newwrongidentity introduced',
102:'Frozen Rodriguez2GoldGloves and Rawlingscreator support answers',
103:'Frozen StElizabeth1855/ProvidenceDC1861 supports all QA and earlierStElizabeth',
104:'Frozen Joulupukki literallyYuleGoat/conflatedSanta and YuleGoatstraw tradition supports reference-levelidentification; retains Finnishfigureunknown after binding YuleGoat fromA2',
105:'Actual all unique readertexts across3steps inspected: JacabambaAndes and nearbyCopap/Chincheybut noAuqui/southeastlink, honestabstentions correct. Goal containsAndes genericbio but missing requiredmountainrelation; avoid inventinglink',
106:'Actual A1reader10 Prince-name/musicdistractors noLeeBalladPrince, honestabstention. A2LeeSeungGiMyGirlfriendGumiho true. Goal correctSBS/date but additionallyfalselycallsSBS state-run. Native/corpusSBS saysnational notstate; authorizedfallback SBSofficial1991history explicitlyprivatebroadcasting and Taeyoung controllingowner1990. Wholegoalfalse while preservingcorrectchannelvalue; originalquestion falsepremise noted',
107:'Actual NewarkLittleGiants paragraph explicitlyNewarkNewJersey, and child2reader alsoYoungstownPuddlers renamedLittleGiants. A1wrong Ohio/predecessorteam selection; A2 mapsNJteam toNewarkOhioLickingCounty, falsehomonymjoin. A3NewarkseatLicking factuallycorrect currentcounty. GoalwrongLicking ratherthan nativeYoungstownMahoning; goal rewrite confirmsknownLicking instead of askingunknowncounty',
108:'Frozen BodeCoalMinersDaughter and SpacekLoretta support QA. Rewrite fillsunknownactressSpacek fromparametricfact not supplied A1film, turns whostars intoconfirmation; RF/RT fail',
109:'Frozen Ezhou1048668(2010) vsDujiangyan600000(2003) supports direction, butyearsunequal. A1correctlycannotidentifylatestcensus; goalretainsuncertaintyforDujiangyan ratherthan falselygiving2003asalatestcensusdate. Codevalidvalues/unequal-sourceyears separately, no2026replacement',
110:'Frozen Cactus3rdBass and2initialstudioalbums supports answers'
}
flows={i:{'i':i,'all_nodes_inspected':True,'reason':s} for i,s in notes.items()}
for i in [86,89,90,91,93,97,102,110]:flows[i]['bindings']={'2':[1]}
flows[86].update(incorrect_answers=[2],answer_subtypes={'2':'nonresponsive_term_instead_referent'})
flows[87].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'3':[1,2]})
flows[88].update(bindings={'3':[2]},answer_subtypes={'1':'reasonable_abstention'})
flows[92].update(incorrect_answers=[2],incorrect_fidelity=[3],incorrect_targets=[3],bindings={'3':[2]},answer_subtypes={'2':'nonresponsive_arbitrary_attribute','3':'factual_recovery_despite_bad_rewrite'})
flows[93].update(incorrect_answers=[1,2],incorrect_targets=[2],answer_subtypes={'1':'wrong_named_campus','2':'propagated_wrong_campus_state'})
flows[97].update(incorrect_answers=[1,2],answer_subtypes={'1':'correct_employer_value_wrong_present_tense','2':'correct_magazine_focus_with_wrong_present_tense'})
flows[98]['bindings']={'2':[1],'3':[1],'4':[1],'5':[1]}
for s in [2,3,4]:flows[98].setdefault('answer_subtypes',{})[str(s)]='factual_partial_relative_time'
flows[99]['bindings']={'2':[1]}
flows[101]['bindings']={'2':[1],'3':[2]}
flows[103]['bindings']={'3':[2]}
flows[104]['bindings']={'3':[2]}
flows[105]['answer_subtypes']={str(s):'reasonable_abstention' for s in [1,2,3]}
flows[106].update(incorrect_answers=[3],bindings={'3':[2]},answer_subtypes={'1':'reasonable_abstention','3':'correct_channel_wrong_added_ownership'})
flows[107].update(incorrect_answers=[1,2,4],incorrect_fidelity=[4],incorrect_targets=[2,3,4],bindings={'2':[1],'3':[2],'4':[2]},answer_subtypes={'1':'wrong_predecessor_team','2':'wrong_city_homonym_join','4':'propagated_wrong_county'})
flows[108].update(incorrect_fidelity=[2],incorrect_targets=[2])
flows[109]['answer_subtypes']={'1':'reasonable_abstention','3':'factual_comparison_unequal_source_years'}
assert set(flows)==set(range(86,111))
write(Path(__file__).parent/'batch_s086_110.json',{'batch_id':'s086_110','axis':'stage_node','manually_reviewed_flows':list(flows.values())})
