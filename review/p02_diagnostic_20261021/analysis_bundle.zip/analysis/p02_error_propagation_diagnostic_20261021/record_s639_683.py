"""Persist the reviewer's 45 flow decisions; this script makes no judgments."""
from prepare_inventory import write
from pathlib import Path
notes={
639:'Native film expressly threecodirectors; actual step4 tenreadertexts contain none oftheirbirthdaybios, so abstention reasonable. Miroslav1896 and firstborn comparison correct per datasetLi1930; no reasoning-grounding penalty on true conclusion',
640:'Gold Forbes1926/Bonnard1889; all facts and earlierConcertIntrigue correct',
641:'Gold TorreNilsson→TorresRios matches facts',
642:'Gold Isabella→CharlesVI matches QA; goal genericWhoisCharles drops grandfather relation',
643:'Gold Band2002/Borzage1962; all facts and earlierVanishingVirginian correct',
644:'Gold US/Iran supports all QA and No sharedcountry',
645:'Gold bothRussia supports QA; bothRussia rewrite equivalent after firstRussia established',
646:'Native show explicitly three executiveproducers BurnettTrumpBienstock, all established creators; nationalitiesBritish/US/US true. Multi-person substitution faithful to supplied answer; no current2026 office needed',
647:'Gold US/Australia supports all QA and No comparison',
648:'Gold HabibAzarAmerican matches facts',
649:'Gold AntelAustrian matches facts',
650:'Gold Despenser hangeddrawnquartered supports answer and high-treason historical charge correct',
651:'Gold Poland/US supports all QA and No comparison',
652:'Gold BrightmanWebber supports past marriage; past tense avoids falsely asserting current marriage',
653:'Gold AbrahamLaborielBerklee supports facts',
654:'Gold ReedBritish/English and MelfordAmerican support all QA and No comparison',
655:'Gold SiemowitIV21Jan1426 matches facts',
656:'Native RowanWilliams explicitly MasterMagdalene2013/ChancellorSouthWales2014 supports alternateemployers at frozenmaterialtime; no currentstatus web replacement',
657:'Gold ChristineSaxonyGerman matches facts',
658:'Gold1953/1979 supports dates and earlierMashdiEbad',
659:'Gold bothUS supports QA; bothUS rewrite equivalent given firstUS established',
660:'Gold MurOti2003/David1964 supports all dates and earlierDenIniquity',
661:'Gold GrevilleNice and France qualifier match facts',
662:'Gold bothUS supports QA and bothUS rewrite equivalent',
663:'Gold PodnieksVGIK; graduation1975 correct native detail',
664:'Actual child1 tenreadertexts are genericYou/Country/Samepopduo, no namedfilm; abstention reasonable. Goal British1960/1914 facts match native dataset, hence factualcorrect independent support. Rewrite replaces namedKingsRomance with nonunique1914Britishfilm, loses identity specificity',
665:'Native1937Hochbaum plus1942remake; web1942 credits French+Stein confirms branched version clarification true. Ordinary3HaroldFrench1970 false: IBDB/DeutscheBiographie19Oct1997. Stein1951/Hochbaum1946/Zharov1981 correct; goal explicitly1937Hochbaum comparison correct, no repeatedfalseFrenchdate',
666:'BuzzPotamkin true director; actual/native bio American occupational descriptor but no birthlocation, so reasonable abstention, not nationality-as-birthplace inference',
667:'Native Safavi expressly marriage vs engagement historical dispute; cautious qualifier faithful. SultanAgha mother correct. Goal genericWhoisSultanAgha drops mother-in-law relation',
668:'Native1stEarl is posthumouschild of DavidBarry(the sonof5thViscount) and ElizabethPower. Native5thViscount motherEllenMacCarthyReagh but wifeEllenRoche and sonHonDavidFitzDavidBarry. Ordinary1 standalonefather sentence wrongly attaches ElizabethPower as additionalparent ofthefather; actual father identity value correct. Ordinary2 and goal erroneously take5thViscounts motherEllenMacCarthy as1stEarls grandmother, rather thanEllenRoche; native/gold has a generation-join error. R2 copies corrupted parent descriptor; goal genericWhoisEllen loses relation',
669:'Gold BjorkIceland matches both facts',
670:'Actual10 readertexts inspected: Jorndirector bio gives hisfatherKai but no Jornschildren; otherDonnerschildren not his. Reasonable child abstention correct',
671:'Gold HughI→EverardI supports all QA, goal retains original relation',
672:'Native Mokammel explicitly2017Ekushey plus10NationalFilmAwards fornamedotherfilms; complete answer correct',
673:'Gold Adreon1902/Guldbrandsen1912 supports all facts and olderTraderTom',
674:'Native gold is Fluxusdesigner KenFriedman bornNewLondon1949, not film director. Authorized fallback NYUTisch official KennethAFriedman bornNewYork explicitly directedMadeInUSA, distinct career/identity. Goal transfers designersSwins/Tongji employers to filmmaker, incorrect identity join despite matching gold',
675:'Gold2005/2003 and19May2005 worldwide qualifier correct; earlierPolleke correct',
676:'Gold Juan4th→Juan2nd supports family QA; goal genericWhoisJuan2nd drops grandfather relation',
677:'Gold Armine→MaryFermor supports family QA; goal genericWhoisMary drops grandmother relation',
678:'Gold US/UK supports QA. Comparing established countryvalues for equality retains samecountry proposition, unlike asking if filmsfrom respectivecountries; RF/RT true here',
679:'Gold bothRussia supports QA and equivalent bothRussia rewrite',
680:'Gold Columbia conflicts with goalCharleston; native shortenedbio lacks deathsite. Targetedfallback SCEncyclopedia byhistorian explicitly diedwhilevisitingCharleston and buriedColumbia, so goalfact supported; competing citytimeline/Wikipediaconflict retained rather than using burialasdeath',
681:'Gold Marchent1926/Adolfi1888 supports all facts and laterRingoLoneRider',
682:'Gold VanessaRedgrave RachelKempson matches facts',
683:'Gold Alix→BouchardV supports family QA; goal genericWhoisBouchard drops maternalgrandfather relation'
}
flows={i:{'i':i,'all_nodes_inspected':True,'reason':s} for i,s in notes.items()}
for i in [639,640,643,660,665,673,681]:flows[i]['bindings']={'3':[1],'4':[2]}
for i in [641,646,648,649,650,652,653,655,656,657,661,663,666,669,670,672,674,680,682]:flows[i]['bindings']={'2':[1]}
for i in [654]:flows[i]['bindings']={'3':[1],'4':[2],'5':[1,2]}
for i in [645,659,662,678,679]:flows[i]['bindings']={'3':[1,2]}
for i in [642,667,676,677,683]:flows[i].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'2':[1],'3':[2]})
flows[664].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'3':[2]},answer_subtypes={'1':'reasonable_abstention','3':'factual_answer_despite_local_child_abstention'})
flows[665].update(incorrect_answers=[3],answer_subtypes={'1':'factual_version_specific_alternatives','3':'mixed_correct_dates_false_extra_director_date'})
flows[668].update(incorrect_answers=[1,2,3],incorrect_fidelity=[3],incorrect_targets=[2,3],bindings={'2':[1],'3':[2]},answer_subtypes={'1':'correct_father_value_malformed_false_parent_relation','2':'family_generation_confusion_gold_join_error','3':'family_generation_confusion_gold_join_error'})
flows[674].update(incorrect_answers=[2],answer_subtypes={'2':'gold_homonym_identity_error'})
for i in [666,670]:flows[i]['answer_subtypes']={'2':'reasonable_abstention'}
flows[639]['answer_subtypes']={'4':'reasonable_abstention','5':'factual_comparison_with_local_attribute_gap'}
flows[680]['answer_subtypes']={'2':'factual_death_vs_burial_gold_conflict'}
assert set(flows)==set(range(639,684))
write(Path(__file__).parent/'batch_s639_683.json',{'batch_id':'s639_683','axis':'stage_node','manually_reviewed_flows':list(flows.values())})
