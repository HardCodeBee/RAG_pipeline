"""Record manual decisions after reading these complete question/answer/rewrite packets."""
from prepare_inventory import write
from pathlib import Path
notes={
594:'Gold Antonioni1912/Cromwell1886; dates and laterLEclisse correct',
595:'Gold Francisci1906/Panh1964; dates and youngerGravesWithoutName correct',
596:'Gold PyunHawaii matches both facts',
597:'Gold WarbeckSouthamptonHampshire matches both facts',
598:'Gold1955/1957; StormRider March1957 qualifier correct; earlierSunsetNaples correct',
599:'Actual all reader texts for every step inspected: missing HisWifesHusband film, only generic husband topics; ordinary1 and goal honest insufficiency correct. Rewrite replaces SlavesInBondage film with its attributeUnitedStates, comparing filmcountry to countrycountry; RF/RT fail',
600:'Gold Rogell1988/Anderson1994; all facts and earlierAdmiralWasLady correct',
601:'Native Townshend explicitly1983Brit/2001GrammyLifetime/2008Kennedy matches full award answer',
602:'Gold MolanderHelsingfors; historical HelsinkiGrandDuchyFinlandRussianEmpire qualifiers correct',
603:'Gold Arthur1st→Arthur2ndBaronet family facts correct; genericWhoisSirArthur goal drops grandfather relation',
604:'Gold FerdinandIVJaen;7Sept1312 qualifier correct',
605:'Gold Robert3rd→MaudDeClare facts correct; genericWhoisMaud goal drops grandmother relation',
606:'Actual10 reader texts inspected; NiccoloIII bio onlylifespan/title, no burial evidence and otherEste biographies not hisburial. Correct father and reasonable local-evidence abstention',
607:'Gold TiborTakacsHungarian matches both facts',
608:'Gold ReneSaguisagMaubanQuezon plus Philippines qualifier matches facts',
609:'Gold AnneLeNy and GeorgeFitzmaurice French; current answerFrenchborn matches native descriptor and commonFrench comparison matches frozen dataset nationality wording; preserve origin-versus-citizenship caveat',
610:'Native song explicitly ACOne with Carpani and Chambers; nativeCarpaniPavia supports goal partialbirthplace. BritishvocalistChambers descriptor true; lack of herbirthplace not falsely filled. Rewrite retains supplied group/person identities',
611:'Gold LordGeorge→John3rdDuke family QA correct; goal retains original relation',
612:'Gold Cabanne1950/Newfield1964; all facts and laterBrandedCoward correct',
613:'Gold1976/2012 and IAmKing8Aug2012 qualifier correct; newerIAmKing correct',
614:'Gold bothBritish supports all QA and Yes commonUK',
615:'Gold ElizabethFitzClarence→WilliamIV family QA correct; goal father-of-known-mother preserves relation',
616:'Gold SeqenenreTao→SenakhtenreAhmose supports family QA and goal father-of-known-father preserves relation',
617:'Gold1906/1961 and laterLincoln comparison correct',
618:'Native Gupta explicitly CNNmedicalcorrespondent and GradyassociatechiefAtlanta; true partial employer answer despite gold choosingEmory',
619:'Native FleshForFrankenstein explicitly written/directorMorrissey and marketingAndyWarholtitle; primary Criterion restored-directors-cut credits Morrissey alone, no Warholco-director. JoBaier otherfilm. One-each goal supported by actual film credits, goldWarhol additionaldirector conflicts',
620:'Actual10 reader texts inspected; David4th father appears but only David5th/10th/2nd dates present. No David4thdeathdate, so reasonable abstention correct',
621:'Gold Wright29July1888 matches facts',
622:'Gold Cerchio1974/Douglas1993; all facts and laterNightNGales correct',
623:'Gold BergmanFaro plus Sweden qualifier matches facts',
624:'Gold1893/2004 and earlierCroatianMuseum correct',
625:'Gold2016/2000 and earlierRomanovs correct',
626:'Gold Pazzaglia1926/Munk1921; all facts and earlierManOnTracks correct',
627:'Gold FrancesCornford→FrancisDarwin supports QA; goal genericWhoisDarwin drops original maternalgrandfather relation',
628:'Actual Judith evidence gives wifeEsau and brotherJacob, no Judithsiblings or spouses thereof; firsttwo reasonable abstentions; remaining family answers correct; rewrite bindsEsau correctly, goal retains sibling-in-law',
629:'Gold JamesTuchetDarleyAbbey and northDerby qualifier correct',
630:'Gold Lieberman1947/ChorYuen1934; all facts and earlierEmperorBrother correct',
631:'Gold Khrabrovitsky1923/Arnold1916; all facts and olderLadyTakesFlyer correct',
632:'Gold FelipeIII Madrid matches facts',
633:'Gold1949/1814 and earlierJohnPage correct',
634:'Gold ElisaDestréeBommerLaeken matches facts',
635:'Frozen CharlesPrinceWales founder/ElizabethII mother supports both QA; no currenttitle replacement needed',
636:'Gold Lewis2016/Aldrich1983; all facts and earlierEmperorNorthPole correct',
637:'Native song expressly writtenbyGeorgeandIra; broad joint songcomposition valid, not assumed bothmusic-only. GeorgeHollywood/IraBeverlyHills deathsites correct; goal fulltwo-person facts retained',
638:'Native Schneeland SundanceJan2005/Germanrelease laterJan explicitly verifies date; Soaked2015 and earlierSchneeland correct'
}
flows={i:{'i':i,'all_nodes_inspected':True,'reason':s} for i,s in notes.items()}
for i in [594,595,600,612,622,626,630,631,636]:flows[i]['bindings']={'3':[1],'4':[2]}
for i in [596,597,601,602,604,606,607,608,610,618,620,621,623,629,632,634,635,637]:flows[i]['bindings']={'2':[1]}
flows[609]['bindings']={'3':[1],'4':[2],'5':[1,2]}
for i in [603,605,627]:flows[i].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'2':[1],'3':[2]})
for i in [611,615,616]:flows[i]['bindings']={'2':[1],'3':[1] if i!=611 else []}
flows[599].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'3':[2]},answer_subtypes={'1':'reasonable_abstention','3':'reasonable_abstention'})
for i in [606,620]:flows[i]['answer_subtypes']={'2':'reasonable_abstention'}
flows[609]['answer_subtypes']={'4':'factual_national_origin_descriptor','5':'dataset_national_origin_comparison'}
flows[610]['answer_subtypes']={'2':'factual_partial_answer_with_reasonable_abstention'}
flows[618]['answer_subtypes']={'2':'factual_partial_employer_list'}
flows[619]['answer_subtypes']={'3':'factual_film_credit_gold_conflict'}
flows[628].update(bindings={'4':[3]},answer_subtypes={'1':'reasonable_abstention','2':'reasonable_abstention'})
assert set(flows)==set(range(594,639))
write(Path(__file__).parent/'batch_s594_638.json',{'batch_id':'s594_638','axis':'stage_node','manually_reviewed_flows':list(flows.values())})
