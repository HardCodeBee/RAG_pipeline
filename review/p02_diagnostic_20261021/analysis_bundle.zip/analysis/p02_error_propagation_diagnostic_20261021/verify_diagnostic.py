"""Meaningful integrity/denominator checks; never execute RAG or change sources."""
from collections import Counter
from datetime import datetime,timezone
from prepare_inventory import ROOT,OUT,read,rows,write,sha
run=OUT/'offline_review_v2'
sources=read(run/'SOURCES.json')['files']
changed=[v['path'] for v in sources if sha(ROOT/v['path'])!=v['sha256']]
assert not changed,changed
print({'fixed_primary_sources_hash_verified':len(sources)},flush=True)
fact=read(run/'FACT_REFERENCE_SOURCES.json')['sources']
changed=[v['path'] for v in fact if sha(ROOT/v['path'])!=v['sha256']]
assert not changed,changed
print({'local_native_fact_sources_hash_verified':len(fact)},flush=True)
qs=rows(run/'QUERY_LABELS_AND_OUTCOMES.jsonl');s=read(run/'STAGE_LABELS_LOCKED.json')['labels'];cp=read(run/'CONDITIONAL_PROBABILITIES.json')
assert len({q['id'] for q in qs})==len(qs)==723
assert Counter(q['dataset'] for q in qs)=={'2wiki':485,'hotpotqa':238}
assert len({(v['id'],v['step_id']) for v in s})==len(s)==2084
assert sum(v['role']=='ordinary' for v in s)==1361
assert sum(v['answer_correct'] is None for v in s)==len(read(run/'PENDING_FACTS.json')['items'])==7
for t in cp['tables']:
 assert sum(g['n'] for g in t['groups'].values())==t['eligible_rows'],t['table']
 for g in t['groups'].values():assert 0<=g['successes']<=g['n']
assert {key:sha(run/name) for key,name in [('stage','STAGE_LABELS_LOCKED.json'),('decomposition','DECOMPOSITION_LABELS_LOCKED.json'),('endpoints','OUTCOMES_SEPARATE.jsonl')]}==cp['annotation_files']
es=rows(run/'REWRITE_EVENTS.jsonl');bad=rows(run/'REWRITE_ERROR_CATALOG.jsonl')
assert len(es)==1361 and len(bad)==88
assert {(e['id'],e['step_id']) for e in es if not e['rewrite_correct']}=={(e['id'],e['step_id']) for e in bad}
vv=read(run/'FINAL_VISIBILITY_VERIFIED.json')
assert vv['all_complete_contexts_exactly_verified']==723 and vv['all_final_contexts_in_saved_final_prompt'] and vv['all_child_prompts_use_original_current_subquestion']
plan=ROOT/'experiments/query_decomposition/unified_rag_eval_v1_20261021'
assert (plan/'STOP_REQUESTED').exists() and not read(plan/'PLAN.json')['execution_approval']['approved']
protected=read(plan/'PROTECTED_FILES_BEFORE.json')
assert all(sha(ROOT/p)==v for p,v in protected.items())
write(run/'VALIDATION.json',{'utc':datetime.now(timezone.utc).isoformat(),'fixed_primary_source_hashes':len(sources),'local_fact_source_hashes':len(fact),'protected_main_method_and_baseline_hashes':len(protected),'query_count':723,'stage_nodes':2084,'pending_goal_facts':7,'rewrite_records':1361,'rewrite_error_records':88,'exact_final_prompt_visibility_checked':723,'denominators_consistent':True,'main_pause_marker_preserved':True,'main_execution_approved':False,'RAG_or_API_execution':False})
print({'validation':'passed','queries':723,'stage_nodes':2084,'pending_goal_facts':7,'main_paused':True},flush=True)
