"""Explicit manual semantic decisions; original predictions remain blinded."""
from prepare_inventory import write
from pathlib import Path
notes={
36:'Frozen AnitaBerber role and OttoDixpainting match both answers; painting identified by itscreator at reference precision',
37:'Frozen JesseWilliamsLawson→JacksonAvery and season6episode5Invasion support all answers',
38:'Frozen Schreker explicitlyteacher, Glassshortbio lacks teaching; currentsource-qualified Glassabstention and Schrekerselection correct',
39:'Frozen BillPollack contemporaryPhilHill and Hill20Apr1927/onlyUSbornF1champion match answers; actual Billbio lacks birthday, reasonable A2abstention',
40:'Frozen Brooklynborough/Tower49MidtownNYC supports all answers',
41:'Commodore16 NorthAmericanorigin coarsebuttrue; CP400Brazil true, differentorigins and No correct; not asserting NorthAmerica is a sovereigncountry',
42:'Frozen SlamNation followsNationalPoetrySlam; RaceToNowhere education documentary notpoetry; answers correct',
43:'Frozen Cianciulli serialkillings1939-40Correggio supports all answers. Goalrewrite fillsunknownkiller and changes whowas into confirmationproposition; RF/RT false although QA factual',
44:'Frozen EmilyBlunt and2001LondonRoyalFamily debut match both answers',
45:'Sheol definition itself true for broad firstchild, but frozen built-over-centuries referent is MontezumaCliffDwellings, notconceptualunderworld. Later answers substitute irrelevant sense and deny realstructurebuilt; nonresponsivewrongreferent. Rewrites copy suppliedSheol faithfully but incompatible with requestedphysicalconstruction target',
46:'Frozen shows/enemies material: listed Hasbro-propertyshows true; Decepticons/Inhumanoids true partialenemies but missingMLPWendigos. Actual goalreader ten texts have noWendigo/Equestria; source-qualified failuretofindpsychosis locallyreasonable. Bindings to true subset are factual, yet partial-listcoverage loses neededroute; flag rootcoverage rather than falseassertion',
47:'Actual child1 reader10 unrelatedToru/Torridon/Torplaces, noTorridretailer; honestabstention correct. Frozen TorridfirstBreaMallBrea supports goal',
48:'Listed golfers1993 and Thomas2017PGAchampionship are valid alternativeanswers to underdeterminedquestion, despite datasetSpiethMasters2015. Goal doesnot require allordinary-listedgolfers toshareonespecifictournament',
49:'A1 generic portraitgallerybackground supplies no particularportrait, nonresponsive under userapprovedrule. Frozen MaryOConnell portraitSmithsonian and Nightingalefoundermodernnursing support A2/goal at originalquestion premise; goal correctMary target',
50:'Frozen Chienpackhunting explicit; Cretanpartialbio lacks packhunting. Source-qualified Cretanabstentions reasonable, no falseNo inferred',
51:'Frozen BestFootForward choreographerGeneKelly and1912 support answers',
52:'Frozen namesakeLouisMountbatten and secondcousinonceremovedElizabethII support answers',
53:'Frozen2015AllStarAwaycaptainToews and centreposition support answers; no currentteamupdates',
54:'AdultSwim CartoonNetworkblock true. Native singlefounderBettyCohen differs TedTurner. Authorized fallback contemporary1992UPI launch and CartoonNetworkInc cofounderhistory corroborate Ted asvalidfounder alternative, not falsejustdifferentgold',
55:'Frozen MetLifeLeBrun supports firstselection;15HudsonmodernDSR/Rockwell design notLeBrun, all answerscorrect',
56:'A1 providescollegecount38+6halls instead of requestedcollegeidentities: nonresponsive under approvedrule. Native Waynflete4fellowshipsMagdalen support A2/goal; goal rewrite asks whichcollegeisMagdalen, replacing fellowshipcondition withgivenanswer verification',
57:'Frozen DogwomancreatorSzubanski born1961 supports both answers',
58:'Frozen Taylorbirthday and wearsPorterLyons support A1/A2/goal. A3 brandbackground instead of requestedjewelry is nonresponsive. R3 replaces brand-productquery with whatTaylorwears, a differenttarget/relationship; RF/RT false',
59:'Actual child1 reader10 music2014 headings/1984Ibizasong, no target2014hits; abstention reasonable. Frozen TenWallsWalkingElephantsIbiza2014 supports A2/goal and single-trackbinding',
60:'Frozen Udhayam? no: StoryvilleBreakinRules→UntilEndWorld1991 and filmSciFiDrama support both actual answers'
}
flows={i:{'i':i,'all_nodes_inspected':True,'reason':s} for i,s in notes.items()}
for i in [36,44,51,52,53,57,60]:flows[i]['bindings']={'2':[1]}
flows[37]['bindings']={'2':[1],'3':[2]}
flows[39].update(bindings={'3':[1],'4':[1]},answer_subtypes={'2':'reasonable_abstention'})
flows[43].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'3':[1,2]})
flows[45].update(incorrect_answers=[2,3],incorrect_targets=[2,3],bindings={'2':[1],'3':[1]},answer_subtypes={'1':'factual_alternative_term_sense','2':'nonresponsive_wrong_referent','3':'propagated_wrong_referent'})
flows[46].update(bindings={'2':[1],'3':[2]},answer_subtypes={'1':'factual_partial_list','2':'factual_partial_list','3':'reasonable_abstention'})
flows[47]['answer_subtypes']={'1':'reasonable_abstention'}
flows[48].update(bindings={'2':[1]},answer_subtypes={'1':'factual_alternative_entities_partial_list','2':'factual_alternative_underconstrained_query'})
flows[49].update(incorrect_answers=[1],bindings={'3':[2]},answer_subtypes={'1':'nonresponsive_general_background'})
flows[50]['answer_subtypes']={'2':'reasonable_abstention','3':'reasonable_abstention'}
flows[54]['answer_subtypes']={'2':'factual_alternative_founder'}
flows[56].update(incorrect_answers=[1],incorrect_fidelity=[3],incorrect_targets=[3],bindings={'2':[1],'3':[2]},answer_subtypes={'1':'nonresponsive_count_instead_entities'})
flows[58].update(incorrect_answers=[3],incorrect_fidelity=[3],incorrect_targets=[3],bindings={'2':[1],'3':[1],'4':[1]},answer_subtypes={'3':'nonresponsive_general_background'})
flows[59].update(bindings={'3':[2]},answer_subtypes={'1':'reasonable_abstention'})
flows[38]['answer_subtypes']={'1':'reasonable_abstention','3':'factual_selection_with_source_qualified_abstention'}
flows[41]['answer_subtypes']={'1':'factual_coarse_origin_precision'}
assert set(flows)==set(range(36,61))
write(Path(__file__).parent/'batch_s036_060.json',{'batch_id':'s036_060','axis':'stage_node','manually_reviewed_flows':list(flows.values())})
