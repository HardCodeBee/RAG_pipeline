"""Final complete-flow HotpotQA batch; existing outcomes remain unseen."""
from pathlib import Path
from prepare_inventory import write
notes={
211:'Frozen SanAntonio seventh and GeorgiaMiddleman age10 supports all',
212:'Frozen tribes Oryzomyini historical Megaoryzomys and current Nesoryzomys supports all, partial historical alternatives allowed',
213:'Frozen GFplatform Capella626 Mazda supports all',
214:'Frozen Bulldogs BryantUniversity SmithfieldRI supports both',
215:'Frozen Craig1976 Paramount1948 supports all and ordering',
216:'Frozen JeffMartinTeaParty KyleClickFive. Actual ClickFive paragraph explicitly Kyle replacedDill and debuted2007secondalbum; extra sentence true',
217:'Frozen Yates director and Germi actorwriterdirector supports all',
218:'Frozen Lakshmi motherinlaw LSubramaniam virtuoso/orchestralfusion supports both',
219:'Frozen GoldenEgg HetGoudenEi EnglishVanishing TimKrabbe and1988Spoorloos GeneBervoets supports both',
220:'Frozen StephenIrelandStoke and Casselldevelopment supports all using corpus-time teamstatus',
221:'Frozen KimKibum ParkYejin cast supports both answers. Rewrite asks co-star alongside ParkYejin instead of alongside KimKibum, swaps known constraint and unknown answer, RF/RTfalse',
222:'Frozen David Frenchdub LaraCroft TombRaider CrystalDynamics SquareEnix supports both',
223:'All10 actual A1 player biographies inspected, list true even though none is needed JustinBrown. SoonersBig12 is frozen historical membership, not 2026, allQAtrue',
224:'Frozen CliftPrewitt FromHereToEternity PearlHarbor supports all',
225:'Frozen canal locations and Pennsylvania countylist supports all. Goal rewrite fills the location answers into candidates but still askswhere, overbinds unknown locations into verification',
226:'Actual readers give2founders but no exhaustive all-time OperationMD roster; DelAmitri explicit4originalmembers with atleast qualification true. Both source-qualified total-count abstentions reasonable, no claim foundersbound all-time membership',
227:'Frozen Florence song and FridaKahlo painting1938 supports all',
228:'Frozen AIACentral AIAGroup panAsian lifeinsurance supports both',
229:'Frozen OlympiaBrewing founding and Tumwater nearOlympia supports all. Rewrite inserts unknown townTumwater and removes interrogative whatWashingtonTown, RF/RTfalse',
230:'Frozen MehranPakistan DebrecenHungary supports all',
231:'Actual A1 reader noEven band, source-qualified no mention reasonable. Goal adds categorical false no musical association for Even, although native Even is Australianrockband. Correct No alone does not rescue fullstatement',
232:'Frozen TenderFictions BarbaraHammer vs Bougainville WayneColesJaness supports all',
233:'Frozen Julie2Deepak and Phulwa supports ordinary1 and goal; all actual A2 readerdocs lack Phulwa/Julie choreography, so source-qualified A2abstention reasonable',
234:'Frozen StJohns institution Jesuit true, trivium grammar rhetoric logic true for liberalarts. Goal specifically calls these Jesuit threecore; actual reader only institutionalJesuit plus unrelatedschools. Targeted RatioStudiorum sources contain grammar/rhetoric/logic in different cycles but do not settle exact threecore attribution. Keep goal factual workitem unlabeled, not force either label; rewrite binds true institutional tradition',
235:'Frozen OcnusTiberinus AlbaLonga12milesSE supports all',
236:'Frozen Colisee4000capacity3677seated, fullgoal correctly distinguishes standingcapacity from seatcount, both true',
237:'Actual reader Osteomelesanthyllidifolia explicitly all listed Pacificislands, MedinillawesternPacific; both true despite native generic Osteomeles onlyeastAsia, gold exclusive choice too narrow',
238:'Actual goal reader AfroSeminoleCreole explicitly OklahomaTexasNorthernMexico, plus nativeMascogosMexico; both QAtrue, not restricted to goldMexico'
}
flows={i:{'i':i,'all_nodes_inspected':True,'reason':v} for i,v in notes.items()}
for i in [214,218,219,222,228,234,238]:flows[i]['bindings']={'2':[1]}
for i in [211,213,224,227,235]:flows[i]['bindings']={'2':[1],'3':[2]}
flows[211]['bindings']['3']=[1]
flows[221].update(incorrect_fidelity=[2],incorrect_targets=[2],bindings={'2':[1]})
flows[223].update(bindings={'3':[2]},answer_subtypes={'1':'factual_partial_list_missing_needed_bridge'})
flows[225].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'3':[1,2]})
flows[226]['answer_subtypes']={'1':'reasonable_abstention','2':'factual_partial_count_lower_bound','3':'reasonable_abstention'}
flows[229].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'2':[1],'3':[2]})
flows[231].update(incorrect_answers=[3],answer_subtypes={'1':'reasonable_abstention','3':'correct_boolean_false_extra_entity_claim'})
flows[233].update(bindings={'2':[1]},answer_subtypes={'2':'reasonable_abstention'})
flows[234].update(pending_answer_facts=[2],answer_subtypes={'2':'pending_exact_educational_tradition_attribution'})
assert set(flows)==set(range(211,239))
write(Path(__file__).parent/'batch_s211_238.json',{'batch_id':'s211_238','axis':'stage_node','manually_reviewed_flows':list(flows.values())})
