"""Apply transparent second-pass amendments before joining any outcome."""
from collections import Counter
import json
from datetime import datetime, timezone
from pathlib import Path
from prepare_inventory import ROOT, OUT, read, write, sha

run=OUT/'offline_review_v2'
review=read(Path(__file__).parent/'decomposition_recheck.json')
annotations=[r for f in sorted((run/'reviews').glob('d*.json')) for r in read(f)['labels']]
assert len(annotations)==723 and len({r['id'] for r in annotations})==723
amend={r['review_index']:r for r in review['amendments']}
for r in annotations:
    r['second_pass_checked']=(not r['correct'] or r['review_index'] in read(run/'RECHECK_SELECTION.json')['correct_indices_seed20261021'])
    if r['review_index'] in amend:
        r['first_pass']={k:r[k] for k in ('dimensions','correct','reason')}
        a=amend[r['review_index']]
        r.update(dimensions=a['dimensions'],correct=all(a['dimensions'].values()),reason=a['reason'])
        r['amended_before_outcome_merge']=True
    r['semantic_failure_dimensions']=[k for k in 'FSC' if not r['dimensions'][k]]
    r['utility_only_failure']=not r['dimensions']['U'] and not r['semantic_failure_dimensions']
write(run/'DECOMPOSITION_LABELS_LOCKED.json',{'status':'all723_reviewed_and_second_pass_locked',
    'labels':annotations,'review':review,'labels_sha_source_batches':read(run/'REVIEW_PROGRESS.json')['reviewed_batch_files'],
    'counts_by_dataset':{ds:dict(Counter('correct' if r['correct'] else 'incorrect' for r in annotations if r['dataset']==ds)) for ds in ('2wiki','hotpotqa')},
    'outcome_merge_performed':False})
plan=ROOT/'experiments/query_decomposition/unified_rag_eval_v1_20261021'
decision={'id':'P02_DIAG_PARTIAL_FACT_LIST_APPROVED','utc':datetime.now(timezone.utc).isoformat(),
    'authority':'User: listed facts correct counts correct; no completeness requirement',
    'child_answer_rule':'partial set/list answers count correct when every listed fact is correct; record partial listing separately',
    'new_RAG_or_external_model':False,'main_evaluation_remains_paused':True}
log=plan/'DECISIONS.jsonl'
if decision['id'] not in log.read_text(encoding='utf-8-sig'):
    with log.open('a',encoding='utf-8') as f:f.write(json.dumps(decision,ensure_ascii=False)+'\n')
p=plan/'reviews/20261021_error_propagation/PROPOSAL.json';v=read(p)
v['approved_protocol']['partial_list_answers']='factually correct listed items count correct; completeness not required; subtype retained'
write(p,v)
md=p.with_suffix('.md');s=md.read_text(encoding='utf-8')
s=s.replace('部分答案/集合完整性出现真实边界时先询问用户。','用户进一步确认：集合型回答只要列出的事实正确即算正确，不要求列全；部分列举另记，不因此判错。')
md.write_text(s,encoding='utf-8');v['proposal_sha256']=sha(md);write(p,v)
print(json.dumps(read(run/'DECOMPOSITION_LABELS_LOCKED.json')['counts_by_dataset']))
