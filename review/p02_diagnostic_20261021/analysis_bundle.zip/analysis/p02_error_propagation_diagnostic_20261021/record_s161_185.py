"""Explicit manual review of 25 frozen HotpotQA flows, before outcome join."""
from prepare_inventory import write
from pathlib import Path
notes={
161:'Frozen State of Franklin1784 Campbell and easternTennessee support both answers; goal binds1',
162:'Gold positive-doc list mismatches Hawaii instead of actual question. Actual reader Dulles explicitly Virginia US and BaltimoreWashington US; all QA true independent of bad gold-doc metadata',
163:'Frozen Branford LongIslandSound110miles supports both answers',
164:'Frozen Montoya podium third and TeamPenskeVerizonIndyCar supports historical-current claim; no 2026 update',
165:'Frozen PIW1967 vs Freedmens1862 former-slaves history supports both judgements and goal. Rewrite preserves two candidate hospitals with equivalent resolved criterion',
166:'All four Carlo roles true, but movie question includes UnCicloneInFamiglia television series as film candidate. Additional frozen corpus record33172485 explicitly television series. A1 wrong media classification; goal uses IlDivo and GreatBeauty Cannes accurately, partial list allowed. Rewrite faithful list but fact target includes TV title as festival film',
167:'Frozen Francis firstJesuit and Mendoza age resignation supports both',
168:'Frozen PeterThiel profile and Andreas name supports both',
169:'Frozen AmericanBulldog StandardClassic types vs French supports QA; question itself uses breeds, no new unsupported taxonomic assertion',
170:'Frozen occupations support both lists and intersection. Rewrite substitutes resolved occupation profiles and retains intersection operator; truth-preserving attribute comparison, although names would improve retrieval specificity',
171:'Frozen PamelynWandaFerdin. Ordinary correct; goal falsely calls full name the middle name, wrong complete relation despite containing correct token Wanda',
172:'Frozen SacredGround cast and Elam lazy left eye support all QA',
173:'Frozen ElenaMefistofele and premiere LaScala Milan5March1868 supports both',
174:'Frozen Greenland/sleeper ingredient; goal explicitly qualifies Greenland range to Atlantic/Arctic, true partial ingredient case',
175:'Frozen ThomasRush scorers and RushWelsh supports all',
176:'All actual A1 and goal reader ten docs checked: Canadian2011 film lists/actor biographies but no ConArtist or June14 release. Both source-qualified abstentions reasonable',
177:'Calare1906 true partial election list. SouthSydney coveredAlexandria is independently true: local reader only broad southSydney, targeted1903 Commonwealth electoral roll index explicitly lists Alexandria. Current A2 lacks1906 constraint, so not wrong solely for differing from goalCook1906, which is also true',
178:'Frozen UlverMesse and founderRygg supports both',
179:'Frozen DonaldOConnor and DebbieReynolds true for broad current child co-star question; goal Francis mule true. Nonexhaustive ordinary answer can be correct yet miss needed bridge',
180:'Frozen American novelists and Capote nonfiction novel qualifier supports all',
181:'Actual all A1 and goal reader docs checked: no Deioces53years passage. Goal has Cyaxares father and grandfather names but cannot link supplied53years criterion, so both source-qualified abstentions reasonable',
182:'Frozen DarylDixon NormanReedus and Prada supports all',
183:'Frozen Tunak DalerMehndi1967 supports both',
184:'Frozen RintSchwarzenberg and CzechBohemian/GermanFranconian descriptors supports both',
185:'Frozen HackmanLexLuthor and30January1930 supports both'
}
flows={i:{'i':i,'all_nodes_inspected':True,'reason':v} for i,v in notes.items()}
for i in [161,163,164,166,167,168,173,174,178,183,184,185]:flows[i]['bindings']={'2':[1]}
flows[165]['bindings']={'3':[2]}
flows[170]['bindings']={'3':[1,2]}
flows[171].update(incorrect_answers=[2],bindings={'2':[1]},answer_subtypes={'2':'correct_token_wrong_name_field_full_statement'})
flows[166].update(incorrect_answers=[1],incorrect_targets=[2],answer_subtypes={'1':'wrong_media_type_in_movie_list','2':'factual_partial_list'})
flows[176]['answer_subtypes']={'1':'reasonable_abstention','2':'reasonable_abstention'}
flows[177]['answer_subtypes']={'1':'factual_partial_list','2':'factual_alternative_underconstrained_child'}
flows[179].update(bindings={'2':[1],'3':[1]},answer_subtypes={'2':'factual_partial_list_missing_needed_bridge'})
flows[181]['answer_subtypes']={'1':'reasonable_abstention','2':'reasonable_abstention'}
flows[182]['bindings']={'2':[1],'3':[1]}
assert set(flows)==set(range(161,186))
write(Path(__file__).parent/'batch_s161_185.json',{'batch_id':'s161_185','axis':'stage_node','manually_reviewed_flows':list(flows.values())})
