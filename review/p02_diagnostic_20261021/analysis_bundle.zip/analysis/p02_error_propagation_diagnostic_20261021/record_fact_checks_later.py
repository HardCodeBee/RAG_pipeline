"""Append already inspected targeted factual sources; no requests or generation."""
from prepare_inventory import OUT,read,write
run=OUT/'offline_review_v2'
checks=[
(619,'Morrissey credited director of FleshForFrankenstein',True,'Primary Criterion film record credits PaulMorrissey; AndyWarhol marketing does not establish codirection',['https://www.criterion.com/films/562','https://www.criterionchannel.com/flesh-for-frankenstein']),
(665,'HaroldFrench died1970',False,'IBDB gives19October1997, GermanBiography corroborates1997; goal1937Hochbaum conclusion still true',['https://www.ibdb.com/broadway-cast-staff/harold-french-14828','https://www.deutsche-biographie.de/1019196246.html']),
(674,'MadeInUSA directorKenFriedman is Swinburne/Tongji professor',False,'NYUTisch filmmaker KennethAFriedman profile differs Fluxusdesigner same name, local source combines homonyms',['https://tisch.nyu.edu/about/directory/grad-film/101907044.html']),
(680,'HenryWilliamDeSaussure diedCharleston',True,'SouthCarolinaEncyclopedia historian distinguishes diedwhilevisitingCharleston and buriedColumbia; citytimeline givesColumbia, retain source conflict',['https://www.scencyclopedia.org/sce/entries/desaussure-henry-william/','https://charleston-sc.gov/DocumentCenter/View/28559/No-9-Henry-William-DeSaussure-1763-1839?bidId=']),
(54,'TedTurner founded CartoonNetwork',True,'Contemporary Turner1992 launch and cofounder history support alternative to singlefounderBettyCohen gold',['https://www.upi.com/Archives/1992/02/18/Turner-to-launch-24-hour-cartoon-network/7793698389200/','https://en.wikipedia.org/wiki/The_Cartoon_Network%2C_Inc.','https://en.wikipedia.org/wiki/Betty_Cohen']),
(64,'BankOfCommunications is a financial holding company',False,'Official parent profile calls commercialbank and distinguishes subsidiary holding company',['https://www.bankcomm.com/BankCommSite/shtml/London/en/3065/list.shtml','https://www.bankcomm.com/BankCommSite/shtml/jygj/en/16641/16651/list.shtml']),
(106,'SBS was state-run in2010',False,'Official SBS history describes privatebroadcasting from1991 and Taeyoungcontrollingowner1990',['https://about.sbs.co.kr/history','https://about.sbs.co.kr/history_graph']),
(133,'JohnArledge appearedinFlowingGold1940 directedbyRalphMurphy',False,'AFI record credits AlfredEGreen and JohnGarfield, not the claimed actor/director pair',['https://catalog.afi.com/Film/5028-FLOWING-GOLD','https://www.imdb.com/title/tt0032481/fullcredits/']),
(136,'StreetKings writtenanddirectedbyDavidAyer',False,'AFI credits Ayer director, EllroyWimmerMoss writers, not Ayer writer',['https://catalog.afi.com/Catalog/moviedetails/64772','https://watch.afi.com/movie/street-kings']),
(143,'BigJohnStudd appearedinBigRed1962',False,'Fullcast lists do not credit him, unlike localDoubleAgent1987; wrong actor-film association',['https://www.tvguide.com/movies/big-red/cast/2030055188/','https://www.themoviedb.org/movie/61871-big-red/cast']),
(177,'SouthSydney electorate coveredAlexandria',True,'Digitized1903 Commonwealth electoralroll index explicitly Alexandria pollingplace, valid alternative currentchild unconstrained by1906',['https://www.ihr.com.au/secure/html/nswer03_southsydney.html','https://www.ihr.com.au/secure/html/recent.html']),
]
w=read(run/'WEB_FACT_CHECKS.json');existing={(c['review_index'],c['claim']) for c in w['checks']}
for i,claim,correct,fact,urls in checks:
 if (i,claim) not in existing:w['checks'].append({'review_index':i,'claim':claim,'correct':correct,'verified_fact':fact,'sources':urls,'scope':'targeted only after local unresolved/conflict; no model judge'})
write(run/'WEB_FACT_CHECKS.json',w)
p=read(run/'PENDING_FACTS.json');existing={(c['review_index'],c['step_id']) for c in p['items']}
new=[
{'review_index':160,'step_id':2,'role':'goal','claim':'Boeing707-436 maximum219passengers','status':'pending_exact_aircraft_subtype_capacity','reason':'Native707 family140-219 does not settle436 subtype. Secondary320C extraexit claim and exampleoperatingseat layouts cannot establish exact436maximum','sources':['https://en.wikipedia.org/wiki/Boeing_707','https://aviation.stackexchange.com/tags/boeing-707/info','https://thelittleaviationmuseum.au/planes/boeing-707-436-boac/']},
{'review_index':234,'step_id':2,'role':'goal','claim':'Jesuit traditions three core subjects weregrammar rhetoric logic','status':'pending_exact_tradition_core_attribution','reason':'Native liberalartstrivium establishes three subjects; Jesuitinstitution identity true but exactJesuitthreecore attribution not settled by RatioStudiorum cycles, no forced truthlabel','sources':['https://www.educatemagis.org/wp-content/uploads/documents/2019/09/ratio-studiorum-1599.pdf','https://jesuitonlinebibliography.bc.edu/catalog/3111','https://en.wikisource.org/wiki/Jesuit_Education/Chapter_13']}
]
for c in new:
 if (c['review_index'],c['step_id']) not in existing:p['items'].append(c)
write(run/'PENDING_FACTS.json',p)
print({'web_checks':len(w['checks']),'pending_facts':len(p['items'])})
