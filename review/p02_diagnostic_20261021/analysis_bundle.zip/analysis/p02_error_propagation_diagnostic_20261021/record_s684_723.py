"""Persist the last 40 manually inspected 2Wiki flows."""
from prepare_inventory import write
from pathlib import Path
notes={
684:'Gold WernickeOsterodeAmHarz matches facts',
685:'Gold LeofricCoventry; CoventryAbbeycofounderLadyGodiva detail correct',
686:'Gold1993/1982 supports dates and earlierPatnam; rewrite retains both filmnames and adds verifieddates',
687:'D misclassifies filmnames as directors, but answers explicitly correct this presupposition by stating realfilmdirector pairs. True1975BangladeshSujon/Khan and1964TwoThousand/Lewis facts; dates1928/1926 and youngerSujon correct. R3/R4 usecorrectactualdirectors supplied by preceding corrective answers; upstream Derror contained rather than copiedliterally',
688:'Gold James11th→Francis10th supports family QA; goal retains originalrelation',
689:'Gold Wong1959/Kosminsky1956 and earlierWutheringHeights correct;1992 film qualifier correct',
690:'Gold FerdinandLesseps7Dec1894 matches facts',
691:'Gold AlexKramerMontrealQuebec and Canada qualifier matches facts',
692:'Gold Dante1946/Lester1932 and laterGremlins2 correct',
693:'Gold bothUS supports QA and Yes commoncountry',
694:'Gold CharlesWilliam→DavidAlexander family facts correct; goal genericWhoisDavid drops grandfatherrelation',
695:'Gold2011/2004 and earlierCheppave correct',
696:'Gold2008/2005 and newerAskTutulmasi correct',
697:'Gold Fregonese1987/Romero1954; dates and earlierMuchachas correct',
698:'Gold1970/1902 and earlierTwentiethCenturyTramp correct',
699:'Gold bothUS supports QA and Yes commoncountry',
700:'Gold ErnestLouis→ElisabethDorothea supports family QA; goal genericWhoisElisabeth drops grandmotherrelation',
701:'Correct AubreyScotto director and1953 deathyear; actual reader lacks his deathplace, locallyreasonable abstention, no inventedLosAngeles required',
702:'Gold Cheung1950/Bhaskaran1924; dates and youngerTraces correct; younger→bornlater preserves meaning',
703:'Gold Oswald1919/Topper1928; dates and earlierAgentHARM correct',
704:'Actual10 readertexts inspected: Birmanbio lists workLeningrad and burialKomarovo but no birthplace; reasonable abstention correctly avoids converting work/burialcity to birth',
705:'Gold McCullough1928/Cloche1907; dates and earlierGirlsNight correct',
706:'Gold Bennet1987/Hathaway1985; dates and laterBlazingOverland correct',
707:'Gold DarejanAlexanderNevskyLavra and StPetersburg qualifier correct',
708:'Actual child1 reader sportshooters/PolarHigh, no namedfilm. Reasonable childabstention; goalUSfilm/SamecountryNo facts match frozen native references independently of grounding. Goalrewrite substitutes movieTheWill with UnitedKingdom, wrong entitytype unlike comparingtwo already-established countryvalues',
709:'Gold AmreshGaneshJayachitra matches facts',
710:'Gold Hogan1890/Laurenti1929; dates and olderQueenMob correct',
711:'Gold MuhammadMecca matches facts',
712:'Gold GeorgeAlbertI16Dec1597 matches facts',
713:'Gold1939/1997 and newerWaco correct',
714:'Gold WilliamBohun16Sept1360 matches facts',
715:'Gold John4th→Patrick3rd supports family QA; goal genericWhoisPatrick drops grandfatherrelation',
716:'Gold1976/1917 and earlierRemorse correct',
717:'Gold Mayring1948/Room1976; dates and laterGhostNeverReturns correct',
718:'Gold1987/1973 and earlierWhatADay correct',
719:'Gold SudhenduRoyFilmfare; threeBestArtDirectionawards Madhumati1959/MereMehboob1964/Sagina1975 correct; no unsupported film-specificaward invented',
720:'Gold WileyMBE; historical2018NewYearHonours and NMEOutstandingContribution details correct at frozen materialtime; later changes not retroactively substituted',
721:'Gold MariaAragon7March1517 supports true year1517 answer with lower dateprecision',
722:'Gold TinieTempahBritish and Englishrapper descriptor correct',
723:'Gold Kachyna2004/Nugent1980; dates and laterForbiddenDreams correct'
}
flows={i:{'i':i,'all_nodes_inspected':True,'reason':s} for i,s in notes.items()}
for i in [687,689,692,697,702,703,705,706,710,717,723]:flows[i]['bindings']={'3':[1],'4':[2]}
for i in [684,685,690,691,701,704,707,709,711,712,714,719,720,721,722]:flows[i]['bindings']={'2':[1]}
flows[686]['bindings']={'3':[1,2]}
for i in [688,694,700,715]:flows[i]['bindings']={'2':[1]}
for i in [694,700,715]:flows[i].update(incorrect_fidelity=[3],incorrect_targets=[3]);flows[i]['bindings']['3']=[2]
flows[708].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'3':[2]},answer_subtypes={'1':'reasonable_abstention','3':'factual_answer_despite_local_child_abstention'})
for i in [701,704]:flows[i]['answer_subtypes']={'2':'reasonable_abstention'}
flows[721]['answer_subtypes']={'2':'factual_partial_date_precision'}
flows[687]['answer_subtypes']={'1':'factual_corrective_response_to_bad_presupposition','2':'factual_corrective_response_to_bad_presupposition'}
assert set(flows)==set(range(684,724))
write(Path(__file__).parent/'batch_s684_723.json',{'batch_id':'s684_723','axis':'stage_node','manually_reviewed_flows':list(flows.values())})
