"""Display recorded review material; never auto-assign semantic labels."""
import argparse
import json
import sys
from pathlib import Path
from prepare_inventory import ROOT, OUT, rows, read

sys.stdout.reconfigure(encoding='utf-8')
run = OUT/'offline_review_v2'
parser = argparse.ArgumentParser()
parser.add_argument('axis', choices=['decomp','stages','context','native','final','facts','compact'])
parser.add_argument('start', type=int)
parser.add_argument('count', type=int, nargs='?', default=10)
parser.add_argument('--step', type=int)
parser.add_argument('--local-facts',action='store_true',help='Display frozen native/gold text with stages, without endpoints')
args=parser.parse_args()
cohort=rows(run/'COHORT.jsonl')
selected=cohort[args.start-1:args.start-1+args.count]
packets={r['id']:r for r in rows(run/('DECOMPOSITION_PACKETS.jsonl' if args.axis=='decomp' else 'STAGE_PACKETS.jsonl'))}
facts={r['id']:r for r in rows(run/'FACT_REFERENCE_PACKETS.jsonl')} if args.axis=='facts' or args.local_facts else {}
native={}
if args.axis in ('native','stages','compact'):
    p=ROOT/'data/multihop_comprehensive_v1_20261015/2wiki/native/dev.json'
    native={r['_id']:r for r in read(p)}
for c in selected:
    p=packets[c['id']]
    v={'i':c['review_index'],'id':c['id'],'q':p['question']}
    if args.axis=='decomp':
        v['children']=p['supporting_questions']
    elif args.axis in ('stages','compact'):
        nr=native.get(c['qid'],{})
        v['gold_triples']=nr.get('evidences')
        v['nodes']=[{'s':n['step_id'],'role':n['role'],'q':n['request'],'a':n['answer'],
                     'rewrite':n['rewritten_query'] if n['rewrite_request_id'] else None,
                     'rejected':n['rewrite_rejection']} for n in p['nodes']]
        if args.axis=='compact':
            v['nodes']=[[n['step_id'],n['role'][0],n['request'] if n['role']=='ordinary' else '=original',
                         n['answer'],n['rewritten_query'] if n['rewrite_request_id'] else None,
                         n['rewrite_rejection']] for n in p['nodes']]
    elif args.axis=='context':
        v['nodes']=[{'s':n['step_id'],'q':n['request'],'a':n['answer'],
                    'docs':[{'title':d['source'],'text':d['text']} for d in n['reader_packet']['docs']]}
                   for n in p['nodes'] if args.step is None or n['step_id']==args.step]
    elif args.axis=='facts':
        v['facts']=facts[c['id']]
    elif args.axis=='native':
        v['native']=native.get(c['qid'])
    else:
        raw=read(ROOT/Path(c['source'].replace('\\','/')))
        v.update(prediction=raw['prediction'],final_context=raw['final_context'])
    if args.local_facts:
        f=facts[c['id']]
        v['local_gold_texts']=[{'title':d['title'],'text':d['text']} for d in f.get('gold_documents',[])]
    print(json.dumps(v,ensure_ascii=False,separators=(',',':')))
