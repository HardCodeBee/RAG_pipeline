"""After label lock: inspect final predictions with stage results, not rescore."""
import json,sys
from prepare_inventory import OUT,read,rows
run=OUT/'offline_review_v2'
query=rows(run/'QUERY_LABELS_AND_OUTCOMES.jsonl')
stage=read(run/'STAGE_LABELS_LOCKED.json')['labels']
labs={(l['review_index'],l['step_id']):l for l in stage}
ys={v['id']:v for v in rows(run/'OUTCOMES_SEPARATE.jsonl')}
packets={p['id']:p for p in rows(run/'STAGE_PACKETS.jsonl') if p.get('complete')}
if sys.argv[1]=='failures':
 selected=[r for r in query if r['dataset']==sys.argv[2] and not r['final_correct']][int(sys.argv[3]):int(sys.argv[3])+int(sys.argv[4])]
else:
 ids={int(i) for i in sys.argv[1:]};selected=[r for r in query if r['review_index'] in ids]
for r in selected:
 p=packets[r['id']];o=ys[r['id']];goal=p['nodes'][-1]
 print(json.dumps({'i':r['review_index'],'id':r['id'],'q':r['question'],'Y':r['final_correct'],'f1':r['f1'],'em':r['em'],'prediction':o['prediction'],'reference':o['reference'],'D':r['decomposition_correct'],'ordinaryA':r['ordinary_answers_all_correct'],'R':r['rewrites_all_correct'],'goalA':r['goal_answer_correct'],'goal':goal['answer'],'ordinary':[[n['request'],n['answer']] for n in p['nodes'] if n['role']=='ordinary']},ensure_ascii=False,separators=(',',':')))
