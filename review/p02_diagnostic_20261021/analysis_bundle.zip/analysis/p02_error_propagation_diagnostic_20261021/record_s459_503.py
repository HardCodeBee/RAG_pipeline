"""Record the current reviewer's explicitly inspected 45 flows, not a classifier."""
from prepare_inventory import write
from pathlib import Path
notes={
459:'Gold Varnel1947/LaCava1952; all four facts and earlierAskAPoliceman correct',
460:'Gold founderAntin and LasPalmasChaco match; Argentina qualifier correct',
461:'Native NeverTheTwain1926 and Lamac Hamburg explicitly verify all added facts',
462:'Gold DAngelo Richmond and Virginia qualifier correct',
463:'Director name correct; native gold joins Angolan footballer of same name. Targeted fallback BrazilianTVMuseum birthSaoPaulo1940 and filmindustry FilmB director filmography verify director Brazilian; goal Brazil factual despite goldAngolan',
464:'Gold LeninSivam JaffnaSriLanka matches both facts',
465:'Gold Kosheverova1989/Gasnier1963 and earlierReefer comparison correct;1936 title qualifier correct',
466:'Gold Mann1991/Herrera1956 and earlierCubanInSpain comparison correct',
467:'Gold JilaBaniyaghoob21Aug1970 matches facts',
468:'Gold JeanII Solothurn and Switzerland qualifier match facts',
469:'Gold2007/1977 and newerKingOfKong comparison correct',
470:'Gold bothBritish; bothUK rewrite equivalent given established firstUK; answers correct',
471:'Gold Cocea2013/Sale1993 and earlierMyWifesBestFriend comparison correct',
472:'Gold1647/1824 and earlierChoe comparison correct',
473:'Gold FrederickAugustus Gochsheim match facts',
474:'Native Varnel explicitly carcrash nearRakeWestSussex matches complete answer',
475:'Gold Buckley overdose; heroin qualifier correct for this death',
476:'Gold Esway1947/Stanton1956 and laterWhyWouldNotMarry comparison correct',
477:'Gold bothAustralia; reformulation bothAustralia equivalent with established firstAustralia',
478:'Gold Canada vs US matches facts and No comparison',
479:'Gold USvsUK matches all QA. Goal rewrite verifies respective separate countries rather than asking if same; RF/RT fail',
480:'Gold ErmlerRezekne matches facts',
481:'Gold AbergKonstfack; graphicdesign department detail consistent with native education',
482:'Gold PhilipCourtenay Constantinople matches facts',
483:'Native MaxVarnel French-bornAustralian director working UK/Australia supports full answer despite singleFrench gold',
484:'Gold ChuckBerry StLouisMissouri matches facts',
485:'Gold Morahan2017/Lloyd1960 and laterElementOfDoubt comparison correct',
486:'Gold Brignone and Carrozzini Italian; all QA and name substitutions preserve comparison',
487:'Gold Greville1966/Laine1989 and laterAfterFallOfMan comparison correct',
488:'Native Nayyar explicitly1958FilmfareBestMusicDirector NayaDaur verifies whole statement',
489:'Gold Alatriste HoustonTexas matches facts',
490:'Gold1977/1950 and laterChung comparison correct',
491:'Gold Bevilacqua Rome matches facts',
492:'Gold Mamin1946/Leisen1898 and earlierMurderAtVanities comparison correct',
493:'Gold Smight/Murphy bothAmerican; all QA and comparison correct',
494:'Native Bulleteers explicitly26Mar1942 vs Champion1934; all QA correct',
495:'Gold Greenaway NewportWales matches facts',
496:'Gold Moll1962/Santos1928; olderHungerForLove comparison correct',
497:'Native ShaadAli explicitly bothWelhamBoys and LawrenceSanawar; complete education answer correct',
498:'Gold Victoria→PrincessVictoria family chain matches QA; goal genericWhoisPrincessVictoria drops grandmother relation',
499:'Gold1997/21Feb2014; earlierJanakiraman comparison correct',
500:'Current child asks FatherAndTheBoys but answers different film FatherAndSons directorMichel; native intended filmJoeDeGrasse bornBathurstNewBrunswick. A1 wrongtarget; goal wrongtarget. Rewrite faithfully substitutes suppliedMichel but effective target wrong due upstream answer; separate RF true RT false',
501:'Gold Skolimowski Lodz implies birthplacePoland; answer true at coarser granularity, not exact city; retain partial precision subtype',
502:'Gold1996/1979; earlierAcrossBlueSea comparison correct',
503:'Gold Suhara Thikkodi; nearCalicut geographic detail correct'
}
flows={i:{'i':i,'all_nodes_inspected':True,'reason':s} for i,s in notes.items()}
for i in [459,465,466,471,476,485,487,492,496]:flows[i]['bindings']={'3':[1],'4':[2]}
for i in [460,461,462,463,464,467,468,473,474,475,480,481,482,483,484,488,489,491,495,497,501,503]:flows[i]['bindings']={'2':[1]}
for i in [486,493]:flows[i]['bindings']={'3':[1],'4':[2],'5':[1,2]}
for i in [470,477]:flows[i]['bindings']={'3':[1,2]}
flows[479].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'3':[1,2]})
flows[498].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'2':[1],'3':[2]})
flows[500].update(incorrect_answers=[1,2],incorrect_targets=[2],bindings={'2':[1]},answer_subtypes={'1':'wrong_film_identity','2':'propagated_wrong_film_identity'})
flows[463]['answer_subtypes']={'2':'factual_gold_homonym_conflict'}
flows[501]['answer_subtypes']={'2':'factual_coarse_place_precision'}
assert set(flows)==set(range(459,504))
write(Path(__file__).parent/'batch_s459_503.json',{'batch_id':'s459_503','axis':'stage_node','manually_reviewed_flows':list(flows.values())})
