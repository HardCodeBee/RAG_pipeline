"""Link the completed approved offline review; main evaluation remains paused."""
from datetime import datetime,timezone
import json
from prepare_inventory import ROOT,OUT,read,write,sha
run=OUT/'offline_review_v2';plan=ROOT/'experiments/query_decomposition/unified_rag_eval_v1_20261021'
review=plan/'reviews/20261021_error_propagation'
assert (run/'VALIDATION.json').exists() and (plan/'STOP_REQUESTED').exists()
assert not read(plan/'PLAN.json')['execution_approval']['approved']
report=(run/'REPORT.md').relative_to(ROOT).as_posix()
proposal=read(review/'PROPOSAL.json')
proposal.update(status='completed_offline_review_with_pending_fact_workitems',report=report,report_sha256=sha(run/'REPORT.md'),completed_review_queries={'2wiki':485,'hotpotqa':238},pending_goal_factual_workitems=7,main_evaluation_resumed=False)
addendum={'id':'P02_DIAG_REWRITE_FINAL_OUTCOME_AND_ERROR_LOCATION','authority':'User: 对于子问题改写，我们只关注最终答案，记录改写错在哪','rule':'Emphasize effective rewrite versus existing final output, with concrete error locations; retain approved four-relation tables as descriptive diagnostics. Actual implementation sends original current subquestion to child reader; rewrites only supplement retrieval.'}
if not any(v['id']==addendum['id'] for v in proposal['approved_protocol']['user_addenda']):proposal['approved_protocol']['user_addenda'].append(addendum)
md=review/'PROPOSAL.md';marker='## 本轮已完成的离线诊断'
if marker not in md.read_text(encoding='utf-8-sig'):
 with md.open('a',encoding='utf-8') as f:f.write('\n'+marker+'\n\n用户进一步要求改写重点对照最终答案，并记录具体错误位置。已完成2Wiki485、HotpotQA238条完整非空轨迹标注与复核；7条goal事实暂留待核，不强制赋真假标签。完整报告：`'+report+'`。实际实现中改写仅用于补充检索，回答器当前问题保持原子问题。主评仍暂停，本记录不批准任何新重跑或GitHub推送。\n')
proposal['proposal_sha256']=sha(md);write(review/'PROPOSAL.json',proposal)
p=read(run/'REVIEW_PROGRESS.json');p.update(all_stages_reviewed=True,all_stages_completed=False,pending_factual_truth_labels=7,review_pass_status='completed_with_pending_fact_workitems',report=report,conditional_probabilities_computed=True)
write(run/'REVIEW_PROGRESS.json',p)
decision={'id':'P02_ERROR_PROPAGATION_OFFLINE_DIAGNOSTIC_REPORT_COMPLETED','utc':datetime.now(timezone.utc).isoformat(),'status':'approved_offline_analysis_delivered_with_pending_facts','report':report,'report_sha256':sha(run/'REPORT.md'),'query_cohort':{'2wiki':485,'hotpotqa':238},'stage_nodes_reviewed':2084,'rewrite_error_records':88,'selected_evidence_cases':36,'goal_fact_workitems_pending':7,'new_RAG_or_external_judge':False,'main_evaluation_resumed':False,'main_plan_revision':6,'validation':(run/'VALIDATION.json').relative_to(ROOT).as_posix()}
log=plan/'DECISIONS.jsonl'
if decision['id'] not in log.read_text(encoding='utf-8-sig'):
 with log.open('a',encoding='utf-8') as f:f.write(json.dumps(decision,ensure_ascii=False)+'\n')
print({'report':report,'main_paused':True,'pending_goal_facts':7})
