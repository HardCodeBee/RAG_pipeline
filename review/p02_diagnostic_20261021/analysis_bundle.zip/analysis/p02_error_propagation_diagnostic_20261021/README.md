# P02现有轨迹离线诊断

已批准按修订2离线排查。主评保持暂停；不重跑RAG或调用外部评审模型。

已完成2Wiki485条、HotpotQA238条完整非空轨迹的首轮标注和第二遍复核，
条件概率和逐条改写错误见工作目录内REPORT.md、REWRITE_ERROR_CATALOG.md。
7条goal附加事实仍为获准暂留的待核工作项，只从goal对应分母排除。

- 规则：experiments/query_decomposition/unified_rag_eval_v1_20261021/reviews/20261021_error_propagation/PROPOSAL.md
- 工作目录：outputs/query_decomposition/p02_error_propagation_diagnostic_20261021/offline_review_v2
- start_offline_review.py登记批准并冻结分离评分的标注材料。
- show_packets.py只展示材料，save_review.py保存当前审阅者明确作出的逐项判定，不自动产生语义标签。
- prepare_inventory.py是原始盘点；record_proposal.py已禁止覆盖获得批准后的方案。
- aggregate_diagnostic.py仅合并既有端点和锁定标签并重聚合，不生成语义标签或新RAG结果。
- audit_final_visibility.py核对保存的真实回答输入，verify_diagnostic.py核对来源哈希与统计分母。
- write_report.py、build_rewrite_catalog.py生成报告和错误目录；不自动修改主方案或恢复评估。
