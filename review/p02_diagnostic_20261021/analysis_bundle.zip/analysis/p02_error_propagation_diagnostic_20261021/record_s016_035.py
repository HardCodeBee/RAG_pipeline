"""Manual Hotpot review, using displayed frozen gold text and actual reader checks."""
from prepare_inventory import write
from pathlib import Path
notes={
16:'Frozen Folie/FallOutBoy texts explicitly WilmetteIllinois; answers and band substitution correct',
17:'Frozen biographies deathArnold2010/Cantor1918 support dates and laterArnold comparison',
18:'Frozen CreationGlendale and Glendale2014population200167 match answers and city substitution',
19:'Frozen CliburnEdenValley and railway viaApplebyWestmorland match both answers',
20:'Frozen birthBejar1972/Koshinaka1980 supports dates and youngerKoshinaka comparison',
21:'Both frozen birth/death pairs match all ordinary answers. Goal explicitly67years vs78 yet claimsLucy livedlonger, false lifespan comparison despite true endpointdates',
22:'Frozen MeadowbrookNorthMerrick and2010population12272 match answers',
23:'Frozen BigStoneGapTrigiani and GreenwichVillageNYC match full answers',
24:'Frozen GVPrakash soundtrack and debutVeyyil2006 match answers',
25:'Frozen Grizzly2005/PrayDevil2008 support dates and earlierGrizzly comparison',
26:'Ronan is a real reservationcity alternative to nativegoldPolson. Actual goalreader10 texts are reservationstub and unrelatedRonan-name politicians, no relevantrepresentative; later honest insufficiency locallycorrect. Branching to Ronan valid currentquestion alternative, no falsecity assertion',
27:'Frozen Speedpass explicitly originally developedbyVerifone, merely introducedbyMobil. Ordinary conflatesdeveloper/introducer, goal answersMobilheadquarters instead of actualcreatorVerifoneSanJose; wrongtarget propagates. Rewrite faithfultoMobilhistory but targetinvalid',
28:'Frozen ForrestMims author/cofounderMITS AlbuquerqueNewMexico match both answers',
29:'Frozen Bainbridge servedfromAdams and JohnAdams wifeAbigail support facts. Ordinary2 rewrite drops namedBainbridge for nonuniquecommodore-career profile; loses specificidentity. Goal wifeJohnAdams retains relation',
30:'Native KimTaeyeon separate SMagencyprojectSMTheBallad is not a GirlsGeneration subunit. A2 and goal wrongly assert that relation while primary groupmembership facts true. Rewrite repeats false subgroup appositive from supplied answer, RFfaithful but factuallywrongconstraint RTfalse',
31:'Frozen hostslist matches A1. Actual A2reader MauryWills explicitly shortstop/switchhitter, notpitcher; A2 andgoal falselyincludehim despite correctBobGibson. Goal name-of-Bob-or-Maury rewrite loses identifying pitchercondition',
32:'Frozen Hazlewoodwriter/died2007 verify A1/goal. Actual A2reader only10 monthdeathlist headings with no namedindividual, so currentbroadquestion abstention reasonable',
33:'Actual A1reader band/album/townstuff noDennisAnderson or relevantmanfromtown; abstention reasonable. Frozen DenniscreatorGraveDiggerKillDevilHills supports A2/goal; goal substitutesactualDennis from A2 correctly',
34:'Frozen MobyDick castJoanPlowright and her2GoldenGlobes match answers. Goalrewrite omitswin verb but sameactress awardcount target intelligible, no semanticattributechange',
35:'Frozen SurreyHollandParkCentralCity and BlackwoodPartners owner match answers; originalmaterialtime retained'
}
flows={i:{'i':i,'all_nodes_inspected':True,'reason':s} for i,s in notes.items()}
for i in [16,18,19,22,23,24,27,28,34,35]:flows[i]['bindings']={'2':[1]}
flows[21].update(incorrect_answers=[5],bindings={'5':[1,2,3,4]},answer_subtypes={'5':'reversed_lifespan_comparison'})
flows[26].update(bindings={'2':[1],'3':[1]},answer_subtypes={'1':'factual_alternative_city','2':'reasonable_abstention','3':'reasonable_abstention'})
flows[27].update(incorrect_answers=[1,2],incorrect_targets=[2],answer_subtypes={'1':'developer_vs_introducer_confusion','2':'propagated_wrong_company_identity'})
flows[29].update(incorrect_fidelity=[2],incorrect_targets=[2],bindings={'2':[1],'3':[2]})
flows[30].update(incorrect_answers=[2,3],incorrect_targets=[3],bindings={'3':[1,2]},answer_subtypes={'2':'mixed_true_membership_false_subunit_relation','3':'propagated_false_subunit_relation'})
flows[31].update(incorrect_answers=[2,3],incorrect_fidelity=[3],incorrect_targets=[3],bindings={'2':[1],'3':[2]},answer_subtypes={'2':'mixed_correct_pitcher_false_shortstop_as_pitcher','3':'propagated_false_role_filter'})
flows[32]['answer_subtypes']={'2':'reasonable_abstention'}
flows[33].update(bindings={'3':[2]},answer_subtypes={'1':'reasonable_abstention'})
assert set(flows)==set(range(16,36))
write(Path(__file__).parent/'batch_s016_035.json',{'batch_id':'s016_035','axis':'stage_node','manually_reviewed_flows':list(flows.values())})
