"""Manual Q2-only annotations of saved incomplete flows; never infer final outcomes."""
from prepare_inventory import OUT,read,rows,write,sha
run=OUT/'offline_review_v2'
packets=[p for p in rows(run/'STAGE_PACKETS.jsonl') if not p.get('complete')]
notes={
4:'Burwash16ton1935 true, Temagami contrast true; second ordinary and goal rewrites preserve mine candidates and property',
7:'Donna1963 and suppliedHailey seven books/dates true partial list; later rewrite comparison over supplied candidates preserves facts and temporal relation, incomplete coverage not false identity. No all-time bestseller-none judgement needed for Q2 prior histories',
10:'Frozen Teotihuacan influence and ValleyMexico identification true, goal rewrite keeps unknownmoderncity and40kmNE relation',
11:'All actual first reader docs checked: piston basics/unrelated automotive renewables, no OrendaOE600 reintroduction. Source-qualified abstention true; second rewrite unchanged valid',
18:'JosefMengele fictionaldefendant true. R2 substitutes identity into still-Whoiswarcriminal, changing unknown identification to redundant known-name identity question; RFRTfalse',
21:'Denis vocalentlyricist and noidentifiedguitar in actuallocalprofile true; MaxCarl unchanged question valid',
23:'ATeam2010 valid alternative film under broad firstchild; subsequent TVseries question legitimately binds thatfilm, not originalLifeWithDerek goal. Rewrite correct for current child even if original-query route misses target',
24:'EricSykesEnglandUK countrydescriptor matches native birthplace and comparison scope; Eccles unchanged query valid',
28:'Burton actor/director with no recordededitor qualifies evidence only, true; Maheen unchanged query valid',
29:'GeneralSurveyActApril1824 true. Rewrite substitutes nonunique actpassedApril1824 for namedact, losing specific law identity; RFRTfalse',
34:'HershelWalkingDead true, second unchanged Carl question valid'
}
out=[]
for pi,p in enumerate(packets,1):
 for n in p['nodes']:
  if not n['rewrite_request_id']:continue
  prior=[a for a in n['prior_complete_answers'] if a['step_id']<n['step_id']]
  assert pi in notes and prior
  out.append({'id':p['id'],'dataset':p['dataset'],'prefix_index':pi,'step_id':n['step_id'],'role':n['role'],'prior_ordinary_answers_all_correct':True,'prior_ordinary_steps':[a['step_id'] for a in prior], 'rewrite_fidelity_correct':pi not in [18,29], 'rewrite_target_correct':pi not in [18,29], 'effective_rewrite':n['rewritten_query'],'current_request':n['request'],'rewrite_rejection':n['rewrite_rejection'],'reason':notes[pi],'source_sha256':p['source_sha256'],'reviewer':'same single Codex reviewer','final_outcome':None,'scope':'Q2 prefix supplement only; no prefix answer-to-final table'})
assert len(out)==13,len(out)
write(run/'PREFIX_REWRITE_LABELS.json',{'incomplete_flows':len(packets),'flows_with_observed_rewrites':len({l['id'] for l in out}),'observed_rewrite_events':len(out),'labels':out,'final_inference_or_imputation':False})
print({'prefixes':len(packets),'events':len(out),'correct_rewrites':sum(l['rewrite_target_correct'] and l['rewrite_fidelity_correct'] for l in out)})
