"""Deterministic review inventory; selection only, never semantic scoring."""
from pathlib import Path
import random
from prepare_inventory import OUT,read,write,rows
run=OUT/'offline_review_v2'
labels=[l for f in sorted((run/'reviews').glob('*.json')) for l in read(f)['labels'] if l['axis']=='stage_node']
bad=[l for l in labels if any(l[k] is False for k in ('answer_correct','rewrite_fidelity_correct','rewrite_target_correct'))]
other=[l for l in labels if l not in bad]
rng=random.Random(20261021)
sample=rng.sample(other,round(len(other)*.1))
selected=sorted(bad+sample,key=lambda l:(l['review_index'],l['step_id']))
write(run/'STAGE_RECHECK_SELECTION.json',{'seed':20261021,'outcomes_hidden':True,'incorrect_nodes':len(bad),'other_sample_nodes':len(sample),'selected':[{'review_index':l['review_index'],'step_id':l['step_id'],'selection':'incorrect' if l in bad else 'sample'} for l in selected]})
print({'complete_stage_nodes':len(labels),'incorrect_nodes':len(bad),'sample':len(sample),'selected':len(selected)})
