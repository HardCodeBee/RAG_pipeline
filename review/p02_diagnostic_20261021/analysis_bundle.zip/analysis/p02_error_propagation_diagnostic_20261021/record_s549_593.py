"""Record explicit manual review decisions for the displayed 45 flows."""
from prepare_inventory import write
from pathlib import Path
notes={
549:'Gold Iran/Botswana and No sharedcountry match all QA',
550:'Gold HerreraSpanish matches both QA',
551:'Gold PhilipI→Margaret match family QA; goal mother-of-known-father retains original grandmother relation, unlike genericWhois',
552:'Gold bothBritish supports QA and Yes sharedUK',
553:'Gold Sewell/RumleyBritish supports all QA and direct name substitution',
554:'Gold Neesima→YamamotoYaeko supports facts',
555:'Gold BasiliscusRomanEmpire; EasternRomanByzantine centeredConstantinople qualifier correct; D redundancy separate',
556:'Gold SovietvsUS supports all QA and No comparison',
557:'Gold Sale1911/Keosayan1966 supports all facts and laterPresident comparison',
558:'Gold ArduinFruttuaria supports spouse and abbey burial facts',
559:'Gold Rolfe1943/Arzner1979 supports dates and earlierSinOfWoman comparison',
560:'All actual unique readertexts inspected for each step: Sophie passage names brotherFrederickIII/husbandLouis/sonFrederick but no father or grandmother; abstentions locally reasonable. Goal rewrite asks maternalgrandmother of Sophies father, adding generation and changing relation from Sophies paternalgrandmother; RF/RT false despite no usable prior answer',
561:'Gold bothBritish supports QA and Yes comparison',
562:'Native Seafield explicitly diedfromwoundsreceivedFlandersBelgium; goal reproduces true statement, no claim woundedplace necessarily exact deathsite',
563:'Gold Decoin/ClementFrench supports all QA and Yes comparison',
564:'Gold Medford12Dec2012 matches facts',
565:'Gold1952/2011 supports dates and earlierMyWifesBestFriend',
566:'All ordinary facts correct Jennings1965/Sauper1966; goal reverses age ordering, claims1965 younger than1966. Direct comparison unchanged, so reader arithmetic/comparison failure',
567:'Gold Samanta2009/Ray1944 supports all facts and earlierThiefInDark',
568:'Gold Rodriguez7Aug2004 matches facts',
569:'Gold LouisII→JeanneHochberg; JohannaHachbergSausenberg alias same person. QA correct; genericWhoisJeanne goal drops grandmother relation',
570:'Gold DonaldsonAustralian+NZ/KhoaAustralian; partial NZ ordinary true, goal No misses sharedAustralian nationality. Rewrite retains original samecountry question, adds true nonexclusive supplied origin descriptors; no false exclusive origin added',
571:'Gold Eastwood1930/Winick1961 supports all facts and olderJEdgar',
572:'Gold BayleyNewark conflicts with unsupported goalBaltimore; native only workbishopcities notdeathsite. Targeted fallback primary SHU StPatricks residence history explicitly diedNewark oldroom3Oct1877 confirms goalwrongplace',
573:'Gold NuhI→NasrII matches family QA; goal father-of-Nuh relation retains original paternalgrandfather meaning',
574:'Gold Goodwins1899/Desai1937 supports all facts and earlierMexicanSpitfireBaby',
575:'Gold Oslo; native fromHaugesundandOslo describes origins not two births. Complete goal falsely asserts borninbothdistinctcities; correct Oslo value does not rescue extra false birthplace',
576:'Gold MendesGerman/AdolfiAmerican supports origin facts and No comparison',
577:'Native Frith explicitly MillsCollegeOakland professor until2018 retirement; whole answer verified without current-status web',
578:'Gold painterJanKotikBerlin supports complete facts',
579:'Gold LordeTakapuna and AucklandNewZealand qualifiers correct',
580:'Gold IanDury27Mar2000 matches facts',
581:'Native Victoria husbandLionel3rdBaron/daughterVita and Vita husbandNicolson support all facts. Goal spouse-of-Vita rewrite preserves original child-in-law relation; extra D spouse retrieval not QA error',
582:'Gold CasimirII Krakow matches facts',
583:'Gold AnnaMaria→George supports all family QA and goal father-of-known-mother relation',
584:'Gold Cavalier/LeconteFrench supports all QA and comparison',
585:'Gold bothBrazil supports QA; bothBrazil rewrite equivalent after established firstBrazil',
586:'Gold LouisIAnjouFrench matches both facts',
587:'Gold Newfield1899/Chabrol1930 supports all facts and olderTerrorTinyTown',
588:'Gold Cuerda1947/Poitier1927 supports all facts and laterAsiEnElCielo',
589:'Gold MozaAlKhor and Qatar qualifier correct',
590:'Gold Ayouch1969/Brecher1914 supports all facts and olderSailCrookedShip',
591:'Gold Capra18May1897 matches both facts',
592:'Gold DamianHarris ElizabethReesWilliams matches facts',
593:'Native biography gives nominations only, goal adds false noGrammyAwards. Authorized fallback primary Grammy artist record confirms2001SymphonyNo1 winner, before dataset era; goal whole statement false, not reasonable abstention'
}
flows={i:{'i':i,'all_nodes_inspected':True,'reason':s} for i,s in notes.items()}
for i in [557,559,566,567,571,574,587,588,590]:flows[i]['bindings']={'3':[1],'4':[2]}
for i in [550,554,555,558,562,564,568,572,575,577,578,579,580,581,582,586,589,591,592,593]:flows[i]['bindings']={'2':[1]}
for i in [553,563,570,576,584]:flows[i]['bindings']={'3':[1],'4':[2],'5':[1,2]}
flows[570]['bindings']['5']=[1,2,3,4]
for i in [551,569,573,583]:flows[i]['bindings']={'2':[1],'3':[1]}
flows[569].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'2':[1],'3':[2]})
flows[560].update(incorrect_fidelity=[3],incorrect_targets=[3],answer_subtypes={str(s):'reasonable_abstention' for s in [1,2,3]})
for i in [566,570,572,575,593]:flows[i]['incorrect_answers']=[5 if i in [566,570] else 2]
flows[566]['answer_subtypes']={'5':'reversed_age_comparison'}
flows[570]['answer_subtypes']={'3':'factual_partial_nationality_list','5':'set_overlap_comparison_error'}
flows[572]['answer_subtypes']={'2':'wrong_death_city_from_work_city'}
flows[575]['answer_subtypes']={'2':'correct_city_plus_false_second_birthplace'}
flows[593]['answer_subtypes']={'2':'false_denial_of_received_award'}
flows[585]['bindings']={'3':[1,2]}
assert set(flows)==set(range(549,594))
write(Path(__file__).parent/'batch_s549_593.json',{'batch_id':'s549_593','axis':'stage_node','manually_reviewed_flows':list(flows.values())})
