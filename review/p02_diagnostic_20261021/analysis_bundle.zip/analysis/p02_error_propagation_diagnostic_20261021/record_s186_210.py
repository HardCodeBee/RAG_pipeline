"""Manual review, before inspecting per-query final predictions or scores."""
from pathlib import Path
from prepare_inventory import write
notes={
186:'Frozen Frana and Koch tennis players supports all, including Frana ESPN historical occupation',
187:'Frozen Wickberg SalvationArmy Protestant supports both answers. Goal rewrite replaces unknown religious sect by already known army and changes sect identification to army linked to itself, RF/RTfalse',
188:'Frozen niece BernicePauahi and CharlesReedBishop supports both',
189:'All actual A1 and goal reader passages checked: drinks and Shikashika but no FindingKraftland film identity, source-qualified abstentions reasonable',
190:'Frozen albumHelterSkelter Beatles/Manson and loud/dirty sound supports all answers. Goal rewrite fills still-unknown sound with loudchaotic rather than binding song/album supplied by prior QA, changing question to confirmation',
191:'Frozen Disporum20Asia Boltonia1Asia supports comparison',
192:'Frozen Prince2004 vs Jenkins film-director biography supports induction distinction',
193:'Actual query has unqualified TheClimb; 2002 film is true alternative to native2007 documentary, both release assertions and their2002 comparison true. Version-choice gold mismatch distinct from child factual error',
194:'Frozen Meitner/Frisch fission explanation plus FrischPeierls mechanism1940; first and partial discovery answers true. Goal false none has both, because Frisch participates in both',
195:'Frozen StephenGraham ThisIsEngland ShaneMeadows supports both',
196:'Frozen first2D2003 Tartakovsky and Dexter/Samurai supports all, effective bindings preserve franchise version',
197:'All actual reader passages checked: unrelated commentators and PressTV overview, neither DouglasMurray nor HenryJacksonSociety. Both abstentions reasonable',
198:'Frozen MarcBolan leadsTRex supports answers. Goal rewrite replaces unknown pronoun with MarcBolan but still asks his name, losing referential question and possibly asking birthname, RF/RTfalse',
199:'Frozen episode nursery rhyme and Roud821 supports both',
200:'Frozen nature-spirit definition answers generic class question; EchoNarcissus true. Actual A2 reader explicitly Hamadryas mother of hamadryads, so absolute mothersnot specified false, despite no Iynx. Goal wrongly infers Echo mother of Echo rather than Iynx childofEcho. Goal adding mountain preserves possible Oreiad Iynx target, no false identity binding',
201:'Actual native ModiMP and SureshPatelMLA statements true separately, but current child asks one person satisfying both, answer gives split persons without joint identification, nonresponsive. Goal India true. Rewrite substitutes onlyPatel for joint-role description, dropping parliament condition',
202:'Frozen HarlandWolff builtIonic Belfast supports both',
203:'Frozen RashidKhan postcolonialist and postmodern thought supports both',
204:'Frozen Cattrall co-star and2002 GoldenGlobeBestSupportingActress supports both',
205:'Frozen uncleZacarias KarlAnthonyTowns Kentucky supports both',
206:'Frozen both botanical genera and respective families supports all',
207:'Frozen OeraLinda formOldFrisian and8thto16thcenturies supports both',
208:'Frozen LionheartVanDamme martialartsactionfilms supports both',
209:'Frozen Novoselov Nobel2010 and GRC NUS Singapore scientific-advice qualifier supports all',
210:'Frozen album LesMcCann23September1935 supports both'
}
flows={i:{'i':i,'all_nodes_inspected':True,'reason':v} for i,v in notes.items()}
for i in [187,188,195,199,202,203,204,205,207,208,210]:flows[i]['bindings']={'2':[1]}
flows[187].update(incorrect_fidelity=[2],incorrect_targets=[2])
flows[189]['answer_subtypes']={'1':'reasonable_abstention','3':'reasonable_abstention'}
flows[190].update(incorrect_fidelity=[3],incorrect_targets=[3])
flows[193].update(bindings={'3':[1]},answer_subtypes={'1':'factual_ambiguous_title_alternative','3':'factual_comparison_alternative_title_version'})
flows[194].update(incorrect_answers=[3],answer_subtypes={'2':'factual_partial_list','3':'false_joint_role_absence'})
flows[196]['bindings']={'2':[1],'3':[2]}
flows[197]['answer_subtypes']={'1':'reasonable_abstention','2':'reasonable_abstention'}
flows[198].update(incorrect_fidelity=[2],incorrect_targets=[2],bindings={'2':[1]})
flows[200].update(incorrect_answers=[2,4],bindings={'2':[1],'4':[3]},answer_subtypes={'2':'false_abstention_available_partial_answer','4':'wrong_parent_child_relationship'})
flows[201].update(incorrect_answers=[1],incorrect_fidelity=[2],incorrect_targets=[2],bindings={'2':[1]},answer_subtypes={'1':'nonresponsive_joint_roles_split_persons','2':'factual_country_recovery'})
flows[209]['bindings']={'2':[1],'3':[1]}
assert set(flows)==set(range(186,211))
write(Path(__file__).parent/'batch_s186_210.json',{'batch_id':'s186_210','axis':'stage_node','manually_reviewed_flows':list(flows.values())})
