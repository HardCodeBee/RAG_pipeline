"""Extract existing local gold-source paragraphs for offline factual checking only."""
import json
import re
from prepare_inventory import ROOT, OUT, rows, read, write, sha, rel

run=OUT/'offline_review_v2'
packets=rows(run/'STAGE_PACKETS.jsonl')
wanted={str(d) for p in packets if p['dataset']=='hotpotqa' for d in p['reference']['positive_doc_ids']}
path=ROOT/'data/beir/hotpotqa/corpus/corpus.jsonl'
found={}
with path.open('rb') as f:
    for line in f:
        # Inspect only the initial ID token; do not parse all 5.2 million documents.
        m=re.search(rb'"_id"\s*:\s*"([^"]+)"',line[:180])
        if m and m.group(1).decode() in wanted:
            r=json.loads(line);found[str(r['_id'])]=r
assert wanted<=found.keys(), sorted(wanted-found.keys())
native_path=ROOT/'data/multihop_comprehensive_v1_20261015/2wiki/native/dev.json'
native={r['_id']:r for r in read(native_path)}
result=[]
for p in packets:
    if p['dataset']=='hotpotqa':
        docs=[found[str(i)] for i in p['reference']['positive_doc_ids']]
        v={'id':p['id'],'gold_documents':docs,'gold_doc_ids':p['reference']['positive_doc_ids'],
           'corpus_source':rel(path)}
    else:
        n=native[p['qid']]
        v={'id':p['id'],'gold_triples':n['evidences'], 'supporting_facts':n['supporting_facts'],
           'context':n['context'],'native_source':rel(native_path)}
    result.append(v)
(run/'FACT_REFERENCE_PACKETS.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in result),encoding='utf-8')
write(run/'FACT_REFERENCE_SOURCES.json',{'purpose':'offline review only; never supplied to RAG',
      'sources':[{'path':rel(p),'sha256':sha(p)} for p in (path,native_path)],
      'hotpot_required_doc_count':len(wanted),'hotpot_extracted_doc_count':len(found)})
print(json.dumps({'gold_packets':len(result),'hotpot_documents':len(found)}))
