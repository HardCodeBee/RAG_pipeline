"""Blinded display of incomplete saved prefixes; not final-answer cohorts."""
import json,sys
from prepare_inventory import OUT,read,rows
run=OUT/'offline_review_v2'
packets=[p for p in rows(run/'STAGE_PACKETS.jsonl') if not p.get('complete')]
facts={p['id']:p for p in rows(run/'FACT_REFERENCE_PACKETS.jsonl')}
for j,p in enumerate(packets,1):
 if len(sys.argv)>1 and not int(sys.argv[1])<=j<=int(sys.argv[2]):continue
 if not p['nodes']:continue
 f=facts[p['id']]
 print(json.dumps({'prefix_index':j,'id':p['id'],'q':p['question'],'nodes':[[n['step_id'],n['role'],n['request'],n['answer'],n['rewritten_query'] if n['rewrite_request_id'] else None] for n in p['nodes']], 'native':f.get('gold_triples',f.get('gold_documents'))},ensure_ascii=False,separators=(',',':')))
