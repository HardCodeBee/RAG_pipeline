"""Second-pass corrections, transparent and applied before outcome association."""
from prepare_inventory import OUT,read,write,sha,ROOT
from datetime import datetime,timezone
import json
run=OUT/'offline_review_v2'
a=read(run/'STAGE_AMENDMENTS.json')
extra=[
{'review_index':189,'step_id':3,'answer_correct':False,'answer_subtype':'false_abstention_explicit_film_evidence_available','reason':'Goal reader rank3 explicitly identifies FindingKraftland as documentary. Ordinary1 lacks this passage and its abstention remains true; goal independently has enough evidence for No. Correct the first-pass goal label after checking actual distinct packets.'},
{'review_index':107,'step_id':3,'answer_correct':False,'answer_subtype':'nonresponsive_true_fact_about_wrong_county','reason':'Actual child_prompt receives original current question, NOT rewritten retrieval query (pipeline.py raw_child rendering). Newark is the true county seat of Licking, but current question asks county of intended LittleGiants team, so this is a truthful wrong-target nonresponse; RT remains false separately.'},
{'review_index':386,'step_id':2,'answer_correct':None,'answer_subtype':'pending_diagnosis_timeline_rounding','reason':'Second pass: native2012 public revelation and deathJan2016 do not decisively exclude colloquial three-years-earlier diagnosis wording; public revelation is not exact diagnosis date. Correct cause/date remain true. Keep entire extra-timeline claim as pending factual workitem rather than force false.'}
]
known={(v['review_index'],v['step_id']) for v in a['amendments']}
for v in extra:
 if (v['review_index'],v['step_id']) not in known:a['amendments'].append(v)
a['outcomes_unseen_at_second_pass']=True
write(run/'STAGE_AMENDMENTS.json',a)
p=read(run/'PENDING_FACTS.json')
if not any(v['review_index']==386 for v in p['items']):p['items'].append({'review_index':386,'step_id':2,'role':'goal','claim':'Rivette diagnosis exactlythree years beforedeath','status':'pending_diagnosis_vs_public_revelation_and_rounding','reason':extra[-1]['reason'],'sources':['https://en.wikipedia.org/wiki/Jacques_Rivette','https://www.letemps.ch/culture/ecrans/jacques-rivette-jamais-libre']})
write(run/'PENDING_FACTS.json',p)
selection=read(run/'STAGE_RECHECK_SELECTION.json')
write(run/'STAGE_RECHECK_COMPLETED.json',{'utc':datetime.now(timezone.utc).isoformat(),'selection_sha256':sha(run/'STAGE_RECHECK_SELECTION.json'),'selected_nodes_reinspected':len(selection['selected']),'incorrect_nodes':selection['incorrect_nodes'],'sampled_other_nodes':selection['other_sample_nodes'],'additional_nodes':[{'review_index':v['review_index'],'step_id':v['step_id']} for v in extra], 'reviewer':'same single Codex reviewer; not independent human adjudication','final_outcomes_hidden':True,'amendments':a['amendments']})
plan=ROOT/'experiments/query_decomposition/unified_rag_eval_v1_20261021'
decision={'id':'P02_DIAG_REWRITE_FINAL_OUTCOME_AND_ERROR_LOCATION','utc':datetime.now(timezone.utc).isoformat(),'authority':'User: 对于子问题改写，我们只关注最终答案，记录改写错在哪','rule':'Emphasize effective rewrite correctness versus existing final answer correctness; record concrete entity/relation/constraint/target errors. Original four approved relations retained. Actual implementation rewrites retrieval only; child receives original current question, and is judged separately against that question. No inference or main resumption.'}
log=plan/'DECISIONS.jsonl'
if decision['id'] not in log.read_text(encoding='utf-8-sig'):
 with log.open('a',encoding='utf-8') as f:f.write(json.dumps(decision,ensure_ascii=False)+'\n')
print({'rechecked_nodes':len(selection['selected']),'amendments':len(a['amendments']),'pending':len(p['items'])})
