"""Audit exact saved final input and expose selected recorded retrieval packets."""
from pathlib import Path
from prepare_inventory import ROOT,OUT,read,rows,write,sha
import json,sys
run=OUT/'offline_review_v2'
cohort=rows(run/'COHORT.jsonl')
selected={int(i) for i in sys.argv[1:]}
audits=[]
for c in cohort:
 raw=read(ROOT/Path(c['source'].replace('\\','/')))
 nodes=raw['nodes'];ordinary=nodes[:-1];goals=nodes[-1:]
 sections=['Auxiliary question-answer pairs']
 if ordinary:sections+=['Intermediate candidate results','\n\n'.join(f"#{n['step_id']} Question: {n['request']}\nAnswer: {n['answer']}" for n in ordinary)]
 sections+=['Candidate conclusion for the Original question','\n\n'.join(f"#{n['step_id']} Question: {n['request']}\nAnswer: {n['answer']}" for n in goals)]
 helper='\n\n'.join(sections)
 passages='\n\n'.join(d['block'] for d in raw['original_retrieval']['docs'])
 assert raw['final_context']==helper+'\n\n'+passages,c['id']
 assert raw['final_context'] in raw['final_prompt'],c['id']
 for n in nodes:
  marker=f"Current subquestion #{n['step_id']}:\n{n['request']}\n\nRetrieved passages:"
  assert marker in n['child_prompt'],(c['id'],n['step_id'])
 audits.append({'id':c['id'],'review_index':c['review_index'],'final_context_sha256':__import__('hashlib').sha256(raw['final_context'].encode()).hexdigest(),'all_saved_ordinary_and_goal_answers_visible':True,'final_root_docs':len(raw['original_retrieval']['docs']),'rewritten_passages_directly_added_to_final':False})
 if c['review_index'] in selected:
  print(json.dumps({'i':c['review_index'],'question':raw['question'],'prediction':raw['prediction'],'helper':helper,'root_docs':[{'title':d['source'],'text':d['text']} for d in raw['original_retrieval']['docs']], 'retrieval_routes':[{ 's':n['step_id'],'rewritten':n['rewritten_query'],'original_titles':[d['source'] for d in n['original_retrieval']['docs']],'rewritten_titles':[d['source'] for d in (n.get('rewritten_retrieval') or {}).get('docs',[])],'reader_titles':[d['source'] for d in n['reader_packet']['docs']]} for n in nodes] if c['review_index']==7 else None},ensure_ascii=False,separators=(',',':')))
write(run/'FINAL_VISIBILITY_VERIFIED.json',{'all_complete_contexts_exactly_verified':len(audits),'all_final_contexts_in_saved_final_prompt':True,'all_child_prompts_use_original_current_subquestion':True,'recorded_inputs_only':True,'final_context_contract':'ordinary QA + goal QA + original question retrieval Top10; rewritten evidence available only through generated QA','records':audits})
