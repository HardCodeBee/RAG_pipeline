"""Manual decisions for25 inspected flows; one subtype-capacity fact remains unlabeled."""
from prepare_inventory import write
from pathlib import Path
notes={
136:'Actual A1SouthCentral1992Anderson is truealternative under underconstrainedcurrentchild, not HarshTimesbutcurrentquestiondropsAyerfilmconstraints. A2fullwriter+directorStreetKings false: localprofile collectivecredits ambiguous, actualfilmparagraphonlydirector; primaryAFI64772 confirms writerEllroyWimmerMoss, Ayer director. OtherthreeAyercreditscorrect. Goalwronglyconcludesnootherfilm instead of recoveringHarshTimesAyerTrainingDay/SuicideSquad; originalgoalqueryretained',
137:'Frozen SeppaGeorgJensensilverfactory and Jensenfounder support all facts',
138:'Frozen FDAagency and asserted700million=threequarters imply933.3million within providedreference. Mathematicalderivationcorrect; report as frozen-material claim, not independentlyverifiedwholeFDAcurrentbudget',
139:'Frozen extinctPoiDog vs extantDandieDinmont supports all QA',
140:'Actual1805Lakefailed4stormattempts and1825-26Combermeresuccess texts bothpresent. CurrentA2CommanderIndiaduringunqualifiedSiege hasvalid1805Lakealternative; A1same1805Irelandoffice notidentified, honestabstention. Goal doesnotidentify onepersonwithbothrequiredroles and choosesfailed1805branch, instead ofsourceCotton whoheldbothandstormed1826. Rewrite changes dualcareerattributesofoneperson into IrelandcommanderANDknownLake, RF/RTfalse',
141:'Frozen WishingStairs/Voice2005Koreanhorror supports goal. ActualA2reader TheVoice2010 explicitlyTurkishhorror, validunqualified-titlealternative; horrorattributeconsistent acrossboth, avoid markingtruealternativewrong solely bygoldversion',
142:'Frozen Born2BREEDPrincecoauthor and100millionrecords support QA',
143:'Frozen BigJohnStudd ringname correct and DisneyDoubleAgent1987creditedrole. Goal BigRed1962 appearance unsupported and targetedfullcastcredits contradict; not a validalternativeDisneyfilm. Goalwrongfilm for correctlyidentifiedwrestler',
144:'Frozen RouteA002Ezeiza and largestinternationalairport supports QA. Goal rewrite substitutes answerairportfor largestcriterion and askswhatairportisEzeiza, changingunknownidentificationtoverification, RF/RTfalse',
145:'Frozen SeanYseultStarDagger and SupagroupChrisLeehusband; goalwronglyTommyLee, distinctmusician, QAincorrect despite correctbassist',
146:'Frozen UDO Venezuela and CSUDHCSU supports QA and No commonsystem. Rewrite substitutes CaliforniaStateUniversitysystem value in placeofCSUDH universitywithoutadjusting same-system-as relation, wrongentitytype',
147:'Frozen RogueOneRebels and Beinartstuntperformer support all QA',
148:'Frozen DowdReport and JohnMDowdlawyer support all QA',
149:'Frozen SteveBiko explicitlypseudonymFrankTalk; A1/goal absolute notpseudonym/noowner falseevenifmagazineofsamenameexists. Rewrite changes pseudonymowner to magazineowner, wrongsenseandrelation',
150:'Frozen townForbes7560, notCowra10063. A1 proposesCowrawhileitdoesnotmatchrequiredpopulation, wrongtown. GoalForbesfactualrecovery; rewrite insertsCowraandturnswhichtownintoconfirmation, RF/RTfalse',
151:'Frozen DiamondbackCocoaFloridaEvergladesguide and FloridaEvergladestropicalwetlands support wholeQA',
152:'Frozen SharksMartinez/Fiers and FiersBrewersAstros support first/goal. A2EricFarris/ChuckPorterBrewers truepartiallist. A3currentquestiononlyAstrosplayers but answeraddsallthree-teamintersectionandfalselydeniesexists, nonresponsiveandfalseglobalabsence; goalrecoversFiers',
153:'Frozen TandrageeCountyArmaghOrchardCounty supports QA',
154:'Frozen SharpeKnutsfordhouse/Cambridgegraduation supports QA',
155:'Frozen FreedELJames and EnglishequivalentBritish supports QA',
156:'Frozen games1966/1980 supports dates and earlierHeyPa',
157:'Frozen DeyemivideoFalz and SchoolBoys careerstart supports QA',
158:'Actual allA1/goalreadertexts inspected. A1noOldhampop; goalhasLakeLouisvillarelationandOldhamnamebutnotcountyoverview60316, honestqualifiedabstentionlocallycorrect. Goalrewritedropspopulationcriterionandasksanycountywithneighborhood, RF/RTfalse',
159:'Actual allA1/goalreadertexts inspected: casinoandWynnproperties but nopiratethemedstatement/TreasureIslandbio, so source-qualifiedabstentionsreasonable. A2truelistdevelopedWynnproperties',
160:'Frozen flight707-436 identitycorrect; referencefamily707max219. Goal asserts219 for exact436subtype, which familyrangealonecannotverify. Targetedlookup finds707-320Cextraexits allow219 vsothers189 but no authoritative436maximum yet; keep onlygoal factpending under approvedworkflow, do not forceeithertruthlabel'
}
flows={i:{'i':i,'all_nodes_inspected':True,'reason':s} for i,s in notes.items()}
for i in [137,138,142,143,145,147,148,154,155,157,160]:flows[i]['bindings']={'2':[1]}
flows[136].update(incorrect_answers=[2,6],answer_subtypes={'1':'factual_alternative_underconstrained_child','2':'correct_director_wrong_writer_credit','6':'nonresponsive_false_inconsistency_claim'})
flows[140].update(incorrect_answers=[3],incorrect_fidelity=[3],incorrect_targets=[3],bindings={'3':[2]},answer_subtypes={'1':'reasonable_abstention','2':'factual_alternative_battle_year','3':'nonresponsive_joint_roles_wrong_battle_branch'})
flows[141]['answer_subtypes']={'2':'factual_ambiguous_title_alternative'}
flows[143].update(incorrect_answers=[2],answer_subtypes={'2':'wrong_actor_film_appearance'})
flows[144].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'3':[2]})
flows[145].update(incorrect_answers=[2],answer_subtypes={'2':'wrong_musician_same_surname'})
flows[146].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'3':[2]})
flows[149].update(incorrect_answers=[1,2],incorrect_fidelity=[2],incorrect_targets=[2],bindings={'2':[1]},answer_subtypes={'1':'false_term_sense_exclusivity','2':'propagated_false_pseudonym_denial'})
flows[150].update(incorrect_answers=[1],incorrect_fidelity=[2],incorrect_targets=[2],bindings={'2':[1]},answer_subtypes={'1':'nonresponsive_town_failing_population_constraint','2':'factual_recovery_despite_bad_rewrite'})
flows[152].update(incorrect_answers=[3],answer_subtypes={'3':'nonresponsive_added_filter_and_false_absence'})
flows[158].update(incorrect_fidelity=[3],incorrect_targets=[3],answer_subtypes={'1':'reasonable_abstention','3':'reasonable_abstention'})
flows[159]['answer_subtypes']={'1':'reasonable_abstention','3':'reasonable_abstention'}
flows[160].update(pending_answer_facts=[2],answer_subtypes={'2':'pending_exact_aircraft_subtype_capacity'})
assert set(flows)==set(range(136,161))
write(Path(__file__).parent/'batch_s136_160.json',{'batch_id':'s136_160','axis':'stage_node','manually_reviewed_flows':list(flows.values())})
