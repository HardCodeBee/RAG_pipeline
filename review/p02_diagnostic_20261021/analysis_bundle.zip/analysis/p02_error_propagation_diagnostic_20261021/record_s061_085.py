"""Record decisions made after examining frozen Hotpot source and stage text."""
from prepare_inventory import write
from pathlib import Path
notes={
61:'Actual A1 tenreadertexts sealindex/waterfalllists but no matching sealidentification, honestabstention correct. Frozen MontanaGreatFallsMissouri5falls supports goal',
62:'Frozen Serri actress and Fogerty occupationalmusician comparison supports reference-based actorselection; no current-status update introduced',
63:'Frozen LesleyMDFPaperCard and paperpressingmoistfibres support all facts; fiberboard also pressedfibres validadditionalmaterial. Goal rewrite inserts paper and becomes confirmation instead of requesting unknownmaterial; RF/RT false',
64:'CIT true1908FHC; extra BankCommunications founded1908 but commercialbank rather than claimedfinancialholdingcompany (nativeprofile and targeted officialBoComclassification). A2 similarly misclassifies MerrillLynchWealthManagement (explicitlydivision), Bloombergfinancialdatamedia asholdingcompanies, despite trueNYC locations. Goal CIT correct, unchanged rewrite contains wrongprior answers but doesnotexplicitlybindthem',
65:'Frozen GiffordMidnightOil1980-87 and Farm1976hatdraw followingGarrettSydney move verify full answer',
66:'Frozen1990/1991 supports all QA and earlierUnwrittenLaw',
67:'Frozen Florida/PalmSpringsnearWestPalmBeachMiamiMetro matches facts; actual A2sourceopenings onlyPalmBeachrank3/Hillsborough4/Orange5, no top2. Correct partialthirdcounty with explicitincompleteness and no false inclusion of4th/5thintop3',
68:'Actual all unique readertexts for3steps inspected. A1 ignores directly matching AfroAmericanreligion definition derivestraditionalAfricanwithChristianinfluence and claims no such category identified, incorrectavailabledefinition. A2/goal noKongo/noothercreolizedlanguage present, reasonable insufficiency. Rewrites unchanged, missingbridge is not erroneous substitution',
69:'Frozen PushmanGrandCentral1922-1966 and Chakmakianmusician support comparative gallerylikelihood. No affirmativegalleryclaimforChakmakian; source-qualified A2uncertainty reasonable',
70:'Frozen BakerrecurringCharmed+WillGrace/CharmedWB/Burgecreator supports all facts. Bad D2 phrasing answered by correcting show-networkrelation; rewrite follows samecurrentquestion and binds correctCharmed, upstreamDgrammar not reassigned asnewrewritefacterror',
71:'Frozen Argand1780oil and LewisArganddesign similarity support QA. Goal turns unknowntypequestion into confirmation ofArgand, RF/RT fail',
72:'Frozen NorthernLightsGoldenCompass audiobookBBC+Cavalcade support book/audiobook identities; BBC Audiobooks laterAudioGO historicalname relation factual',
73:'Frozen HarrisbenefactorMuseum and MuseumPreston match answers',
74:'Frozen SeriousRequest inspiration and2004 inception match answers',
75:'Frozen ValueAllianceVanillaAirNaritaTerminal2 and whollyANA match answers at originalmaterialtime',
76:'Frozen Christie1976/Greenberg1994 match dates and laterGreenberg',
77:'Frozen UGA72milesAtlanta and GotayUGAgraduate match QA. Rewrite insertsUGA and replaces unknownuniversity with confirmation, RF/RT fail',
78:'Frozen expedition allfour namedpeople and tribes match true partialmembership answers; SpokaneReservation237squaremiles matches goal; multipletribes retained rather than selecting unsupportedone',
79:'Frozen IsKatsura born1962 supports all QA; goal keepsyearunknown for givenseriesauthor',
80:'Frozen Bedknobs13Dec1971/Muppet1992 supports dates and olderBedknobs',
81:'Unqualified Guam includes1941 and1944 battles; actual1941FirstBattle8-10Dec isvalidalternative, no date-disambiguator in original. Antietam1862 earlier either way; true dates retained withnames in rewrite',
82:'Actual A1 MyLittlePony1986 text expresslyDannyDeVito voice; Lorax2012castDanny and KoolKojakwrittenproducedLorax native support all factualpartialanswers',
83:'Frozen HoyleB2FH1957 and formalpaperSynthesisElementsStars, fourauthors match whole answer',
84:'Native targetPoplarCottonwood. A1 gives trueoak/robur background but no single tree species satisfying allthreegeographicconstraints, wrongconstraint/taxon answer. A2ImperialFelicity true partialcommunities. Goal absolute no suchcommunity false, nativeAlamorio existsnamedalamo+rio; goal rewrite binds unrelatedoak fromA1 RTfalse despite literalhistoryfidelity',
85:'Frozen station2.1miNESmyrna entails citySWstation; Smyrna2010population51271 matches all facts'
}
flows={i:{'i':i,'all_nodes_inspected':True,'reason':s} for i,s in notes.items()}
for i in [63,65,73,74,75,77,83,85]:flows[i]['bindings']={'2':[1]}
for i in [63,71,77]:flows[i].update(incorrect_fidelity=[2],incorrect_targets=[2])
flows[64].update(incorrect_answers=[1,2],answer_subtypes={'1':'mixed_true_date_wrong_organization_type','2':'mixed_true_locations_wrong_organization_types'})
flows[67].update(bindings={'2':[1],'3':[1]},answer_subtypes={'2':'factual_partial_list_with_reasonable_abstention'})
flows[68].update(incorrect_answers=[1],answer_subtypes={'1':'available_definition_ignored','2':'reasonable_abstention','3':'reasonable_abstention'})
flows[69]['answer_subtypes']={'2':'reasonable_abstention'}
flows[70].update(bindings={'2':[1],'3':[1,2]},answer_subtypes={'2':'factual_corrective_response_to_bad_presupposition'})
flows[72]['bindings']={'2':[1],'3':[1]}
flows[78]['bindings']={'2':[1],'3':[1,2]}
flows[79]['bindings']={'2':[1],'3':[1]}
flows[81].update(bindings={'3':[1,2]},answer_subtypes={'2':'factual_ambiguous_battle_alternative','3':'factual_ambiguous_battle_alternative'})
flows[84].update(incorrect_answers=[1,3],incorrect_targets=[3],bindings={'3':[1]},answer_subtypes={'1':'nonresponsive_wrong_constraint_taxon','2':'factual_partial_list','3':'false_global_absence_from_wrong_branch'})
flows[61]['answer_subtypes']={'1':'reasonable_abstention'}
assert set(flows)==set(range(61,86))
write(Path(__file__).parent/'batch_s061_085.json',{'batch_id':'s061_085','axis':'stage_node','manually_reviewed_flows':list(flows.values())})
