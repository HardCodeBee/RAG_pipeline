"""Persist the user-approved distinction between truthful background and answering."""
from prepare_inventory import ROOT,OUT,read,write,sha
from datetime import datetime,timezone
import json
plan=ROOT/'experiments/query_decomposition/unified_rag_eval_v1_20261021'
rule={'id':'P02_DIAG_NONRESPONSIVE_TRUE_BACKGROUND_INCORRECT','utc':datetime.now(timezone.utc).isoformat(),
 'authority':'User replied 按这个区分 to truthful-background/count/nomination vs requested entity/received award distinction',
 'rule':'Truthful but nonresponsive background, object counts instead of objects, and nominations instead of received awards are incorrect and separately coded; answers supplying requested information at coarser precision or incomplete true lists remain correct',
 'main_evaluation_remains_paused':True,'new_RAG_or_external_judge':False}
log=plan/'DECISIONS.jsonl'
if rule['id'] not in log.read_text(encoding='utf-8-sig'):
 with log.open('a',encoding='utf-8') as f:f.write(json.dumps(rule,ensure_ascii=False)+'\n')
p=plan/'reviews/20261021_error_propagation/PROPOSAL.json';v=read(p)
v['approved_protocol']['nonresponsive_answers']=rule['rule']
if not any(x['id']==rule['id'] for x in v['approved_protocol']['user_addenda']):v['approved_protocol']['user_addenda'].append(rule)
md=p.with_suffix('.md');s=md.read_text(encoding='utf-8')
if rule['id'] not in s:s+='\n- '+rule['id']+'：事实属实但只答背景、数量或提名，没有回答具体对象或获奖信息，判错并单列“答非所问”；已回答所问但粒度较粗、未列全，仍判正确。\n'
md.write_text(s,encoding='utf-8');v['proposal_sha256']=sha(md);write(p,v)
write(OUT/'offline_review_v2/NONRESPONSIVE_RULE_APPROVAL.json',rule)
print('User-approved responsiveness rule recorded without changing existing factual pending items.')
