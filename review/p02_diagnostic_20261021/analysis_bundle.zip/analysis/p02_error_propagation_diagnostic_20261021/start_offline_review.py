"""Record explicit offline approval and freeze blinded review packets. No inference."""
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
from prepare_inventory import ROOT, FORMAL, Q, OUT, read, rows, sha, rel, write, ledger

PLAN = Q/'unified_rag_eval_v1_20261021'
REVIEW = PLAN/'reviews/20261021_error_propagation'
RUN = OUT/'offline_review_v2'


def main():
    RUN.mkdir(parents=True, exist_ok=True)
    proposal = read(REVIEW/'PROPOSAL.json')
    if proposal['status'] == 'draft_pending_user_protocol_review':
        history = REVIEW/'history/proposal_v1_pending'
        history.mkdir(parents=True, exist_ok=True)
        for name in ('PROPOSAL.md', 'PROPOSAL.json', 'VERIFICATION.json'):
            shutil.copy2(REVIEW/name, history/name)
    old = proposal.pop('proposed_not_approved', proposal.get('approved_protocol', {}))
    old.update(final_correctness='existing official F1 == 1 OR EM == 1',
               stage_labels=['correct', 'incorrect'],
               decomposition_empty_helpers='exclude from every diagnostic population',
               decomposition_rubric='experiments/query_decomposition/multigrain_4b_frozen_eval300_v1_20261017/PROTOCOL.txt: F/S/C/U',
               child_correctness='current child question factual correctness; correct regardless of retrieved support; reasonable abstention when evidence truly insufficient is correct',
               goal_preanswer='review separately from ordinary child answers',
               final_evidence='inspect actual final-visible context, separately from child factual correctness',
               missing='record absent data as missing, never as a semantic label; unresolved factual decisions go to user',
               review='offline stage review hidden final outputs/scores; recheck incorrect and fixed-seed 10 percent correct',
               root_cause='evidence-based nonexclusive failure locations and propagation/containment, not counterfactual causal effects')
    proposal.update(status='approved_offline_review_in_progress', protocol_revision=2, approved_protocol=old)
    proposal['approval'].update(new_semantic_annotation=True, conditional_probability_computation=True)
    proposal['approval_authority'] = [
        'User: F1 or EM exactly 1 counts correct; binary labels; exclude no-child queries',
        'User: factual child answers count correct regardless of retrieved support',
        'User: include goal preanswers and final evidence diagnosis, separate ordinary and goal',
        'User: start offline diagnosis; main campaign remains paused, no external judge or RAG rerun']
    write(REVIEW/'PROPOSAL.json', proposal)
    log = PLAN/'DECISIONS.jsonl'
    decision_id = 'P02_ERROR_PROPAGATION_OFFLINE_REVIEW_V2_APPROVED'
    if decision_id not in log.read_text(encoding='utf-8-sig'):
        with log.open('a', encoding='utf-8') as f:
            f.write(json.dumps({'id':decision_id, 'utc':datetime.now(timezone.utc).isoformat(),
                'status':'approved_offline_existing_trace_diagnosis', 'authority':proposal['approval_authority'],
                'rules':old, 'main_execution_approval':False, 'external_model_or_new_RAG':False,
                'main_evaluation_remains_paused':True}, ensure_ascii=False)+'\n')
    pending = PLAN/'EXECUTION_DECISIONS_PENDING.txt'
    marker = 'P02_ERROR_PROPAGATION_OFFLINE_REVIEW_V2_APPROVED'
    if marker not in pending.read_text(encoding='utf-8-sig'):
        with pending.open('a', encoding='utf-8') as f:
            f.write('\n'+marker+'\n第7项旧的待审批状态已由用户明确批准离线排查而取代。按修订二值口径执行；主评、外部模型和新RAG仍未批准。\n')
    if (RUN/'COHORT.jsonl').exists():
        print('Cohort already frozen; protocol approval recorded.'); return
    before = ledger()
    refs = {r['id']:r for r in rows(Q/'p02_formal1500_v1_20261021/references1500.local.frozen.jsonl')}
    cohort, outcomes, dp, stages, excluded, prefixes = [], [], [], [], [], []
    source_files = {FORMAL/'SCORES.jsonl', Q/'p02_formal1500_v1_20261021/references1500.local.frozen.jsonl',
                    Q/'multigrain_4b_frozen_eval300_v1_20261017/PROTOCOL.txt'}
    for s in rows(FORMAL/'SCORES.jsonl'):
        if s['dataset'] not in ('2wiki','hotpotqa') or not s['source']: continue
        path = ROOT/Path(s['source'].replace('\\','/')); c = read(path); source_files.add(path)
        if not c.get('supporting_questions'):
            excluded.append({'id':s['id'],'reason':'no_supporting_child_query','status':s['status']}); continue
        complete = s['status'].startswith('success')
        base = {'id':s['id'],'qid':s['qid'],'dataset':s['dataset'],'type':s['type'],
                'source':s['source'],'source_sha256':sha(path),'complete':complete}
        if complete:
            base['review_index'] = len(cohort)+1
            cohort.append(base)
            outcomes.append({'id':s['id'],'em':s['em'],'f1':s['f1'],
                'final_correct':int(s['em']==1 or s['f1']==1), 'prediction':s['prediction'],'reference':s['answer']})
        else:
            prefixes.append(base)
        dp.append({**base,'question':c['question'],'supporting_questions':c['supporting_questions']})
        stages.append({**base,'question':c['question'],'supporting_questions':c['supporting_questions'],
            'reference':refs[s['id']], 'nodes':[{
                k:n.get(k) for k in ('step_id','role','request','answer','initial_answer','prior_complete_answers',
                    'rewritten_query','raw_rewrite','rewrite_request_id','rewrite_rejection',
                    'answer_request_id','reader_packet') } for n in c['nodes']]})
    for name, values in [('COHORT',cohort),('OUTCOMES_SEPARATE',outcomes),('DECOMPOSITION_PACKETS',dp),
                         ('STAGE_PACKETS',stages),('EXCLUDED',excluded),('PREFIXES',prefixes)]:
        (RUN/(name+'.jsonl')).write_text(''.join(json.dumps(v,ensure_ascii=False)+'\n' for v in values),encoding='utf-8')
    write(RUN/'SOURCES.json', {'files':[{'path':rel(p),'sha256':sha(p)} for p in sorted(source_files)]})
    protected=read(PLAN/'PROTECTED_FILES_BEFORE.json')
    assert all(sha(ROOT/p)==v for p,v in protected.items())
    assert not read(PLAN/'PLAN.json')['execution_approval']['approved']
    assert (PLAN/'STOP_REQUESTED').is_file()
    write(RUN/'START_VERIFICATION.json', {'ledger_before':before,'ledger_after':ledger(),
        'main_pause_preserved':True,'new_API_requests':0,'new_RAG_runs':0,'new_GPU_jobs':0,
        'protected_hashes_checked':len(protected),'complete_cohort':dict(Counter(r['dataset'] for r in cohort)),
        'prefix_cohort':dict(Counter(r['dataset'] for r in prefixes)), 'empty_child_excluded':len(excluded),
        'stage_review_blinding':'final prediction and score kept only in separate outcome file'})
    write(OUT/'LATEST.json', {'run_directory':rel(RUN),'status':'approved_offline_semantic_review_in_progress'})
    print(json.dumps(read(RUN/'START_VERIFICATION.json'),ensure_ascii=False))


if __name__ == '__main__': main()
