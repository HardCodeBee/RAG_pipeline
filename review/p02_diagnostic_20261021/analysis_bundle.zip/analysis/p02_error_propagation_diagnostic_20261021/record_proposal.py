"""Register the requested draft, keeping annotation/execution approvals false."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
PLAN=ROOT/'experiments/query_decomposition/unified_rag_eval_v1_20261021'
REVIEW=PLAN/'reviews/20261021_error_propagation'
OUT=ROOT/'outputs/query_decomposition/p02_error_propagation_diagnostic_20261021'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rel(p):return p.relative_to(ROOT).as_posix()
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

if read(REVIEW/'PROPOSAL.json').get('approval',{}).get('new_semantic_annotation'):
 raise SystemExit('Historical draft writer disabled after explicit offline approval; use start_offline_review.py.')
latest=read(OUT/'LATEST.json');audit=ROOT/latest['run_directory']
inventory=read(audit/'INVENTORY.json')
assert not inventory['semantic_annotation_performed'] and not inventory['conditional_probability_calculated']
proposal={
 'id':'p02_error_propagation_existing_formal_20261021',
 'status':'draft_pending_user_protocol_review',
 'date':'2026-10-21','timezone':'Australia/Sydney','main_plan_revision':6,
 'scope_confirmed':{'method':'p02_multigrain_timing_cachefix_v1','protocol':'historical formal, before shared layer',
   'datasets':['2wiki','hotpotqa'],'require_complete500':False,'existing_trajectories_only':True,
   'relations':['decomposition_to_final','prior_child_answer_to_later_rewrite','child_answer_to_final','rewrite_to_final']},
 'approval':{'inventory':True,'new_semantic_annotation':False,'conditional_probability_computation':False,
             'external_judge_model':False,'new_RAG_inference':False,'main_campaign_resume':False},
 'proposed_not_approved':{
  'final_correctness':'existing official EM == 1; explicitly EM pass rate, not semantic equivalence',
  'stage_labels':['correct','incorrect','undetermined'],
  'decomposition_empty_helpers':'separate no-decomposition route',
  'ordinary_answer_population':'role ordinary, exclude goal pre-answer',
  'rewrite_population':'recorded rewrite calls, including goal separately; distinguish proposal and effective query',
  'rewrite_axes':['semantic fidelity to current question and supplied history','effective factual referent/target validity'],
  'answer_to_rewrite_unit':'one later rewrite, grouped by supplied prior-answer history; actual binding sources traced separately; never pair current answer with earlier same-step rewrite',
  'final_outcome_tables':['original-query aggregate groups','literal node/event conditional proportions as supplements'],
  'uncertainty':{'method':'original-query cluster bootstrap','replicates':2000,'seed':20261021,'coverage':0.95},
  'review':'offline, hidden final predictions/EM; all incorrect and undetermined rechecked; random10percent correct rechecked',
  'old_labels':'strict matching plus scope/evidence/axis compatibility verification, candidates only',
  'missing':'keep unknown and inapplicable, do not fill with incorrect or zero; observed prefixes only for no-final-outcome relations'},
 'inventory':rel(audit/'INVENTORY.json'),'label_reuse_candidates':rel(audit/'PRIOR_LABEL_CANDIDATES.json'),
 'sources':rel(audit/'SOURCES.json'),'read_only_verification':rel(audit/'READ_ONLY_VERIFICATION.json'),
 'proposal_document':rel(REVIEW/'PROPOSAL.md'),'proposal_sha256':sha(REVIEW/'PROPOSAL.md'),
 'method_tool_reference':{'local_skill':'scientific-critical-thinking','skill_version':'1.5',
  'paper':'Scientific Agent Skills: A Library of Procedural Knowledge for Research Agents',
  'authors':['Timothy Kassis','Vinayak Agarwal','Yuhuan He','Darshil Patel','Aubrey M. Brueckner'],
  'year':2026,'url':'https://arxiv.org/abs/2609.00065','doi':'10.48550/arXiv.2609.00065',
  'verified_record_revision_date':'2026-09-02','verified_on':'2026-10-21','role':'analysis workflow source, not empirical P02 evidence'}}
write(REVIEW/'PROPOSAL.json',proposal)

decision_id='P02_ERROR_PROPAGATION_EXISTING_TRACES_20261021_PROPOSAL'
log=PLAN/'DECISIONS.jsonl';original=log.read_bytes()
if decision_id not in original.decode('utf-8-sig'):
 entry={'id':decision_id,'utc':datetime.now(timezone.utc).isoformat(),
   'status':'scope_confirmed_protocol_pending_user_review','main_plan_revision':6,
   'authority':['User confirmed the normalized four conditional relationships',
                'User added partly completed HotpotQA', 'User clarified complete500 is not important for this diagnosis',
                'User selected see complete proposal before confirmation'],
   'scope':['2wiki','hotpotqa'],'existing_formal_P02_trajectories_only':True,'wait_for500':False,
   'proposal':rel(REVIEW/'PROPOSAL.md'),'inventory':rel(audit/'INVENTORY.json'),
   'new_semantic_annotation_approved':False,'conditional_probability_computation_approved':False,
   'new_RAG_or_external_judge_approved':False,'main_evaluation_remains_paused':True,
   'new_offline_inventory_completed':True,'existing_main_quality_protocol_unchanged':True}
 with log.open('ab') as f:f.write((json.dumps(entry,ensure_ascii=False)+'\n').encode('utf-8'))
 assert log.read_bytes().startswith(original)

pending=PLAN/'EXECUTION_DECISIONS_PENDING.txt';old=pending.read_bytes()
marker='P02_ERROR_PROPAGATION_EXISTING_TRACES_20261021_PROPOSAL'
if marker not in old.decode('utf-8-sig'):
 with pending.open('ab') as f:
  f.write(('\n\n7. 已有P02轨迹错误传播诊断（独立辅助方案，不作为主评恢复前置）\n'
   +marker+'\n'
   +'范围已确认：2Wiki及部分完成HotpotQA，四组条件关系；不等待500题。\n'
   +'用户要求先看完整方案再确认：新标注、条件概率计算、外部评审和新RAG执行均未获准。\n'
   +'具体口径、goal/空分解、统计单位、标签与复核规则见 reviews/20261021_error_propagation/PROPOSAL.md。\n'
   +'现仅完成已有资料盘点和标签候选核验，不修改主表或暂停状态。\n').encode('utf-8'))
 assert pending.read_bytes().startswith(old)

protected=read(PLAN/'PROTECTED_FILES_BEFORE.json')
assert all(sha(ROOT/p)==v for p,v in protected.items())
active=read(PLAN/'PLAN.json');assert active['execution_approval']['approved'] is False
assert (PLAN/'STOP_REQUESTED').is_file()
write(REVIEW/'VERIFICATION.json',{'proposal_only':True,'new_semantic_annotations':0,
 'conditional_probabilities_computed':False,'new_RAG_runs':0,'new_API_requests':0,'new_GPU_jobs':0,
 'protected_source_hashes_unchanged':len(protected),'main_plan_revision_unchanged':active['revision'],
 'main_execution_approval':False,'pause_marker_preserved':True,
 'inventory_source':rel(audit),'source_inventory_verification':read(audit/'READ_ONLY_VERIFICATION.json')})
(Path(__file__).parent/'README.md').write_text('''# P02 现有轨迹错误传播诊断

状态：用户要求先审核完整方案；未开始新语义标注或条件概率计算。

- 方案：`experiments/query_decomposition/unified_rag_eval_v1_20261021/reviews/20261021_error_propagation/PROPOSAL.md`
- 机器可读状态：同目录 `PROPOSAL.json`、`VERIFICATION.json`。
- 现有资料盘点：`outputs/query_decomposition/p02_error_propagation_diagnostic_20261021/LATEST.json`。
- `prepare_inventory.py` 只读取原轨迹和已有标签，生成来源清单与候选复用关系；不打正确性标签、不评分、不启动API/GPU。

尚待确认EM/语义正确口径、三值标签、goal及空分解处理、实际绑定来源、统计单位和复核规则。主评继续暂停。
''',encoding='utf-8')
print(json.dumps({'proposal':rel(REVIEW/'PROPOSAL.md'),'status':proposal['status'],
 'protected_hashes_unchanged':len(protected),'new_annotations':0,'new_API_requests':0},ensure_ascii=False))
