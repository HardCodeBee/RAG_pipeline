"""Show a second-pass node selection, blinded to final outcome."""
import sys,json
from prepare_inventory import OUT,read,rows
run=OUT/'offline_review_v2'
selected=read(run/'STAGE_RECHECK_SELECTION.json')['selected']
labels={(l['review_index'],l['step_id']):l for f in sorted((run/'reviews').glob('*.json')) for l in read(f)['labels'] if l['axis']=='stage_node'}
packets={p['review_index']:p for p in rows(run/'STAGE_PACKETS.jsonl') if p.get('complete')}
start=int(sys.argv[1]);count=int(sys.argv[2])
for j,k in enumerate(selected[start:start+count],start):
 l=labels[k['review_index'],k['step_id']];p=packets[l['review_index']]
 print(json.dumps({'j':j,'i':l['review_index'],'s':l['step_id'],'role':l['role'],'A_RF_RT':[l['answer_correct'],l['rewrite_fidelity_correct'],l['rewrite_target_correct']], 'original_query':p['question'],'request':l['reviewed_request'],'a':l['reviewed_answer'],'r':l['effective_rewrite'],'reason':l['reason']},ensure_ascii=False,separators=(',',':')))
