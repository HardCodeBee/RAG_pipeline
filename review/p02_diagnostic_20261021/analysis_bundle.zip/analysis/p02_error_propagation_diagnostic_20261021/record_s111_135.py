"""Persist25 manually reviewed Hotpot flows, including full-statement and response checks."""
from prepare_inventory import write
from pathlib import Path
notes={
111:'Frozen Reunions1990/MoneyOct1972 match dates and earlierMoney',
112:'Frozen AmericanZeitgeistwar/religion vsThisIsItconcertrehearsals support fullQA and No bothentertainment',
113:'Frozen Cleopatraidentity correct; actual10 goalreadertexts have Ptolemyfamily/Apollodorushelper but no militarycommander identification, reasonableabstention',
114:'Frozen townRichmond2010population3411 true; native1864in2000 isRichmondCDP not entiretown. Honest townpopulationabstention correct, do not force goldCDPvalue onto town',
115:'Actual allreadertexts forbothsteps inspected, county/towns/mountainbut no sportingfacilityidentified. Honestabstentions correct; NansenMilan reference not retrieved',
116:'Frozen Penderecki4operas supportscomposer/goalcount. A2 asksbestknownworkidentities but gives onlycount4andgenericcategoryoperas, no namedwork; nonresponsive under userapprovedcount-vs-objectrule even though useful downstreamcount true',
117:'Actual allreadertexts reviewed: namedDalIndia/WatertonUSCanada regions but explicitlatitudeabsent(blankcoordinates). Ordinary latitudeabstentions reasonable. Goal refusesorderingwithoutlatitude; retain conservative local-evidenceabstention and note qualitativegeography mightpermitrescue, notnegativeclaimDalnotsouth',
118:'Frozen Fletcheractor correct; actual10 goaltexts do notincludeJuliaFletcher/JohnDeMita/Connor, onlyunrelatedElliot/Fletcherbrothers; reasonableabstention',
119:'Frozen SanginHelmandvalley and HelmandprimarywatershedSistan support fullrelationanswers; awkwardD2 answered with correctdrainageriver. Goal rewrite deletes primarywatershedrelation and makes brokenriver-valley-forquestion, RF/RTfail',
120:'Frozen hotToddybedtime tradition and KirFrenchaperitif contrast support QA',
121:'Frozen SASTechArlanda and SASGroupSolnaownership support fullQA',
122:'Native Butautasattemptfailed. A1 correctlynamesAlgirdas but falselyrepeatshewasdeposed, wholeanswerincorrect. Goal onlysays triedduringbroad1345-1377interval, includesactualattemptperiod and nativeAlgirdasruleinterval; no successfuldepositionclaim, preserve coarseperiod/missingverb originalambiguity',
123:'Frozen HelenaLewisClark correct; actualgoalreader CigaretteRock explicitly summitLewisClark. Validalternativesummit toScapegoat because originalnonunique',
124:'Frozen CookLandingPlaceSeventeenSeventy and JamesCookBritish match fullQA',
125:'Frozen Rispoli+GandolfiniPelham2009 and TonyroleGandolfini support answers; responses avoid originalbad wenton chronologicalimplication',
126:'Frozen ButteredCatParadox identification correct. A2 saysanonymous/noindividualcreator, but nativeJohnFrazee explicitlyknownforstoryhewroteOMNI; wrong/noauthorclaim and nonresponse. GoalJohnFrazeeNYC matches native reference',
127:'Frozen GlinkaRussianfountainhead/LullyItalianbornFrench support allfacts and Yescomposers',
128:'Frozen1950CinderellaRKO/EmperorDisney and actual2015CinderellaDisney alternative true. Goalconditionalexplanationnotallversionssame isfactual; rewrite changes ambiguoussingleCinderella to universal3filmconjunction, RF/RTfalse',
129:'Frozen Hindemith1895/Bartok1881 supports facts and earlierBartok',
130:'ActualA1reader showsgenericItgirl/Pharrellsong(countryEP)but no Derulosongclassification; source-qualifiedabstention reasonable. Frozen Derulomidtempo/Tempo definition support goal',
131:'Frozen DavidWalkerfather/Boston1829Appeal supports answers',
132:'Frozen TonyMcCoy20consecutive supports first/goal. A2 asksonwhatoccasions but givescount20only, no actualyears/occasions, nonresponsive under approvedrule; countitself true and usefulforgoal',
133:'Local JohnArledgebio namesGrapesWrath while FlowingGold starsJohnGarfield; local1940body lacksdirector. Targetedfallback primaryAFI5028 verifies AlfredEGreen director and creditedcast noArledge, corroborates actorconfusion. A1wrongactor-filmjoin; goal RalphMurphy alsofactuallywrongdirector, not merely differentvalid1940film. Goalrewrite binds suppliedwrongfilm, RFfaithful RTfalse',
134:'Frozen Noori1996/TestIcicles2004 supports facts and earlierNoori',
135:'Frozen Celluloid1995/Station2014 supports facts and earlierCelluloid; later2015distribution doesnotinvalidate2014filmdate'
}
flows={i:{'i':i,'all_nodes_inspected':True,'reason':s} for i,s in notes.items()}
for i in [113,114,116,118,123,131,133]:flows[i]['bindings']={'2':[1]}
flows[116].update(incorrect_answers=[2],bindings={'2':[1],'3':[1]},answer_subtypes={'2':'nonresponsive_count_instead_work_identities'})
for i,ss in [(113,[2]),(114,[2]),(115,[1,2]),(117,[1,2,3]),(118,[2]),(130,[1])]:flows[i]['answer_subtypes']={str(s):'reasonable_abstention' for s in ss}
flows[119].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'2':[1],'3':[1,2]})
flows[121]['bindings']={'3':[1]}
flows[122].update(incorrect_answers=[1],bindings={'2':[1]},answer_subtypes={'1':'correct_uncle_value_false_successful_deposition','2':'factual_coarse_attempt_interval_ambiguous_original'})
flows[123]['answer_subtypes']={'2':'factual_alternative_underconstrained_query'}
flows[124]['bindings']={'2':[1],'3':[2]}
flows[125]['bindings']={'2':[1],'3':[1]}
flows[126].update(incorrect_answers=[2],bindings={'2':[1],'3':[1]},answer_subtypes={'2':'false_no_author_claim'})
flows[128].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'3':[1]},answer_subtypes={'1':'factual_version_specific_alternatives','3':'factual_conditional_disambiguation'})
flows[132].update(incorrect_answers=[2],bindings={'2':[1],'3':[1]},answer_subtypes={'2':'nonresponsive_count_instead_occasions'})
flows[133].update(incorrect_answers=[1,2],incorrect_targets=[2],answer_subtypes={'1':'actor_name_confusion_wrong_film','2':'wrong_director_and_wrong_actor_film'})
assert set(flows)==set(range(111,136))
write(Path(__file__).parent/'batch_s111_135.json',{'batch_id':'s111_135','axis':'stage_node','manually_reviewed_flows':list(flows.values())})
