"""Persist 45 flows inspected by the reviewer against displayed packets."""
from prepare_inventory import write
from pathlib import Path
notes={
504:'Gold fatherErikMagnus Sweden match facts',
505:'Gold UKvsUS match all facts and No sharedcountry',
506:'Gold LiuCong fatherLiuYuan; ordinary2 and goal incorrectly useLiuYin. Ordinary rewrite correctly retainsEmperorZhaowu, so reader identity mistake. Goal genericWhoisLiuYin loses familyrelation and also binds wrong prior answer',
507:'Gold Priyadarshan1957/Atorthy1890 match all QA. Goal rewrite replaces younger comparison with which director born30Jan1957; queried attribute/proposition changed despite selecting same film in this case',
508:'Native Sakellarios explicitly FirstCemeteryAthens familygrave confirms complete answer',
509:'Frozen dataset birthDutch mappedNetherlands; director and country-level birthplace answer match reference granularity',
510:'Actual10 readertexts inspected; CraigMoss bio gives nationality/education but no birth place. Correct director and reasonable local-evidence abstention; goldAmerican is not birth evidence',
511:'Gold Braham2May1934 matches facts',
512:'Gold AlexandraPelosi NancyPelosi matches facts',
513:'Gold HamiltonBee SanAntonioTexas matches facts',
514:'Gold1956/1552 and earlierCavendish comparison correct',
515:'Gold1922/1931 and earlierMurray comparison correct',
516:'Gold PrinceAmerican; additional singer/songwriter/musician descriptors correct',
517:'Native Nayyar already inspected at488 gives1958FilmfareNayaDaur; no film-specificHowrah award asserted. Complete award answer factual with correct qualification',
518:'Gold SelimII Ottoman matches both answers; redundancy belongs to D',
519:'MotherClaraGonzaga correct; asserted exact deathMontpensier not settled. Gold broaderAuvergne and external sourcesFrance/Auvergne do not verify town; keep only goal fact pending rather than force true/false',
520:'Native Encounter explicitly1953 bothfounders, so ordinary correct and dual-founder rewrite valid. Goal HaroldSpender matches native reference; added JosephKristol rabbi claim unresolved: name corroborated by sons funeral account, occupational biographies garmenttrade but no reliable rabbinate confirmation; whole goal pending',
521:'Gold JeanPierreWillem SedanFrance matches facts',
522:'Gold bothFrench; bothFrench rewrite equivalent given established firstFrench; all QA correct',
523:'Gold2014/1941 and earlierNaiRoshni comparison correct',
524:'Gold PadillaCamarinesNorte entails Philippines; true coarse birthplace retained',
525:'Gold2010/2004 and FreeWilly23Mar2010US date correct; earlierOnceUponTimeHighSchool comparison correct',
526:'Gold1995/26Nov2010 and earlierItsGreat comparison correct',
527:'Native ShammiKapoor explicitly both1968Brahmachari/1982VidhaataFilmfare awards support complete statement',
528:'Gold fatherIsaac; ordinary Andronikos1183-85/sonIsaac factual. Goal wrongly answers AlexiosI instead of Isaac (great-grandfather vs grandfather); effective unchanged query remains valid',
529:'Actual reader inspected; Williambio says born/diedDuesseldorf but no burialplace, otherpeople burials not his. Reasonable burial abstention correct; cannot equate death and burial',
530:'Gold Malcolm20th→Norman19th matches family QA; goal genericWhoisNorman drops paternal-grandfather relation',
531:'Ordinary WestGermany vs Germany facts true per native film descriptions. Goal denies common German country by treating historical WestGermany descriptor as different nationality; gold bothGerman, country-normalization/comparison error',
532:'Gold bothAmerican and native film1935/2014 match QA; bothAmerican rewrite equivalent',
533:'Ordinary BonJovi performer correct. Goal reports true Grammy nomination but gives no received award, adds unsupported task restriction specifically for song; reader explicitly lists Grammy win, HallOfFame, MeritAward. Wrong requested-attribute answer despite some true background facts',
534:'Native Sibyl explicitly eldestsonFrancis and successorgrandsonMichael; ordinary1 wrongly lists grandsonMichael as child. Ordinary2 answers correct Francis spouseMary, but effective query includes wrong-generation Michael from prior answer. Goal correct Mary though genericWhoisMary rewrite drops child-in-law relation',
535:'Gold Motwane1976/DelToro1964 and earlierHellboy comparison correct',
536:'Gold Varda2019/Crevenna1996 and laterCleo comparison correct',
537:'Gold Emes1949/Baggot1879 and youngerYob comparison correct; laterbirth equivalent younger',
538:'Gold HenryRadcliffe1507 matches husband/year answer; incomplete daymonth not invented',
539:'Gold Carnimeo2016/Korda1956 and earlierHarrisonBarrison comparison correct',
540:'Native JacquesRaverat explicitly6Mar1925 multipleSclerosiscomplications verifies complete answer',
541:'Gold bothBritish supports all facts; awkward but connector not a false nationality fact',
542:'Gold Erice1940/Marchent1926 and olderAvenger comparison correct',
543:'Gold1975/1988 and earlierBloodsucker comparison correct',
544:'Gold Squitieri2017/Iliu1968 and earlierMillGoodLuck comparison correct',
545:'Native Namahana explicitly both Kamehameha marriage and arrangedmarriage GideonLaanui. Child Gideon is true partial spouse alternative, Hawaiian nationality correct; gold singleKamehameha does not invalidate second husband',
546:'Gold Sharp2011/Gavaldon1986 and earlierHiddenOne comparison correct',
547:'Native Hirsch explicitly graduatePutneyVermont and HampshireAmherstMA confirms full answer',
548:'Gold Stanton22May1956/Henabery18Feb1976 supports all QA. Rewrite retains named films, dates and earlierdeath relation; awkward wording still preserves requested comparison'
}
flows={i:{'i':i,'all_nodes_inspected':True,'reason':s} for i,s in notes.items()}
for i in [507,535,536,537,539,542,544,546,548]:flows[i]['bindings']={'3':[1],'4':[2]}
for i in [504,508,509,510,511,512,513,516,517,518,519,520,521,524,527,529,538,540,545,547]:flows[i]['bindings']={'2':[1]}
flows[507]['bindings']['5']=[3]
flows[548]['bindings']['5']=[3,4]
for i in [522,532]:flows[i]['bindings']={'3':[1,2]}
flows[506].update(incorrect_answers=[2,3],incorrect_fidelity=[3],incorrect_targets=[3],bindings={'2':[1],'3':[2]},answer_subtypes={'2':'wrong_person_same_name','3':'propagated_wrong_father'})
flows[507].update(incorrect_fidelity=[5],incorrect_targets=[5])
flows[519].update(pending_answer_facts=[2],answer_subtypes={'2':'pending_exact_death_town'})
flows[520].update(pending_answer_facts=[2],answer_subtypes={'2':'pending_extra_father_occupation'})
flows[524]['answer_subtypes']={'2':'factual_coarse_place_precision'}
flows[528].update(incorrect_answers=[3],bindings={'2':[1]},answer_subtypes={'3':'family_generation_confusion'})
flows[530].update(incorrect_fidelity=[3],incorrect_targets=[3],bindings={'2':[1],'3':[2]})
flows[531].update(incorrect_answers=[3],answer_subtypes={'3':'historical_country_normalization_error'})
flows[533].update(incorrect_answers=[2],bindings={'2':[1]},answer_subtypes={'2':'nonresponsive_nomination_instead_received_award'})
flows[534].update(incorrect_answers=[1],incorrect_fidelity=[3],incorrect_targets=[2,3],bindings={'2':[1],'3':[2]},answer_subtypes={'1':'mixed_correct_child_wrong_grandchild'})
for i in [510,529]:flows[i]['answer_subtypes']={'2':'reasonable_abstention'}
flows[545]['answer_subtypes']={'1':'factual_partial_list_alternative_spouse'}
assert set(flows)==set(range(504,549))
write(Path(__file__).parent/'batch_s504_548.json',{'batch_id':'s504_548','axis':'stage_node','manually_reviewed_flows':list(flows.values())})
