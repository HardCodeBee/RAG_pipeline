"""Inventory existing P02 trajectories and old labels; no annotation or scoring."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT/'outputs/query_decomposition/hotpot_formal_eval_v1/p02_formal1500_v1_20261021'
Q = ROOT/'experiments/query_decomposition'
H = ROOT/'outputs/query_decomposition/hotpot_formal_eval_v1'
OUT = ROOT/'outputs/query_decomposition/p02_error_propagation_diagnostic_20261021'
DATASETS = ('2wiki', 'hotpotqa')
METHOD = 'p02_multigrain_timing_cachefix_v1'

def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def rows(path): return [json.loads(s) for s in path.read_text(encoding='utf-8-sig').splitlines() if s.strip()]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def rel(path): return path.relative_to(ROOT).as_posix()
def write(path, value): path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def ledger():
    with sqlite3.connect((H/'budget.sqlite3').as_uri()+'?mode=ro', uri=True) as db:
        n, actual, unknown = db.execute('SELECT count(*),sum(actual),sum(CASE WHEN actual IS NULL THEN reserved ELSE 0 END) FROM charges').fetchone()
    return {'rows':n, 'known_CNY':actual, 'unknown_reserved_CNY':unknown}

def main():
    before = ledger()
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    out = OUT/stamp
    out.mkdir(parents=True, exist_ok=False)
    scores = rows(FORMAL/'SCORES.jsonl')
    files = {FORMAL/'SCORES.jsonl', Q/'p02_formal1500_v1_20261021/references1500.local.frozen.jsonl',
             Q/'p02_formal1500_v1_20261021/questions1500.frozen.jsonl'}
    refs = {v['id']:v for v in rows(Q/'p02_formal1500_v1_20261021/references1500.local.frozen.jsonl')}
    questions = {v['id']:v for v in rows(Q/'p02_formal1500_v1_20261021/questions1500.frozen.jsonl')}
    completed = {}
    population = []
    inventory = {}
    for ds in DATASETS:
        selected = [s for s in scores if s['dataset']==ds]
        stats = {'recorded_statuses':dict(Counter(s['status'] for s in selected)),
                 'complete':Counter(), 'incomplete_prefix':Counter()}
        for s in selected:
            entry = {'id':s['id'], 'qid':s['qid'], 'dataset':ds, 'type':s['type'],
                     'status':s['status'], 'source':s['source'], 'has_recorded_final_EM':s['em'] is not None}
            if s['source']:
                p = ROOT/Path(s['source'].replace('\\','/'))
                c = read(p); files.add(p)
                assert c['id']==s['id'] and c['question']==questions[s['id']]['question']
                assert c['question'].strip()==refs[s['id']]['question'].strip()
                assert c.get('method', c.get('arm'))==METHOD
                successful = s['status'].startswith('success')
                bucket = stats['complete' if successful else 'incomplete_prefix']
                bucket['flows'] += 1
                nodes = c.get('nodes', [])
                ordinary = [n for n in nodes if n['role']=='ordinary']
                rewrites = [n for n in nodes if n.get('rewrite_request_id')]
                entry.update(source_sha256=sha(p), ordinary_nodes=len(ordinary),
                             reference_question_exact=c['question']==refs[s['id']]['question'],
                             question_binding='exact frozen generation input; reference may differ in outer whitespace only',
                             goal_nodes=sum(n['role']=='goal' for n in nodes), rewrite_events=len(rewrites))
                bucket['ordinary_nodes'] += len(ordinary)
                bucket['goal_nodes'] += sum(n['role']=='goal' for n in nodes)
                bucket['rewrite_events'] += len(rewrites)
                bucket['ordinary_rewrites'] += sum(n['role']=='ordinary' for n in rewrites)
                bucket['goal_rewrites'] += sum(n['role']=='goal' for n in rewrites)
                bucket['recorded_unchanged_rewrites'] += sum(n['rewritten_query']==n['request'] for n in rewrites)
                bucket['rejected_proposals'] += sum(bool(n.get('rewrite_rejection')) for n in rewrites)
                bucket['history_inclusions'] += sum(len(n.get('prior_complete_answers',[])) for n in rewrites)
                if successful:
                    assert s['em'] in (0,1) and c.get('method')==METHOD
                    bucket['empty_helper_list_flows'] += not ordinary
                    completed[s['qid']] = c
                else:
                    bucket['flows_with_recorded_nodes'] += bool(nodes)
            population.append(entry)
        inventory[ds] = {k:dict(v) if isinstance(v,Counter) else v for k,v in stats.items()}

    decomp_candidates = []
    for name in ['decomposition_error_downstream_v1_20261018/quality_labels.frozen.jsonl',
                 'decomposition_error_expand60_v1_20261019/reviews/ALL_REVIEWED.frozen.jsonl']:
        p = Q/name; files.add(p); rr = rows(p)
        overlap = {ds:sum(r.get('id') in {c['id'] for c in completed.values() if c['dataset']==ds} for r in rr) for ds in DATASETS}
        decomp_candidates.append({'source':rel(p), 'existing_label_rows':len(rr), 'complete_flow_qid_overlap':overlap})

    child_review = H/'child_answer_accuracy_v1_20261017/round10/reassessment_v2/GRADES_SEPARATE.json'
    files.add(child_review)
    child_candidates = []
    for g in read(child_review):
        qid = next((qid for qid in completed if qid in g['case_id']),None)
        if not qid: continue
        c = completed[qid]
        for n in c['nodes']:
            if n['role']=='ordinary' and n['request']==g['current_subquestion'] and n['answer']==g['answer']:
                child_candidates.append({'id':c['id'], 'step_id':n['step_id'], 'prior_case_id':g['case_id'],
                    'prior_condition':g['condition'], 'prior_review_source':rel(child_review),
                    'current_question_and_actual_answer_exact':True,
                    'original_question_exact':c['question']==g['original_query'],
                    'status':'candidate_only; no label imported; grounding and scope still require verification'})

    rewrite_candidates = []
    for name in ['rewrite_correctness_v1_20261017','rewrite_correctness_v2_20261017','rewrite_correctness_confirm40_20261017']:
        p = Q/name/'inputs.frozen.jsonl'; files.add(p)
        report = H/name/'CASE_REVIEW.jsonl'
        review = {v['input_id']:v for v in rows(report)} if report.exists() else {}
        if report.exists(): files.add(report)
        rr = rows(p); input_matches = []
        for r in rr:
            if r['qid'] not in completed: continue
            for n in completed[r['qid']]['nodes']:
                old_history = [(v['request'],v['answer']) for v in r['history']]
                new_history = [(v['request'],v['answer']) for v in n.get('prior_complete_answers',[])]
                if n.get('rewrite_request_id') and r['current_question']==n['request'] and old_history==new_history:
                    variants = review.get(r['input_id'],{}).get('variants',{})
                    c02 = variants.get('candidate_c02',{})
                    same_output = c02.get('proposed_rewrite')==n.get('raw_rewrite')
                    input_matches.append({'id':completed[r['qid']]['id'], 'step_id':n['step_id'],
                        'prior_input_id':r['input_id'], 'input_source':rel(p),
                        'candidate_c02_review_present':bool(c02),
                        'candidate_c02_output_exact':same_output, 'review_source':rel(report) if report.exists() else None,
                        'limitation':'Historical fidelity is not factual binding truth; no label imported'})
        rewrite_candidates.append({'experiment':name, 'qid_overlap':sum(r['qid'] in completed for r in rr),
                                   'exact_input_candidates':input_matches})

    write(out/'INVENTORY.json', {'snapshot_utc':datetime.now(timezone.utc).isoformat(), 'method':METHOD,
        'scope':'Existing old-protocol formal trajectories only; no requirement to complete500',
        'datasets':inventory, 'semantic_annotation_performed':False, 'conditional_probability_calculated':False,
        'ordinary_answers_exclude_goal':True, 'rewrites_include_goal_separately':True,
        'history_inclusion_is_not_proven_semantic_use':True})
    write(out/'PRIOR_LABEL_CANDIDATES.json', {'decomposition':decomp_candidates,
        'child_factual_candidates':child_candidates, 'rewrite':rewrite_candidates,
        'automatic_label_import':False, 'semantic_correctness_not_inferred_from_EM':True})
    (out/'FLOW_INVENTORY.jsonl').write_text(''.join(json.dumps(v,ensure_ascii=False)+'\n' for v in population),encoding='utf-8')
    write(out/'SOURCES.json', {'files':[{'path':rel(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(files)],
        'selection':'Authoritative SCORES source binding; no selection by correctness or best retry outcome'})
    after = ledger()
    write(out/'READ_ONLY_VERIFICATION.json', {'new_API_requests':0,'new_GPU_jobs':0,'new_RAG_runs':0,
        'new_semantic_annotations':0,'new_final_scoring':0,'conditional_probabilities_computed':False,
        'ledger_before':before,'ledger_after':after,'global_ledger_unchanged':before==after,
        'main_evaluation_resumed':False})
    OUT.mkdir(parents=True,exist_ok=True)
    write(OUT/'LATEST.json', {'run_directory':rel(out),'status':'inventory_only_protocol_pending_user_review'})
    print(json.dumps({'run_directory':rel(out),'complete_flows':sum(v['complete']['flows'] for v in inventory.values()),
        'ordinary_answer_records':sum(v['complete']['ordinary_nodes'] for v in inventory.values()),
        'complete_flow_rewrite_records':sum(v['complete']['rewrite_events'] for v in inventory.values()),
        'incomplete_prefix_rewrite_records':sum(v['incomplete_prefix']['rewrite_events'] for v in inventory.values()),
        'candidate_child_factual_labels':len(child_candidates),'ledger_unchanged':before==after},ensure_ascii=False))

if __name__=='__main__': main()
