import sys,json
from prepare_inventory import OUT,rows
p=[p for p in rows(OUT/'offline_review_v2/STAGE_PACKETS.jsonl') if not p.get('complete')][int(sys.argv[1])-1]
for n in p['nodes']:
 if len(sys.argv)>2 and n['step_id']!=int(sys.argv[2]):continue
 print(json.dumps({'s':n['step_id'],'q':n['request'],'a':n['answer'],'docs':[{'title':d['source'],'text':d['text']} for d in n['reader_packet']['docs']]},ensure_ascii=False,separators=(',',':')))
