"""Verify protection/pause/billing and publish honest diagnostic coverage."""
from collections import Counter
from datetime import datetime,timezone
from prepare_inventory import ROOT,OUT,read,write,sha,ledger,rows,H
import sqlite3
run=OUT/'offline_review_v2';plan=ROOT/'experiments/query_decomposition/unified_rag_eval_v1_20261021'
protected=read(plan/'PROTECTED_FILES_BEFORE.json')
changed=[p for p,h in protected.items() if sha(ROOT/p)!=h]
assert not changed,changed
start=read(run/'START_VERIFICATION.json');current=ledger()
with sqlite3.connect((H/'budget.sqlite3').as_uri()+'?mode=ro',uri=True) as db:
    additions=[{'namespace':ns,'rows':n,'known_CNY':a or 0,'unknown_reserved_CNY':u or 0}
        for ns,n,a,u in db.execute('SELECT namespace,count(*),sum(actual),sum(CASE WHEN actual IS NULL THEN reserved ELSE 0 END) FROM charges WHERE rowid>? GROUP BY namespace',(start['ledger_before']['rows'],))]
decision_ids={d['id'] for d in rows(plan/'DECISIONS.jsonl')}
external_scopes={
 'p02_childprompt_selfcontained_quick90_v1_20261021':'P02_CHILDPROMPT_QUICK90_EXTERNAL_PAYLOAD_APPROVED',
 'p02_prompt_minimal_ablation_quick90_v1_20261021':'P02_PROMPT_MINIMAL_ABLATION_QUICK90_V1_20261021'}
for v in additions:
 v['approval_ids']=[did for scope,did in external_scopes.items() if scope in v['namespace'] and did in decision_ids]
external_known=all(v['approval_ids'] for v in additions)
assert not additions or external_known,('New shared-ledger activity requires source audit',additions)
assert (plan/'STOP_REQUESTED').exists()
labs=[l for f in sorted((run/'reviews').glob('*.json')) for l in read(f)['labels']]
stage=[l for l in labs if l['axis']=='stage_node'];stage_ids={l['id'] for l in stage}
amendments=read(run/'STAGE_AMENDMENTS.json')['amendments']
for l in stage:
 for a in amendments:
  if l['review_index']==a['review_index'] and l['step_id']==a['step_id']:l.update({k:a[k] for k in ['answer_correct','answer_subtype'] if k in a})
packets={p['id']:p for p in rows(run/'STAGE_PACKETS.jsonl') if p.get('complete')}
complete_ids={i for i in stage_ids if len([l for l in stage if l['id']==i])==len(packets[i]['nodes'])}
published=(run/'REPORT.md').exists() and (run/'VALIDATION.json').exists()
pending_count=sum(l['answer_correct'] is None for l in stage)
v={'updated_utc':datetime.now(timezone.utc).isoformat(),'proposal_only':False,'review_status':'completed_with_pending_fact_workitems' if published else 'in_progress',
 'new_semantic_annotations':len(labs),'decomposition_labels':len([l for l in labs if l['axis']=='decomposition']),
 'stage_node_labels':len(stage),'stage_complete_flows':len(complete_ids),
 'stage_complete_flows_by_dataset':dict(Counter(packets[i]['dataset'] for i in complete_ids)),
 'pending_factual_answer_labels':pending_count,
 'conditional_probabilities_computed':(run/'CONDITIONAL_PROBABILITIES.json').exists(),
 'all_stage_records_reviewed':len(complete_ids)==len(packets),
 'all_factual_truth_labels_settled':pending_count==0,
 'all_stage_labels_complete':len(complete_ids)==len(packets) and pending_count==0,
 'new_RAG_runs':0,'new_LLM_API_requests':0,'new_GPU_jobs':0,'external_judge_model_calls':0,
 'targeted_fact_check_web_only':True,'protected_source_hashes_unchanged':len(protected),
 'ledger_before':start['ledger_before'],'ledger_after':current,'global_ledger_unchanged':current==start['ledger_before'],
 'other_explicitly_approved_experiment_activity':additions,
 'other_activity_approval':sorted({i for v in additions for i in v['approval_ids']}),
 'diagnostic_generated_ledger_charges':0,
 'main_evaluation_resumed':False,'pause_marker_preserved':True,'main_execution_approval':False,
 'main_plan_revision_unchanged':6,'run_directory':run.relative_to(ROOT).as_posix()}
write(run/'CURRENT_VERIFICATION.json',v)
write(plan/'reviews/20261021_error_propagation/VERIFICATION.json',v)
write(OUT/'LATEST.json',{'run_directory':run.relative_to(ROOT).as_posix(),'status':'completed_offline_diagnostic_with_pending_facts' if published else 'approved_offline_semantic_review_in_progress','verification':'offline_review_v2/CURRENT_VERIFICATION.json','report':'offline_review_v2/REPORT.md' if published else None})
print({k:v[k] for k in ['new_semantic_annotations','stage_complete_flows_by_dataset','pending_factual_answer_labels','protected_source_hashes_unchanged','global_ledger_unchanged','main_evaluation_resumed']})
