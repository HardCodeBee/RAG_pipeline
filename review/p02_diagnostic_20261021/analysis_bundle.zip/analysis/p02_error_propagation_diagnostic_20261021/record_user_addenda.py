"""Append the user's diagnostic-specific decisions; never resume the main plan."""
import json
from datetime import datetime, timezone
from prepare_inventory import ROOT, OUT, read, write, sha

plan=ROOT/'experiments/query_decomposition/unified_rag_eval_v1_20261021'
rules=[
 {'id':'P02_DIAG_UNRESOLVED_FACT_WORK_ITEMS_APPROVED',
  'authority':'User: temporarily keep unresolved facts pending; continue remaining annotation and statistics',
  'rule':'No forced true/false label on unresolved claims; exclude only affected labels/tables with explicit counts, not unrelated query outcomes'},
 {'id':'P02_DIAG_COMPLETE_STATEMENT_REQUIRED',
  'authority':'User: complete answer is required; if complete statement is wrong, count incorrect',
  'rule':'Correct entity value does not rescue a false relation or other false statement in the answer; retain value-correct subtype separately'},
 {'id':'P02_DIAG_LOCAL_EVIDENCE_FIRST_WEB_FALLBACK',
  'authority':'User: only use web when retrieval corpus cannot decide answer correctness; otherwise judge using retrieved material or dataset',
  'rule':'Use recorded retrieved material and native frozen dataset first; web only for unresolved or conflicting facts. Do not replace historical material time context with current2026 status by default'}]
log=plan/'DECISIONS.jsonl'
for r in rules:
    if r['id'] not in log.read_text(encoding='utf-8-sig'):
        with log.open('a',encoding='utf-8') as f:
            f.write(json.dumps({**r,'utc':datetime.now(timezone.utc).isoformat(),
                'new_RAG_or_external_judge':False,'main_evaluation_remains_paused':True},ensure_ascii=False)+'\n')
p=plan/'reviews/20261021_error_propagation/PROPOSAL.json';v=read(p)
v['approved_protocol']['user_addenda']=rules
v['approved_protocol']['full_statement_correctness']='Every asserted factual relation must be correct; correct answer value alone does not rescue false statement'
v['approved_protocol']['web_scope']='retrieved material/native dataset first; web only if local materials cannot determine correctness'
v['approved_protocol']['fact_pending']='User approved pending workflow, no truth label; exclude only affected table denominators and disclose'
md=p.with_suffix('.md');s=md.read_text(encoding='utf-8')
marker='## 已确认的后续边界'
if marker not in s:
    s+='\n'+marker+'\n\n- 集合回答无需列全，但完整回答中已经陈述的事实和关系必须正确；实体值正确不能挽救错误的完整关系句。\n- 原检索材料和原数据集优先；只有本地不能确定正确性时才定向联网核验，保持原材料所指的时间语境。\n- 已获准暂留确实未查清的事实工作项，不强制打真假标签；只扣除受影响表的对应项，不能连带删除已经可判的其它环节和最终端点。\n'
md.write_text(s,encoding='utf-8');v['proposal_sha256']=sha(md);write(p,v)
run=OUT/'offline_review_v2'
write(run/'PENDING_FACTS.json',{'truth_label_class_added':False,'user_approved_workflow':True,'items':[
 {'review_index':309,'step_id':2,'role':'goal','claim':'VSC founder JonathanGregg bornNYC','status':'pending_identity_bound_birthplace','sources':['https://jongregg.com/vsc/','https://www.flynnvt.org/Your-Visit/Venues/Amy-E-Tarrant-Gallery/Exhibit-Archives/Jon-Gregg'],'reason':'Founder painter and same-name musician are different; current local/official founder material does not establish birthplace'},
 {'review_index':319,'step_id':2,'role':'goal','claim':'FerencEsterhazy1533 bornGalanta','status':'pending_conflicting_birthplaces','sources':['https://www.wikidata.org/wiki/Q5444007','https://de.wikipedia.org/wiki/Nikolaus_Esterh%C3%A1zy','https://www.esterhazygalanta.sk/en/history'],'reason':'Galanta versus Pressburg conflict; family museum only verifies inheritance not birth'}]})
write(run/'STAGE_AMENDMENTS.json',{'applied_before_any_stage_outcome_merge':True,
 'authority':'P02_DIAG_COMPLETE_STATEMENT_REQUIRED','amendments':[
 {'review_index':329,'step_id':2,'answer_correct':False,
  'answer_subtype':'reasonable_target_abstention_but_false_evidence_statement',
  'reason':'Death-place absent, but complete answer falsely states composer not identified even though both actual film paragraphs identify Mozart. User requires complete statement correctness; value/abstention alone does not rescue false assertion.'}]})
print('User addenda recorded;2 goal facts pending;1 stage correction recorded transparently.')
