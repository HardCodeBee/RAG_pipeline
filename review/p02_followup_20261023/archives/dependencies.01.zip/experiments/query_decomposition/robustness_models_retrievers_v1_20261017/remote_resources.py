"""Portable frozen resources and batched, exact retrieval for the A6000 run.

This adapter reuses the frozen project's BM25 scorer and exact dense scanner.
It does not rebuild BGE vectors, change corpus rows, or rewrite signed offsets.
All paths in a staged manifest are relative to that manifest's directory.
"""
from __future__ import annotations

import argparse
from concurrent.futures import Future
from collections import OrderedDict
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import queue
import re
import shutil
import sqlite3
import threading
import time

import numpy as np

DATASETS = ("hotpotqa", "2wiki", "musique")
BGE_REVISION = "5c38ec7c405ec4b44b94cc5a9bb96e735b38267a"
E5_MODEL = "intfloat/e5-base-v2"


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix + ".partial")
    partial.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    partial.replace(path)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":")).encode("utf-8")).hexdigest()


def _inside(root, relative):
    root = Path(root).resolve()
    relative = Path(relative)
    result = (root / relative).resolve()
    if relative.is_absolute() or not result.is_relative_to(root):
        raise ValueError(f"Resource path escapes its dataset directory: {relative}")
    return result


def resource_plan(workspace_root):
    """Enumerate exact files for a builder; no large files are read or copied.

    Returns files with source, target (relative to bundle root), bytes and SHA,
    plus portable_manifests keyed by their bundle-relative destination.
    """
    root = Path(workspace_root).resolve()
    files, manifests = [], {}
    base = root / "experiments/query_decomposition"
    for dataset in DATASETS:
        original = read(base / ("query_form_ablation_v1/resources.json" if dataset == "hotpotqa"
                               else f"comprehensive_eval_v1_20261015/resources_frozen/{dataset}.json"))
        corpus, bge, sparse = original["corpus"], original["dense"]["bge"], original["bm25"]
        source_manifest = read(corpus["manifest"])
        descriptors = []

        def add(source, relative, expected_sha=None):
            source = Path(source)
            descriptor = {"path": relative, "size_bytes": source.stat().st_size,
                          "sha256": expected_sha or sha(source)}
            descriptors.append(descriptor)
            files.append({"source": str(source), "target": f"resources/{dataset}/{relative}",
                          "size_bytes": descriptor["size_bytes"], "sha256": descriptor["sha256"]})

        add(corpus["manifest"], "corpus/FROZEN_SOURCE.json", corpus["manifest_sha256"])
        add(corpus["chunks"], "corpus/chunks.jsonl", corpus["chunks_sha256"])
        offsets_hash = source_manifest.get("offsets_sha256")
        if not offsets_hash:
            offsets_hash = read(Path(bge["build"]) / "manifest.json")["artifacts"]["chunk_offsets"]["sha256"]
        add(corpus["offsets"], "corpus/chunk_offsets.npy", offsets_hash)
        build = Path(bge["build"])
        if dataset == "hotpotqa":
            add(build / "manifest.json", "bge/FROZEN_SOURCE.json", bge["manifest_sha256"])
            embeddings = read(build / "embeddings/manifest.json")
            add(build / "embeddings/manifest.json", "bge/embeddings/manifest.json",
                bge["embeddings_manifest_sha256"])
            parts = [(build / "embeddings" / p["file"], p["sha256"]) for p in embeddings["parts"]]
        else:
            frozen = read(build / "DENSE_FROZEN.json")
            add(build / "DENSE_FROZEN.json", "bge/FROZEN_SOURCE.json", bge["manifest_sha256"])
            parts = [(build / name, expected) for name, expected in frozen["part_sha256"].items()]
        for source, expected in parts:
            add(source, f"bge/embeddings/{source.name}", expected)
        sparse_dir = Path(sparse["directory"])
        sparse_manifest = read(sparse_dir / "manifest.json")
        add(sparse_dir / "manifest.json", "bm25/manifest.json", sparse["manifest_sha256"])
        add(sparse_dir / "index.sqlite3", "bm25/index.sqlite3",
            sparse_manifest["artifacts"]["database"]["sha256"])
        manifests[f"resources/{dataset}/manifest.json"] = {
            "schema_version": 1, "dataset": dataset, "status": "frozen",
            "corpus": {"dataset": dataset, "documents": corpus["documents"],
                       "chunks": "corpus/chunks.jsonl", "offsets": "corpus/chunk_offsets.npy",
                       "chunks_sha256": corpus["chunks_sha256"],
                       "manifest": "corpus/FROZEN_SOURCE.json",
                       "manifest_sha256": corpus["manifest_sha256"]},
            "dense": {
                "bge": {"source": "bge/embeddings", "query_model": bge["query_model"],
                        "query_revision": bge["query_revision"], "query_prefix": "",
                        "document_prefix": "", "space": bge["space"]},
                "e5": {"source": "e5", "frozen_manifest": "e5/E5_FROZEN.json"}},
            "bm25": {**{k: v for k, v in sparse.items() if k != "directory"}, "directory": "bm25"},
            "files": descriptors,
            "policy": {"identical_id": "retrieve_k_plus_one_filter_original_qid_then_keep_k",
                       "dense": "frozen StreamingFlatIPIndex exact float32 inner product",
                       "sparse": "frozen sqlite_bm25_v1, including short returns",
                       "offsets": "accept original int64 or uint64 bytes; do not rewrite"}}
    return {"schema_version": 1, "files": files, "portable_manifests": manifests,
            "size_bytes": sum(f["size_bytes"] for f in files),
            "dataset_sizes": {d: sum(f["size_bytes"] for f in files
                                     if f["target"].startswith(f"resources/{d}/")) for d in DATASETS}}


def stage_resources(workspace_root, bundle_root, hardlink=False):
    """Optional staging for archive creation. Existing files must match size."""
    plan = resource_plan(workspace_root)
    bundle_root = Path(bundle_root).resolve()
    for entry in plan["files"]:
        destination = _inside(bundle_root, entry["target"])
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            if destination.stat().st_size != entry["size_bytes"]:
                raise ValueError(f"Existing staged file has a different size: {destination}")
            continue
        if hardlink:
            destination.hardlink_to(entry["source"])
        else:
            shutil.copy2(entry["source"], destination)
    for relative, manifest in plan["portable_manifests"].items():
        save(_inside(bundle_root, relative), manifest)
    return plan


def load_resources(manifest_path):
    path = Path(manifest_path).resolve()
    data = read(path)
    if data.get("schema_version") != 1 or data.get("dataset") not in DATASETS:
        raise ValueError("Invalid portable dataset resource manifest")
    data["_manifest_path"] = str(path)
    data["_root"] = str(path.parent)
    return data


class PortableChunkStore:
    """Read immutable canonical rows with their original signed/unsigned offsets."""
    def __init__(self, chunks, offsets, expected_rows):
        self.path = Path(chunks)
        self.offsets = np.load(offsets, mmap_mode="r", allow_pickle=False)
        if self.offsets.ndim != 1 or self.offsets.dtype not in (np.dtype("uint64"), np.dtype("int64")):
            raise ValueError("Offsets must be the original int64/uint64 array")
        if len(self.offsets) != expected_rows or not len(self.offsets):
            raise ValueError("Offset count differs from frozen corpus")
        if int(self.offsets[0]) != 0 or int(self.offsets[-1]) >= self.path.stat().st_size:
            raise ValueError("Offsets are outside frozen corpus")
        if np.any(self.offsets[1:] <= self.offsets[:-1]):
            raise ValueError("Offsets must strictly increase")

    def __len__(self):
        return len(self.offsets)

    def get(self, vector_id):
        return self.get_many([vector_id])[0]

    def get_many(self, vector_ids):
        from src.persistence.artifact_io import decode_chunk_record_line
        result = []
        with self.path.open("rb") as source:
            for value in vector_ids:
                value = int(value)
                if not 0 <= value < len(self.offsets):
                    raise KeyError(value)
                source.seek(int(self.offsets[value]))
                result.append(decode_chunk_record_line(source.readline(), value))
        return result

    def close(self):
        self.offsets._mmap.close()


def _validate_frozen_sqlite(resources, root):
    """Check metadata of the byte-identical, previously validated frozen DB.

    All database bytes are SHA checked by verify_resources(full=True). Repeating
    foreign-key scans over unchanged postings would not establish a new fact.
    """
    from src.provenance import json_sha256
    from src.retrievers.sqlite_bm25 import _ANALYZER_SPEC, _metadata_values, _required_table_columns
    spec = resources["bm25"]
    directory = _inside(root, spec["directory"])
    manifest = read(directory / "manifest.json")
    identity = manifest["identity"]
    source = identity["source_chunks"]
    bm25 = identity["bm25"]
    corpus = resources["corpus"]
    if (manifest.get("schema_version") != 1 or manifest.get("status") != "complete"
            or manifest.get("backend") != "sqlite_bm25_v1"
            or manifest.get("document_count") != corpus["documents"]
            or manifest.get("sparse_index_id") != spec["sparse_index_id"]
            or manifest.get("identity_sha256") != json_sha256(identity)
            or manifest["sparse_index_id"] != "sqlite_bm25_" + manifest["identity_sha256"][:16]
            or any(identity["analyzer"].get(k) != v for k, v in _ANALYZER_SPEC.items())
            or identity.get("backend") != "sqlite_bm25_v1"
            or bm25.get("k1") != spec["k1"] or bm25.get("b") != spec["b"]
            or bm25.get("method") != "lucene"
            or source.get("sha256") != corpus["chunks_sha256"]
            or source.get("rows") != corpus["documents"]):
        raise ValueError("Frozen BM25 metadata or parameters differ")
    descriptor = manifest["artifacts"]["database"]
    declared = next(item for item in resources["files"] if item["path"] == spec["directory"] + "/index.sqlite3")
    if descriptor.get("sha256") != declared["sha256"] or descriptor.get("size_bytes") != declared["size_bytes"]:
        raise ValueError("Frozen database identity differs from portable manifest")
    database = directory / "index.sqlite3"
    if any(database.with_name(database.name + suffix).exists() for suffix in ("-wal", "-shm")):
        raise ValueError("Frozen BM25 database has unexpected WAL sidecars")
    connection = sqlite3.connect(database.resolve().as_uri() + "?mode=ro&immutable=1", uri=True)
    try:
        _required_table_columns(connection)
        metadata = _metadata_values(connection)
        expected = {"schema_version": 1, "backend": "sqlite_bm25_v1", "status": "complete",
                    "identity_sha256": manifest["identity_sha256"], "identity": identity,
                    "document_count": corpus["documents"], "next_vector_id": corpus["documents"],
                    "total_length": manifest["total_document_length"],
                    "average_document_length": manifest["average_document_length"]}
        if any(metadata.get(key) != value for key, value in expected.items()):
            raise ValueError("Frozen database metadata differs from source identity")
    finally:
        connection.close()


def verify_resources(resources_root, datasets=DATASETS, full=False, deep_sqlite=False):
    """SHA all frozen bytes once; restart checks preserve the full receipt."""
    full = bool(full or deep_sqlite)
    results = []
    for dataset in datasets:
        path = Path(resources_root) / dataset / "manifest.json"
        resources = load_resources(path)
        root = path.parent
        receipt = root / "VALIDATED.json"
        old = read(receipt) if receipt.exists() else None
        stamps = {}
        for entry in resources["files"]:
            artifact = _inside(root, entry["path"])
            stat = artifact.stat()
            if stat.st_size != entry["size_bytes"]:
                raise ValueError(f"Resource byte size changed: {artifact}")
            stamps[entry["path"]] = [stat.st_size, stat.st_mtime_ns]
            if full and sha(artifact) != entry["sha256"]:
                raise ValueError(f"Resource SHA-256 mismatch: {artifact}")
        corpus = resources["corpus"]
        chunks = PortableChunkStore(_inside(root, corpus["chunks"]), _inside(root, corpus["offsets"]), corpus["documents"])
        chunks.close()
        if full:
            _validate_frozen_sqlite(resources, root)
            if deep_sqlite:
                from src.retrievers.sqlite_bm25 import validate_sqlite_bm25_index
                validate_sqlite_bm25_index(_inside(root, resources["bm25"]["directory"]))
        stamp = {"schema_version": 1, "manifest_sha256": sha(path), "files": stamps,
                 "sparse_validation": "frozen_database_full_sha256_and_manifest_metadata" if full else "unchanged_verified_file_stamps",
                 "deep_sqlite_revalidated": bool(deep_sqlite),
                 "fully_verified": bool(full or (old and old.get("fully_verified")
                                                 and old.get("files") == stamps
                                                 and old.get("manifest_sha256") == sha(path)))}
        save(receipt, stamp)
        results.append({"dataset": dataset, "documents": corpus["documents"],
                        "fully_verified": stamp["fully_verified"], "file_count": len(stamps)})
    return results


class E5Encoder:
    """Official E5-v2 masked mean, L2 normalization, float32 and max512."""
    def __init__(self, revision, device="cpu", batch_size=128, local_path=None):
        import torch
        from transformers import AutoModel, AutoTokenizer
        if not re.fullmatch(r"[0-9a-f]{40}", revision):
            raise ValueError("E5 requires a pinned 40-character model commit")
        source = str(local_path) if local_path is not None else E5_MODEL
        options = {"local_files_only": True} if local_path is not None else {"revision": revision}
        self.tokenizer = AutoTokenizer.from_pretrained(source, **options)
        self.model = AutoModel.from_pretrained(source, **options).to(device).eval()
        self.device, self.batch_size = device, batch_size
        self.torch = torch

    def encode(self, texts, prefix):
        rows = []
        with self.torch.inference_mode():
            for start in range(0, len(texts), self.batch_size):
                batch = self.tokenizer([prefix + t for t in texts[start:start+self.batch_size]],
                                       max_length=512, padding=True, truncation=True, return_tensors="pt")
                batch = {k: v.to(self.device) for k, v in batch.items()}
                hidden = self.model(**batch).last_hidden_state
                mask = batch["attention_mask"].bool()
                hidden = hidden.masked_fill(~mask[..., None], 0.0)
                values = hidden.sum(dim=1) / mask.sum(dim=1)[..., None]
                values = self.torch.nn.functional.normalize(values, p=2, dim=1)
                rows.append(values.float().cpu().numpy())
        return np.ascontiguousarray(np.concatenate(rows), dtype=np.float32)

    def encode_queries(self, texts):
        return self.encode(texts, "query: ")


def build_e5(resources_root, datasets=DATASETS, device="cuda", batch_size=128,
             part_size=10000, revision=None):
    """Resume only committed, hash-checked shards; freeze encoder and corpus."""
    root = Path(resources_root)
    models_path = root / "MODELS_FROZEN.json"
    entry = read(models_path)["models"].get("e5-base-v2") if models_path.exists() else None
    if entry:
        if entry["repo_id"] != E5_MODEL or (revision and revision != entry["revision"]):
            raise ValueError("E5 model lock conflicts with requested encoder")
        revision = entry["revision"]
    local_model = root.parent / entry["local_path"] if entry else None
    pin_path = root / "E5_MODEL_FROZEN.json"
    if pin_path.exists():
        pin = read(pin_path)
        if revision and pin["revision"] != revision:
            raise ValueError("Requested E5 revision differs from already frozen encoder")
    else:
        if revision is None:
            from huggingface_hub import HfApi
            revision = HfApi().model_info(E5_MODEL).sha
        if not re.fullmatch(r"[0-9a-f]{40}", revision or ""):
            raise ValueError("Could not resolve immutable E5 revision")
        pin = {"model": E5_MODEL, "revision": revision, "dimension": 768,
               "max_sequence_length": 512, "pooling": "masked_mean", "normalized": True,
               "query_prefix": "query: ", "document_prefix": "passage: ", "dtype": "float32"}
        save(pin_path, pin)
    encoder = None
    for dataset in datasets:
        resources = load_resources(root / dataset / "manifest.json")
        dataset_root = Path(resources["_root"])
        folder = dataset_root / "e5"
        folder.mkdir(exist_ok=True)
        frozen_path = folder / "E5_FROZEN.json"
        identity = {"encoder": pin, "source_sha256": resources["corpus"]["chunks_sha256"],
                    "documents": resources["corpus"]["documents"], "part_size": part_size}
        if frozen_path.exists():
            frozen = read(frozen_path)
            if frozen["identity"] != identity:
                raise ValueError("Frozen E5 build configuration differs")
            for part in frozen["parts"]:
                if sha(folder / part["file"]) != part["sha256"]:
                    raise ValueError("Existing frozen E5 shard changed")
            print(json.dumps({"dataset": dataset, "status": "e5_already_complete"}), flush=True)
            continue
        progress_path = folder / "ENCODING_PROGRESS.json"
        progress = read(progress_path) if progress_path.exists() else {"identity": identity, "parts": []}
        if progress["identity"] != identity:
            raise ValueError("Cannot resume E5 with different encoder/corpus/part size")
        for part in progress["parts"]:
            if sha(folder / part["file"]) != part["sha256"]:
                raise ValueError("Committed E5 resume shard changed")
        done = sum(p["rows"] for p in progress["parts"])
        offset_values = np.load(_inside(dataset_root, resources["corpus"]["offsets"]), mmap_mode="r")
        with _inside(dataset_root, resources["corpus"]["chunks"]).open("rb") as source:
            if done < len(offset_values):
                source.seek(int(offset_values[done]))
            else:
                source.seek(0, 2)
            while done < identity["documents"]:
                stop_marker = os.environ.get("RAG_STOP_FILE")
                if stop_marker and Path(stop_marker).is_file():
                    save(progress_path, progress)
                    print(json.dumps({"dataset": dataset, "status": "e5_interrupted_for_resume",
                                      "done": done, "documents": identity["documents"]}), flush=True)
                    raise SystemExit(75)
                texts = [json.loads(source.readline())["text"]
                         for _ in range(min(part_size, identity["documents"] - done))]
                if encoder is None:
                    encoder = E5Encoder(pin["revision"], device, batch_size, local_model)
                vectors = encoder.encode(texts, pin["document_prefix"])
                if vectors.shape != (len(texts), 768) or not np.isfinite(vectors).all():
                    raise ValueError("Invalid E5 encoding output")
                filename = f"part-{len(progress['parts']):05d}.npy"
                path = folder / filename
                partial = folder / (filename + ".partial")
                with partial.open("wb") as output:
                    np.save(output, vectors, allow_pickle=False)
                partial.replace(path)
                part = {"file": filename, "rows": len(texts), "shape": [len(texts), 768],
                        "start_row": done, "sha256": sha(path), "size_bytes": path.stat().st_size}
                progress["parts"].append(part)
                done += len(texts)
                save(progress_path, progress)
                print(json.dumps({"dataset": dataset, "status": "e5_encoding", "done": done,
                                  "documents": identity["documents"]}), flush=True)
        # Standard immutable manifest is understood by the original exact scanner.
        manifest = {"schema_version": 1, "dimension": 768, "dtype": "float32",
                    "total_rows": done, "parts": progress["parts"]}
        save(folder / "manifest.json", manifest)
        save(frozen_path, {"status": "complete", "identity": identity, "parts": progress["parts"],
                           "embedding_manifest_sha256": sha(folder / "manifest.json")})


def _doc(chunk, rank, score):
    return {"rank": rank, "score": float(score), "doc_id": chunk.doc_id,
            "vector_id": chunk.vector_id, "source": chunk.source, "text": chunk.text,
            "block": f"[Chunk {rank} | source={chunk.source}, pages={chunk.page_start}-{chunk.page_end}]\n{chunk.text}"}


class _SharedKernel:
    """One query thread per dataset/backend; coalesces searches across methods."""
    def __init__(self, resources, backend, device, threads=4, batch_wait=0.03, max_batch=32):
        self.resources, self.backend, self.device = resources, backend, device
        self.root = Path(resources["_root"])
        self.threads, self.batch_wait, self.max_batch = threads, batch_wait, max_batch
        self.queue = queue.Queue()
        self.cache = OrderedDict()
        self.inflight = {}
        self.cache_lock = threading.Lock()
        self.index = self.encoder = self.sparse = self.chunks = None
        self.thread = threading.Thread(target=self._work, daemon=True,
                                       name=f"retrieval-{resources['dataset']}-{backend}")
        self.thread.start()

    def _load(self):
        if self.chunks is not None:
            return
        corpus = self.resources["corpus"]
        receipt_path = self.root / "VALIDATED.json"
        if not receipt_path.exists() or not read(receipt_path).get("fully_verified"):
            raise ValueError("Run resource verify --full once before evaluation")
        receipt = read(receipt_path)
        if receipt["manifest_sha256"] != sha(self.resources["_manifest_path"]):
            raise ValueError("Resource manifest changed after full verification")
        for relative, stamp in receipt["files"].items():
            stat = _inside(self.root, relative).stat()
            if [stat.st_size, stat.st_mtime_ns] != stamp:
                raise ValueError("Resource file changed after full verification")
        chunks = PortableChunkStore(_inside(self.root, corpus["chunks"]),
                                    _inside(self.root, corpus["offsets"]), corpus["documents"])
        if self.backend == "bm25":
            from src.retrievers.sqlite_bm25 import SQLiteBM25Artifact, SQLiteBM25Retriever
            directory = _inside(self.root, self.resources["bm25"]["directory"])
            artifact = SQLiteBM25Artifact(directory=directory, manifest=read(directory / "manifest.json"),
                                          database=directory / "index.sqlite3")
            self.sparse = SQLiteBM25Retriever(chunks, artifact,
                                              sparse_index_id=self.resources["bm25"]["sparse_index_id"])
        else:
            import torch
            import faiss
            from src.indexes.streaming_flat_index import StreamingFlatIPIndex
            torch.set_num_threads(self.threads)
            faiss.omp_set_num_threads(self.threads)
            spec = self.resources["dense"][self.backend]
            self.index = StreamingFlatIPIndex(_inside(self.root, spec["source"]), corpus_chunk_size=50000)
            if self.backend == "bge":
                from src.embedders.text_embedder import TextEmbedder
                self.encoder = TextEmbedder(backend="sentence_transformers", model_name=spec["query_model"],
                                           revision=spec["query_revision"], normalize=True, batch_size=32,
                                           query_prefix="", document_prefix="", max_sequence_length=512,
                                           local_files_only=True, device=self.device)
                if self.encoder.embedding_space("inner_product").to_dict() != spec["space"]:
                    raise ValueError("Frozen BGE query encoder space differs")
            else:
                frozen = read(_inside(self.root, spec["frozen_manifest"]))
                if frozen["identity"]["source_sha256"] != corpus["chunks_sha256"]:
                    raise ValueError("E5 was encoded against a different corpus")
                if sha(_inside(self.root, spec["source"]) / "manifest.json") != frozen["embedding_manifest_sha256"]:
                    raise ValueError("Frozen E5 vector manifest changed")
                models_path = self.root.parent / "MODELS_FROZEN.json"
                entry = read(models_path)["models"].get("e5-base-v2") if models_path.exists() else None
                if entry and entry["revision"] != frozen["identity"]["encoder"]["revision"]:
                    raise ValueError("E5 model revision differs from its frozen vectors")
                local_model = self.root.parent.parent / entry["local_path"] if entry else None
                self.encoder = E5Encoder(frozen["identity"]["encoder"]["revision"], self.device,
                                         local_path=local_model)
            expected_dimension = 384 if self.backend == "bge" else 768
            if self.index.count != corpus["documents"] or self.index.dimension != expected_dimension:
                raise ValueError("Incomplete or incompatible dense index")
        self.chunks = chunks

    def submit(self, qid, query, k):
        key = (qid, query, k)
        with self.cache_lock:
            if key in self.cache:
                self.cache.move_to_end(key)
                future = Future()
                future.set_result(self.cache[key])
                return future
            if key in self.inflight:
                return self.inflight[key]
            future = Future()
            self.inflight[key] = future
            self.queue.put((qid, query, k, future))
            return future

    def _work(self):
        while True:
            first = self.queue.get()
            if first is None:
                if self.sparse is not None:
                    self.sparse.close()
                if self.chunks is not None:
                    self.chunks.close()
                return
            jobs = [first]
            until = time.monotonic() + self.batch_wait
            while len(jobs) < self.max_batch:
                try:
                    next_job = self.queue.get(timeout=max(0.0, until-time.monotonic()))
                    if next_job is None:
                        self.queue.put(None)
                        break
                    jobs.append(next_job)
                except queue.Empty:
                    break
            try:
                self._load()
                packets = self._search(jobs)
                for job, packet in zip(jobs, packets):
                    with self.cache_lock:
                        key = tuple(job[:3])
                        self.inflight.pop(key, None)
                        self.cache[key] = packet
                        while len(self.cache) > 20000:
                            self.cache.popitem(last=False)
                    job[3].set_result(packet)
            except BaseException as exc:
                for job in jobs:
                    with self.cache_lock:
                        self.inflight.pop(tuple(job[:3]), None)
                    job[3].set_exception(exc)

    def close(self):
        """Release worker-owned SQLite and memmap handles after pending work."""
        self.queue.put(None)
        self.thread.join(timeout=60)
        if self.thread.is_alive():
            raise TimeoutError("Retrieval worker did not finish pending work")

    def _search(self, jobs):
        start = time.perf_counter()
        if self.backend == "bm25":
            packets = []
            for qid, query, k, _ in jobs:
                trace = self.sparse.retrieve_trace(query, k+1)
                hits = [hit for hit in trace.results if hit.chunk.doc_id != qid][:k]
                packets.append({"qid": qid, "query": query, "k": k,
                                "docs": [_doc(hit.chunk, rank, hit.score) for rank, hit in enumerate(hits, 1)],
                                "timings_ms": trace.timings_ms, "backend": "bm25"})
            return packets
        queries = [job[1] for job in jobs]
        tokenizer = self.encoder._model[0].tokenizer if self.backend == "bge" else self.encoder.tokenizer
        prefix = "" if self.backend == "bge" else "query: "
        counts = [len(tokenizer(prefix+query, add_special_tokens=True, truncation=False)["input_ids"])
                  for query in queries]
        vectors = np.ascontiguousarray(self.encoder.encode_queries(queries), dtype=np.float32)
        # All ready searches share each full-corpus scan; stable exact ranking unchanged.
        scores, ids = self.index.search_many(vectors, max(j[2] for j in jobs)+1,
                                             query_batch_size=len(jobs))
        packets = []
        for (qid, query, k, _), values, indices, count in zip(jobs, scores, ids, counts):
            docs = []
            for score, chunk in zip(values, self.chunks.get_many(indices.tolist())):
                if chunk.doc_id == qid:
                    continue
                docs.append(_doc(chunk, len(docs)+1, score))
                if len(docs) == k:
                    break
            if len(docs) != k:
                raise ValueError("Incomplete dense retrieval")
            packets.append({"qid": qid, "query": query, "k": k, "docs": docs,
                            "query_tokens": count, "encoder_truncated": count > 512,
                            "batch_queries": len(jobs), "batch_seconds": time.perf_counter()-start,
                            "backend": self.backend})
        return packets


_KERNELS = {}
_KERNELS_LOCK = threading.Lock()


class PortableRetrieval:
    """Frozen-method API with private store and shared batched resource kernels."""
    def __init__(self, store, resources, backend="bge", device="cpu", threads=4,
                 batch_wait=0.03, max_batch=32):
        self.store = store
        self.resources = load_resources(resources) if isinstance(resources, (str, Path)) else resources
        self.backend, self.device = backend, device
        identity = {"manifest": sha(self.resources["_manifest_path"]), "backend": backend}
        if backend == "e5":
            identity["e5_frozen_sha256"] = sha(_inside(self.resources["_root"],
                                                       self.resources["dense"]["e5"]["frozen_manifest"]))
        self.resource_identity = digest(identity)
        self.settings = (threads, batch_wait, max_batch)
        if backend not in {"bge", "bm25", "e5"}:
            raise ValueError("Unknown frozen retrieval backend")

    def _kernel(self, backend):
        identity = (self.resources["_manifest_path"], backend, self.device, self.settings,
                    self.resource_identity if backend == "e5" else None)
        with _KERNELS_LOCK:
            if identity not in _KERNELS:
                _KERNELS[identity] = _SharedKernel(self.resources, backend, self.device, *self.settings)
            return _KERNELS[identity]

    def load(self):
        # Real loading remains on the kernel thread to preserve SQLite affinity.
        return self._kernel(self.backend)

    def _many(self, cases, k, backend, namespace="retrieval"):
        if not isinstance(k, int) or isinstance(k, bool) or k <= 0:
            raise ValueError("k must be a positive integer")
        jobs = []
        for case in cases:
            qid, query = case["qid"], case["query"]
            if not isinstance(query, str) or not query.strip():
                raise ValueError("Retrieval query must be a nonempty string")
            key = digest(["portable_exact_v1", self.resources["dataset"], backend,
                          self.resource_identity, self.resources["corpus"]["chunks_sha256"], qid, query, k])
            cached = self.store.get(namespace, key)
            future = None if cached is not None else self._kernel(backend).submit(qid, query, k)
            jobs.append((key, namespace, cached, future))
        results = []
        for key, namespace, cached, future in jobs:
            packet = cached if cached is not None else future.result()
            if cached is None:
                self.store.put(namespace, key, packet)
                self.store.event("retrieval", backend=backend, qid=packet["qid"], query=packet["query"],
                                 k=k, doc_ids=[d["doc_id"] for d in packet["docs"]])
            results.append(deepcopy(packet))
        self.store.export()
        return results

    def retrieve_many(self, cases, k):
        return self._many(cases, k, self.backend)

    def retrieve(self, qid, query, k):
        return self.retrieve_many([{"qid": qid, "query": query}], k)[0]

    def retrieve_sparse(self, qid, query, k):
        return self._many([{"qid": qid, "query": query}], k, "bm25", namespace="sparse_retrieval")[0]


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    inventory = commands.add_parser("inventory")
    inventory.add_argument("--workspace-root", default=".")
    inventory.add_argument("--output")
    stage = commands.add_parser("stage")
    stage.add_argument("--workspace-root", default=".")
    stage.add_argument("--bundle-root", required=True)
    stage.add_argument("--hardlink", action="store_true")
    verify = commands.add_parser("verify")
    verify.add_argument("--resources-root", default="resources")
    verify.add_argument("--datasets", nargs="+", choices=DATASETS, default=DATASETS)
    verify.add_argument("--full", action="store_true")
    verify.add_argument("--deep-sqlite", action="store_true", help="Also repeat costly postings/foreign-key scans; implies --full")
    e5 = commands.add_parser("build-e5")
    e5.add_argument("--resources-root", default="resources")
    e5.add_argument("--datasets", nargs="+", choices=DATASETS, default=DATASETS)
    e5.add_argument("--device", default="cuda", choices=("cpu", "cuda"))
    e5.add_argument("--batch-size", default=128, type=int)
    e5.add_argument("--part-size", default=10000, type=int)
    e5.add_argument("--revision")
    args = parser.parse_args(argv)
    if args.command == "inventory":
        result = resource_plan(args.workspace_root)
        if args.output:
            save(args.output, result)
        print(json.dumps({k: v for k, v in result.items() if k not in {"files", "portable_manifests"}}, indent=2))
    elif args.command == "stage":
        result = stage_resources(args.workspace_root, args.bundle_root, args.hardlink)
        print(json.dumps({"size_bytes": result["size_bytes"], "files": len(result["files"])}))
    elif args.command == "verify":
        print(json.dumps(verify_resources(args.resources_root, args.datasets, args.full, args.deep_sqlite), indent=2))
    else:
        if args.batch_size <= 0 or args.part_size <= 0:
            parser.error("batch-size and part-size must be positive")
        build_e5(args.resources_root, args.datasets, args.device, args.batch_size,
                 args.part_size, args.revision)


if __name__ == "__main__":
    main()
