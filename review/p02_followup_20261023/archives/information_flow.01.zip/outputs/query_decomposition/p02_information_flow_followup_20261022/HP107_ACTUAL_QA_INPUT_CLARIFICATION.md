# HP107 ordinary3 实际 QA 输入澄清

本注释纠正 V6 对“实际改写问题”措辞的含糊之处。**回答器实际收到的是原始描述问题，检索改写没有替换 child_prompt 的 Current subquestion。** 不改原 ordinary3=False 标签、原生分数、统计、索引记录或 V6 文件字节。

## 原始记录

- query_id：`hotpotqa:5a7a616355429941d65f25f7`，ordinary step3。
- 源文件：`outputs/query_decomposition/hotpot_formal_eval_v1/p02_formal1500_v1_20261021/rounds/r000/cases/hotpotqa/p02_multigrain_timing_cachefix_v1/5a7a616355429941d65f25f7.json`。
- SHA256：`8dad533a39bb97ce4ad885d6ad3d18e7ba82bb3b495384b6c9302db92773276c`。审阅包 node3 与源文件 node3 完全相等。

| 字段 | 原文 | 源文件行 |
|---|---|---:|
| request | What is the county seat of the Ohio county where the team that would become the Little Giants was located? | 565 |
| rewritten_query | What is the county seat of Licking County, Ohio? | 683 |
| child_prompt Current subquestion #3 | What is the county seat of the Ohio county where the team that would become the Little Giants was located? | 888 |
| answer | The county seat of Licking County, Ohio, is Newark. | 566 |

## 实际 child_prompt 的关联历史

```text
#1 Question: What team would become the Little Giants?
Answer: The Newark Little Giants would become the Little Giants.

#2 Question: In what Ohio county was the team that would become the Little Giants located?
Answer: The team that would become the Little Giants was located in Licking County, Ohio.

Current subquestion #3:
What is the county seat of the Ohio county where the team that would become the Little Giants was located?
```

同一 prompt 明确规定：先前答案是候选中间结果，不是验证过的证据；匹配材料直接支持不同事实时可以纠正。reader第2块支持 Licking县治Newark，第9块支持 YoungstownPuddlers 后称LittleGiants。因此不能把错误历史中的Licking直接当作当前问题已经核实的范围。

## 应区分的三个判断

1. **独立事实命题为真**：Licking县治是Newark，实际reader支持。
2. **对检索改写语义响应**：该答案响应“Licking的县治是什么”。
3. **对实际QA题是否正确响应**：实际题仍有真实球队限定；回答错误县的县治，没有正确完成实际送给回答器的题目。不能因此称旧False标签有误。

V6 关于上游错误球队、NJ/Ohio同名城市混接及下游传播的观察保留；但将“回答器收到原始问题”写成“实际改写问题”的表述应由此注释限定。原V6不覆盖重写，本文作为独立澄清随当前指针引用。索引语义以实际child_prompt的Current subquestion为准，不能用rewritten_query替代。

## 保护检查

JSON附录保存确切字段、实际task前缀、历史、读入证据、sourcehash与V6文件哈希。原诊断64文件以及本次写入前已有文件全部保持，唯一更新的既有文件为 `CURRENT_REVIEW_VERSION.json`，只追加澄清路径字段；更新前指针另存 `CURRENT_REVIEW_VERSION_V6_BEFORE_CLARIFICATION.json`。不扩展审阅队列，不重算表，不调用API/新检索/GPU。
