# 信息流诊断V5：新增40条及受控对照假设

当前视图：MANUAL_INFORMATION_FLOW_REVIEWS_V5.json、REVIEW_INDEX_V5.jsonl、REVIEW_PROGRESS_V5.json。V4及更早文件均保持原字节，旧版本指针另存。BATCH005固定沿各集递增队列取20条，不按答案或F1挑选。

累计亲读110包：固定成功40，非满分70（Wiki30、HP40）；107条完成声明的信息范围检查，3条待核。尚未开始168包，其中160条为非满分，另8条为主队列之外的历史成功案例。原36案例本轮复核覆盖数见进展JSON。

三项清楚的新边界：Wiki288正确goal包含Indian-born/NewZealand却final取India；Wiki296正确地理事实共享Bolivia，goal却擅加exclusively条件再输出No；HP86改写及goal reader已经给Jehovah→GodofIsrael，goal却复述发明词语，未把所问指称关系传到final。这三类应分别针对final字段选择、goal运算条件、goal关系综合。

信息不足也有具体区分：Wiki292没有第二部电影来源；Wiki312/314读到正确人物却没有出生/安葬关系，不能拿统治地或住地代替；Wiki329漏读已可见Mozart音乐引用且下游仍缺死亡地；Wiki347缺第二部影片制作人列表，不能用演员名单或有限gold三元组补真实总数。HP45/84/93把描述绑定到Sheol/oak/WoodsHole，目标材料从未命中；仅改goal/final不等于已证明能修好。

同时，HP47普通阶段弃答后原题goal直接找到Brea；HP92普通错误Greenland分支被goal原路Russia最大country纠正。HP83正确论文正式名与BFH简称、HP53正确centre却参考附带国籍职业、HP28仅答所问州却参考附带城市等仍造成未满分；不能把所有非满分都当事实错误，也不能反过来把所有部分F1都当格式。

待核：保留Wiki317/254，再纳入原本已获准待核的Wiki319（Galanta与Pressburg出生地冲突）。继承领地/头衔不能证明出生地，旧goal None与原0分均不改。本轮没有新联网。

修复假设已映射到接下来的goal综合、goal改写检索、final可见性对照，详见REPAIR_HYPOTHESIS_EXPERIMENT_MAPPING_V5.json。文件只列假设、应冻结项、应观察的受益/损害和混杂因素，没有实现方法改动或启动新评估。尤其：关闭改写同时改变补充材料及merge；删整条goal同时删独有事实；人工按gold挑必要证据只能称oracle诊断。

剩余失败固定顺序见REMAINING_NONFULLSCORE_QUEUE_V5.jsonl。当前失败样本是有序前缀/最初案例，成功是按集抽样，覆盖与数据集混合仍不同，不估总体率、不做组件因果排名。API、检索、GPU为0；旧事实标签、原生F1/EM与评估主方案不变。
