# 信息流诊断进展V4：新增各集10条非满分

当前视图：MANUAL_INFORMATION_FLOW_REVIEWS_V4.json、REVIEW_INDEX_V4.jsonl、REVIEW_PROGRESS_V4.json。先前V3各文件保留原字节；版本指针旧内容另存CURRENT_REVIEW_VERSION_V3.json。

本批按各数据集review_index递增固定取最前10条未审非满分，不按答案或F1选取。累计亲读70包：满分40、非满分30（Wiki10/HP20），68条完成声明范围检查、2条待核；208包未开始，其中200条为剩余非满分。下一轮顺序见REMAINING_NONFULLSCORE_QUEUE_V4.jsonl。

已有材料新确认的失效位置：

- Wiki248：1955日期已经进入普通step4 reader，却在弃答中没有传递；goal/final没有该日期。旧普通标签已判错误，最终不能据此归因为忽略可见日期。
- HP26：Ronan是真城市，但后续搜索落入同名政治家；Polson虽在原路候选第10被裁，Greg Hertz代表关系仍未命中。缺代表关系和桥接候选裁剪并存，保留Polson不等于已证明能修好。
- HP27：Speedpass同一段落明确区分developer Verifone与introducer Mobil，普通回答混淆角色，改写与goal传播；final仍有原始关系句，却没有正确总部关系材料。
- HP21：正确生卒日期与78/67年龄均可见，goal反向比较，final沿用。HP31则把实际reader中的shortstop Maury Wills误当pitcher并带到final。这两条部分/零分都不是单纯匹配问题。
- HP23：goal含Greenwich Village, New York City，final却只取社区名，缺了所问城市。与HP28按问题只返回州New Mexico、参考却含城市的情况分开。

其它记录分别标识合法附加粒度、名称限定符、参考混入额外字段和参考同名实体。Wiki274的British参考来自同名拳击手；管道返回Irish对应小提琴手，沿用原冻结事实核验，不重跑网页。Wiki273既包含正确William IV，也额外带入已被旧事实核查证伪的Christoph，不能把其部分F1当纯格式损失。

待核维持Wiki317，并新增Wiki254：正确Earl的Irish与另一个同名Richard的Anglo-Irish同时在reader，无法只凭输出确定合法描述还是属性串接；保留原goal True与原分数，不强行给新结论。

只审本条声明的信息范围，多路径、合理弃答、真实不完整列表旧标签不变。30条失败的覆盖仍少且不是随机样本，描述性对照不代表总体发生率或组件因果收益。API、检索、GPU均为0。
