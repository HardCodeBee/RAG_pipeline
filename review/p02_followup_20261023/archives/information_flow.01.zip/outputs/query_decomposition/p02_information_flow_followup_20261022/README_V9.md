# P02 信息流离线审阅 V9

追加 `MANUAL_INFORMATION_FLOW_REVIEWS_BATCH009.json` 的40条，严格匹配 `ASSIGNMENT_BATCH009.json` 的ID与顺序。累计亲读270条：固定seed满分对照40、非满分230（2Wiki127、HotpotQA103）。258条完成各自声明的必要信息/路径范围，12条保留待核。并非对每个无关附加事实重新制作独立金标。

主270队列剩余非满分0条。8条补充包明确尚未审阅，不计入主cohort完成数。所有先前待核项原样保留；新歧义允许追加待核，不强行判标签。


本版按冻结任务包追加另一位代理亲读的40条记录；合并执行逐字段、原始sourcehash、原生分数保留、实际QA问题及证据摘录位置验证。详见本批逐条记录；此页不自动从关键词生成原因结论。


## 实际QA输入口径

以 `child_prompt` 的 Current subquestion 为准。`rewritten_query` 是检索查询，不能直接视作替换了回答器问题。HP107澄清见 `HP107_ACTUAL_QA_INPUT_CLARIFICATION.md/.json`；原V6字节保留。独立真命题、对检索改写响应、对实际问题响应分开。

## 验证与文件

- 累计：`MANUAL_INFORMATION_FLOW_REVIEWS_V9.json`；状态：`REVIEW_INDEX_V9.jsonl`、`REVIEW_PROGRESS_V9.json`。
- 剩余：`REMAINING_NONFULLSCORE_QUEUE_V9.jsonl`；待核：`INFORMATION_FLOW_PENDING_WORK_ITEMS_V9.json`。
- 描述性对照：`REVIEWED_SUCCESS40_NONFULLSCORE230_DESCRIPTIVE.json`。成功对照是固定seed样本，非满分此前有初始案例与递增前缀；本页不提供总体原因占比或因果排名。
- 本次合并校验40条sourcehash、94个实际QA问题，以及118条证据/goal摘录位置。摘录检查只证明位置，不自动判语义充分；语义结论来自逐条亲读记录。
- `VALIDATION_V9.json` 证明原诊断64文件及全部先前已有文件保持原字节（仅当前指针更新），原指针保存为 `CURRENT_REVIEW_VERSION_V8.json`。旧truth、原生F1/EM、四组主表及主评价计划不改。
- 无API、网络、新检索、GPU或RAG重跑。假设映射仅整理已有案例，不实施新实验。
