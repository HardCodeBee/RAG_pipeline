# Final信息标志语义：固定前5条核对

`final_has_sufficient_information_for_target=True` 与 `final_uses_target_information_correctly=True` 是每条声明范围内必要目标信息的保留/使用检查，**不是对完整final逐句复核后的正确金标，也不等于原生F1/EM满分**。非满分230中此组合120条；以下严格取V9原记录顺序的前5，未按得分或案例特点选择。

| 记录 | 真实问题 | Final | 原参考 | F1 | EM | 标志解释 |
|---|---|---|---|---:|---:|---|
| HP98 | When does the universe, Earth, and all life on Earth were created as believed by an organization which commissioned The Voyage That Shook The World? | In six 24-hour days during the creation week described in Genesis 1, less than 10,000 years ago | 10,000 years ago | 0.315789 | 0.0 | 仅核所问elapsed-time量级less than10000yearsago传到final；六日/Genesis等附加叙述没有作全句独立复核。 |
| HP6 | Out of two American colonies that had a series of skirmishes and raids between 1701 and 1765 at the disputed border, which British proprietary colony became a royal colony on the northeast coast of North America? | Province of New Jersey | Province of New York | 0.750000 | 0.0 | 两个殖民地均满足读入的proprietary→royal属性；记录接受另一满足者，原参考只选NewYork。 |
| HP13 | Barbara Streisand's 34th album Partners features a duet with which of her children? | Jason Gould | Jason Emanuel Gould | 0.800000 | 0.0 | 同一人物以常用短名回答；原参考中名Emanuel未出现在实际final输入。 |
| HP15 | Who starred in Smurfs: The Lost Village and was also in The Office? | Rainn Wilson | Ellie Kemper | 0.000000 | 0.0 | 原冻结核验确认RainnWilson为两部作品交集中的另一有效人选；不能因唯一参考EllieKemper就判此实体不存在。 |
| HP16 | Folie à Deux is a studio album by the American rock band formed in which city? | Wilmette, Illinois | Wilmette | 0.666667 | 0.0 | 完整目标城市已返回，另外保留真实州名；原生词元匹配仍扣分。 |

前5已显示中名/地理粒度、输出冗余，以及不唯一目标/有效替代答案。未发现这5条需要“未列全对象列表”的解释，但不能据此前5推断其余115条不存在不完整或其他范围问题。JSON保留每条必要信息声明、原审阅scope、证据及sourcehash。

因此147条信息充分不能称为147条可修复错误；26条充分但使用未对也可能涉及冲突goal、作用域或比较运算，不能称纯final模型的因果错误数或总体占比。120条充分且用对更不能视作完整native正确，亦不能一律归成格式。原flag、truth、分数及统计不修改，本注释只明确其解释边界。
