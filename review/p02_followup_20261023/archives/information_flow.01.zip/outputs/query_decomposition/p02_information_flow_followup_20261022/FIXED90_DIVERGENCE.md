# 已完成fixed90变体离线分叉核查

变化是文字或材料差异，不是错误数量；使用最终完成目录，保留原评分。

| 对照 | 已计分/可比轨迹 | 首次行为分叉：普通/goal/无 | 普通回答变化 | goal回答变化 | final文字变化 | F1变化百分点 |
|---|---:|---:|---:|---:|---:|---:|
| original_to_selfcontained | 90/90 | 39/0/51 | 53 | 27 | 7 | -2.5886 |
| original_to_no_refs | 90/90 | 36/15/39 | 53 | 40 | 12 | -2.4446 |
| original_to_A_no_only | 90/90 | 37/0/53 | 55 | 28 | 9 | -2.1005 |
| original_to_B_no_resolve | 90/90 | 39/20/31 | 53 | 44 | 16 | -3.4457 |
| original_to_three_prompts_v1 | 90/89 | 61/24/4 | 89 | 84 | 29 | -4.9810 |
| original_to_minimal4 | 90/90 | 34/0/56 | 51 | 27 | 5 | -2.0794 |
| original_to_three_prompts_compact_v2 | 90/90 | 37/22/31 | 51 | 51 | 19 | -0.6439 |
| selfcontained_to_A_no_only | 90/90 | 30/0/60 | 47 | 24 | 9 | +0.4882 |
| selfcontained_to_B_no_resolve | 90/90 | 0/35/55 | 0 | 35 | 10 | -0.8571 |

three_prompts_v1中的无nodes算法失败保留评分，不强行补成完整轨迹。A/B同时提供相对其真实selfcontained对照的分叉与相对原冻结P02的比较。
no_refs同时删除解析句、history/current编号并扩展两个示例的描述短语；不是#字符的单因素实验。
