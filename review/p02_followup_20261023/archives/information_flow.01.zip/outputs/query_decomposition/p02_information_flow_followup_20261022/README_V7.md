# P02 信息流离线审阅 V7

追加 `MANUAL_INFORMATION_FLOW_REVIEWS_BATCH007.json` 的40条，严格匹配 `ASSIGNMENT_BATCH007.json` 的ID与顺序。累计亲读190条：固定seed满分对照40、非满分150（2Wiki70、HotpotQA80）。186条完成各自声明的必要信息/路径范围，4条保留待核。并非对每个无关附加事实重新制作独立金标。

主270队列剩余非满分80条。8条补充包明确尚未审阅，不计入主cohort完成数。所有先前待核项原样保留；新歧义允许追加待核，不强行判标签。


本批新增实证：Wiki506 在ordinary reader中已经出现LiuCong的父亲LiuYuan，QA却取Empress自己的父亲LiuYin，并通过goal传播；正确父亲未保留到final。HP187的goal/helper已给Protestant Christian，final仍返回桥梁组织SalvationArmy。HP140同时读到1805失败围城与1826Combermere攻克，却沿错事件版本。

另有保留纠错能力的实例：HP141从未限定Voice的土耳其版本回到正确韩国版本；HP150从Cowra改回Forbes；HP152补全Fiers跨队关系；HP189 goal忽略新纪录片事实但final正确输出No。不能将“所有上游错误必传播”或“统一删goal一定更好”视为已证明。

参考与来源问题分列：Wiki433片段明确Canadian-American，原参考只取Canadian并给No；456原读入传记有27/17Feb冲突，冻结核验已判27错误；463参考连接同名足球员而非导演。HP145原参考是bassist本身，但方法输出的TommyLee亦不是真配偶；189问布尔而参考为单实体描述。原标签及原生分数均不修改。


## 实际QA输入口径

以 `child_prompt` 的 Current subquestion 为准。`rewritten_query` 是检索查询，不能直接视作替换了回答器问题。HP107澄清见 `HP107_ACTUAL_QA_INPUT_CLARIFICATION.md/.json`；原V6字节保留。独立真命题、对检索改写响应、对实际问题响应分开。

## 验证与文件

- 累计：`MANUAL_INFORMATION_FLOW_REVIEWS_V7.json`；状态：`REVIEW_INDEX_V7.jsonl`、`REVIEW_PROGRESS_V7.json`。
- 剩余：`REMAINING_NONFULLSCORE_QUEUE_V7.jsonl`；待核：`INFORMATION_FLOW_PENDING_WORK_ITEMS_V7.json`。
- 描述性对照：`REVIEWED_SUCCESS40_NONFULLSCORE150_DESCRIPTIVE.json`。成功对照是固定seed样本，非满分此前有初始案例与递增前缀；本页不提供总体原因占比或因果排名。
- 本次合并校验40条sourcehash、92个实际QA问题，以及75条reader摘录位置。摘录检查只证明位置，不自动判语义充分；语义结论来自逐条亲读记录。
- `VALIDATION_V7.json` 证明原诊断64文件及全部先前已有文件保持原字节（仅当前指针更新），原指针保存为 `CURRENT_REVIEW_VERSION_V6.json`。旧truth、原生F1/EM、四组主表及主评价计划不改。
- 无API、网络、新检索、GPU或RAG重跑。假设映射仅整理已有案例，不实施新实验。
