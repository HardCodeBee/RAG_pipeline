# I8执行入口：仅准备，等待root授权

此入口继承原8节点离线协议及全部冻结输入、I1单句、16合同、公开来源和实际R02分解证明；原`PROTOCOL.frozen.json`与prepare产物保留原字节。执行合同另存`EXECUTION_PROTOCOL.frozen.json`，pin原协议及新增runner。执行前由root审核并写绑定该新协议hash的授权；本次准备不写授权、不发请求。

I0/I1共16条件，在同一个新的checkpoint中运行。`StrictAsk(seed=None)`不读历史答案缓存，原历史回执仅作费用参照。首次控制与处理均新生成，续跑只复用本实验已保存的同payload回执；不更换namespace重抽、不挑优输出。8节点与原先后次序固定，每个节点按已冻结的arm顺序运行，128cap保持。

沿用共享串行gate、原累计ledger、无固定预算上限及五次技术尝试上限，跨重启保留attempt计数、旧回执与未决预留。仅无返回迹象的unknown及既定瞬态技术失败可按原规则有界恢复；已有usage、response-id、返回模型、原响应或内容的unknown不盲重发。SDK/HTTP重试均为0。

新增runner只读恢复保护：退休旧请求之前同时检查当前回执及对应ledger条目。即使cache尚无回执，只要ledger已记录returned_usage/actual费用，也暂停待核，覆盖“先记账、后保存cache时崩溃”的窗口；failed瞬态但已经带返回迹象同样不重发。保留而无cache记录的孤立预留单列，不自动删除，也不由其推断已经提交。共享StrictAsk文件不修改。

新正常回执须stop、非空、无refusal，requested/returned model匹配冻结模型，prompt/completion/total tokens均为非负整数（排除bool）且total=sum。身份或usage异常技术held，保留回执；length、content-filter、拒答或空答在模型和usage有效时作为终止算法结果保存，不为了质量重试。算法结果计入16条件状态覆盖，technicalheld单列；不写伪F1，不调用金标评分器，不把正常完成等同语义正确。

报告分列6条局部问题与2条合理弃答边界，记录候选、状态、输入/输出tokens、费用与未决预留；同时给全部同期I0/I1文本变化及终止状态，后续盲审再判断事实、响应性、必要信息及角色。没有下游goal/final、格式化、检索或分解执行，没有总体准确率或完整RAG收益声明。371多走一代、122下游旧恢复等原边界保持。

```powershell
python -B -m experiments.query_decomposition.p02_ordinary_failure_challenge8_v1_20261022.run prepare-runner
python -B -m experiments.query_decomposition.p02_ordinary_failure_challenge8_v1_20261022.run dry-run
python -B -m experiments.query_decomposition.p02_ordinary_failure_challenge8_v1_20261022.run report
```

`run`是另一个显式动作，只有root批准的新协议hash和共享决策记录同时匹配时才进入网络上下文。主评审批保持false。
