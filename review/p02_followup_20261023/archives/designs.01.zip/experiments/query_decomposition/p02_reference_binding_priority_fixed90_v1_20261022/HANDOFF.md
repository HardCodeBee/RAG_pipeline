# Root execution handoff

State: offline prepared, not frozen, not authorized, zero new services.
No existing stage template, flow.py or predecessor source/output was modified.
Independent root review precedes freeze. The read-only remote preflight belongs
to root and is pinned when freeze is called.

Offline commands from repository root:

```powershell
python -B -m experiments.query_decomposition.p02_reference_binding_priority_fixed90_v1_20261022.run prepare
python -B -m experiments.query_decomposition.p02_reference_binding_priority_fixed90_v1_20261022.offline_checks
python -B -m experiments.query_decomposition.p02_reference_binding_priority_fixed90_v1_20261022.validate_controller_offline
python -B -m experiments.query_decomposition.p02_reference_binding_priority_fixed90_v1_20261022.run predecessors
```

After independent review, root runs `run freeze`. This verifies copied source
bytes, both predecessor protocols, protected main STOP files, controller and
flow checks, and the root's partition preflight. It pins imported NativeAsk,
transport/runtime/bridge/worker/resources, native pipeline and scorer sources.
Root then writes RUN_AUTHORIZATION.json and appends its decision to the main
DECISIONS log. Neither preparation nor the runner writes this authorization.
Required authorization fields are approved=true, experiment equal to this
folder name, protocol_sha256 exact, decision_id present in the main log,
current_namespace_returnless_recovery_only=true, maximum_technical_attempts=5.

Only then, launch with an interactive hidden PTY for the ephemeral getpass:

```powershell
python -B -m experiments.query_decomposition.p02_reference_binding_priority_fixed90_v1_20261022.run run --wait-for-predecessors
```

No credential is read while waiting. Once both predecessor barriers pass,
the runner asks for the remote password in getpass, connects with the original
strict host key, allocates its isolated A6000 worker and uses the existing
ephemeral API-key helper. Do not pass the password via arguments/environment.
The shared provider gate serializes requests with any other authorized small
experiment. A returned/ledger-backed failure or held condition is not retried.

The exact first24 are an engineering gate, not a quality screen. After it
passes, the remaining336 conditions continue automatically. The fresh C0 and
all three candidates remain planned regardless of local stage outcomes.
If the conservative allocation clock falls below15minutes, stop dispatching
new conditions and close the worker after the current flow; remaining tasks
stay unstarted. No new GPU job is silently submitted on a later invocation.
A stopped or unknown allocation requires root receipt review and a concrete
continuation decision before any replacement job.

`run report` writes metadata/known-fee/unknown-reserve STATUS.json without F1.
After method-masked review/lock of differing final texts, root explicitly runs:

```powershell
python -B -m experiments.query_decomposition.p02_reference_binding_priority_fixed90_v1_20261022.score
```

REPORT.json, DETAILS.jsonl and PAIRED.jsonl retain per-dataset and matched
denominators, algorithm zeros and technical missingness. Historical P02 is a
separate same-ID reference, never seeded into new inference. No formal500,
timing campaign, method promotion or publication is implied.
