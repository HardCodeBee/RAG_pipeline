# ordinary minimal4：四条原生F1损害记录的离线复核

2026-10-22，Australia/Sydney。复核对象是已结束的
`p02_childprompt_minimal4_quick90_v1_20261021/approved_resume002_20261022`，
不是新局部probe结果。其最终报告UTC为2026-10-21T13:51:30.997387+00:00。
全部90题可计分；真实控制为原冻结P02，F1 76.6889%→74.6095%，
EM66.6667%→64.4444%，改善0、持平86、损害4。

这是按最终分数选出的事后案例复核，用来发现可检验机制，不作总体因果归因。
各阶段事实判断依据实际保存的reader材料；不因最终分数下降就倒推上游回答错误。
没有重跑RAG、调用评审模型或联网，没有更改正式诊断标签。

可核对的输入、前序历史、reader集合和回答差异存于同目录
`CASE_EVIDENCE.json`。来源报告、配对文件和control90的哈希同时保留。

| 题目 | 最早输出文字分叉 | 最终变化 | 可确认的问题及边界 |
|---|---|---|---|
| HotpotQA `5a7a59d15542996c55b2dd67` | ordinary1，空历史，同reader | Eve and Trina→Diamond, Eve, and Trina；F1 1→0.8571 | final没有按other排除原题人物本人；并非普通回答给出的三个人名为假 |
| 2Wiki `923b15ba0bb011ebab90acde48001122` | ordinary1，空历史，同reader | Tristão Gonçalves de Alencar, later Araripe→Cannot be determined；F1 0.5→0 | 新回答先弃答，后续未再绑定父亲实体，必要文段从后续reader消失；第一步实际材料没有明确父子关系，不能仅凭分数判弃答错误 |
| 2Wiki `fcd3ff500baf11ebab90acde48001122` | ordinary2，同历史、同reader | Queen Pōmare IV→Queen Pōmare IV of Tahiti；F1 0.8→0.5714 | 指向同一正确人物，新增属实地域限定导致匹配下降；没有检索材料或实体角色改变的证据 |
| MuSiQue `2hop__104095_40501` | ordinary1，空历史，同reader | 75,000 to 100,000→Cannot be determined；F1 1→0 | 新回答不把职业活动地当公民身份，后续不再按Dutch Republic检索；当前材料未确定公民身份，不能仅凭F1将该弃答标成事实错误 |

四题的原问题原路Top10在两组完全相同。前三种观察应分别保留：
所问关系/排除范围未执行、可见材料不足时的弃答与后续覆盖变化、
同一正确实体的评分敏感。这里没有发现一个新的“坐席/容量属性选错”案例。

## 1. Diamond、Eve、Trina：实体身份正确，但final未执行排除

问题问Brittany Nicole Carpentero之外的其他女说唱歌手。
ordinary1两组都读到《My Chick Bad》文段，明确列Diamond、Eve、Trina。
控制回答说尚未识别，minimal4回答列出这三个人。goal两组随后都读到
《Diamond (rapper)》对Brittany Nicole Carpentero＝Diamond的身份说明，
两组goal都包含Diamond、Eve、Trina。

minimal4的goal改写将已有完整列表代入“还有哪些其他人”的结构，实际检索目标有所变化，
但goal和final可见的身份关系足以区分本人和其他人。控制final正确输出Eve and Trina，
候选final仍把Diamond列入。可定位到最终集合/排除关系没有正确执行。

不能由这一例断定ordinary1的新答案错误，或者“回答更充分必然损害最终质量”；
新普通回答中的列表事实与所保存的文段一致。仍需受控实验确定哪些表达会促成或抑制排除操作。

## 2. Araripe：第一步缺证弃答改变后续实体绑定与检索

ordinary1两组reader第一篇《Araripe Júnior》只提供本名、日期和职业，
没有明确说父亲是谁。控制给出Tristão de Alencar Araripe，候选弃答。
随后控制把第二步改成询问该具体实体的父亲，候选保留“Araripe Júnior的父亲的父亲”描述。
两路reader文档集合从第二步开始变化。

控制的后续reader出现题名《Tristão de Alencar Araripe》的文段，
正文却以1789年出生的Tristão Gonçalves de Alencar, later Araripe开头；
该段本身也没有清楚写出父子链。这是需要保留的实体/语料身份风险。
本次没有外部事实核验，不能据此给控制或候选新增确定的事实错误标签。

可确认的是：最早变化为同一reader输入下的第一步弃答，之后具体实体替换和检索覆盖随之变化。
控制本来只有F1 0.5，而非满分；分数损害不能当作原流程父系链已被独立核实的证据。

## 3. Queen Pōmare IV：实体未变，输出附加限定造成匹配下降

ordinary1回答逐字相同。ordinary2两组历史及reader完全相同；
《Tamatoa V》明确说Tamatoa V为Queen Pōmare IV of Tahiti之子，
《Teriimaevarua III》提供其与Tamatoa V的父女关系。
ordinary2的新句子只增加同一父亲的Prince Tamatoa-a-tu名称。
goal改写及reader仍相同，goal和final最后多保留“of Tahiti”。

两种最终输出都指向同一人物；《Pōmare IV》明确其为Tahiti女王。
当前证据支持将此例视作别名/附加描述的评分敏感，而不是新出现的事实或亲属关系错误。
这不授权修改主评分、临时扩大别名表或追溯覆盖旧分数。

## 4. Clara Peeters：职业地域不等于公民归属

ordinary1实际《Clara Peeters》文段说她来自Antwerp，
可能主要在新Dutch Republic从事职业活动，且很多人生细节仍不清楚。
该段没有直接确立公民身份。控制回答Dutch Republic，minimal4说无法确定。

控制goal据此查询Dutch Republic，读到《Huguenots》的75,000至100,000移民数量。
候选goal未能确定目标国家，其检索中的《Huguenots》变成德国/斯堪的纳维亚相关的另一段，
没有控制读取的那个数量。这里同时存在保守回答与后续必要证据覆盖改变。

“在某地活动”与“该国公民”是不同关系；不能因为原参考能给控制满分，就把候选第一步弃答当作错误。
本次材料复核不决定她的真实公民归属，也不更改原生F1或数据集参考。

## 对下一步的约束

1. 三条损害的最早分叉位于没有前序历史的第一个ordinary。当前绑定probe只抽有历史ordinary，
   可以回答实体绑定问题，但不会覆盖全部minimal4差异。后续如需解释这些首节点变化，
   应单列无历史reader对照，不能把差异都归为使用前序结果的方式。
2. minimal4在ordinary模块内同时改两条规则及两个示例。本复核不能将首节点弃答变化归因于其中某一句。
3. 四条分数下降不是四条已确认事实错误；两条与当前可见材料不足时的弃答相关，一条为集合排除失误，
   一条为属实附加描述引起的匹配变化。事实标签和任务必要信息覆盖仍应分开。
4. 这四例是事后选出的全部损害例，不能用来估计独立样本上的收益或损害率，也不能据此直接选最终模板。
