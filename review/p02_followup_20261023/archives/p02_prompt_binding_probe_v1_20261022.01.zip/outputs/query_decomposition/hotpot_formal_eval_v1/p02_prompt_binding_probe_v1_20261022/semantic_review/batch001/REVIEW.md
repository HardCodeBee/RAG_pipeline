# 第1批局部输出语义复核

固定快照见`COVERAGE_SNAPSHOT.json`。本批覆盖3个节点、8条匿名输出：
有历史组2个节点（普通1、goal1）的控制2条及候选4条；
无历史组1个首节点的控制1条及已保存候选1条。
未保存的输出不补齐、不推断。最终原生F1及参考答案均未进入审阅材料。

方法名称在标签写入并锁定后才合并。8条输出按当前实际问题均正确，
没有待核事实、错误角色对应或不合理弃答。这是一个Codex审阅者的初始小批复核，
含同节点重复文本，不能当成8个独立问题或总体准确率估计。

| 节点 | 可核实材料 | 观察 |
|---|---|---|
| Mount Stimson/Glacier National Park，goal | Mount Stimson材料明确其为Glacier第二高峰；Glacier材料明确面积over1million acre | 两种简短答案和一种显式保留桥接关系的长句均正确；全部保留over限定，没有改成精确一百万 |
| Crinum，ordinary有历史 | Crinum材料明确perennial、沼泽/湿地；Crinum americanum明确aquatic | 控制及两个候选逐字相同，均正确回答当前Crinum类别问题，没有把前序Tabernaemontana的shrubs/small trees套到Crinum |
| Mount Stimson，ordinary无历史 | 首篇材料直接提供Glacier National Park及second highest peak关系 | 控制和已保存的删除指令候选逐字相同，正确提供后续需要的公园实体；当前步不要求面积，不能因未给面积判不充分 |

两个限制需要保留：

- Crinum节点虽然有历史，当前问题直接点名Crinum，并不需要将前序答案实体代入。
  有历史样本应另记实际依赖/绑定需求，不能把这种不变输出当作绑定机制已被验证。
- Crinum回答正确，不等于该输入包已建立原题所问的两属共同类别；前序摘要只有shrubs/small trees。
  这应属于必要信息覆盖的后续检查，不能倒过来将当前正确回答改判错。

本批仅观察到Glacier答案多写或省略一个属实桥接从句，没有发现事实或必要信息改变。
它没有证明删解析句、描述式绑定规则优于或等价于冻结模板，也没有产生完整RAG成绩。

新API请求为0；未修改原诊断标签、runner代码或其他运行任务。
