"""Offline aggregation of locked component reviews. No provider/network calls."""
from __future__ import annotations

import collections
import datetime
import hashlib
import json
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[5]
REVIEW = Path(__file__).resolve().parent
OUTPUT = REVIEW.parent
EXPERIMENT = ROOT / "experiments/query_decomposition/p02_prompt_binding_probe_v1_20261022"


def read(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write(name: str, value):
    (REVIEW / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    inputs, texts, expected = {}, {}, set()
    for group, relative, db in [
        ("with_history", "PROBES.frozen.jsonl", OUTPUT / "checkpoint.sqlite3"),
        ("no_history", "first_node_followup/PROBES.frozen.jsonl", OUTPUT / "first_node_followup/checkpoint.sqlite3"),
    ]:
        nodes = [json.loads(line) for line in (EXPERIMENT / relative).read_text(encoding="utf-8").splitlines()]
        with sqlite3.connect(db.as_uri() + "?mode=ro", uri=True) as conn:
            outcomes = [json.loads(row[0]) for row in conn.execute("SELECT value FROM data WHERE kind='outcome'")]
        assert len(outcomes) == 2 * len(nodes)
        for node in nodes:
            probe = node["probe_id"]
            inputs[probe] = {**node, "group": group}
            texts[(probe, "control")] = node["control_result"]["answer"]
            expected.add((probe, "control", node["control_source_request_id"]))
        for outcome in outcomes:
            assert outcome["probe_id"] in inputs
            assert outcome["status"] == "success", outcome.get("status")
            key = outcome["probe_id"], outcome["variant"]
            assert key not in texts
            texts[key] = outcome["answer"]
            expected.add((*key, outcome["request_id"]))

    reviewed = {}
    duplicate_count = 0
    locks = []
    for file in sorted(REVIEW.glob("batch*/UNBLINDED_REVIEW.json")):
        locked = file.with_name("LABELS_LOCKED.json")
        lock = read(locked)
        assert lock["method_labels_hidden_until_this_file_written"]
        assert lock.get("gold_native_scores_not_used", lock.get("gold_and_native_final_scores_not_used"))
        packet_file = file.with_name("BLINDED_PACKETS.jsonl")
        assert hashlib.sha256(packet_file.read_bytes()).hexdigest() == lock["packets_sha256"]
        packets = {p["packet_id"]: p for p in [json.loads(line) for line in packet_file.read_text(encoding="utf-8").splitlines()]}
        mapping = {(m["packet_id"], m["answer_id"]): m for m in read(file.with_name("BLINDING_KEY.json"))["mapping"]}
        for label in lock["labels"]:
            mapped = mapping[(label["packet_id"], label["answer_id"])]
            shown = next(a["text"] for a in packets[label["packet_id"]]["answers"] if a["answer_id"] == label["answer_id"])
            assert shown == texts[(mapped["probe_id"], mapped["origin"])]
        digest = hashlib.sha256(locked.read_bytes()).hexdigest()
        locks.append({"batch": file.parent.name, "labels_sha256": digest, "labels": len(lock["labels"])})
        for record in read(file)["records"]:
            key = record["probe_id"], record["origin"], record["request_id"]
            if key in reviewed:
                assert reviewed[key]["answer_correct"] == record["answer_correct"]
                duplicate_count += 1
                continue
            node = inputs[record["probe_id"]]
            assert record["group"] == node["group"]
            reviewed[key] = {
                **record,
                "role": node["role"], "dataset": node["dataset"],
                "source_batch": file.parent.name, "labels_sha256": digest,
                "answer_sha256": hashlib.sha256(texts[key[:2]].encode()).hexdigest(),
            }
    assert set(reviewed) == expected, {"missing": sorted(expected - set(reviewed)), "extra": sorted(set(reviewed) - expected)}
    assert len(reviewed) == 135 and len(inputs) == 45
    records = list(reviewed.values())
    lookup = {(r["probe_id"], r["origin"]): r for r in records}

    groups, changed = [], []
    for group in ("with_history", "no_history"):
        for role in ("ordinary", "goal"):
            nodes = [node for node in inputs.values() if node["group"] == group and node["role"] == role]
            if not nodes:
                continue
            for variant in ("control", "delete_resolve", "describe_binding"):
                rs = [lookup[(node["probe_id"], variant)] for node in nodes]
                row = dict(group=group, role=role, variant=variant, nodes=len(rs),
                           correct=sum(r["answer_correct"] is True for r in rs),
                           incorrect=sum(r["answer_correct"] is False for r in rs),
                           pending=sum(r["answer_correct"] is None for r in rs),
                           reasonable_abstentions=sum(r["abstention"] == "reasonable" for r in rs))
                if variant != "control":
                    pairs = [(lookup[(node["probe_id"], "control")], lookup[(node["probe_id"], variant)]) for node in nodes]
                    eligible = [(a, b) for a, b in pairs if a["answer_correct"] is not None and b["answer_correct"] is not None]
                    row.update(paired_known=len(eligible), gains=sum(not a["answer_correct"] and b["answer_correct"] for a, b in eligible),
                               losses=sum(a["answer_correct"] and not b["answer_correct"] for a, b in eligible))
                    changes = []
                    for node in nodes:
                        probe = node["probe_id"]
                        control, candidate = texts[(probe, "control")], texts[(probe, variant)]
                        if candidate == control:
                            continue
                        a, b = lookup[(probe, "control")], lookup[(probe, variant)]
                        changes.append(dict(probe_id=probe, group=group, role=role, dataset=node["dataset"], variant=variant,
                                            current_question=node["current_question"], control_answer=control, candidate_answer=candidate,
                                            control_correct=a["answer_correct"], candidate_correct=b["answer_correct"],
                                            control_information=a["necessary_information_status"], candidate_information=b["necessary_information_status"]))
                    row["exact_text_changes"] = len(changes)
                    changed.extend(changes)
                groups.append(row)

    pending = []
    for node in inputs.values():
        rs = [lookup[(node["probe_id"], variant)] for variant in ("control", "delete_resolve", "describe_binding")]
        if any(r["answer_correct"] is None for r in rs):
            pending.append(dict(probe_id=node["probe_id"], group=node["group"], role=node["role"],
                                question=node["current_question"], issue=rs[0]["issue_type"], reason=rs[0]["reason"],
                                affected_outputs=sum(r["answer_correct"] is None for r in rs)))
    timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
    summary = dict(created_utc=timestamp, scope="Frozen local stage probes; not final RAG quality", nodes=45, unique_outputs=135,
                   candidate_outputs=90, controls=45, repeated_control_review_deduplicated=duplicate_count,
                   correct=sum(r["answer_correct"] is True for r in records), incorrect=sum(r["answer_correct"] is False for r in records),
                   pending_outputs=sum(r["answer_correct"] is None for r in records), pending_nodes=len(pending),
                   by_group_role_variant=groups, pending_work_items=pending, locks=locks,
                   new_provider_submissions_by_review=0, original_diagnostic_labels_modified=False,
                   gold_native_scores_used_for_semantic_labels=False, single_Codex_reviewer=True,
                   method_labels_hidden_before_each_lock=True)
    write("ALL_REVIEW_RECORDS.json", {"created_utc": timestamp, "records": records})
    write("CHANGED_OUTPUTS.json", {"definition": "Exact raw answer-string difference from same-node frozen control; not a correctness label", "records": changed})
    write("SUMMARY.json", summary)
    write("REVIEW_COVERAGE.json", dict(created_utc=timestamp, status="complete", expected_nodes=45, reviewed_nodes=45,
                                      expected_unique_outputs=135, reviewed_unique_outputs=135, candidate_outputs_reviewed=90,
                                      frozen_controls_reviewed=45, repeated_control_review_deduplicated=duplicate_count,
                                      by_group={g: dict(nodes=sum(n["group"] == g for n in inputs.values()),
                                                        outputs=sum(r["group"] == g for r in records)) for g in ("with_history", "no_history")},
                                      pending_nodes=len(pending), pending_outputs=sum(r["answer_correct"] is None for r in records),
                                      missing_outputs=[], extra_outputs=[], new_provider_submissions=0))
    print(json.dumps({"nodes": len(inputs), "unique_outputs": len(records), "pending_nodes": len(pending), "rows": groups}, ensure_ascii=True))


if __name__ == "__main__":
    main()
