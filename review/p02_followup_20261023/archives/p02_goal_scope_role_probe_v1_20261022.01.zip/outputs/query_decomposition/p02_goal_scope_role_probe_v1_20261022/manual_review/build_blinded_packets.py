"""Read-only extraction; do not print the local method key before review lock."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sqlite3

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
INPUT = ROOT / "experiments/query_decomposition/p02_goal_scope_role_probe_v1_20261022/inputs27.frozen.jsonl"
DB = HERE.parent / "scope27/checkpoint.sqlite3"


def rows(path):
    return [json.loads(s) for s in path.read_text(encoding="utf8").splitlines() if s.strip()]


def main():
    inputs = rows(INPUT)
    keyfile = HERE / "METHOD_KEY.local.json"
    key = json.loads(keyfile.read_text(encoding="utf8")) if keyfile.exists() else {}
    packed_file = HERE / "BLINDED_PACKETS.jsonl"
    packed = {r["id"]: r for r in rows(packed_file)} if packed_file.exists() else {}
    terminal_file = HERE / "TERMINAL_LENGTH_REGISTER.jsonl"
    terminal = {r["request_id"] for r in rows(terminal_file)} if terminal_file.exists() else set()
    added = []
    with sqlite3.connect(DB.resolve().as_uri() + "?mode=ro", uri=True) as db:
        # Final text remains hidden: record only terminal metadata, not the
        # endpoint. This does not touch the live checkpoint or retry anything.
        for rid, stage, status, finish, usage in db.execute("SELECT id,stage,status,json_extract(result,'$.finish_reason'),json_extract(result,'$.usage') FROM requests WHERE stage LIKE 'final/%'"):
            result = {"finish_reason": finish, "usage": json.loads(usage) if usage else None}
            if result.get("finish_reason") == "length" and rid not in terminal:
                ident = stage.split("|", 1)[1]
                with terminal_file.open("a", encoding="utf8") as h:
                    h.write(json.dumps({"id": ident, "request_id": rid,
                        "stage": "final", "status": status, "finish_reason": "length",
                        "endpoint_content_not_opened": True, "usage": result.get("usage"),
                        "no_retry": True}, ensure_ascii=False) + "\n")
                terminal.add(rid)
        for index, rec in enumerate(inputs, 1):
            if rec["id"] in packed:
                continue
            saved = {}
            for arm in ("S0", "S1", "S2"):
                row = db.execute("SELECT id,status,result FROM requests WHERE stage=?",
                                 ("goal/" + arm + "|" + rec["id"],)).fetchone()
                if row is None:
                    continue
                rid, status, raw = row
                result = json.loads(raw) if raw else {}
                if result.get("finish_reason") == "length" and rid not in terminal:
                    with terminal_file.open("a", encoding="utf8") as h:
                        h.write(json.dumps({"id": rec["id"], "request_id": rid,
                            "stage": "goal", "status": status, "finish_reason": "length",
                            "content": result.get("answer"), "usage": result.get("usage"),
                            "no_retry": True}, ensure_ascii=False) + "\n")
                    terminal.add(rid)
                usage = result.get("usage") or {}
                if status == "success" and result.get("finish_reason") == "stop" and result.get("answer", "").strip() and all(k in usage for k in ("prompt_tokens", "completion_tokens")):
                    saved[arm] = (rid, result["answer"])
            if len(saved) != 3:
                continue
            # Different stable permutation for each case. The reviewer sees
            # no arm, request-ID, prompt, endpoint, usage or outcome in packet.
            ordered = sorted(saved, key=lambda arm: hashlib.sha256(
                ("20261022|scope_role_semantic_blind|" + rec["id"] + "|" + arm).encode()).hexdigest())
            candidate = [{"candidate_id": "V" + str(i), "text": saved[arm][1]}
                         for i, arm in enumerate(ordered, 1)]
            key[rec["id"]] = {"V" + str(i): {"arm": arm, "request_id": saved[arm][0]}
                              for i, arm in enumerate(ordered, 1)}
            packet = {"id": rec["id"], "frozen_case_index": index,
                "question": rec["question"], "ordinary_nodes": rec["ordinary_nodes"],
                "goal_reader_docs": [{"rank": d["rank"], "source": d["source"], "text": d["text"]}
                                     for d in rec["goal_reader_packet"]["docs"]],
                "candidates": candidate,
                "frozen_source_sha256": rec["source_sha256"]}
            with packed_file.open("a", encoding="utf8") as h:
                h.write(json.dumps(packet, ensure_ascii=False) + "\n")
            packed[rec["id"]] = packet
            added.append(rec["id"])
    keyfile.write_text(json.dumps(key, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    print(json.dumps({"new_blinded_cases": added, "available_blinded_cases": len(packed),
                      "terminal_length_registered": len(terminal), "new_API_requests": 0}))


if __name__ == "__main__":
    main()
