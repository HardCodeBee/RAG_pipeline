# L90 independent native, receipt and paired audit

The recount passes. **L1 does not improve the complete-RAG final F1 endpoint** on this frozen-upstream, repeatedly exposed development cohort: 75.9565% → 75.3945%, a decrease of 0.5620 percentage points. Historical original P02 was 76.6889%. This branch is not promoted; the formal evaluation remains paused.

| Cohort | L0 F1 | L1 F1 | L0 EM | L1 EM |
|---|---:|---:|---:|---:|
| Main fixed 90 | 75.9565% | 75.3945% | 65.5556% | 66.6667% |
| HotpotQA 30 | 81.9921% | 79.4921% | 70.0000% | 66.6667% |
| 2Wiki 30 | 93.5714% | 93.5714% | 90.0000% | 90.0000% |
| MuSiQue 30 | 52.3061% | 53.1199% | 36.6667% | 43.3333% |
| Predeclared ordinary-present 84 | 78.9385% | 78.7931% | 69.0476% | 70.2381% |

The paired dataset-stratified bootstrap uses seed 20261022 and 10,000 resamples. Main-90 F1 delta 95% percentile interval is **[-2.8878, +1.4885] percentage points**; the 84-case interval is **[-2.4302, +1.8063]**. These intervals describe the exposed cohort; they are not independent confirmation. Four native-F1 gains, three losses and 83 ties are retained without selection.

All 180 outcomes are complete normal successes. The predeclared semantic scope is the nine final-text-different pairs: all 18 candidate reviews in five batches are locked and match packet/key/full-outcome digests and independently re-rendered actual final-visible contexts. The other 81 pairs have identical final text and were not redundantly annotated. They remain in native scoring; absent duplicate annotation never means score zero. No first labels were edited. L's original reviewers recorded final-context SHA256 rather than candidate-text SHA256; the audit respects that schema and additionally binds exact candidate text through the locked packet and full source record.

| Native change | Locked semantic interpretation |
|---|---|
| Mississippi River → Mississippi River Delta; +0.2000 F1 | A real requested-location repair. L0 gives the already identified river; L1 retains its mouth/location from the goal conclusion. The frozen earlier goal reader independently verifies that location. |
| Karen Fairchild of Little Big Town → Karen Fairchild; +0.5000 | Both are correct. Removing a true affiliation improves string match; it is not a repaired relation. |
| Genetic explanation adds intermarriage/conversion; +0.0379 | Specific mechanism information is better retained, but the demographic population binding is still pending. This is not a verified whole-answer repair. |
| After Hours longer negative; +0.0087 | The wrong work/person scope remains and the available positive nomination is omitted. Whole factual certainty is pending; native overlap does not repair it. |
| O → five-production list; -0.7500 | Extra productions' eligibility under “1998 onward” remains pending. Native loss alone does not establish false facts; a pre-1998 debut does not exclude later runs. |
| Detailed Golestan location → Golestan in Iran; -0.4216 | Both are correct and responsive. The omitted northern/Caspian detail is true; native granularity loss is not a factual error. |
| Genesis answer adds explicit NES 8-bit comparison; -0.0808 | Both retain the valid comparative advantages. The longer true comparison receives lower native overlap; do not count that as factual damage. |

The two other different-text pairs have tied F1: St. George / St. George, Maine are both correct; the shared-vegetation pair remains the same incorrect negative inference. Among these nine reviewed pairs, only Mississippi establishes a complete final-answer repair. This is a scoped observation, not a population repair rate.

The separate historical original-P02 → fresh-L0 repetition uses **90/90 byte-identical complete goal requests**. Twenty-six goal texts change; 64 final requests remain byte-identical; six final texts change, including one under an identical final request. Native F1 has one gain, two losses and 87 ties, yielding 76.6889% → 75.9565% (-0.7324 points). The six final-text changes concern Veltjens/Goering punctuation, Pōmare qualification, Bozimo name form, Genesis wording, Springfield answer phrasing and the German-unification date granularity. This nonconcurrent drift mixes time/service/generation variation; it is not a pure random-variance estimate or a concurrent factorial control. L1 remains 1.2944 points below the historical reference.

The strict audit verifies all 138 frozen pins, all 90 original goal/formatter/final renderings, prefix exclusion of old goal/formatter/final charges and every one of 360 logical stage uses. There are 309 unique new current receipts, all matching-model, nonempty `stop`, no refusal and complete nonnegative integer token counts excluding booleans with total=sum. Neither arm triggers formatter or final length in this run; the stage-aware audit still preserves the declared legal final-length policy. Maximum observed durable attempts are three, below five.

| Expense | CNY |
|---|---:|
| Actual new returned usage | 0.5620716 |
| Eleven retired unknown submissions, reservation retained | 0.0851000 |
| Orphan reservation | 0 |

Repeated full-payload uses are attributed logically without charging the namespace twice. Historical source expenses are excluded from new charges. Completion does not clear unknown liabilities. No API, retrieval or GPU operation was performed by this audit.

The [core audit JSON](ROOT_NATIVE_RECEIPT_AUDIT.json) contains receipt, native, cost, bootstrap and source proofs. The [paired interpretation JSON](ROOT_NATIVE_PAIRED_INTERPRETATION.json) retains all nine paired answers and their original locked reviews, plus all 90 historical repetitions. Original L scripts, reports, inputs and labels remain unchanged. The upstream pipeline was frozen: these results describe final quality after regenerated goal/final stages and do not measure fresh upstream processing time or a full fresh run.
