# balanced20：变动节点的事后解释

这是**非盲、探索性**轨迹解释，不是独立金标。仅核查全部发生输出文字变化的2题、3个普通节点与1个goal；不重新标注其他题，也不估计全局事实正确率。40个计划条件中38成功、2个已知provider-held，只有19个完整配对；不把缺失题补成结果。

19个可用配对的final全部相同。32对普通节点只有6对实际current改变（18.75%）；3个普通回答文字改变、1个goal文字改变，所有reader保持相同。此前筛出的8题是7/16 current改变（43.75%），其样本由已暴露的6个失效和2个弃答边界组成；两个比例只说明此次干预实际触发覆盖不同，不是正确率或总体失效分布。

| 题目与节点 | 实际变化 | 事实与必要信息 | 为何final持平 |
|---|---|---|---|
| HotpotQA `5abcee275542993a06baf9af` step2 | 描述式current→Who directed *Pulgasari*?；Shin Sang-ok→Shin Sang-ok and Chong Gon Jo | 同reader明确列两位导演。旧答真实但未列全按既有规则仍对；新答增加真实细节，没有修复所问绑架年份 | 两臂goal实时改写都问Shin被绑架年份，保留同一主体与1978 |
| 同题goal step3 | the director→a director | 主体Shin、电影Pulgasari、年份1978均相同；不能只凭the/a宣称旧答断言唯一导演 | final同为1978；没有把绑架对象换成新增共同导演 |
| 2Wiki `d6e9771908dd11ebbd9eac1f6bf848b6` step3/4 | actual current明确Dinu Cocea/Richard Sale，回答删去各自电影名同位说明 | 卒日分别仍为26 December 2013和March 4, 1993，reader直接支持。前答电影→导演映射及raw row.request保留，必要关系没丢 | history文字虽变，接受的rewrite和reader未变；goal完全相同，比较1993早于2013，final仍My Wife’s Best Friend |

新回答的变化有事实依据，但这两题没有观察到**必要事实纠错**。因此未产生新的下游实体、日期或比较结论。另26/32普通节点的实际current本来未变化，也限制了这项接口改动的可作用范围；不能把此结果解释成“冻结D的下游普遍不能改进”，也不能据此判其余未变答案都已正确。

证据全部来自本轮实际reader：Pulgasari（doc1900912）明确“directed by Shin Sang-ok and Chong Gon Jo”及“Director Shin had been kidnapped in 1978”；Dinu Cocea（docb9c2…）给2013卒日，Richard Sale导演（doc0b832…）给1993卒日。完整raw/model current、两臂回答、live改写、history/reader变化、请求及outcome/context哈希与逐字短引见同名JSON。本报告没有待核新事实，也没有新增API/GPU/网页/外部评审请求；原始源、标签与native分数均保留。
