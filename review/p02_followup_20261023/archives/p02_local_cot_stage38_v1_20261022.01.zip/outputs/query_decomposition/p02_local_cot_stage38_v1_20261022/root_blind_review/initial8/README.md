# Method-masked ordinary-answer review

Review only the current subquestion, prior QA, frozen retrieved passages and
candidate outputs in this packet. Do not open the private identity mapping,
other experiment scores or method-specific outputs until labels are locked.
Candidate order and IDs are randomized. Response structure remains visible,
so method masking cannot provide perfect blinding.

Three axes are separate:

1. complete_raw_response_correctness: assess every factual assertion and
   relation/operation in the raw response, including Support. A correct Answer
   does not make false Support correct. Allowed working values are correct,
   incorrect, pending, or no_response. Pending is an unresolved work item, not
   a new truth category. Explain the exact incorrect statement or open fact.
2. accepted_answer_correctness: judge the actual answer that would be handed
   onward after the native formatter, independently from Support. Values are
   correct, incorrect, pending, or no_accepted_answer. A returned format or
   length failure has no accepted answer; do not invent one from a plausible
   substring. Raw and parsed text remain available for diagnosis.
3. accepted_information: sufficient_for_current_question, useful_partial,
   no_useful_information, misleading, pending, or no_accepted_answer. State
   which necessary entity, directed relation, attribute, qualifier, condition
   or operation the inputs establish and whether the accepted answer retains
   it. True but incomplete answers or reasonable abstentions may be correct
   on axis 2 while transmitting little useful information on axis 3.

Apply the previously agreed correctness rules: judge full statements, not
just an answer entity; a correct relevant factual answer stays correct even
if retrieval was weak; an incomplete list is acceptable if its stated facts
are correct and responsive; true background that does not answer the question
is incorrect. A reasonable abstention can be correct when the supplied facts
are insufficient. Do not infer absence from missing evidence. Evaluate time-
sensitive facts in the dataset/frozen-material setting. Resolve facts from
these materials first; outside verification is reserved for genuine missing
or conflicting facts and must be recorded with its source.

Inputs are exposed development cases, not a new holdout. No final-answer F1 is
measured here. Formatter output is shown separately: it may repair a short
response or introduce a new error. The first axis concerns raw emitted text;
the second and third concern accepted_answer, not the unforwarded Support.

Fill REVIEW_LABELS.jsonl, keeping candidate IDs unchanged. Give concrete local
evidence and uncertainty notes. Lock that file's SHA256 before using the private
identity map. Do not replace a held/algorithm-failed outcome with a historical
answer or silently count missing outputs as factually incorrect.
