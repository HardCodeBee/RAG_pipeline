"""Reproduce M4 exact source-title/token duplicate groups and replacement sets."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[5]


def rows(path):return[json.loads(s)for s in Path(path).read_text(encoding='utf-8').splitlines()if s.strip()]
def digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()


def detail(inv):
    path=ROOT/inv['source']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==inv['source_sha256']
    case=json.loads(path.read_text(encoding='utf-8-sig'))
    node=next(n for n in case['nodes']if n['step_id']==inv['step_id'])
    union=[];seen=set();ranks={}
    for i in range(10):
        for name in ('original_retrieval','rewritten_retrieval'):
            packet=node.get(name)
            if packet:
                d=packet['docs'][i]
                ranks.setdefault(d['doc_id'],{})[name]=i+1
                if d['doc_id']not in seen:union.append(d);seen.add(d['doc_id'])
    docs={d['doc_id']:d for d in union}
    groups={}
    for d in union:
        # This is the exact signature used by policies.py M4; no lowercasing,
        # punctuation deletion, stemming, sorting, or cross-title equivalence.
        signature=(d['source'],tuple(re.findall(r'\w+|[^\w\s]',d['text'])))
        groups.setdefault(signature,[]).append(d['doc_id'])
    clusters=[dict(source_field_exact=signature[0],ordered_case_sensitive_word_and_punctuation_fingerprint=digest(signature),
        representative_doc_id=ids[0],doc_ids=ids,route_ranks={i:ranks[i]for i in ids},
        texts=[docs[i]['text']for i in ids])for signature,ids in groups.items()if len(ids)>1]
    old,new=inv['selected_doc_ids']['M0_original_interleave'],inv['selected_doc_ids']['M4_format_duplicate_fill']
    def describe(i):return dict(doc_id=i,source=docs[i]['source'],route_ranks=ranks[i],text=docs[i]['text'])
    return dict(id=inv['id'],dataset=inv['dataset'],review_index=inv['review_index'],step_id=inv['step_id'],role=inv['role'],
        source=inv['source'],source_sha256=inv['source_sha256'],changed_membership=set(old)!=set(new),
        source_binding='Exact doc.source field: article title/identity, not dataset/corpus name. doc.text also retains original heading.',
        duplicate_groups=clusters,old_doc_ids=old,new_doc_ids=new,
        removed_old_selected_documents=[describe(i)for i in old if i not in new],
        added_saved_pool_documents=[describe(i)for i in new if i not in old],
        replacement_pairing='Sets of removed/added slots only, no invented semantic one-to-one attribution.')


def main():
    inv=rows(HERE/'NODE_POOL_INVENTORY.jsonl')
    changed=[r for r in inv if r['changed_membership']['M4_format_duplicate_fill']]
    ds={d:{role:dict(nodes=sum(r['dataset']==d and r['role']==role for r in changed),
        queries=len({r['id']for r in changed if r['dataset']==d and r['role']==role}))for role in ('ordinary','goal')}for d in ('hotpotqa','2wiki')}
    totals={role:dict(nodes=sum(r['role']==role for r in changed),queries=len({r['id']for r in changed if r['role']==role}))for role in ('ordinary','goal')}
    details=[detail(r)for r in changed]
    (HERE/'M4_EXACT_CHANGED_NODE_DETAILS.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in details),encoding='utf-8')
    targets=[detail(next(r for r in inv if r['review_index']==idx and r['dataset']==ds and r['step_id']==2))for ds,idx in [('hotpotqa',7),('2wiki',721)]]
    spans=rows(HERE/'ANNOTATED_READER_DOCUMENT_STRESS.jsonl')
    assert all(r['retained_document']['M4_format_duplicate_fill']for r in spans)
    output=dict(total_changed_nodes=len(changed),total_changed_queries=len({r['id']for r in changed}),by_role=totals,by_dataset_role=ds,
        role_query_sets_overlap=True,exact_source_binding='doc.source string equality; perarticle title, no cross-title duplicate merging',
        normalization='Ordered case-sensitive Unicode word and punctuation token sequence; preserve word boundaries, numbers, punctuation/symbols and case. Whitespace around tokens alone may differ; never remove all spaces and compare concatenated letters.',
        targets=targets,retained517_definition=dict(annotation_file='MANUAL_INFORMATION_FLOW_REVIEWS_V9.json',
            source='reviews[].evidence[] with route=reader_packet and explicit step_id/doc_id/verified_quote',
            raw_instances=len(spans),unique_case_step_doc=len({(r['id'],r['step_id'],r['doc_id'])for r in spans}),
            unique_cases=len({r['id']for r in spans}),exact_original_quote_locations=sum(r['exact_quote_in_original_reader']for r in spans),
            all_same_doc_ids_retained=True,criterion='Same original doc_id in M4 selection for same case+step, not mere answer-string matching. Body text/source comes from same saved route doc; renumbered Chunk header is not new evidence.',
            scope='Previously cited necessary facts/counterevidence within declared manual checks, including pending records; not exhaustive gold, not517 independent queries, not final correctness.'),
        new_API_GPU_retrieval=0,no_F1_effect_evaluated=True)
    (HERE/'M4_DETAIL_SUMMARY.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in output.items()if k!='targets'},ensure_ascii=True))


if __name__=='__main__':main()
