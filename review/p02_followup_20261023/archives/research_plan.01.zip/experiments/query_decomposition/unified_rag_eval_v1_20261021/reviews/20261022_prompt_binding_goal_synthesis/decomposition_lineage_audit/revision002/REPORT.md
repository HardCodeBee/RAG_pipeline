# P02 分解输入溯源补充：W90 / E / R 与 S27

W90全部90题均逐字追到冻结R02/v12真实远端输出，没有发现人工corrected60替换。E30的27个独立原题、R15的14个独立原题全部来自这90题，实际子问、历史QA、reader及控制prompt与源节点一致。此结论来自逐条数组和来源核查，并非从此前formal40题外推。

| 来源 | 核查范围 | 真实分解来源 | 结果 |
|---|---:|---|---|
| W90 | 90题 | role_headers → parent/source_prefix B0_legacy_multigrain_R02 → raw300 → returned snapshot_004.zip | 90/90数组、原题、prompt、身份及返回JSON所有字段一致；原bytes因CRLF不等，LF规范化后完全一致 |
| E | 30节点、27独立原题 | W90对应源节点及raw数组项 | 全部一致 |
| R | 15节点、14独立原题 | E同期节点及W90完整raw数组 | 全部一致 |
| S27 | 27题 | formal1500 remote_raw | 27/27数组、原题、prompt及身份一致 |

W90对应远端任务154657，输出目录为`/home/projects/u7830488/decomposition_error_expand60_v1_20261019/results/round1_300`。`expand60`只是原诊断目录名；这里使用的是该次300题全部生成池中的原始数组，不是人工修正60题。W90与人工修正60题有16个相同题目ID，但16/16实际数组均与人工修正版不同，同时90/90实际数组都与远端返回包中raw_output字符串及全部JSON字段完全相同。逐条证据见W90_LINEAGE.jsonl。

两条来源的记录均绑定同一checkpoint：`/home/projects/u7830488/multigrain_4b_coverage_retrain_v3_20261018/results/v001/training40/r02_expanded/checkpoint-final`，manifest hash `728fb4761116debf44ca4c7078a09283939beeb590b35e4a8647e6131a9fce92`；v12 prompt hash `508709f217ee58ca53d60ecce6001d5e5b0e6d51a858dd4b95b2d6d311864ee8`。基础模型记录为`Qwen/Qwen3-4B-Instruct-2507`，revision `cdbee75f17c01a7cc42f958dc650907174af0554`。本次复核了本地返回manifest及可用metadata；没有重读远端adapter/base权重，不把这次审查称作实时权重验证。

必须分列生成口径：W90是较早score_model.py产生的真实历史输出，身份记录只有greedy/beam1/max1024/seed1729。formal1500使用更新的`explicit_generation_config_v002`，多记录effective_do_sample/effective_num_beams并显式传入generation_config。相同checkpoint/v12不意味着同一次生成，也不能证明旧批满足formal的新默认覆盖合同。这不影响保留W90作为冻结历史开发对照，但限制跨批的解码一致性表述。

W90与formal1500按`(dataset,qid)`比较交集为0；按数据集加原题完整文本比较交集也为0。因此交集题目的数组一致性比较不适用，不能用裸qid跨数据集拼接。

本次只新增溯源报告，不修改任何输入、历史source、付费W协议或进程状态；不联网、不发API、不运行推理。T分支仍只准备。原始文件bytes并非逐字相同：90/90本地raw使用CRLF，远端zip成员使用LF；规范化换行后90/90文件bytes完全相同，所有JSON字段和tokenIDs均相同。首次审计将此bytes差异标成FAIL的记录仍保留在父目录；其报告中预先写入的bytes一致表述由本revision002明确更正。完整计数、核验hash与限制见SUMMARY.json；E/R逐节点表见E_R_NODE_LINEAGE.json，S27逐条表见S27_FORMAL_LINEAGE.jsonl。
