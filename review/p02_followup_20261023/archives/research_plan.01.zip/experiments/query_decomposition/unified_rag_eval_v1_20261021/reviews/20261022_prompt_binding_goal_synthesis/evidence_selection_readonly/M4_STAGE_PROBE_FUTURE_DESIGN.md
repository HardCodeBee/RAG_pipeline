# M4最小阶段对照的后续设计（未排队、未授权）

当前仅O8实际任务原题块对照获准执行。本文是下一候选的只读可行性建议，没有新实验目录、采样冻结、授权、模型调用、检索或GPU作业；O8结束及复核前不安排M4执行，不与O1、live实体目标或ROLE叠加。

已有依据限定在主270条的保存材料。M4改变138节点、108题，均为2Wiki；普通43节点/28题、goal95节点/95题。按原270分组，已有满分对照中改变ordinary20节点/12题、goal7节点/7题；原非满分组为ordinary23节点/16题、goal88节点/88题。以上仅是选集变化池，尚不表示所有节点的R02实际数组、原请求回执与公开来源都已为一个新runner完成逐项冻结。

明确candidate→reader必要证据丢失只人工确认2例。M4能使Wiki721 goal step2的Queen of Portugal日期段进入reader，不能救回HP7的Doomsday Prophecy；不能将所有69条最终信息不足归为merge。旧517条reader引用全部保留，只是机械引用保留，不能作为质量安全证明。

建议最小的实际生成范围为8个**发生M4选集变化的节点**、16条fresh条件：

| 预声明组成 | 节点数 | 用途 |
|---|---:|---|
| Wiki721 goal step2 | 1 | 已曝光、已确认的必要日期段恢复案例，单列诊断，不作未见确认 |
| 既有固定满分对照中的changed goal | 3 | 检查加入候选及同名身份冲突是否伤害原成功路线的局部回答 |
| 既有非满分组中的changed ordinary | 2 | 不按局部问答错误或新生成输赢筛选，检查一般子问材料利用 |
| 既有固定满分对照中的changed ordinary | 2 | ordinary成功路线回归面 |

这是4 ordinary、4 goal，全部2Wiki、暴露开发挑战。除明确指定的Wiki721外，将来若授权准备，再按固定ID/step哈希从上述完整分层池取样、优先每题一节点；不得看新增输出后换题。选择“已有满分路线”只定义回归层，不表示旧节点QA本身必然正确。不用历史得分挑最高/最低节点，不声称总体提升率。此处没有产生实际入选名单或冻结新cohort。HP7作为**离线不变合同**保留：M4对其19候选无排版重复、选集不变，不为相同输入额外启动一组付费随机重复。

两个条件只有选文不同：M0为原core.merge的doc_id去重、original优先交错Top10；M4为既有policies.py的M4_format_duplicate_fill原样。source严格等于doc.source的文章标题/实体归属，正文指纹为区分大小写的有序Unicode词和标点序列`tuple(re.findall(r'\w+|[^\w\s]', text))`。不跨标题合并，不折叠father/grandfather、日期、单位、否定、词边界或大小写；保留旧union先出现的文段，依旧union回填并保持相对顺序。若不同指纹不足10，沿既有规则用原池候选回填，维持10篇；这不是保证10种互不重复内容。不得按gold、诊断quote、预测或得分选文，也不得改成M3词汇排序。只读policies.py包含多个探索分支，实际新入口应明确只允许M0/M4，不把其他规则列为候选再择优。

源输入固定到节点当时的原始query、R02/v12实际supporting_questions、step、raw Current、先前完整QA、已保存的original/rewritten两路各Top10及顺序。逐源hash/公开manifest核验，逐题将D与formal remote_raw实际数组匹配；不从人工60或query-only修正导入D。M0 reader必须逐字等于原node.reader_packet；M0完整goal/ordinary payload必须逐字等于原真实请求。M4只重新渲染实际材料块，保留原child主指令、fewshots、Original question、history、raw Current与goal特有GOAL_RULE。原QA目标保持raw Current，不能采用C/live实体目标或O1原题块删除。

两臂均fresh、同新checkpoint、seed=None，普通及goal回答均128；若strip后少于4个空白分词，使用原Pipeline完整事实句formatter128、原raw Current与**本臂reader**，保留原触发规则和文本。分别保存initial与formatted answer，防止把formatter造成的改变归为reader直接作用。最多16个QA阶段和16个条件触发的formatter阶段；没有rewrite、retrieval、goal下游或final重算，没有完整RAG F1/EM。若普通回答变了，固定旧history的后继节点只仍是独立保存阶段，不能称动态完整流程。

实现可继承的最小入口：

- O8 `p02_ordinary_scope_input_probe8_v1_20261022/run.py`的独立16条件账本、授权、只读report与fresh骨架；删除其O1模板接口，新增仅M0/M4 reader成员差异合同。
- `p02_live_target_balanced20_dev_v1_20261022/native_ask.py`及共享StrictAsk/gate/NoCapBudget原样导入并pin；model和三项usage一致、SDK/HTTP0、技术max5、返回迹象/账本崩溃窗hold、算法失败不重抽、unknown预留全部保留。
- 原`core.child_prompts.child`、`core.pipeline.passages`及goal GOAL_RULE；formatter文字/少于4词分支参照`p02_goal_native_role_fixed90_v1_20261022/templates.py`的原生合同，但Question取**当前节点raw request**，Context取本臂reader，绝不调用该文件的ROLE或final函数。
- 现有`evidence_selection_readonly/policies.py`的M4原函数，以及`M4_EXACT_CHANGED_NODE_DETAILS.jsonl`/source hash作离线复现依据。新代码不改core、旧M4、旧实验或正式协议。

准备阶段的必要fake/字节合同包括：M0 wire与源完全一致；M4只有实际材料块及由其派生的formatter Context改变；相同标题不同事实不得合并；不同标题相同正文不得合并；有序词边界、亲属、日期/单位差异不得合并；选集保持10篇且来自原union；Wiki721目标段恢复、HP7选集不变；少于4词才formatter且普通/goal两臂都同规则；缺usage/模型不符held、length/拒绝/空答不重抽；16fresh和续跑不导入历史回执、report不构造Cache。无formatter触发的历史不代表新两臂不会触发。

若未来执行，方法遮蔽后按raw Current检查完整事实正确性、必要信息实际获得/保留、同名身份/时间范围和新增干扰；原合理弃答与真实不完整答案的truth口径不变，truth与必要信息增益分列，所有退步报告。机械省slot、答案更长或表面词匹配不等于实质修复。Wiki721若改答仍不能单凭“正确日期进入reader”认定成功，也不能由一例局部修复推断完整RAG收益。出现明确原成功信息/事实回归应先停止推进并核查；没有实质局部修复则不扩大。之后是否值得完整动态小对照，由root在O8结果及该阶段证据后另行决定；完整动态验证必须重算受影响的后续rewrite、检索、QA、goal及final。
