# HP10+Wiki10完整动态对照：最小复用可行性

这是后续可行性设计，不是新实验协议、cohort冻结、执行授权或结果。当前full8及其所有文件保持不变，不启动API、SSH、上传或GPU。Info agent正在只读核可用性及排除清单；是否执行由full8审核后决定。

## 可以原样复用的部分

现有`p02_failure8_dynamic_target_fullrag_draft_20261022/flow.py`、`native_ask.py`、`resource_contract.py`和`retrieval_bridge.py`是注入式接口，逻辑不依赖8题。复制到独立兄弟目录后要求字节不变、固定来源SHA：两臂仍为原QA current与本臂现场accepted rewrite作为actual ordinary current，全部ordinary统一应用；rawD/request、goal、formatter及final原生行为不变。共享StrictAsk、gate、NoCapBudget继续直接引用已冻结版本，不改旧shared代码。

现有worker按allowed_qids集合工作，不依赖题数，可原样复制和pin。桥主要按目录、输入文件名、独立job prefix定位，不需新框架；新目录必须产生新的protocolhash、namespace、spool和GPU job，不能接管full8作业158960或其提交回执。`QUERY_MODEL.frozen.json`及两数据集物理资源合同保持字节一致，实际运行前仍校验代码、VALIDATED stamps、模型文件hash、GPU分配和唯一部署锁。旧作业终止后不静默重投；技术恢复需root核查job/receipt。

## 新兄弟runner只需的改动

以已审核full8 runner复制形成新文件，不修改原runner。用`N=len(INPUTS)`派生每臂20、条件40，替换报告/完成退出检查/轮换顺序中的8和16常数，以及文件名和旧I8 assemble。参数化止于此，不建立通用大框架。

新assemble直接join Info冻结的formal1500原题表与实际`remote_raw/<position>.json`，逐字验证ID、原题、rawD数组、v12实际prompt和未截断/无generation_error，生成只含id/qid/dataset/question/supporting_questions的推理输入。**不要求已有完整RAG轨迹**，因此可纳入已有正式rawD但尚未完成旧RAG的HotpotQA题。原始D来源和近期probe排除来源留在单独provenance，不传给模型。参考答案从正式本地reference独立join，只在report读取；不能为缺旧轨迹虚构旧预测或旧成绩。

Info当前拟定最小cohort字段为：id/qid/dataset/question/supporting_questions、formal_position_one_based、question_file_sha256、raw_file/raw_sha256、actual_R02_array_exact、exclusion_sources，以及all723_prior_semantic_exposure。按seed20261022哈希ID在两数据集各选10，不按旧F1、新改写或修复输赢选题；只排实际近期prompt/inference实验IDs。2026-10-22冻结前已修正：**不排除被动信息审阅270**，否则会因这270包含全部230个旧非满分而把Wiki剩余集合偏成旧满分回归集。旧完整RAG是否可用也不作选择过滤。排除空D的范围需明确沿用户有ordinary问题的约定；1个ordinary的题可自然成为无历史、两臂接口相同的部署负对照，不为增加效应事后剔除。

Wiki已有723诊断中的语义暴露不能消除；这只能称与近期probe不重叠的更广开发对照，不能称独立未见确认。若某原始rawD/问题或来源未出现在此前公开归档，provenance必须如实标记，不凭ID声称已有公开proof；具体外部发送仍需root审核授权。

## 费用与复用边界

两臂均用新checkpoint fresh运行，LLM `seed=None`。只复用同一新实验内完整payload与严格receipt相同的前缀；不导入full8/C/W/L模型回答。检索也只复用新实验内resource+dataset+qid+query+k精确packet，变化查询真检索。各臂完整逻辑tokens/cold费包含共享前缀，实际新增按首次付费request去重，失败技术尝试已知实付计入、unknown预留单列。

新题没有同题旧完整RAG费用时，不能填0或把阶段费冒充query费。使用冻结的同方法、同数据集完整query历史均费作为明确标记的proxy（若连该项也没有则另标同方法跨集proxy）；记录来源、完整query数和均值。新runner的历史费用接口只需改为每题reference_CNY与reference_kind，无需保留full8硬编码的历史stage列表或旧质量参考。单query超过参考3倍提醒，趋势仍为最近20个完整paid query均费、排除纯缓存/技术partial/unknown；同期variant共享前缀是费用代理，不能包装为独立cold部署费用。

## 离线准备与审核门槛

原全8 source replay保持原目录的历史验证不动；新20只要求原题/rawD来源与完整推理输入隔离正确，缺旧轨迹不强造回放。复制原dynamic flow/formatter/receipt/5次恢复/费用/全条件完成前不建桥等fake合同，测试用N派生，并继续验证40条件全部完成后重复run仅只读report、不会重复分配GPU。每数据集官方scorer仍只构造一次。原root远端六类mock亦复制复核新目录、allowed_qids和spool隔离。

完成后冻结独立代码、输入、资源、排除清单及参考，交root审核；未审核前只停留在设计。无额外prompt因子，不同时加入ROLE或M4，不恢复正式500题主评。
