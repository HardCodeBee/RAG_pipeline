# 子问题改进之后的完整下游验证与远端检索入口

本文件只记录2026-10-22的离线只读设计，没有创建执行授权，没有调用API、SSH、检索或GPU，没有打开可写Cache，也不改变任何正式评估STOP。本轮I8是5条HotpotQA、3条2Wiki的8个不同原题；只有局部子回答改善，不能算完整RAG最终F1目标已经达成。

最轻的既有完整下游模板是`experiments/query_decomposition/p02_childprompt_selfcontained_quick90_v1_20261021/run.py:229`的`run_dataset`。它保留实际分解，运行完整`Pipeline`，检索精确命中旧只读缓存后复用，变化查询没有命中时真正搜索冻结全语料。该旧文件绑定自己的历史实验目录、旧Ask、300元上限和三线程，不能直接作为本轮入口启动。新的独立小runner只借其结构，使用当前StrictAsk/SubmissionAwareStrictAsk、NoCapBudget、共享gate和持久最多5次技术尝试。

原流程入口为`src/p02_multigrain_timing_cachefix_v1/core/pipeline.py:118`。固定source中的真实R02/v12 `supporting_questions`、数据集及原题全文，排除人工corrected60。不顺手切换`p02_noformatter_quick90_v1_20261021/pipeline.py`：原流程的短回答formatter、rewrite256、ordinary/goal128、final64和原展示包装属于控制。旧quick90的`run.py`是禁止任何新查询的纯回放，不能承担改动回答后的动态完整下游验证。

可复用首个改动ordinary QA之前的不变前缀，但必须逐项比较完整请求body、stop、模型身份及整数usage；只比较当前子问题文本不够。改动QA进入history以后，所有后继rewrite应从新history重新渲染，变化的查询必须真实检索，重新合并reader、生成后继子答、goal和final。即使某个原子问题文字没变，历史答案变了，完整LLM payload通常也变了。旧reader冻结的阶段回放不能改名为完整流程运行。

后续完整质量比较建议保留全部8题并使用同期fresh控制，不只挑I中局部获胜题。需在执行前明确二选一的干预范围：只改I8锚节点并重算完整下游，用于机制传播；或将新句应用于全部ordinary节点，验证真实部署策略。这两种范围不能混作同一结果。参考答案仅在本地report加入，每数据集初始化一次官方scorer；局部语义结论与最终F1/EM分别保留。完整流程逻辑tokens归属包括复用前缀，新增实付与unknown预留另列；复用运行不能证明完整流程新鲜耗时。

安全检索复用已有较完整组件：`experiments/query_decomposition/p02_flow_simplify_v1_20261020/retrieval_adapter.py:80`。其`seed_cases`与`seed_databases`只读旧source或DB，使用原route packets，不拿合并reader冒充检索缓存；qid、原样query、k和完整资源对象共同绑定。case seeding要求同资源，重复身份保留第一份，不按gold覆盖或最终分数选择。`src/.../core/runtime.py:258`是更轻例子，但其检索key不含完整资源，只靠checkpoint身份；跨机器时不能直接混用Windows/Linux路径不同的资源对象。

当前本地三套corpus/chunks/offsets/BGEparts和固定HF snapshot路径均存在。本轮只检查存在及大小，没有重新全量hash或载入GPU。资源路径详见`src/p02_multigrain_timing_cachefix_v1/config.json`：HotpotQA为`artifacts/build_65e9037e4c1eed7b`，2Wiki与MuSiQue为`data/multihop_comprehensive_v1_20261015/{dataset}/corpus`及其`dense`目录。文段数分别为5,233,329、430,225、139,416。

远端优先借已有资源，不重建向量。历史部署根为`/home/projects/u7830488/robustness_models_retrievers_v1_20261017`；资源在`resources/{dataset}/manifest.json`，Python环境在`.remote_env/robustness_models_retrievers_v1_20261017/venv/bin/python`，HF缓存为`.remote_cache/huggingface`。这是本地记录中的部署位置，不是本轮实时SSH核验。旧`PAUSE_STATUS.json`记录了持久暂停，不能调用该项目的旧resume/run_gpu/continuation来借用资源。

可复用`experiments/query_decomposition/robustness_models_retrievers_v1_20261017/remote_resources.py`的`load_resources:157`、`verify_resources:253`、`PortableRetrieval:597`。BGE固定为`BAAI/bge-small-en-v1.5@5c38ec7c405ec4b44b94cc5a9bb96e735b38267a`、384维、归一化内积、max512；原Top11过滤qid后取Top10，50000行分块精确CPU FAISS扫描。GPU只承担query编码，原语料向量不搬GPU、不重新编码。指定`device='cuda', threads=4, max_batch=1`维持单查询算子；默认max_batch32不宜悄悄作为同算术合同使用。

最小落地可以是新独立remote retrieval-only worker和本地付费API orchestrator，保留当前端点、共享gate、账本，远端不需要API凭据。本轮未找到可直接使用的P02动态远程检索RPC，需要另做小JSONL桥；整体runner移到远端则还涉及账本、gate及凭据部署，变更更大。实际执行前需独立核对当前远端manifest/VALIDATED stamps、冻结文件hash、GPU分配及已有任务，不据旧状态推断资源此刻空闲。

历史`ACTUAL_RESOURCE_VALIDATION.json`保存了全资源SHA验证和少量parent packet核对：文段ID与文本一致，历史score浮差最高2.98e-7。它不能证明所有跨硬件查询位等价。跨机缓存须冻结源corpus、offsets、embedding、模型和tokenizer的hash对应及路径转换，不能只因模型名相同便复用。新检索保留query、rank、score、doc_id、文本和硬件，必要时报告边界浮差。

此设计尚未实现新RPC或新完整RAG执行器，未创建RUN_AUTHORIZATION。正式评估及其STOP保持不变。
