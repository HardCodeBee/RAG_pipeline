# 双路候选到reader：只读盘点与最小选择候选

主270条中，目前能以既有人工判断加原始packet独立证实“必要材料已检到、随后被merged10丢弃”的是**2条**：HP7和Wiki721。270由230条非满分及40条固定seed满分对照组成，258条完成其声明的必要信息检查、12条待核。本次逐源hash核验270题、逐节点复现696份原`core.merge`，全部与保存reader逐字一致；这不使原语义审阅自动变成穷尽金标。

| 范围 | 可核验计数 | 含义 |
|---|---:|---|
| 主cohort | 270题、696节点 | 全部原sourcehash及merge复现 |
| 双路检索 | 303节点、234题 | 存在额外改写route |
| 候选union超过10 | 287节点 | 至少有候选必须被截去 |
| 有候选被截的题 | 223/270 | 仅容量事实，不能称223个错误 |
| 被截候选 | 2335个节点-doc组合 | 不表示2335条必要事实 |
| 人工已证实必要candidate→reader loss | 2/270；均在非满分230内 | 保守可核验发现数，非穷尽发生率 |
| 原final信息不足组 | 69/230 | 不足可能发生在候选、QA、传递或scope等位置，不能全部归merge |

两条明确证据如下。完整原题、source/hash、当前实际子问、改写、人工信息需求和原文引用保存在`SUMMARY.json`。

| 案例 | 已取得的必要信息 | 丢失位置 |
|---|---|---|
| HP7 `5ab3eeb5554299233954fff4`，ordinary step2 | 改写route rank10，Doomsday Prophecy段明确同时给Jewel Staite、Alan Dale及2011 | 不在merged reader，也不在该实际child prompt；原问题最终问年份 |
| Wiki721 `d8ffd42a0bda11eba7f7acde48001122`，goal step2 | 改写route rank6，Maria of Aragon, Queen of Portugal段给7 March1517 | 正确身份的完整日期不在merged reader；Lady of Cameros同名段被保留 |

HP26的Polson段也在original rank10被截，但它仅提供另一座符合reservation条件的城市，并没有目标政治人物代表关系，不能与上述2条一起计作已取得充分必要链。W90的May1990 rank9案例不属于主270，单列在`SUPPLEMENTAL_CASES_SEPARATE.json`，不混分母。

当前merge按original优先交错，doc_id去重后截10。它不判断必要关系、同名身份或两个候选是否只是排版不同的同一段。这解释了为什么独有改写低rank证据会被丢，但并不说明保留任何低rank证据都会改善答案。

本次只在已经保存的两路各Top10内进行CPU选文，始终最多且实际保持10篇，不调用LLM、embedding、检索或GPU。所有规则只接收原route packets和当前子问文本，词汇规则另使用已经生成的rewrite；没有输入gold、人工quote、原预测或得分。选中后仍按旧interleaved union相对顺序排列，避免仅因集合不变却重排上下文引入额外因素。没有开展新RAG评估或创建固定90正式评估。

| 离线规则 | HP7必要doc | Wiki721必要doc | 改变的节点/题 | 移走原审阅引用doc实例 |
|---|---|---|---:|---:|
| M0原interleave | 未留 | 未留 | 0/0 | 0 |
| M1 RRF60，仅rank sanity | 未留 | 未留 | 27/27 | 0 |
| M2 每路Top1锚＋来源分散 sanity | 未留 | 保留 | 143/111 | 0 |
| M3 每路Top1锚＋当前题及rewrite的词汇覆盖 | 保留 | 未留 | 282/218 | 1 |
| M4 仅同来源排版重复去重后从原union回填 | 未留 | 保留 | 138/108 | 0 |

原审阅引用共517个reader文段实例、517处原文位置，全部先在原reader重新核实。上表只是这些已引用doc的机械保留，既不是所有必要事实覆盖率，也不能把换掉doc自动判为新错误；其他文段可能有相同事实，新加入的干扰段也可能改变QA。M3移走的是仍待核的Wiki254同名Richard Óg de Burgh文段，不能据此强判新事实错误。M3在HP7还引入Alan Alda、Alan Ruscoe，说明词面名字覆盖不足以证明实体绑定与关系相关性。单纯rank融合在两个明确例中都没有救回低rank文段。

最保守、具有较普适工程理由的下一候选是M4：doc_id不同但同source、相同有序单词及标点序列，只在标点周围空白不同的段落，保留旧union先出现的一份，把省下的slot给同池后续候选。保留大小写、拼写、词边界、否定词、日期、数字和标点顺序；不按source删除所有同人物文段，避免丢掉同一传记中的互补事实。原语料确有Maria of Navarre、Lady of Cameros等多份仅排版不同段落占slot；这一依据不依赖参考答案。M4是在初版四规则盘点后，针对排版重复提出的暴露开发修订，初版`SUMMARY_PASS001.json`及`policies_pass001.py`保留，不能包装为盲选或独立确认。

M4仍救不了HP7：那19篇候选多数来自不同文章，没有排版重复可去。HP7需要在保持实体身份与关系的前提下提升候选相关性；M3只能作轻量词面诊断，尚不宜直接作为方法。这里没有把M3、M4叠加调参直至两个案例都命中，也没有声称一种规则已经解决所有证据问题。

若下一步进行小probe，建议先单独验证M4，保留原QA、formatter和final协议，另抽查被替换段确实只是排版重复、补入的低rank文段是否增加同名冲突，并保留原成功样本作回归面。若只冻结原history/双路候选再生成该reader对应QA，那只能称reader选择的阶段probe。若应用于整个ordinary及goal流程，回答改变后必须重算后继rewrite、真实检索、goal和final，不能继续固定旧reader并称完整动态RAG。本文件没有定义新的正式cohort、没有执行授权，没有启动付费probe；最终F1/EM收益仍未知。

M4的“同来源”严格绑定原文段的`doc.source`字符串相等，即本批保存packet里的具体文章标题/身份；不是`dataset`、Wikipedia语料库名称或一个全局来源标签。标题字段和`doc.text`中原有标题均保留。因此`Maria of Aragon, Queen of Portugal`与`Maria of Aragon, Lady of Cameros`不能互相去重。文本指纹为`tuple(re.findall(r"\w+|[^\w\s]", doc.text))`，区分大小写，保留有序词边界、数字、标点及符号，不做全部删空格后拼接字母的比较。例如`New York`与`NewYork`不同；`father`与`grandfather`、1900与1901亦不同。去掉的只是这些有序token之间的排版空白差异。

M4全270题的实际集合变化为138节点、108题，全部来自2Wiki。普通子问为43节点、28题；goal为95节点、95题；两类题集合有交集，不能将28与95相加当总题数。HotpotQA普通和goal均为0变化。控制组40题中变化27节点、15题，非满分230题中变化111节点、93题。每个变化节点的原source/hash、完整去重簇、原选集、新选集、被移走和新选入doc均列在`M4_EXACT_CHANGED_NODE_DETAILS.jsonl`。

Wiki721 goal step2的Top10原选集内，三份排版重复被回填替换：

| 保留的同标题簇代表 | 不再占slot的同簇doc/route rank | 从原候选池新选入doc/route rank |
|---|---|---|
| Maria of Navarre `21e995…`，rewrite2 | `69fd4b…`，rewrite3 | Afonso of Portugal, Lord of Leiria `f94c4b…`，original6 |
| Afonso of Portugal, Lord of Portalegre `0e2f06…`，original3 | `5d8920…`，original4 | Maria of Aragon, Queen of Portugal `604e2b…`，rewrite6，含7 March1517 |
| Maria of Aragon, Lady of Cameros `67599e…`，rewrite4 | `ee44de…`，rewrite5 | Afonso II of Portugal `a30b42…`，original7 |

此表左右按原union顺序展示移走集合和补入集合，不表示逐行语义一对一替换；实际算法仅先去重复、再顺序补slot。完整20候选池还存在Afonso IV和Isabella, Queen of France两簇格式重复，原Top10之外的簇也完整记录，不能把它们都算作原选集移走量。正确Queen文段本身没有同源重复，它是省下slot后进入reader。HP7的19个doc无此指纹重复，Doomsday Prophecy `33214212`仍在rewrite10未被选入，旧选集无移走、无新选入。

“517保留”来自原V9的`reviews[].evidence[]`：只取`route == reader_packet`且有明确`step_id`、`doc_id`、`verified_quote`的原审阅引用，共517个原始标注实例，去重后502个`(case, step, doc_id)`组合，覆盖265题。517处quote均先重新定位到原reader中同一doc；M4再按同题、同step检查这517个原`doc_id`仍在选集，文段正文和source仍来自相同原route文档。重复引用不算独立样本，重编号Chunk标题不算新证据。这些引用包含声明范围内的必要事实和反证及待核题，不能视为穷尽的必要事实金标，更不等于517题最终答对。

M4也有范围限制：有序token相同不等于对所有排版敏感文本都语义等价，代码、诗歌或特殊数式需谨慎。原引用全部保留不证明没有干扰增加或未标注事实损失。语料候选完全缺少必要关系的题，任何20选10规则都无法凭空补回证据。这些都是离线候选证据，尚未测量任何新F1效果。

文件入口：`NODE_POOL_INVENTORY.jsonl`为696节点候选及每规则选择，`ANNOTATED_READER_DOCUMENT_STRESS.jsonl`为517个原引用doc的保留标志，`SUMMARY.json`含原sourcehash与分母，`SUPPLEMENTAL_CASES_SEPARATE.json`分列不充分桥梁及W90日期案例，`OFFLINE_INVARIANTS.json`核对输出上限、单路不变和词边界/关系/日期等区别不被格式去重合并。原core、labels、scores、评估协议和运行状态均未修改。
