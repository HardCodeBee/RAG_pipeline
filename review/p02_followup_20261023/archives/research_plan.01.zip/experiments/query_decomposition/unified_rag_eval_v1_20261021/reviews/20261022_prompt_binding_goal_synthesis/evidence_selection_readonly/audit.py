"""Offline saved-packet inventory; no API, GPU, retrieval, Cache or old writes."""
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
import importlib.util
import hashlib
import json
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[5]
sys.path.insert(0,str(ROOT/'src'))
from p02_multigrain_timing_cachefix_v1.core.pipeline import merge
spec=importlib.util.spec_from_file_location('selection_policy',HERE/'policies.py')
policy=importlib.util.module_from_spec(spec);spec.loader.exec_module(policy)
BASE=ROOT/'outputs/query_decomposition/p02_information_flow_followup_20261022'


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def rows(path):return[json.loads(s)for s in Path(path).read_text(encoding='utf-8-sig').splitlines()if s.strip()]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(name,value):
    (HERE/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def jsonl(name,values):
    (HERE/name).write_text(''.join(json.dumps(v,ensure_ascii=False)+'\n'for v in values),encoding='utf8')


def main():
    assert ROOT.name=='RAG_pipeline' and (ROOT/'src').exists()
    manual=read(BASE/'MANUAL_INFORMATION_FLOW_REVIEWS_V9.json')['reviews']
    cohort={r['id']:r for r in rows(BASE/'INFORMATION_FLOW_COHORT.jsonl')}
    assert len(manual)==len(cohort)==270
    inventories=[];annotation_checks=[];sources={};node_index={}
    for r in manual:
        c=cohort[r['id']];p=ROOT/c['source'];h=sha(p)
        assert h==r['original_source_sha256']==c['source_sha256']
        sources[str(p.relative_to(ROOT)).replace('\\','/')]=h
        case=read(p)
        assert case['id']==r['id'] and case['dataset']==r['dataset']
        assert case['question']==c['question']
        for node in case['nodes']:
            original,rewritten=node['original_retrieval'],node['rewritten_retrieval']
            assert original['query']==node['request'] and len(original['docs'])==10
            if rewritten:assert rewritten['query']==node['rewritten_query']and len(rewritten['docs'])==10
            expected=merge(original,rewritten)
            assert expected==node['reader_packet'],(r['id'],node['step_id'],'native merge mismatch')
            union=policy.pool(original,rewritten)
            predictions={m:policy.select(original,rewritten,node['request'],m)for m in policy.POLICIES}
            ids={m:[d['doc_id']for d in docs]for m,docs in predictions.items()}
            assert ids['M0_original_interleave']==[d['doc_id']for d in expected['docs']]
            route_ranks={d['doc_id']:{name:next((i for i,x in enumerate(route['docs'],1)if x['doc_id']==d['doc_id']),None)
                for name,route in [('original',original),('rewritten',rewritten or{'docs':[]})]}for d in union}
            row=dict(id=r['id'],dataset=r['dataset'],review_index=r['review_index'],selection=r['selection'],
                step_id=node['step_id'],role=node['role'],actual_question=node['request'],rewritten_query=node['rewritten_query'],
                source=str(p.relative_to(ROOT)).replace('\\','/'),source_sha256=h,has_rewritten_route=rewritten is not None,
                unique_union_documents=len(union),original_saved_merge_exact=True,
                original_dropped_candidates=[dict(doc_id=d['doc_id'],source=d['source'],route_ranks=route_ranks[d['doc_id']])
                    for d in union if d['doc_id']not in ids['M0_original_interleave']],
                selected_doc_ids=ids,selected_reader_words={m:sum(len(d['text'].split())for d in docs)for m,docs in predictions.items()},
                selected_reader_utf8_bytes={m:sum(len(d['text'].encode())for d in docs)for m,docs in predictions.items()},
                changed_membership={m:set(v)!=set(ids['M0_original_interleave'])for m,v in ids.items()})
            inventories.append(row);node_index[r['id'],node['step_id']]=(node,predictions,row)
        for e in r.get('evidence',[]):
            if e.get('route')!='reader_packet' or 'doc_id'not in e:continue
            node,predictions,inv=node_index[r['id'],e['step_id']]
            olddoc=next((d for d in node['reader_packet']['docs']if d['doc_id']==e['doc_id']),None)
            assert olddoc is not None,(r['id'],e)
            quote=e['verified_quote']
            exact=quote in olddoc['block']
            annotation_checks.append(dict(id=r['id'],dataset=r['dataset'],review_index=r['review_index'],step_id=e['step_id'],
                doc_id=e['doc_id'],source=e.get('source'),verified_quote=quote,exact_quote_in_original_reader=exact,
                pending_review=r['review_status'].startswith('pending'),
                retained_document={m:e['doc_id']in{d['doc_id']for d in ds}for m,ds in predictions.items()},
                literal_quote_elsewhere={m:any(quote in d['block']for d in ds if d['doc_id']!=e['doc_id'])for m,ds in predictions.items()}))
    assert len({r['id']for r in inventories})==270
    confirmed=[]
    for cid,sid,did in [('hotpotqa:5ab3eeb5554299233954fff4',2,'33214212'),
        ('2wiki:d8ffd42a0bda11eba7f7acde48001122',2,'604e2bf53393913c1d2efa88274bbca4e5e46736e6ed4bcedf03043bfdc5275e')]:
        review=next(r for r in manual if r['id']==cid)
        node,predictions,inv=node_index[cid,sid]
        evidence=next(e for e in review['evidence']if e.get('doc_id')==did)
        packet=node[evidence['route']]
        d=next(d for d in packet['docs']if d['doc_id']==did)
        assert evidence['verified_quote']in d['block']and did not in inv['selected_doc_ids']['M0_original_interleave']
        assert evidence['verified_quote']not in node['child_prompt']
        confirmed.append(dict(id=cid,dataset=review['dataset'],review_index=review['review_index'],step_id=sid,
            source=inv['source'],source_sha256=inv['source_sha256'],actual_question=node['request'],rewritten_query=node['rewritten_query'],
            manually_required_information=review['required_information_manually_identified'],finding=review['findings'],evidence=evidence,
            absent_from_native_merged_reader=True,verified_quote_absent_from_actual_child_prompt=True,
            offline_selected={m:did in ids for m,ids in inv['selected_doc_ids'].items()},
            limit='Verified candidate-to-reader loss only; restoring document does not establish QA or final F1 improvement.'))
    def aggregate(selected):
        return dict(nodes=len(selected),queries=len({x['id']for x in selected}),
            dual_route_nodes=sum(r['has_rewritten_route']for r in selected),
            dual_route_queries=len({r['id']for r in selected if r['has_rewritten_route']}),
            union_more_than10_nodes=sum(r['unique_union_documents']>10 for r in selected),
            some_candidate_discarded_queries=len({r['id']for r in selected if r['original_dropped_candidates']}),
            dropped_unique_node_document_pairs=sum(len(r['original_dropped_candidates'])for r in selected),
            policy_membership_changed_nodes={m:sum(r['changed_membership'][m]for r in selected)for m in policy.POLICIES},
            policy_membership_changed_queries={m:len({r['id']for r in selected if r['changed_membership'][m]})for m in policy.POLICIES})
    summary=dict(utc=datetime.now(timezone.utc).isoformat(),status='offline_saved_packet_design_inventory_only',
        cohort=dict(material_reviewed=270,nonfullscore=230,seeded_fullscore_controls=40,
            nonfullscore_final_information_insufficient=69,declared_review_complete=258,pending=12),
        exact_existing_merge_reproductions=len(inventories),inventory=aggregate(inventories),
        by_dataset={ds:aggregate([r for r in inventories if r['dataset']==ds])for ds in ('hotpotqa','2wiki')},
        by_selection={s:aggregate([r for r in inventories if r['selection']==s])for s in ('all_nonfullscore','seeded_fullscore_control')},
        confirmed_necessary_candidate_to_reader_loss=dict(cases=2,denominator_primary270=270,denominator_nonfullscore=230,
            denominator_existing_final_insufficient_group=69,scope='Only2 manual-confirmed cases independently rechecked here; a conservative verified count, not exhaustive prevalence/cause fraction',cases_detail=confirmed),
        annotated_reader_document_stress=dict(annotated_doc_instances=len(annotation_checks),
            exact_original_quote_locations=sum(r['exact_quote_in_original_reader']for r in annotation_checks),
            dropped_annotated_doc_instances={m:sum(not r['retained_document'][m]for r in annotation_checks)for m in policy.POLICIES},
            changed_annotated_doc_cases={m:len({r['id']for r in annotation_checks if not r['retained_document'][m]})for m in policy.POLICIES},
            interpretation='Mechanical retention of previously cited reader documents only. Excerpts can be counterevidence or incomplete; alternative spans may carry same fact. These are regression-review flags, not new semantic errors or quality labels.'),
        policy_source_sha256=sha(HERE/'policies.py'),manual_review_sha256=sha(BASE/'MANUAL_INFORMATION_FLOW_REVIEWS_V9.json'),
        source_case_hashes=sources,all_old_source_hashes_still_exact=all(sha(ROOT/p)==h for p,h in sources.items()),
        no_gold_or_findings_passed_to_selector=True,no_new_API_GPU_retrieval_SSH=0,old_core_sources_labels_scores_protocols_changed=False,
        no_new_formal_or_fixed90_evaluation=True,limitations='Exposed diagnostic cohort, only saved20-candidate pools, no LLM/reader output tested, not independent causal evidence or automatic necessary-fact extraction.')
    jsonl('NODE_POOL_INVENTORY.jsonl',inventories)
    jsonl('ANNOTATED_READER_DOCUMENT_STRESS.jsonl',annotation_checks)
    dump('SUMMARY.json',summary)
    print(json.dumps({k:v for k,v in summary.items()if k in ['inventory','exact_existing_merge_reproductions','annotated_reader_document_stress','policy_source_sha256']}|{'confirmed_case_policies':[(r['review_index'],r['offline_selected'])for r in confirmed]},ensure_ascii=True))


if __name__=='__main__':main()
