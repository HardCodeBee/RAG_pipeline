# 第二轮及后续自主探索进展

状态时间（UTC）：2026-10-21T18:52:24.449018+00:00。主评保持暂停；尚未提升或替换正式主方法。

目标：保留冻结P02 R02/v12分解器及实际输出，解释下游未充分利用分解的原因，以同题完整RAG最终F1检验改进。人工修正60题不替换本轮输入。

| 实验 | 已处理/计划条件 | 完整输出 | 算法终止 | 已知usage估费/元 | 尚未结算预留/元 |
|---|---:|---:|---:|---:|---:|
| 普通QA：原引用/实体名/描述式少样例 | 90/90 | 90 | 0 | 0.161635 | 0.026554 |
| goal：综合说明/目标约束/角色核对 | 81/81 | 81 | 0 | 0.351234 | 0.089606 |
| 实际子问：原题/重复题/已有改写候选 | 45/45 | 45 | 0 | 0.037682 | 0.000000 |
| 完整上游复用：原final/单句目标核对 | 180/180 | 180 | 0 | 0.398486 | 0.033179 |
| 后续goal原事实句：原版/单句角色核对 | 54/54 | 54 | 0 | 0.179196 | 0.023172 |
| 后续8个失效/弃答边界：原版/目标关系核对 | 16/16 | 16 | 0 | 0.033139 | 0.000000 |
| 同8节点：复用新控制/重复原题/已有实体改写候选 | 24/24 | 24 | 0 | 0.028351 | 0.006725 |
| 原生90：goal128原版/角色核对，原formatter与final64 | 180/180 | 180 | 0 | 0.562072 | 0.085100 |
| 同8节点：原当前子问/已有改写作为实际QA目标 | 16/16 | 16 | 0 | 0.011314 | 0.012071 |
| 完整动态8题：新鲜原版/全部普通QA接入live改写 | 16/16 | 16 | 0 | 0.107914 | 0.000000 |
| 平衡开发20题：新鲜原版/全部普通QA接入live改写 | 38/40（另2技术held） | 38 | 0 | 0.155964 | 0.011890 |

预留包含运行中或缺少结算回执的请求，不等于已确认花费；退役未知请求及技术尝试账目均保留。

完整动态full8已收齐16个success；本地session45651及远端A6000作业158960均已结束，该旧批次已无活跃推理/GPU任务。普通少样例、goal scope/role及表内其他实验也均已结束。此处仅只读SQLite状态汇总及账本，未打开新预测、原生评分REPORT或配对结果。

信息流当前为V9，主270条材料均已读取：230条非满分、40条固定成功对照；258条完成声明范围检查，12条保留事实/口径待核。另8条补充包未开展新复核。

必要信息标志只描述本次检查范围内的信息保留和使用，不是完整最终回答金标；不得把147条充分标志当成147条可修复错误。原始F1/EM及事实标签不改。

实际子问接口严格复用本轮15条E0控制（费用已在少样例实验记账），9组相同候选条件也精确共享回执；45逻辑条件不等于45个新付费输出。final目标核对两臂独立保留原P02完整上游，不与子问或goal新变体混合。具体执行以各协议、授权和检查点为准。

第一批246条件和两项旧fixed90实验结果保留于 RESULTS_SUMMARY.md；第二轮全部公开为开发证据，不声称独立确认，不替换正式主方法。

平衡20执行已结束：本地session45101退出0、只读监控session39898退出0，远端A6000作业158988为COMPLETED（26m30s）、worker FINISHED，无活跃推理或GPU任务。每臂36ordinary，不组合ROLE/M4；16/20题有既往723语义暴露。旧严格完整参考覆盖15/20，另报旧15与新两臂同15子集，缺5不填0。独立完整性审核已通过（ROOT_NATIVE_RECEIPT_AUDIT.json，SHA187bcc49…）；不作方法提升。

平衡20最终有38条success、2条已知provider HTTP400技术held、0未启动、0算法终止/截断；不能称40条质量完整。两held共享同一首QA失败回执，未按质量0计分、未重试该400或修改内容绕过。全20主点估计为空并保留固定分母边界；该题不在旧匹配15中。

本批已知usage估费0.1559644元；未结算预留合计0.0118896元，其中provider失败回执0.0062344元、另一个退役unknown回执0.0056552元。0.0080696是旧说明中的错误归属，已由ROOT_RESERVATION_NOTE_CORRECTION.json补正，原字节保留；预留不是已确认花费或零花费。

下一项仅准备O8普通QA阶段机制对照：8个既有节点、16条fresh条件，仅删实际任务中的Original question标题和值，原指令/少样例/history/raw Current/reader均固定，128上限。协议已冻结（21091d8e…），未创建真实检查点或启动API/GPU；须独立审核及root另行授权。此项不产生完整RAG F1，不自动安排M4或恢复主评。

O8 actual execution update: root approved frozen protocol21091d8e under P02_ORDINARY_ORIGINAL_BLOCK_FRESH8_STAGE_20261022; API session97885. Read-only status snapshot 2026-10-21T19:07:20.317458+00:00: 10/16 terminal, request statuses {"in_flight": 1, "success": 10}. No answer/F1 read; no GPU/job; main evaluation remains paused. The preceding O8 preparation-only paragraph records its earlier state.

O8 execution completed 2026-10-21T19:09:14.999443+00:00: session97885 exited0;16/16 ordinary QA normal stop,0 held/algorithmterminal,8 complete stagepairs. Known new usage estimate 0.0326384 CNY, unknown reserve 0 CNY. E is reviewing masked16 candidates; semantic lock pending. No active runner or GPU. Stage-only outputs do not establish complete-RAG F1 or promotion. Earlier running snapshots are historical.

Status reconciliation 2026-10-21T19:19:27.152560+00:00: O8 complete_audited_no_expansion; independent audit1f6e3d37... passed and root continuation decision recorded. Locked stage review2 to4 correct,2 substantive repairs,no new clear scope harm; necessary gate passed but root declines O1 expansion. Stage results are not full-RAG F1 or method promotion.

M4 reader-stage8 is frozen_prepared_awaiting_root_authorization (protocol8fca8f23...,52pins+3holds):8 distinct Wiki queries,4ordinary/4goal,16fresh conditions;19 offline contract groups passed. Info final review pending; noAUTH, no real checkpoint/API/GPU or active runner. Main evaluation remains paused. Earlier O8 semantic-pending/running paragraphs retain their historical snapshots.

M4 actual execution completed 2026-10-21T19:22:49.293925+00:00: root-authorized API session97632 exited0. SQLite mode=ro confirms16/16 normal success,0formatter,0held/algorithmterminal; ledger known new usage estimate0.0251008 CNY, reserve0. E is reviewing masked16; stage-semantic lock pending. No active model/GPU. This supersedes the prior M4 preparation-only snapshot and does not establish full-RAG F1 or promotion.

M4 full8 actual running update 2026-10-21T19:39:17.458151+00:00: stage16 audit051fb77c... and root gate decision recorded; separate authorization P02_M4_FULL8_COMPLETE_DYNAMIC_REMOTE_EXECUTION_20261022 approved protocol2056ecaa.... API session82173 and remote job159027 observed; 2/16 quality outcomes at snapshot, requests {"in_flight": 1, "success": 8}. Known new usage estimate 0.0107464 CNY; unresolved reservation 0.0069616 CNY. GPU job receipt confirmed; local READY identity awaits root observer. All ordinary+goal use only the assigned merge rule; complete dynamic downstream, rawR02/Current/formatter/root/final unchanged. No fresh answers, native report or key opened for this status. Main remains paused/no promotion.

M4 full8 complete 2026-10-21T19:55:08.804204+00:00:16success;API runner82173 and readonlyobserver50965 exit0;Slurm159027 COMPLETED11m47s,worker processed39,independent audit8764f8a42867 passed. Ledger knownnewusage 0.0949644 CNY,reserve 0 CNY. No active model/GPU. Root locked native comparison before interpretation; main not promoted. Only a new fixed-hash Wiki20 offline preparation is underway; no AUTH/API/SSH/GPU for it. Earlier full8 running entries retain historical snapshot meaning.

Wiki20 frozen preparation 2026-10-21T20:07:23.226005+00:00:protocolab1206ff...,242pins+3mainholds;prospective20/40flows,44ordinary/arm,[]allowed but0selected;20/20prior723 and4/20passive270 disclosed. Native message/retrieval/receipt reference resolver fixedr000->r100 beforelookup:18+2 legal samequeryreferences,no scoreselection. Local/remote offline contracts passed; Info final review/root authorization pending. NoAUTH/checkpoint/API/SSH/GPU; main remains approval=false, and no active job.

Wiki20 actual running 2026-10-21T20:12:02.206768+00:00: root exact AUTH/decision P02_M4_WIKI20_COMPLETE_DYNAMIC_REMOTE_EXECUTION_20261022 approved protocolab1206ff.... Runner55177,readonlyobserver58891,job159041 RUNNING on weirdo NVIDIA RTX A6000 verified fromlocalREADY/observer. Snapshot 2/40 quality outcomes,requests {"in_flight": 1, "success": 6},known newusage 0.0067132 CNY,reserve 0.0073744 CNY. No fresh final/native/key opened for status. Main remains approved=false/no promotion. Finish this fixed20 and stop adaptive expansion, then close the report; no next experiment queued. Earlier prep-only paragraph is a historical snapshot.

Wiki20 final closure 2026-10-21T20:39:56.104596+00:00:40/40success,0held/algorithmterminal;runner55177 and observer58891 exit0;Slurm159041 COMPLETED00:26:49,actualA6000worker stopped95packets,errornull. Independent audit06946ebd28bd357d531b25aa6ab0aad668543150fb828e2ac2f47fed3e4dcab3 passed. Root-locked old/M0/M4same20 nativeF1=EM=.85,each17full;0gain20tie0harm,2finaltextdifferencepairs(oneexistingbirthfactpending,onecaseonly). KnownLLMusageestimate .2159856 CNY,reserve0,maxattempt1,orphan0,noexpensealerts. No active GPU/inference,no next experiment,no promotion/publication;main approval=false. Adaptive expansion stops and report closes;pendingfactreview is separate from complete native denominators. Earlier running entries are historical snapshots.

Final interpretation closure 2026-10-21T20:46:23.605735+00:00: root paired JSON43cbce8f... and remaining-failure JSON9001e000... locked; continuation decision7865bc9d... records P02_M4_WIKI20_COMPLETE_NO_GENERAL_GAIN_RESEARCH_ROUND_CLOSED_20261022. Status completed_audited_and_interpreted,no active runner/GPU,no queued experiment or promotion/publication,main approval=false. Earlier trace_pending status is superseded. Existing birthfact verification remains a workitem and is not native scoring missingness. Eason region/country/nationality granularity and Buzz identity-as-birthplace support errors are interpreted while official0 remains unchanged. The round contains local repairs but has not verified generalF1superiority;no adaptive expansion follows.
