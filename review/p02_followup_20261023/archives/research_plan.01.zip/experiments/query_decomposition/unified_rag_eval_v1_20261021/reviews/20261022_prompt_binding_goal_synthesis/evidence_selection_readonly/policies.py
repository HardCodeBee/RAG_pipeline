"""Gold-free, CPU-only selection over two already saved Top10 route packets.

These are exploratory deterministic selection rules, not validated repairs.
No reference, answer, manual finding or final score is accepted by the API.
Output order always follows the old interleaved union, isolating membership.
"""
from collections import Counter
import math
import re

POLICIES = ('M0_original_interleave', 'M1_rrf60_sanity', 'M2_source_diversity_sanity', 'M3_anchored_lexical_coverage', 'M4_format_duplicate_fill')
STOP = set('a an the and or of in on at to for from by with as is are was were be been being do does did has have had who what which when where why how that this these those it its their his her he she they them then than into about after before during only all any can could would should may might must also'.split())


def tokens(value):
    return {t for t in re.findall(r'[a-z0-9]+', value.casefold()) if t not in STOP and len(t)>1}


def pool(original, rewritten):
    union, seen = [], set()
    for rank in range(10):
        for route in (original, rewritten):
            if route and rank < len(route['docs']):
                d = route['docs'][rank]
                if d['doc_id'] not in seen:
                    union.append(d);seen.add(d['doc_id'])
    assert len(union)>=10
    return union


def select(original, rewritten, current_question, policy):
    assert policy in POLICIES
    union=pool(original,rewritten)
    if policy=='M0_original_interleave' or rewritten is None or len(union)==10:
        return union[:10]
    position={d['doc_id']:i for i,d in enumerate(union)}
    if policy=='M4_format_duplicate_fill':
        # Exposed diagnostic refinement, added after pass001: only collapse
        # same-source identical ordered word/punctuation token sequences.
        # Preserve case, negation, dates, numbers, word boundaries and spelling;
        # only whitespace around punctuation can differ. Do NOT collapse all
        # chunks from one biography. Fill a spare slot from the same saved pool.
        chosen=[];seen=set()
        for d in union:
            signature=(d['source'],tuple(re.findall(r'\w+|[^\w\s]',d['text'])))
            if signature not in seen:
                chosen.append(d);seen.add(signature)
                if len(chosen)==10:break
        ids={d['doc_id']for d in chosen}
        chosen += [d for d in union if d['doc_id']not in ids][:10-len(chosen)]
        return sorted(chosen,key=lambda d:position[d['doc_id']])
    fused=Counter()
    for route in (original,rewritten):
        for rank,d in enumerate(route['docs'],1):fused[d['doc_id']]+=1/(60+rank)
    if policy=='M1_rrf60_sanity':
        chosen=sorted(union,key=lambda d:(-fused[d['doc_id']],position[d['doc_id']]))[:10]
    else:
        # Retain one original and one rewritten route anchor, deduplicated.
        chosen=[]
        for route in (original,rewritten):
            d=route['docs'][0]
            if d['doc_id'] not in {c['doc_id'] for c in chosen}:chosen.append(d)
        if policy=='M2_source_diversity_sanity':
            sources={d['source'].casefold().strip() for d in chosen}
            for d in union:
                if len(chosen)==10:break
                if d['source'].casefold().strip() not in sources:
                    chosen.append(d);sources.add(d['source'].casefold().strip())
            chosen_ids={d['doc_id'] for d in chosen}
            chosen += [d for d in union if d['doc_id'] not in chosen_ids][:10-len(chosen)]
        else:
            # Query terms are current original + already-produced rewrite only.
            # IDF uses just this saved union; there is no training or gold join.
            q=tokens(current_question)|tokens(rewritten['query'])
            dt={d['doc_id']:tokens(d['source']+' '+d['text']) for d in union}
            df={t:sum(t in words for words in dt.values()) for t in sorted(q)}
            weights={t:math.log1p(len(union)/(1+df[t])) for t in sorted(q)}
            coverage={d['doc_id']:sum(weights[t] for t in sorted(q&dt[d['doc_id']])) for d in union}
            chosen_ids={d['doc_id'] for d in chosen}
            ranked=sorted((d for d in union if d['doc_id'] not in chosen_ids),
                key=lambda d:(-coverage[d['doc_id']],-fused[d['doc_id']],position[d['doc_id']]))
            chosen += ranked[:10-len(chosen)]
    assert len(chosen)==len({d['doc_id'] for d in chosen})==10
    # Do not introduce a context-order change when membership is unchanged.
    return sorted(chosen,key=lambda d:position[d['doc_id']])
