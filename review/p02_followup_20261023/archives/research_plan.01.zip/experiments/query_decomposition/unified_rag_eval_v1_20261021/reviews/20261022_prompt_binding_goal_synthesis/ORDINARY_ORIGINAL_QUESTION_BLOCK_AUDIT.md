# 普通QA的Original question块：已有对照与未来单因素假设

本次只读已有模板、协议及旧结果，没有读取正在运行的balanced20预测/原生分数，没有修改任何冻结代码、准备新runner或调用API/GPU。

状态：O0/O1仅为未来假设，**未排队、未授权、未准备执行**；当前唯一在跑的新候选仍是balanced20。先完成20题，再由root选择是否需要这个假设或M4的下一独立检验。

**未发现当前P02曾完成“只移除实际ordinary任务的Original question块、其他指令/例子/history/reader/goal全不变”的隔离对照。**但存在一项重要的旧近似实验，不能遗漏，也不能把它当成这个精确问题已被检验。

| 已有实验 | 实际改变 | 能否回答当前问题 |
|---|---|---|
| `reader_context_route_ablation_v1_20261019/no_parent` | 删Actual task的Original字段，**同时删scope指令，且ordinary与goal都应用**；旧C08/c02 reader及历史过滤、无legacy formatter | 接近，但不隔离actual ordinary块 |
| selfcontained / minimal4 / frozen_no_refs | 改普通指令、#N/示例及QA编号等，actual Original保留 | 不能 |
| minimal_ablation A_no_only / B_no_resolve | ordinary删only；goal删Resolve指令 | 不能 |
| 当前binding/fewshot/R/B/I/C系列 | 改指令、示例、候选块或实际Current；actual Original保留 | 不能 |
| round3 q03 / round4 r04 | 移final问题位置或替换final scope规则，普通QA不改 | 不能 |

核查入口：旧近似实验`prepare.py:56`明确写了字段与指令一起移除；其`pipeline.py`的`execute`对每个节点调用同一`render_child(...,parent=...)`，`render_child`没有ordinary/goal分支。当前fewshot的`variant_prompt`只改例子prefix，C的`templates.prompt`只改actual Current。搜索覆盖这些P02模板及旧reader/final scope实现，不声称仓库所有历史分支已穷尽查新。

旧no_parent的A组12题、每集4题；control可用10/12，no_parent12/12。**共同10题**原query最终nativeF1为0.683333→0.650000，EM为0.50→0.60，1升8平1降；不能比较两个各自不同覆盖的available均值来声称收益。B报告复用了相同control/no_parent记录，不是第二份独立确认。原模型也是`qwen-plus-2025-12-01`，区别主要在C08/c02提示、五例、弃答过滤、无legacy formatter、同时改goal及动态下游，不能误称只是模型版本不同。

旧Robert Petre例有与本次Richard类似的scope串扰迹象：actual问父亲的母亲，control子答先正确说Robert7的母亲是Mary Clifton，又补说未给Robert7的祖母；去parent后的子答集中回答母亲。但两组final都已包含Mary Clifton，F1从0.444444到1主要因删去额外亲属描述，**不是新增一个正确姓名事实**。旧整体F1反而略降，说明不能由这个例子推出“Original全有害”。数据入口为旧`RESULTS_A.json`和`SUMMARY.txt`，无重算或重跑。

## 当前可支持的假设

Richard的表现与“原题目标抢占局部任务”一致，也与实体/代际绑定不清、输出陈述主语选错等解释一致。C保留了Original，却使actual Current明确化，因此C的改善不能单独归因于消除了root干扰。更合理的机制表述是**原始目标与当前局部任务竞争、显式任务参数/实体绑定有助于区分角色**；这属于通常的任务条件化和工作记忆使用假设，不是已经证实的新型#提示范式。

## 唯一候选后续：固定8节点的ordinary块去除stage对照

仅在balanced20结束并审核后，由root决定是否值得开展；本文件不授权或开始。使用既有同8个ordinary节点（含2合理弃答边界，不只Richard或事后获胜节点），保持原raw Current及原冻结history、reader、fewshots和全部指令。

- O0：同期fresh原普通QA完整prompt。
- O1：只在唯一Actual task段删除`Original question:\n{原题}\n\n`，后面的Relevant prior、Current、Retrieved passages和Answer逐字保留。示例中Original不删；`The original question supplies scope`指令暂保留，以隔离块的存在；不连带删第二项指令，也不同时实体化Current。

原QA128、若触发则原formatter128、stop/model/三usage与5次技术恢复规则保持；不把任何goal或final输入改掉。两臂同批新控制，不能把旧I/C/B控制称作同期；若整条payload恰好完全相同才精确复用，不重复成功输出选优。先锁方法遮蔽的完整陈述事实判定、必要信息保留与是否错答成原题目标，旧分数/新final输赢不用于选节点。

关键限制：Original可能补齐同名身份、比较集合、时间/地域/单位及否定条件。Current表面自包含不保证保留全部约束，删除后合理弃答可能增加；要把事实正确、是否取得所需信息、目标错位分开。移除块也改变长度与信息位置，因此即便stage改善，也不能直接证明纯语义竞争机制或完整RAG收益。保留scope指令但移走实际字段还留下一个无实参的指令，这正是单项块贡献对照的限制；不要为使结果好看临时再改指令。若此唯一stage对照有清晰且无明显条件损失的局部信号，才另议完整动态下游验证；不直接加入当前20、ROLE或M4，更不据此提升主方法。
