# T54原生指标、请求合同与配对解释

54条最终预测已独立按原生scorer重算，DETAIL与REPORT无差异；54条阶段标注先锁（22＋32），本审计不改原标注。108个逻辑阶段使用对应97份当前完整回执：请求/返回模型一致，三项tokens为非负整数且total=sum，stop、非空、无拒答。goal512/final64、T1仅加ROLE句、全部final全文及context均吻合；11次final使用为本实验内同完整payload复用。另有3份retired unknown保留，同payload最多观察到3次实际尝试，未越过5次上限。

已知费用**0.179196元**，另保留未决预留**0.023172元**（两次连接错、一次超时）。100条账务恰对应97当前＋3旧回执，无孤立账务。54条件已完成不代表这3份未知负债已核销。回执数量属于审计覆盖，不新增LLM调用数指标。

| 同期27题 | F1 | EM | 相对T0 |
|---|---:|---:|---:|
| T0事实句 | 32.8171% | 18.5185% | — |
| T1事实句＋ROLE | 41.4590% | 29.6296% | F1 +8.6420百分点 |

全部27配对为4个F1改善、23持平、0退化；EM为3改善、24持平。**其中2个改善可核验为真实代际修复，另外2个含词面/参考问题。**

| 原问题/目标 | T0→T1实际final | F1 | 阶段及必要信息 | 判断 |
|---|---|---:|---|---|
| Alexios（Andronikos I之子）的祖父 | Alexios I Komnenos→Isaac Komnenos | 2/3→1 | 均False→True | 原答案多走一代，恢复正确祖父 |
| Robert Petre8的祖母 | Catherine Walmesley→Mary Clifton | 0→1 | 均False→True | 母亲改成父系祖母，真实角色修复 |
| Destination:Dewsbury导演卒因 | Parkinson’s disease→Parkinson's disease | .5→1 | 均待核 | U+2019改ASCII撇号；导演与同名球员的身份桥仍未成立 |
| Star & Dagger贝斯手的配偶 | Tommy Lee→Sean Lowe | 0→.5 | 均待核 | reference为贝斯手本人Sean Yseult，Sean词面重合获分；未建立Yseult配偶关系 |

四条的总增量2.3333/27中，两条有材料支持的代际修复贡献1.3333/27＝4.9383百分点，两条词面/参考效应贡献1/27＝3.7037百分点。这只是对四个已观察变化的算术拆分，不是总体原因比例或独立因果效应。新goal均逐字进入实际final context，未把不可见期望信息算作模型输入。

## 阶段4→6：3得1失

实际为3条False→True、1条True→False，其余3条True→True、9条False→False、11条待核→待核：

- 两条代际修复同步改善最终F1。
- Pamelyn Wanda Ferdin的中间名：T0把全名叫作中间名，T1明确Wanda，阶段修复；两臂final早已都是Wanda，F1均1，没有新增最终收益。
- Finding Kraftland/Shikashika：T0保留documentary与drink并正确No，T1退回Finding是否是drink不确定；阶段及必要信息True→False。但documentary仍在两臂实际final材料中，final均No。native均0涉及布尔原题与参考实体的范围不一致，不能据0分反推No事实错或掩盖阶段退化。

## 旧G0→新T0的非同期漂移

27/27完整goal请求逐字相同（含模型、消息及512cap），5段goal文字变化。4条final变化；22个完整final请求也相同，其中3条答案仍改变：

| 问题 | 旧G0 final→新T0 final | 完整final请求 | F1 |
|---|---|---|---:|
| Alexios祖父 | Isaac→Alexios I | 相同，goal也相同且错误 | 1→2/3 |
| Petre祖母 | Mary→Catherine | 不同，goal由Mary变Catherine | 1→0 |
| 作家寿命比较 | Owen Wister→Lucy Maud Montgomery | 相同，goal文字相同且比较反向 | 1→0 |
| 核裂变/机制交集人物 | Otto Robert Frisch→Cannot be determined | 相同，goal均否定存在 | 1→0 |

旧G0 F1 **45.1627%**→新T0 **32.8171%**，4退化、23持平、0改善，下降12.3457百分点。新T1 **41.4590%**仍比旧G0低3.7037百分点。旧final曾纠正错误goal而本轮未纠正，是可见的恢复漂移边界；不能把它全归于goal提示，也不能将同请求重复当成纯随机方差。时间、服务状态与生成变化未隔离；旧G0/旧G2与本轮不是同期完整factorial，不能据几组差分确认格式×ROLE交互。

27题是诊断挑选、反复暴露的开发挑战，且共同512不同于原P02原生128协议。结果提供具体关系约束的开发线索，不能宣布原P02整体F1提高或主评目标达成。阶段标签亦为知情Codex审阅，非独立人工金标。

[逐条native、108阶段请求合同、四个改善、阶段得失及27历史重复](ROOT_NATIVE_AND_PAIRED_AUDIT.json)附原文件SHA和锁定来源。本次无API、新检索/GPU，不读取L未跑输出；T及旧G报告、标签均保持原字节。
