# 固定8题：实际动态轨迹的修复与未修复路径

本报告在两批最终答案语义盲审锁定后读取方法映射，逐题核对本轮fresh D0/D1完整trajectory。原始盲审、native计分和引用均不修改。这里的“路径”是受控接口变化后的可观察承接关系，不是对全部723条的因果证明。

16/16流程正常完成，0技术held、0算法失败。普通节点16对中7对实际prompt改变；4对回答文字改变，其中3对是完整事实陈述修复（Richard、Liu、Bob），另1对Tsutsunava仅弃答措辞变化。16对普通reader的文档及顺序均未改变。3题goal实时改写和reader改变；最终2题文本改变、F1提高，6题持平，0题F1降低。

官方native平均F1：24.4643% → 33.3929%（+8.9286个百分点）；EM：0% → 12.5%。按用户“F1或EM为1才最终正确”，0/8 → 1/8，新增仅Liu E。Bob Gibson事实修复成立，但冻结参考为Robert Gibson，native F1=.5、EM0，不计满分正确，也不补改alias或分数。

| 题目 | 普通QA实质修复 | 后续实际路径与残留原因 | final D0 → D1 | native F1 |
|---|---|---|---|---|
| Richard | 是，纠正RobertI之父的完整陈述 | history与goal改写改变，但冻结D多走一代，goal仍选RichardII | RichardII → 相同 | .6 → .6 |
| Liu E | 是，配偶父亲从LiuYin改为LiuYuan | 正确history进入新goal改写/reader与final | LiuYin → LiuYuan | .5 → 1 |
| Speedpass | 否，首节点输入未改变 | 把推出方Mobil当开发方，继续查询错误公司总部 | FairfaxCountyVirginia → 相同 | 0 → 0 |
| Bob Gibson | 是，排除游击手MauryWills | 筛选结果进入history、goal与final；Bob/Robert别名仍部分得分 | Bob+Maury → Bob | 2/7 → .5 |
| Butautas | 否，首节点输入未改变 | 冻结子问预设已废黜；goal把在位期错绑为政变尝试期 | 1345and1377 → 相同 | 4/7 → 4/7 |
| Tsutsunava | 否，明确实体后仍弃答 | 普通reader有1955卒日端点但未传出；goal/final实际未见该日 | Cannotbedetermined → 相同 | 0 → 0 |
| HP7 / Firefly | 否，同reader合理弃答 | Doomsday证据在改写路rank10，被Top10合并丢弃，goal也未重新取回 | Cannotbedetermined → 相同 | 0 → 0 |
| HP50 / CretanHound | 否，实际prompt未改变 | 材料是截断简介，没有群猎关系，不能由未见pack推No | Cannotbedetermined → 相同 | 0 → 0 |

## 每题证据与边界

### Richard：局部关系修复未纠正多一代结论

`2wiki:a6fd9c120baf11ebab90acde48001122`

D0 step2的实体RichardII虽然回答了RobertI之父，但完整句把它说成原题Richard的祖父，关系错误；D1改成RobertI之父RichardII，完整陈述修复。
修复后的回答写入本臂history。goal实时改写从Who is Richard II, Duke of Normandy?变为Who is Richard, Son Of William The Conqueror's father's father?，goal reader也改变；goal仍把RichardII当原题Richard的祖父，final未改变。
冻结分解step1已得到William之父RobertI，即原题Richard的祖父；step2又追问RobertI之父RichardII，多走一代。D1只修当前QA陈述，不删除这一步，也未使goal重新核对原题的代际关系。
两臂最终RichardII均是原题Richard的曾祖父，不是其祖父RobertI。F1=.6是实体名称部分重叠，不表示关系正确。

- 证据：2wiki:a6fd9c120baf11ebab90acde48001122/D0 / step1 / reader_packet / William the Conqueror / rank1 / doc cf9e90c2fef4334e1582dac742cd2512f69eecb064078a52b96caf5f9c3a7423：William was the son of the unmarried Robert I, Duke of Normandy
- 证据：2wiki:a6fd9c120baf11ebab90acde48001122/D0 / step1 / reader_packet / Richard, son of William the Conqueror / rank6 / doc 9d417176c86667dccb2f2ed0bf35b1b25f1f6f4434214dac690e2b9b49f525cb：was the second son of William the Conqueror
- 证据：2wiki:a6fd9c120baf11ebab90acde48001122/D0 / step2 / reader_packet / Robert I, Duke of Normandy / rank2 / doc 040b5e4976f5fc12d5ba2ce48e60961f8fcc5064e256281a724085ab43787ac8：He was the son of Richard II

### Liu E：配偶父亲绑定修复传到最终答案

`2wiki:02f574780baf11ebab90acde48001122`

step2同history/同reader下，D0误把LiuE自己的父亲LiuYin当其配偶LiuCong之父；D1实际current明确为LiuCong之父，回答LiuYuan。
改正结果进入history；goal实时改写由Who is Liu Yin?变Who is Liu Yuan?，其检索reader改变，goal与final均保留LiuYuan。
本题修复成功。D1 goal改写仍退化成询问候选人物身份；其新goal reader并未带回LiuCong之父的关键段落。因此不能把改善只归功于新goal检索，更直接的可见路径是正确普通QA进入history/goal/helper。
已锁盲审确认D0 LiuYin错、D1 LiuYuan对；nativeF1 .5→1，EM0→1，且是唯一新增满足用户F1或EM等于1的题。

- 证据：2wiki:02f574780baf11ebab90acde48001122/D0 / step2 / reader_packet / Liu Cong (Han Zhao) / rank2 / doc be98fe779becb88135e978757c376d0cf63145648e6aa4ec98144ac8ce41bdfa：during his father Liu Yuan's reign
- 证据：2wiki:02f574780baf11ebab90acde48001122/D0 / step1 / reader_packet / Empress Liu E / rank1 / doc 79ef236f92d6c60ca8acd13d4a030986d29529c79337a7d4e978066787eb7111：Liu E was the daughter of one of Liu Cong's honored officials, Liu Yin

### Speedpass：首节点未改，推出方/开发方角色错持续

`hotpotqa:5a83431d5542993344745ff5`

只有一个普通节点，没有prior history，因此无rewrite，D1实际current与D0逐字相同。两臂都把Mobil推出设备误写为创建/开发设备；同reader的Speedpass段明确说原开发方是Verifone。
相同普通QA进入相同history；goal都改写查询Mobil总部，检得Mobil原总部FairfaxCountyVirginia，goal/final按错误公司回答。两臂整个逻辑流程的文本相同。
错误位于无历史首节点的创建者角色识别；将accepted rewrite送入普通QA在这里是实际no-op，无法修补这一角色错误。
FairfaxCountyVirginia对Mobil旧总部有文献支持，但原题目标是设备开发方。冻结native参考SanJoseCalifornia只用于计分，本报告不把它伪称为本轮reader可见的Verifone总部证据。

- 证据：hotpotqa:5a83431d5542993344745ff5/D0 / step1 / reader_packet / Speedpass / rank1 / doc 1324009：It was originally developed by Verifone.
- 证据：hotpotqa:5a83431d5542993344745ff5/D0 / step1 / reader_packet / Speedpass / rank1 / doc 1324009：introduced in 1997 by Mobil Oil Corp.
- 证据：hotpotqa:5a83431d5542993344745ff5/D0 / step2 / reader_packet / Mobil / rank2 / doc 20708：former Mobil headquarters in Fairfax County, Virginia

### Bob Gibson：投手筛选修复传到最终，别名计分仍不满

`hotpotqa:5a8512035542992a431d1ace`

step2同history/同reader下，D0把BobGibson与MauryWills都称为投手；D1实际current枚举前答5名主持人，明确只有Bob是投手、Maury是游击手，完整事实修复。
新history排除Maury。goal实时改写从What is the name of Bob Gibson or Maury Wills?变为What is the name of Bob Gibson?，reader改变；D0 goal reader其实已含Maury游击手及Bob投手段仍未纠正，D1 goal/final则仅保留Bob。
事实筛选已成功，native词面别名仍限制满分。ordinary reader只含Maury角色段、没有Bob生平段；事实正确性另由本轮goal reader的Bob/Robert同一人物段及先前锁定盲审核实，不因普通reader未覆盖Bob而判其答案错。
已锁盲审确认D1 BobGibson语义正确。冻结参考是RobertGibson，D1 F1=.5/EM0，D0 F1=2/7；不改参考、不改native分数。用户F1或EM为1口径下此题仍不计最终正确。

- 证据：hotpotqa:5a8512035542992a431d1ace/D0 / step2 / reader_packet / Maury Wills / rank8 / doc 515445：as a shortstop and switch-hitter
- 证据：hotpotqa:5a8512035542992a431d1ace/D0 / step3 / reader_packet / Bob Gibson / rank10 / doc 367170：Robert Gibson (born November 9, 1935) is a retired American baseball pitcher

### Butautas：冻结前提错误与谓词绑定未改

`hotpotqa:5a79f37a5542996a35c17045`

只有一个无历史普通节点，D1 current与D0相同。原题是tried to depose，冻结子问却预设was deposed by Butautas，回答也重复已废黜；实际Butautas段明确attempted but failed。
同一错误前提进入history；两臂goal改写相同，并把Algirdas在位1345–1377误写成Butautas尝试废黜的持续期间。
D1没有改变首节点或修复分解前提，亦未检查时间属于在位期间还是政变尝试。
两臂短答1345and1377都保留Algirdas实际统治年端点，native参考from1345to1377使F1=4/7而EM0。不能仅因部分F1判短答年份事实错；但ordinary/goal完整陈述的成功/尝试及时间谓词错误依然存在，且未满足用户满分口径。原题语法省略也限制对最终短答单独作更强关系判断。

- 证据：hotpotqa:5a79f37a5542996a35c17045/D0 / step1 / reader_packet / Butautas / rank1 / doc 1953517：but failed and was forced into exile.
- 证据：hotpotqa:5a79f37a5542996a35c17045/D0 / step2 / reader_packet / Algirdas / rank3 / doc 1175523：He ruled the Lithuanians and Ruthenians from 1345 to 1377.

### Tsutsunava：明确实体后仍未抽取可见卒日

`2wiki:54bf355508b811ebbd88ac1f6bf848b6`

D1改了step2重复问号、step3当前题为ClaudeChabrol、step4当前题为AlexandreTsutsunava；step2/3事实答案不变，step4只是换措辞继续弃答。两臂step4 reader rank2都有born –25October1955。
1955卒日未进入任一history；goal改写仍为原比较题，goal reader及最终原query raw reader没有Tsutsunava生平段。goal两臂都无法比较，final均Cannotbedetermined。
不是无检索命中：关键日期已在普通QA实际reader，但损坏的born–寿命写法未被提取。冻结数据辅助材料的dateofdeath三元组确认25October1955；当前文本改名没有修复这一日期抽取问题。不能说final忽视了它实际不可见的1955。
F1/EM均0且输出相同。普通QA的必要日期丢失阻断了比较；本轮没有独立测试是版式、日期语义还是其他阅读因素导致弃答。

- 证据：2wiki:54bf355508b811ebbd88ac1f6bf848b6/D0 / step4 / reader_packet / Alexandre Tsutsunava / rank2 / doc 07ecaf2afb2e71972a34c67684205c316b5c0f39409941d04dfa12bb75b89655：born – 25 October 1955

### HP7：检索命中在合并截断时丢失

`hotpotqa:5ab3eeb5554299233954fff4`

D1将step2实际current明确为JewelStaite，但同reader下两臂都合理弃答。DoomsdayProphecy段包含演员与2011，在两臂step2 rewritten route rank10；合并后普通QA reader没有该doc。
普通history未传片名；两臂goal实时改写均询问JewelStaite与AlanDale合演片年份，goal双路及merged reader都没有Doomsday段，final原query reader也无，因此均弃答。
缺的是实际可见reader中的所需证据；现行original-first interleave取Top10没有保留改写路rank10。仅改普通QA current不能恢复被丢弃的段落。
native参考2011，两臂F1/EM均0。普通QA合理弃答与质量分数为0可以同时成立；不能误记为它忽视了可见的Doomsday证据。

- 证据：hotpotqa:5ab3eeb5554299233954fff4/D0 / step2 / rewritten_retrieval / Doomsday Prophecy / rank10 / doc 33214212：Doomsday Prophecy is a 2011 sci-fi disaster television film by Jason Bourque starring Jewel Staite, Alan Dale and A.J. Buckley.

### HP50：实体已明确但pack关系材料缺失

`hotpotqa:5a893fc855429951533612f0`

step2的raw current与accepted rewrite本来相同，D1没有实际改变prompt；两臂CretanHound doc都截在Itisconsidered，没有群猎关系。普通QA保留证据不足，未把不知道误称为no。
同一不确定结果进入history；goal改写相同，goal/final仍只见同一截断Cretan简介和另一犬种的群猎事实，最终同为Cannotbedetermined。
信息缺口而非描述实体绑定。冻结native答案no与本轮实际材料不足需要分列；不得从缺少pack词就推出Cretan不群猎。
两臂nativeF1/EM均0。当前证据边界下的弃答合理；本报告不把native参考no升级为已在reader核实的否定事实。

- 证据：hotpotqa:5a893fc855429951533612f0/D0 / step2 / reader_packet / Cretan Hound / rank2 / doc 6863876：It is considered
- 待核工作项：本轮及已有同题冻结参考文档都只有同一截断简介。native参考no用于计分，不能独立充当语义事实证据；此项只作待核工作项，不新增第三类标签。

## 如何解释

这8题提供了一个具体支持：在reader和已有history相同的普通节点，显式实体current可以修复部分角色/代际/集合筛选错误；其中2题修复贯穿实际动态下游。Richard也说明普通QA局部正确并不足以保证原题组合正确。另一方面，首节点角色错误、冻结分解前提、日期抽取、合并丢证及源材料缺口均不由本次接口改动自动解决。不能据此宣称普通QA是全部723条最主要瓶颈，或宣称goal/检索各自的独立因果贡献。

Butautas短答年端点与原文统治期一致，native部分得分含连接词差异；这和其ordinary/goal完整关系陈述错误需要分列。HP7和HP50的合理弃答也与官方质量0分分列。Tsutsunava则确有日期形式在普通reader中；已在离线冻结数据date-of-death三元组核实1955，不能归为零命中，也不能把最终读取不到的日期当作final阅读失败。

此前C/I材料与局部修复先验已接触；本轮不是独立确认集。两批final首次标签保持原锁。每个新payload仅一次生成，完全相同payload允许同轮精确复用，不能称每臂独立冷启动复现。完整节点变化、每臂当前题/回答/改写、reader文档、请求ID、outcome/context哈希、短引与待核项见同目录ROOT_CAUSAL_TRACE8.json。没有新增API、GPU、网页或外部评审请求；正式主评仍暂停。
