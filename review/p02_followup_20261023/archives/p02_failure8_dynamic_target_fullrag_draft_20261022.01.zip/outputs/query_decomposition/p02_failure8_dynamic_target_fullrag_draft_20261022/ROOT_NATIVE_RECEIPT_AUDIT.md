# Full8 dynamic-RAG audit

The independent audit passes. With the original formal R02/v12 decomposition fixed, D1 changes only ordinary-QA's actual current text to that arm's live accepted rewrite. Later rewrites, retrieval, QA, goal and final run dynamically. This selected, exposed eight-query development cohort shows a positive signal; it does not establish a general improvement or authorize main-method promotion.

| Dataset | Queries | D0 F1 | D1 F1 | D0 EM | D1 EM |
|---|---:|---:|---:|---:|---:|
| 2Wiki | 3 | 36.6667% | 53.3333% | 0% | 33.3333% |
| HotpotQA | 5 | 17.1429% | 21.4286% | 0% | 0% |
| Pooled | 8 | 24.4643% | 33.3929% | 0% | 12.5% |

Two native F1 gains, six ties, no losses. Both changed-final pairs have already locked method-masked semantic reviews; the six identical-final pairs require no duplicate annotation and remain in the denominator. No first labels were edited.

The two improvements have concrete downstream paths:

- **Liu:** ordinary QA changes Liu Cong's father from Liu Yin to Liu Yuan; goal and final preserve Liu Yuan. The new final gives the requested father-in-law, with F1=1 and EM=1. The old answer had confused the wife's father with the husband's father.
- **Bob Gibson:** ordinary QA excludes shortstop Maury Wills, and goal/final retain Bob Gibson alone. The frozen same-case factual materials support this as a real eligibility correction. Native reference is **Robert Gibson**, whereas the output is **Bob Gibson**: D1 therefore receives F1=0.5 and EM=0, rather than a full native match. Under the user's fixed final-correct criterion **F1=1 or EM=1**, this remains a partially scoring final, not a new fully correct item. Semantic truth and the fixed scoring rule are reported separately; neither the blinded labels nor reference answers are changed.

Consequently fully correct finals by that native criterion are D0 **0/8**, D1 **1/8**. The two semantic repairs must not be reported as two native-full successes. The earlier local Richard relation repair still does not establish a root-answer repair because the original decomposition's generation boundary remains fixed.

All 70 code/input pins and the eight original actual R02 arrays match. Exact offline replay of each condition verifies all request bodies and the live-query → frozen physical-resource identity → returned packet → merged reader wiring. D1's actual ordinary questions equal its own accepted rewrites; original raw requests/history, formatter question, goal and final packaging follow the unchanged core. The recorded allocation was **NVIDIA RTX A6000, job 158960**. This audit used only the root-downloaded READY artifact and local records; it made no SSH/API/GPU operation.

The 96 logical stage uses resolve to 67 unique matching-model, complete three-integer-usage receipts. Every flow succeeds; no formatter/final truncation, algorithm terminal or technical hold occurred. All requests stay within the durable five-attempt policy; maximum observed attempts are one. Forty query/resource packets match recorded remote returns. New actual returned-usage cost is **¥0.1079136**, with **zero unknown reservation or orphan charge**. Logical full-flow costs are D0 ¥0.0722552 and D1 ¥0.0721852; exact same-run shared prefixes reduce new actual expense and are attributed to the first submitting condition. These are not independent cold-run cost or timing measurements.

The old-source → fresh-D0 comparison is separate from treatment. All eight final texts and all native scores happen to agree, including historical pooled F1=24.4643% and EM=0. However, the Butautas goal rewrite changes; Liu's original-route/reader ordering changes at one node; Tsutsunava's original-route/reader ordering changes at three nodes. Thus equal old/new final scores do not imply byte-identical intermediate execution. These nonconcurrent retrieval/response changes are not attributed to D1.

The [audit JSON](ROOT_NATIVE_RECEIPT_AUDIT.json) records the 16 exact replays, all payloads/usage, remote-resource proof, paid attribution and per-node historical differences. The [native-criterion supplement](ROOT_FINAL_CORRECTNESS_CRITERION_SUPPLEMENT.json) preserves the Robert/Bob reference distinction. Original sources, scripts, reports and first labels remain unchanged. The separate balanced-20 inventory is not part of this result; the formal evaluation remains paused.
