# R首锁后的事实补证与口径对齐

R首次45条标签保持原字节，SHA256：`6dd9ba7ce55cae0fcf0f6a582ff10214c3dcb6e4d00cca98a93358996767d0fe`。本补充仅复用此前已保存的DNB传记核查，不访问网页，不打开R methodkey/DB/REPORT或E新输出。

Charles Edmund Nugent的既有[DNB历史传记记录](https://en.wikisource.org/wiki/Dictionary_of_National_Biography,_1885-1900/Nugent,_Charles_Edmund)明确卒于**1844年1月7日**。本R题三个匿名候选均额外断言卒于1843；按“完整陈述有错误即判错”，补充事实标签均为False。1999年不可能迁居的方向合理，不能抵消卒年错误。响应当前问题的True保持；本次不由事实False机械推导信息丢失，必要信息原None保留其声明范围。

依据为旧`semantic_review/batch004/WEB_FACT_CHECKS.json`，SHA256 `850fa5f10ed8660f08e3cce75b35e5d3382244f42fa68630eb04166f4dec5dfc`。E的已锁补证文件SHA256 `99a788a8ecd763a719c29257dbe37d3533510e587f4cc8ebff094c953de8f005`亦引用同一来源。这里复用的是本地历史网页核查记录；没有声称本轮重新核验远端页面，旧navy.mil页面502也不冒充已读取来源。

补证后仅事实维度为36条True、3条False、6条待核。仍保留三个题的工作项：Venussian的影片/拍摄年与首次上映年；Sunrise材料2002/1992及改名2001的冲突；Disney个人制作人与company简写的语义。没有为了统一标签强行结案。

R与E由两位有旧材料接触的Codex审阅者分别首锁，不是独立人工金标。相同文本首标签的差异可能来自核验范围、日期粒度、公司/个人界限与不确定度阈值；它是测量或证据边界，不是方法产生了不同答案，更不能算方法收益。Nugent在双方复用同一补证后应统一“完整事实陈述错误”。其他工作项仍保留；R的必要信息None与E补证False也不能在没有统一声明范围时混为跨方法计分。9组共享payload/回执不构成独立重复样本。

[逐候选补充记录与全部sourcehash](SUPPLEMENTAL_FACT_VERIFICATION.local.json)保留三个匿名candidate_id、原/补充事实标签及证据链。R/E首次标签均未重写。
