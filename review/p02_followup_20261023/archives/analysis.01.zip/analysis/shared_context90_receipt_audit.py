"""Pure receipt/charge checks for the completed shared-context90 experiment.

This module never opens files, SQLite, provider clients or remote services.
The caller must first verify all 270 planned conditions are quality-terminal,
lock the whole final-text review scope, and replay every logical stage through
its stage-specific policy (including the native final-only length exception).
Neither completion nor that exception can be inferred from this function's
receipt-only arguments. Technical held records must not be filled with zeros.
"""
from collections import Counter
import json
import math


INPUT_CNY_PER_TOKEN = .8e-6
OUTPUT_CNY_PER_TOKEN = 2e-6
USAGE_KEYS = ("prompt_tokens", "completion_tokens", "total_tokens")


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _returned(receipt):
    if any(receipt.get(k) is not None for k in
           ("response_id", "raw_response", "usage", "returned_model", "refusal", "finish_reason")):
        return True
    content = receipt.get("answer") or receipt.get("content") or ""
    return bool(content.strip()) if isinstance(content, str) else bool(content)


def _money(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def audit_receipts(current, retired, charges, task_ids, used_request_ids, old_request_ids, model):
    """Validate detached dictionaries and return unique first-owner accounting.

    current/retired: {request_id: {stage, payload(canonical JSON), status,
                                 result(decoded receipt)}}.
    charges: [{id, reserved_CNY, actual_CNY, status}].
    task_ids is the full, unique 270-condition set, not a set of successful-only
    tasks. used_request_ids must contain every current request referenced by the
    caller's already-completed stage replay. No mutation or external I/O occurs.
    """
    assert isinstance(current, dict) and isinstance(retired, dict)
    assert isinstance(charges, list) and isinstance(model, str) and model
    task_sequence = list(task_ids)
    tasks = set(task_sequence)
    assert len(task_sequence) == len(tasks) == 270, "Completed270 audit only; caller gates all terminal outcomes"
    assert all(isinstance(t, str) and t for t in tasks)
    assert not set(current).intersection(retired), "Active and retired IDs must be disjoint"
    all_requests = {**current, **retired}
    assert all(isinstance(rid, str) and rid for rid in all_requests)
    assert set(used_request_ids) == set(current), "Every active receipt must be bound by complete logical replay"
    old = set(old_request_ids)
    assert not old.intersection(all_requests), "No historical receipt IDs imported into this fresh namespace"

    charge_index = {}
    for charge in charges:
        assert isinstance(charge, dict) and isinstance(charge.get("id"), str)
        assert charge["id"] not in charge_index, "A physical request can have only one charge row"
        assert _money(charge.get("reserved_CNY")), "Missing/invalid reservation is not zero"
        assert charge.get("actual_CNY") is None or _money(charge["actual_CNY"])
        charge_index[charge["id"]] = charge
    assert set(charge_index) == set(all_requests), "No orphan reservation, unbound paid row or missing charge"
    assert not old.intersection(charge_index), "Historical requests are not newly charged"

    owner, attempts = {}, Counter()
    summaries = {t: dict(actual_new_returned_usage_CNY=0., unresolved_reserved_CNY=0.,
        current_unique_requests=0, retired_no_return_requests=0) for t in sorted(tasks)}
    expected_actual = {}
    for rid, row in all_requests.items():
        assert isinstance(row, dict) and isinstance(row.get("payload"), str)
        request = json.loads(row["payload"])
        assert _canonical(request) == row["payload"], "Attempts are counted by exact canonical full payload"
        assert request.get("model") == model
        assert isinstance(request.get("messages"), list) and request["messages"]
        attempts[row["payload"]] += 1
        matches = [t for t in tasks if row["stage"].startswith("full8/" + t + "/")]
        assert len(matches) == 1, "Exactly one first-submitting condition must own each physical request"
        owner[rid] = matches[0]
        receipt = row.get("result") or {}
        assert isinstance(receipt, dict)
        charge = charge_index[rid]
        dest = summaries[owner[rid]]
        if rid in current:
            assert row.get("status") == receipt.get("status") == "success"
            assert receipt.get("requested_model") == receipt.get("returned_model") == model
            usage = receipt.get("usage") or {}
            assert all(type(usage.get(k)) is int and usage[k] >= 0 for k in USAGE_KEYS)
            assert usage["total_tokens"] == usage["prompt_tokens"] + usage["completion_tokens"]
            # Finish reason/content/refusal validity is checked by the caller's
            # exact stage replay. Algorithm-terminal receipts also have usage.
            expected = usage["prompt_tokens"] * INPUT_CNY_PER_TOKEN + usage["completion_tokens"] * OUTPUT_CNY_PER_TOKEN
            assert charge["status"] == "returned_usage" and charge["actual_CNY"] is not None
            assert abs(charge["actual_CNY"] - expected) < 1e-12
            expected_actual[rid] = expected
            dest["actual_new_returned_usage_CNY"] += charge["actual_CNY"]
            dest["current_unique_requests"] += 1
        else:
            assert row.get("status") in ("unknown", "in_flight", "failed")
            assert not _returned(receipt), "Returned content/metadata must be held, never retired/reissued blindly"
            assert charge["actual_CNY"] is None and charge["status"] == "reserved"
            assert charge["reserved_CNY"] > 0, "Unresolved submission retains a positive liability"
            dest["unresolved_reserved_CNY"] += charge["reserved_CNY"]
            dest["retired_no_return_requests"] += 1
    assert max(attempts.values(), default=0) <= 5, "At most five actual attempts, including all retired attempts"
    actual = sum(c["actual_CNY"] for c in charges if c["actual_CNY"] is not None)
    reserved = sum(c["reserved_CNY"] for c in charges if c["actual_CNY"] is None)
    assert abs(actual - sum(s["actual_new_returned_usage_CNY"] for s in summaries.values())) < 1e-12
    assert abs(reserved - sum(s["unresolved_reserved_CNY"] for s in summaries.values())) < 1e-12
    return dict(passed=True, mode="caller-gated completed270 exact-stage replay",
        planned_conditions=270, current_unique_receipts=len(current), retired_no_return_receipts=len(retired),
        maximum_attempts_per_exact_payload=max(attempts.values(), default=0),
        unique_payloads_with_attempts=len(attempts), owner_by_request_id=owner,
        paid_summaries=summaries, expected_actual_CNY_by_current_request_id=expected_actual,
        actual_new_returned_usage_CNY=actual, unresolved_reserved_CNY=reserved,
        unattributed_charges=dict(actual_new_returned_usage_CNY=0., unresolved_reserved_CNY=0.),
        orphan_reservation_ids=[], imported_old_request_ids=[],
        known_usage_model_and_charge_binding_exact=True,
        retired_return_evidence_and_unknown_liabilities_checked=True,
        stage_terminal_and_final_length_verified_by_caller_not_this_helper=True,
        same_run_exact_sharing_first_owner_not_independent_cold_cost=True)
