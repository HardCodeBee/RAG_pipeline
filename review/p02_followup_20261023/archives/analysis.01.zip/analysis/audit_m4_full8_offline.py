"""Post-lock audit of fixed-D dynamic full8. Prepare only until root notification.

No API, SSH, GPU, Cache, report() or execution runner is invoked. The only
execution below is offline exact-response replay through the frozen Pipeline.
Writes independent ROOT_* artifacts, preserving original sources and labels.
"""
from collections import Counter
from contextlib import closing
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))
from p02_multigrain_timing_cachefix_v1.core.cache import canonical
from p02_multigrain_timing_cachefix_v1.core.llm import build_payload
from p02_multigrain_timing_cachefix_v1.core.pipeline import Pipeline
from experiments.query_decomposition.p02_m4_full8_dynamic_v1_20261022 import flow
from experiments.query_decomposition.p02_m4_full8_dynamic_v1_20261022.native_ask import AlgorithmTerminal
from experiments.query_decomposition.p02_m4_full8_dynamic_v1_20261022.retrieval_bridge import identity, key, check_packet
from experiments.query_decomposition.comprehensive_eval_v1_20261015.scoring import metric

B = ROOT / "experiments/query_decomposition/p02_m4_full8_dynamic_v1_20261022"
P = ROOT / "outputs/query_decomposition" / B.name
PACKAGE = ROOT / "src/p02_multigrain_timing_cachefix_v1"
DS = ("2wiki",)
UKEYS = ("prompt_tokens", "completion_tokens", "total_tokens")


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def rows(path):
    return [json.loads(s) for s in Path(path).read_text(encoding="utf-8-sig").splitlines() if s.strip()]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def rel(path):
    return str(Path(path).resolve().relative_to(ROOT)).replace("\\", "/")


def ro(path):
    return sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True)


def equal(left, right, label=""):
    if isinstance(right, dict):
        assert isinstance(left, dict) and set(left) == set(right), label
        for k in right:
            equal(left[k], right[k], label + "/" + str(k))
    elif isinstance(right, list):
        assert isinstance(left, list) and len(left) == len(right), label
        for n, (a, b) in enumerate(zip(left, right)):
            equal(a, b, label + "/" + str(n))
    elif type(right) in (float, int) and type(left) in (float, int):
        assert abs(left - right) < 1e-12, (label, left, right)
    else:
        assert left == right, (label, left, right)


def usage_ok(value):
    u = value.get("usage") or {}
    return all(type(u.get(k)) is int and u[k] >= 0 for k in UKEYS) and u["total_tokens"] == u["prompt_tokens"] + u["completion_tokens"]


def integrity(value, model):
    return value.get("status") == "success" and usage_ok(value) and value.get("requested_model") == value.get("returned_model") == model


def success(value, model, stage):
    return (integrity(value, model) and value.get("finish_reason") in (("stop", "length") if stage == "legacy/final" else ("stop",))
        and isinstance(value.get("answer"), str) and bool(value["answer"].strip()) and not value.get("refusal"))


def terminal(value, model):
    if not integrity(value, model):
        return None
    if value.get("refusal"):
        return "terminal_refusal"
    if value.get("finish_reason") in ("length", "content_filter"):
        return "terminal_" + value["finish_reason"]
    if isinstance(value.get("answer"), str) and not value["answer"].strip():
        return "terminal_empty"
    return None


def returned(value):
    if any(value.get(k) is not None for k in ("response_id", "raw_response", "usage", "returned_model", "refusal", "finish_reason")):
        return True
    content=value.get("answer") or value.get("content") or ""
    return bool(content.strip()) if isinstance(content,str) else bool(content)


def cost(usage):
    return usage["prompt_tokens"] * .8e-6 + usage["completion_tokens"] * 2e-6


def semantic_locks(outcomes, details, data):
    index = {(r["id"], r["arm"]): r for r in outcomes}
    assert set(index) == {(i, a) for i in data for a in flow.ARMS}
    diff = [i for i in data if index[i, "M0"]["prediction"] != index[i, "M4"]["prediction"]]
    same = [i for i in data if i not in set(diff)]
    join_path = P / "root_blind_review/SEMANTIC_JOIN.json"
    joined = read(join_path) if join_path.exists() else {"records": []}
    semantic = {(r["case_id"], r["arm"]): r for r in joined["records"]}
    expected = {(i, a) for i in diff for a in flow.ARMS}
    assert len(semantic) == len(joined["records"]) and set(semantic) == expected
    detail_index = {(r["id"], r["arm"]): r for r in details}
    covered, locks, checks = set(), [], []
    for batch in sorted((P / "root_blind_review").glob("batch*")):
        lock = read(batch / "ROOT_REVIEW_LOCK.json")
        packet_path, key_path = batch / "PACKET.json", batch / "METHOD_KEY.local.json"
        reviews_path = batch / "SEMANTIC_REVIEWS.blinded.jsonl"
        packet_sha, method_sha, review_sha = sha(packet_path), sha(key_path), sha(reviews_path)
        assert packet_sha == lock["packet_sha256"] and review_sha == lock["review_sha256"] and lock["locked_before_root_method_join"]
        assert method_sha==read(batch/"PACKET_LOCK.json")["method_key_sha256"]
        if "method_key_sha256" in lock:
            assert lock["method_key_sha256"] == method_sha
        candidates = {(c["case_id"], v["candidate_id"]): v for c in read(packet_path)["cases"] for v in c["candidates"]}
        methods = {(r["case_id"], r["candidate_id"]): r for r in read(key_path)}
        reviews = {(r["case_id"], r["candidate_id"]): r for r in rows(reviews_path)}
        assert len(candidates) == len(methods) == len(reviews) == lock["records"]
        assert set(candidates) == set(methods) == set(reviews)
        for ck, candidate in candidates.items():
            method, review = methods[ck], reviews[ck]
            pair = (ck[0], method["arm"])
            assert pair in expected and pair not in covered
            outcome = index[pair]
            assert candidate["text"] == outcome["prediction"]
            text_sha = hashlib.sha256(candidate["text"].encode()).hexdigest()
            assert review["packet_sha256"] == packet_sha
            if "candidate_text_sha256" in review:
                assert review["candidate_text_sha256"] == text_sha
            context = outcome.get("trajectory", {}).get("final_context")
            if "final_visible_context" in candidate:
                assert candidate["final_visible_context"] == context
            if "final_visible_context_sha256" in review:
                assert review["final_visible_context_sha256"] == (hashlib.sha256(context.encode()).hexdigest() if isinstance(context,str) else None)
            for name, value in review.items():
                assert semantic[pair][name] == value, (pair, name, "first locked label must remain unchanged")
            possible = {digest(outcome): "checkpoint_outcome", digest(detail_index[pair]): "native_report_detail"}
            bound = method.get("outcome_sha256", method.get("source_outcome_sha256"))
            assert bound in possible
            if "source_request_id" in method:
                assert method["source_request_id"] == outcome["stages"][-1]["request_id"]
            covered.add(pair)
            checks.append(dict(id=pair[0], arm=pair[1], candidate_id=ck[1], text_sha256=text_sha,
                source_digest=bound, source_digest_kind=possible[bound], packet_key_review_join_exact=True))
        locks.append({**lock, "batch": batch.name, "method_key_sha256": method_sha})
    assert covered == expected and sum(l["records"] for l in locks) == 2 * len(diff)
    return dict(scope="All final-text-different pairs, both arms; same-text pairs not reannotated or zeroed", diff_case_ids=diff,
        same_text_case_ids=same, reviewed_records=len(covered), locks=locks, checks=checks), semantic


def packet_signature(packet):
    if packet is None:
        return None
    return [(d["doc_id"], d["source"], hashlib.sha256(d["text"].encode()).hexdigest()) for d in packet["docs"]]


def audit_ready(path, protocol_sha, resources):
    ready = read(path)
    assert ready["status"] == "ready" and "A6000" in ready["gpu"] and ready["protocol_sha256"] == protocol_sha
    assert ready["no_LLM_credentials_or_requests"] is True
    job_path = P / "REMOTE_JOB_ID.json"
    job = read(job_path)
    assert str(ready["job_id"]) == str(job["job_id"]) and job["protocol_sha256"] == protocol_sha
    for ds in DS:
        actual, expected = ready["resources"][ds], resources[ds]
        assert actual["identity"] == expected["identity"]
        assert actual["manifest_sha256"] == expected["contract"]["portable_manifest_sha256"]
        assert actual["verified_file_stamps"] > 0 and actual["fresh_full_byte_hash_not_claimed"] is True
    return dict(path=rel(path), sha256=sha(path), job_file=rel(job_path), job_sha256=sha(job_path),
        GPU=ready["gpu"], job_id=ready["job_id"], exact_protocol_resources=True,
        limitation="Recorded remote READY verifies allocated CUDA device and preserved prior validation stamps; audit makes no new remote/full-byte assertion")


def main(root_confirmed=False, ready_path=None):
    assert root_confirmed, "Wait for root's explicit semantic-lock notification before opening new outputs"
    assert ready_path is not None, "Root must provide the local downloaded actual remote READY artifact"
    ready_path = Path(ready_path).resolve()
    assert ready_path.is_relative_to(P.resolve())
    protected = [B / "PROTOCOL.frozen.json", B / "flow.py", B / "run.py", B / "INPUTS8.jsonl", B / "SOURCE_PROVENANCE8.jsonl",
        B / "RESOURCE_CONTRACTS.json", B / "HISTORICAL_REFERENCES8.local.jsonl", P / "REPORT.json", P / "DETAILS.jsonl", P / "PAIRED.jsonl",
        P / "events.jsonl", P / "REMOTE_EVENTS.jsonl", ready_path, P / "REMOTE_JOB_ID.json"]
    protected += [f for d in (P / "root_blind_review").glob("batch*") for f in d.glob("*.json*")]
    if (P / "root_blind_review/SEMANTIC_JOIN.json").exists():
        protected.append(P / "root_blind_review/SEMANTIC_JOIN.json")
    before = {rel(p): sha(p) for p in protected}
    protocol = read(B / "PROTOCOL.frozen.json")
    assert len(protocol["pins"]) == 128
    assert len(protocol["protected_holds"]) == 3
    assert sha(B / "PROTOCOL.frozen.json") == "2056ecaa609dd6af2ae83dc849c7d5024f56760ea4d6c6ceeb1086ed533b9b4d"
    for path, expected in {**protocol["pins"], **protocol["protected_holds"]}.items():
        assert sha(ROOT / path) == expected, path
    config = read(PACKAGE / "config.json")
    model = config["generation"]["model"]
    data = {r["id"]: r for r in rows(B / "INPUTS8.jsonl")}
    tasks = rows(B / "ORDER16.jsonl")
    references = {r["id"]: r for r in rows(B / "references8.local.jsonl")}
    historical = {r["id"]: r for r in rows(B / "HISTORICAL_REFERENCES8.local.jsonl")}
    provenance = {r["id"]: r for r in rows(B / "SOURCE_PROVENANCE8.jsonl")}
    resources = read(B / "RESOURCE_CONTRACTS.json")
    assert len(data) == len(references) == len(historical) == len(provenance) == 8
    assert Counter(r["dataset"] for r in data.values()) == {"2wiki": 8}
    assert sum(len(r["supporting_questions"]) for r in data.values()) == 17
    assert len(tasks) == len({r["task_id"] for r in tasks}) == 16
    assert {r["task_id"] for r in tasks} == {i + "/" + a for i in data for a in flow.ARMS}
    manifest_path=ROOT/"tmp/p02_review_delivery_20261021/snapshot/review/p02_20261021/SOURCE_MANIFEST.json"
    mb=manifest_path.read_bytes()
    assert hashlib.sha1(f"blob {len(mb)}\0".encode()+mb).hexdigest()=="06c67be3c2091ef4066366b8c0c87c2b4d1ece17"
    manifest=json.loads(mb);public={r["source"].replace("\\","/"):r for r in manifest["source_files"]}
    for archive in manifest["archives"]:
        for member in archive.get("members",[]):public[member["source"].replace("\\","/")]=member
    source_checks, old_sources, old_ids = [], {}, set()
    for i, case in data.items():
        assert set(case)=={"id","qid","dataset","question","supporting_questions"}
        proof=provenance[i];old=old_sources[i]=read(ROOT/proof["source"])
        assert sha(ROOT/proof["source"])==proof["source_sha256"]==public[proof["source"]]["sha256"]
        assert {k:old[k]for k in case}==case
        raw=read(ROOT/proof["raw_file"])
        assert sha(ROOT/proof["raw_file"])==proof["raw_sha256"]
        assert raw["id"]==i and raw["query"]==case["question"] and raw["parsed"]==case["supporting_questions"]
        assert raw["format_valid"]and not raw["truncated"]and not raw["generation_error"]
        assert proof["actual_R02_array_exact"]is True and proof["manual_or_semantic_repairs_applied"]is False
        assert proof["all_inference_fields_exact_public_runtime"]is True
        runtime=ROOT/proof["public_runtime"]
        assert read(runtime)==case and sha(runtime)==proof["public_runtime_sha256"]==public[proof["public_runtime"]]["sha256"]
        old_ids.update(c["request_id"]for c in old["logical_calls"])
        assert historical[i]["source_sha256"]==proof["source_sha256"]and historical[i]["historical_quality_available"]is True
        assert historical[i]["final_prediction_reference_only"]==old["prediction"]
        assert abs(historical[i]["reference_CNY"]-sum(cost(c["usage"])for c in old["logical_calls"]))<1e-12
        source_checks.append(dict(id=i,source=proof["source"],source_sha256=proof["source_sha256"],raw_D_source=proof["raw_file"],
            raw_D_sha256=proof["raw_sha256"],actual_R02_array_exact=True,no_manual_repair=True,public_runtime=proof["public_runtime"],public_runtime_SHA_exact=True))
    ready = audit_ready(ready_path, sha(B / "PROTOCOL.frozen.json"), resources)
    with closing(ro(P / "checkpoint.sqlite3")) as db:
        current = {i: dict(stage=t, payload=p, status=s, result={**(json.loads(v) if v else {}), "status": s}) for i, t, p, s, v in db.execute("SELECT id,stage,payload,status,result FROM requests")}
        retired = {i: dict(stage=t, payload=p, status=s, result={**(json.loads(v) if v else {}), "status": s}) for i, t, p, s, v in db.execute("SELECT id,stage,payload,status,result FROM retired_requests")}
        outcomes = [json.loads(v) for (v,) in db.execute("SELECT value FROM data WHERE kind='outcome'")]
        packets = {k: json.loads(v) for k, v in db.execute("SELECT key,value FROM data WHERE kind='retrieval'")}
        saved_nodes = {k: json.loads(v) for k, v in db.execute("SELECT key,value FROM data WHERE kind='node'")}
        saved_stages = {k: json.loads(v) for k, v in db.execute("SELECT key,value FROM data WHERE kind='stage'")}
        checkpoint_identity = json.loads(db.execute("SELECT value FROM data WHERE kind='meta' AND key='identity'").fetchone()[0])
    assert len(outcomes) == len({r["task_id"] for r in outcomes}) == 16
    assert {r["task_id"] for r in outcomes} == {r["task_id"] for r in tasks}
    assert checkpoint_identity == dict(protocol_sha256=sha(B / "PROTOCOL.frozen.json"), inputs_sha256=sha(B / "INPUTS8.jsonl"),
        order_sha256=sha(B / "ORDER16.jsonl"), resources=resources, no_historical_LLM_seed=True)
    assert not old_ids.intersection(current) and not old_ids.intersection(retired)
    assert len(current) == len({v["payload"] for v in current.values()})
    attempts = Counter(v["payload"] for v in list(current.values()) + list(retired.values()))
    assert max(attempts.values(), default=0) <= 5
    logical_events = [r for r in rows(P / "events.jsonl") if r["event"] == "logical_retrieval"]
    remote_events = [r for r in rows(P / "REMOTE_EVENTS.jsonl") if r["event"] == "actual_retrieval_or_exact_worker_reuse"]
    remote_index = {}
    for event in remote_events:
        request = identity(resources[event["dataset"]]["identity"], event["dataset"], event["qid"], event["query"], 10)
        assert event["request_id"] == key(request)
        assert event["request_id"] in packets
        packet = check_packet(request, packets[event["request_id"]])
        assert event["doc_ids"] == [d["doc_id"] for d in packet["docs"]]
        remote_index[event["request_id"]] = event
    for event in logical_events:
        request = identity(resources[event["dataset"]]["identity"], event["dataset"], event["qid"], event["query"], 10)
        assert event["request_id"] == key(request) and event["resource_identity"] == resources[event["dataset"]]["identity"]
        assert event["request_id"] in remote_index
        check_packet(request, packets[event["request_id"]])
    assert set(packets) == set(remote_index)
    stage_checks, replay_checks, retrieval_checks, reconstructed = [], [], [], {}
    used = set()
    for outcome in outcomes:
        case = data[outcome["id"]]
        task_id, arm = outcome["task_id"], outcome["arm"]
        assert task_id == case["id"] + "/" + arm
        position, calls, nodes = [0], [], []
        stage_rows = outcome["stages"]
        def retrieve(query):
            request = identity(resources[case["dataset"]]["identity"], case["dataset"], case["qid"], query, 10)
            rid = key(request)
            assert rid in packets and rid in remote_index
            assert any(e["task_id"] == task_id and e["request_id"] == rid for e in logical_events)
            packet = check_packet(request, packets[rid])
            calls.append(dict(query=query, request_id=rid, resource_identity=request["resource_identity"],
                doc_ids=[d["doc_id"] for d in packet["docs"]]))
            return packet
        def ask(stage, prompt, maximum, allow_final_truncation=False):
            assert position[0] < len(stage_rows)
            saved = stage_rows[position[0]]
            position[0] += 1
            assert saved["stage"] == stage
            expected_cap = 64 if stage == "legacy/final" else (256 if stage.startswith("legacy/rewrite/") else 128)
            assert maximum == expected_cap and bool(allow_final_truncation) == (stage == "legacy/final")
            payload = build_payload(config["generation"], prompt, maximum)
            actual = current[saved["request_id"]]
            assert actual["payload"] == canonical(payload) and saved["payload_sha256"] == digest(payload)
            receipt = actual["result"]
            assert integrity(receipt, model) and saved["usage"] == receipt["usage"]
            answer_text=receipt.get("answer")
            assert saved["finish_reason"] == receipt["finish_reason"] and saved["answer"] == (answer_text.strip() if isinstance(answer_text,str) else "")
            assert saved_stages[task_id + "/" + stage] == saved
            good = success(receipt, model, stage)
            reason = None if good else terminal(receipt, model)
            assert good or reason
            assert saved["terminal_reason"] == reason
            used.add(saved["request_id"])
            stage_checks.append(dict(task_id=task_id, stage=stage, request_id=saved["request_id"], cap=maximum,
                full_wire_sha256=digest(payload), exact_body_model_three_integer_usage=True,
                finish_reason=receipt["finish_reason"], final_length_accepted=(stage == "legacy/final" and receipt["finish_reason"] == "length" and good)))
            if reason:
                raise AlgorithmTerminal(saved)
            return saved["request_id"], saved["answer"], saved["finish_reason"]
        try:
            result = flow.execute_arm(case, retrieve, ask, arm, pipeline=Pipeline(config), record_node=lambda node: nodes.append(deepcopy(node)))
        except AlgorithmTerminal as exc:
            assert outcome["status"] == "algorithm_failure" and outcome["prediction"] == ""
            assert outcome["terminal_reason"] == exc.value["terminal_reason"] and outcome["terminal_stage"] == exc.value["stage"]
            assert outcome["partial_nodes"] == nodes
            result = None
        else:
            assert outcome["status"] in ("success", "success_truncated")
            assert result == outcome["trajectory"] and result["prediction"] == outcome["prediction"] and result["status"] == outcome["status"]
            reconstructed[task_id] = result
        assert position[0] == len(stage_rows)
        for node in nodes:
            assert saved_nodes[task_id + "/" + str(node["step_id"])] == node
            from experiments.query_decomposition.p02_m4_reader_stage_probe8_v1_20261022 import selection
            expected_reader=selection.packet(node["original_retrieval"],node["rewritten_retrieval"],arm)
            assert node["reader_packet"]==expected_reader
            assert node["request"]==(case["supporting_questions"]+[case["question"]])[node["step_id"]-1]
        if result is not None:
            assert result["original_retrieval"]==nodes[-1]["original_retrieval"],"Final root must remain original goal retrieval"
        retrieval_checks.append(dict(task_id=task_id, all_live_query_resource_packet_reader_links_exact=True, logical_lookups=calls))
        replay_checks.append(dict(task_id=task_id, stages=len(stage_rows), complete_nodes=len(nodes), status=outcome["status"],
            fixed_rawD_history_goal_formatter_final_core_exact=True, allordinary_and_goal_reader_selection_exact=True, raw_Current_preserved=True,
            exact_offline_receipt_replay_not_new_inference=True))
    assert used == set(current)
    report, details = read(P / "REPORT.json"), rows(P / "DETAILS.jsonl")
    semantic_scope, semantic = semantic_locks(outcomes, details, data)
    scorers = {ds: metric(ds) for ds in DS}
    reference_scores = {i: scorers[data[i]["dataset"]](historical[i]["final_prediction_reference_only"], references[i]) for i in data}
    native = []
    for outcome in outcomes:
        metrics = scorers[outcome["dataset"]](outcome["prediction"], references[outcome["id"]]) if outcome["status"] in ("success", "success_truncated") else dict(f1=0., em=0.)
        u = {k: sum(s["usage"][k] for s in outcome["stages"]) for k in UKEYS}
        native.append({**{k: v for k, v in outcome.items() if k not in ("trajectory", "partial_nodes")}, **metrics,
            "native_full_correct":metrics["f1"]==1. or metrics["em"]==1.,
            "full_flow_logical_usage": u, "full_flow_logical_estimated_CNY": cost(u)})
    index = {(r["id"], r["arm"]): r for r in native}
    task_ids = {t["task_id"] for t in tasks}
    namespace = "p02_prompt_research_v1_20261022/" + str(P.resolve())
    with closing(ro(config["budget"]["ledger"])) as ledger:
        charges = [dict(id=i, reserved_CNY=r, actual_CNY=a, status=s) for i, r, a, s in ledger.execute(
            "SELECT id,reserved,actual,status FROM charges WHERE namespace=?", (namespace,))]
    charge_index = {r["id"]: r for r in charges}
    assert set(current) | set(retired) <= set(charge_index) and not old_ids.intersection(charge_index)
    owner, paid = {}, {t: dict(actual_new_returned_usage_CNY=0., unresolved_reserved_CNY=0.) for t in task_ids}
    for rid, value in {**current, **retired}.items():
        owners = [t for t in task_ids if value["stage"].startswith("full8/" + t + "/")]
        assert len(owners) == 1
        owner[rid] = owners[0]
    unattributed = dict(actual_new_returned_usage_CNY=0., unresolved_reserved_CNY=0.)
    for charge in charges:
        assert charge["reserved_CNY"] >= 0 and (charge["actual_CNY"] is None or charge["actual_CNY"] >= 0)
        dest = paid[owner[charge["id"]]] if charge["id"] in owner else unattributed
        dest["actual_new_returned_usage_CNY"] += charge["actual_CNY"] or 0.
        if charge["actual_CNY"] is None:
            dest["unresolved_reserved_CNY"] += charge["reserved_CNY"]
        if charge["id"] in current:
            assert charge["status"] == "returned_usage" and charge["actual_CNY"] is not None
            assert abs(charge["actual_CNY"] - cost(current[charge["id"]]["result"]["usage"])) < 1e-12
        elif charge["id"] in retired:
            assert not returned(retired[charge["id"]]["result"])
            assert charge["status"] == "reserved" and charge["actual_CNY"] is None
        else:
            assert charge["actual_CNY"] is None, "Unknown paid orphan needs reconciliation"
    out_index = {r["task_id"]: r for r in outcomes}
    paid_rows = []
    for task in tasks:
        value = paid[task["task_id"]]
        outcome = out_index[task["task_id"]]
        baseline = historical[task["id"]]["reference_CNY"]
        eligible = outcome["status"] in ("success", "success_truncated") and value["actual_new_returned_usage_CNY"] > 0 and value["unresolved_reserved_CNY"] == 0
        paid_rows.append({**task, **value, "status": outcome["status"], "historical_complete_query_CNY": baseline,
            "eligible_for_complete_paid_query_trend": eligible,
            "historical_expense_reference_kind":historical[task["id"]]["reference_kind"],
            "attribution": "First submitting condition; complete flow with shared prefix is a same-period variant proxy, not independent cold full-cost measurement", "utc": outcome["utc"]})
    paid_index = {r["task_id"]: r for r in paid_rows}
    for row in native:
        row["actual_new_spend_first_owner_attribution"] = paid_index[row["task_id"]]
    recorded = {r["task_id"]: r for r in details}
    assert len(recorded) == len(details) == 16
    for row in native:
        equal(recorded[row["task_id"]], row, row["task_id"])
    def summary(arm, ds=None):
        selected = [r for r in native if r["arm"] == arm and (ds is None or r["dataset"] == ds)]
        n = 8 if ds is None else sum(r["dataset"] == ds for r in data.values())
        assert len(selected) == n
        f, e = sum(r["f1"] for r in selected), sum(r["em"] for r in selected)
        return dict(planned=n, quality_terminal=n, held_or_unstarted=0, F1=f / n, EM=e / n,
            F1_fixed_denominator_bounds=[f / n, f / n], EM_fixed_denominator_bounds=[e / n, e / n],
            algorithm_failures=sum(r["status"] == "algorithm_failure" for r in selected), native_full_correct_count=sum(r["native_full_correct"]for r in selected), success_truncated=sum(r["status"] == "success_truncated" for r in selected),
            logical_prompt_tokens=sum(r["full_flow_logical_usage"]["prompt_tokens"] for r in selected),
            logical_completion_tokens=sum(r["full_flow_logical_usage"]["completion_tokens"] for r in selected),
            logical_estimated_CNY=sum(r["full_flow_logical_estimated_CNY"] for r in selected))
    arm_summary = {a: summary(a) for a in flow.ARMS}
    ds_summary = {ds: {a: summary(a, ds) for a in flow.ARMS} for ds in DS}
    equal(report["arms"], arm_summary)
    equal(report["by_dataset"], ds_summary)
    pairs = [dict(id=i, dataset=references[i]["dataset"], M0=index[i, "M0"]["f1"], M4=index[i, "M4"]["f1"],
        delta_F1=index[i, "M4"]["f1"] - index[i, "M0"]["f1"], delta_EM=index[i, "M4"]["em"] - index[i, "M0"]["em"]) for i in references]
    paired = dict(complete_pairs=8, delta_F1=sum(r["delta_F1"] for r in pairs) / 8, delta_EM=sum(r["delta_EM"] for r in pairs) / 8,
        improved=sum(r["delta_F1"] > 0 for r in pairs), tied=sum(r["delta_F1"] == 0 for r in pairs), harmed=sum(r["delta_F1"] < 0 for r in pairs))
    historical_summary=dict(scope="Exact8 public formal source cases selected by priorstage protocol (r000/r100); nonconcurrent reference only",planned=8,available=8,missing=0,
        F1=sum(r["f1"]for r in reference_scores.values())/8,EM=sum(r["em"]for r in reference_scores.values())/8,
        F1_available=sum(r["f1"]for r in reference_scores.values())/8,EM_available=sum(r["em"]for r in reference_scores.values())/8,missing_not_imputed=True)
    def old_subset(ids):
        v=[reference_scores[i]for i in ids];return dict(n=len(v),F1=sum(r["f1"]for r in v)/len(v)if v else None,EM=sum(r["em"]for r in v)/len(v)if v else None)
    def fresh_subset(arm,ids):
        v=[index[i,arm]for i in ids];n=len(ids);f=sum(r["f1"]for r in v);e=sum(r["em"]for r in v)
        return dict(planned=n,quality_terminal=len(v),held_or_unstarted=n-len(v),F1=f/n if n else None,EM=e/n if n else None,F1_fixed_denominator_bounds=[f/n,f/n]if n else None,EM_fixed_denominator_bounds=[e/n,e/n]if n else None)
    allids=set(data)
    matched=dict(scope="Same8 frozen source historical references; noqualityselection;fresh controls separate from oldnonconcurrent",n=8,missing_historical=0,missing_historical_ids=[],old_native=old_subset(allids),M0_native=fresh_subset("M0",allids),M4_native=fresh_subset("M4",allids),
        by_dataset={ds:dict(n=sum(data[i]["dataset"]==ds for i in allids),old_native=old_subset({i for i in allids if data[i]["dataset"]==ds}),M0_native=fresh_subset("M0",{i for i in allids if data[i]["dataset"]==ds}),M4_native=fresh_subset("M4",{i for i in allids if data[i]["dataset"]==ds}))for ds in DS})
    equal(report["matched_historical_subset"],matched)
    equal(report["paired"], paired)
    equal(rows(P / "PAIRED.jsonl"), pairs)
    equal(report["historical_source_reference_only"], historical_summary)
    equal(report["per_query_new_paid_attribution"], paid_rows)
    equal(report["unattributed_charges"], unattributed)
    assert set(charge_index)==set(current)|set(retired),"No orphan namespace reservation or missing request charge"
    eligible=sum(r["eligible_for_complete_paid_query_trend"]for r in paid_rows)
    equal(report["expense_trend"],dict(unit="complete_paid_query",eligible=eligible,threshold=20,enough_queries_for_window=False,note="Only completepaidqueries; no purecache/partial/unknown stagecount proxy; sharedprefix variants labelledcostproxy"))
    assert eligible<=16
    actual = sum(c["actual_CNY"] or 0 for c in charges)
    reserved = sum(c["reserved_CNY"] for c in charges if c["actual_CNY"] is None)
    equal(report["actual_new_returned_usage_CNY"], actual)
    equal(report["unresolved_reserved_CNY"], reserved)
    equal(report["request_statuses"], dict(Counter(v["status"] for v in current.values())))
    equal(report["retired_request_statuses"], dict(Counter(v["status"] for v in retired.values())))
    assert report["planned_conditions"]==16 and report["scorer_factory_calls_once_per_dataset"]==1
    assert report["quality_terminal"] == 16 and report["held_technical_tasks"] == 0 and report["not_started_tasks"] == 0 and report["status"] == "completed"
    # Keep old-source/new-M0 retrieval changes separate from the treatment.
    historical_repeat = []
    for i, old in old_sources.items():
        fresh = reconstructed.get(i + "/M0")
        if fresh is None:
            historical_repeat.append(dict(id=i, fresh_M0_algorithm_terminal=True, historical_native=reference_scores[i]))
            continue
        assert len(old["nodes"]) == len(fresh["nodes"])
        node_diff = []
        for on, nn in zip(old["nodes"], fresh["nodes"]):
            assert on["request"] == nn["request"] and on["step_id"] == nn["step_id"]
            routes = {}
            for route in ("original_retrieval", "rewritten_retrieval", "reader_packet"):
                op, np = on.get(route), nn.get(route)
                routes[route] = dict(old_query=op.get("query") if op else None, new_query=np.get("query") if np else None,
                    route_query_same=(op.get("query") if op else None) == (np.get("query") if np else None),
                    ordered_document_ids_same=([d["doc_id"] for d in op["docs"]] if op else None) == ([d["doc_id"] for d in np["docs"]] if np else None),
                    document_identity_source_text_same=packet_signature(op) == packet_signature(np))
            node_diff.append(dict(step_id=on["step_id"], role=on["role"], raw_request_same=True,
                accepted_rewrite_same=on["rewritten_query"] == nn["rewritten_query"], old_rewrite=on["rewritten_query"], new_rewrite=nn["rewritten_query"],
                full_QA_prompt_same=on["child_prompt"] == nn["child_prompt"], answer_text_same=on["answer"] == nn["answer"], routes=routes))
        historical_repeat.append(dict(id=i, question=data[i]["question"], node_changes=node_diff,
            historical_final=old["prediction"], fresh_M0_final=fresh["prediction"], final_text_same=old["prediction"] == fresh["prediction"],
            full_final_prompt_same=old["final_prompt"] == fresh["final_prompt"], historical_native=reference_scores[i],
            fresh_M0_native=dict(f1=index[i, "M0"]["f1"], em=index[i, "M0"]["em"]),
            F1_delta=index[i, "M0"]["f1"] - reference_scores[i]["f1"], EM_delta=index[i, "M0"]["em"] - reference_scores[i]["em"]))
    result = dict(created_utc=datetime.now(timezone.utc).isoformat(), scope="Post-lock independent M4 fixed-D dynamic full8 local development audit; not formal500 or independent confirmation",
        protected_source_hashes=before, frozen_pins_verified=128, protected_holds_verified=3, actual_R02_source_checks=source_checks, remote_ready=ready,
        semantic_scope=semantic_scope, exact_offline_dynamic_pipeline_replay=replay_checks,
        retrieval_wiring=dict(unique_query_resource_packets=len(packets), all_match_recorded_remote_return_doc_ids=True, per_condition=retrieval_checks,
            physical_scope="Original frozen query-resource contracts, recorded actual remote READY and retrieval return events; no new SSH or full-byte remote verification"),
        request_contracts=dict(logical_stage_uses=len(stage_checks), current_unique_receipts=len(current), stage_checks=stage_checks,
            no_old_request_ids_imported=True, maximum_durable_attempts_observed=max(attempts.values(), default=0),
            retired_records={rid: dict(stage=v["stage"], status=v["status"], result=v["result"], payload_sha256=digest(json.loads(v["payload"]))) for rid, v in retired.items()}),
        native=dict(scorer_factory_calls=1, full16_details_match=True, arms=arm_summary, by_dataset=ds_summary,
            paired=paired, historical_source_reference_only=historical_summary,matched_historical_subset=matched,
            full_correct_criterion="Official F1==1 OR EM==1;separate from semantic truth"),
        costs=dict(actual_new_returned_usage_CNY=actual, unresolved_reserved_CNY=reserved, charges=charges,
            first_submitting_query_paid_attribution=paid_rows, unattributed_charges=unattributed,
            orphan_reservation_ids=sorted(set(charge_index) - set(current) - set(retired)), old_source_expense_not_newly_charged=True,
            complete_query20_window_unavailable=True, note="16 planned flows cannot form20 complete paidquery window; shared-prefix first-owner spend is not independent cold cost"),
        historical_source_vs_fresh_M0=dict(cases=historical_repeat, limit="Nonconcurrent new control recomputes retrieval and responses; route/reader/time-service drift is separate from M4 intervention, not pure random error or evidence of a M4 effect"),
        limits=["Repeatedly exposed selected8, all fixedD retained. Native final improvement cannot be inferred from local QA repair alone.",
            "M4 changes only allordinary/goal reader merging;raw Current/history/native formatter/final root and final64 preserved by exact replay.",
            "Algorithm terminals remain in fixed8 denominator at0; technicalheld is not fabricated as algorithm0. All16 must be quality-terminal before this completed audit.",
            "Reviewer prior exposure and original locks remain; no new semantic labels are created by this audit."],
        original_scripts_reports_labels_unchanged=True, new_API_SSH_GPU_operations=0, main_evaluation_remains_paused=True)
    assert before == {rel(p): sha(p) for p in protected}
    for path,h in {**protocol["pins"],**protocol["protected_holds"]}.items():assert sha(ROOT/path)==h,path
    target = P / "ROOT_NATIVE_RECEIPT_AUDIT.json"
    assert not target.exists(), "Preserve existing audits; version deliberately"
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    print(json.dumps(dict(passed=True, path=rel(target), sha256=sha(target)), ensure_ascii=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root-confirmed-semantic-lock", action="store_true")
    parser.add_argument("--remote-ready", help="Root-downloaded actual remote READY JSON inside this experiment OUT")
    args = parser.parse_args()
    main(root_confirmed=args.root_confirmed_semantic_lock, ready_path=args.remote_ready)
