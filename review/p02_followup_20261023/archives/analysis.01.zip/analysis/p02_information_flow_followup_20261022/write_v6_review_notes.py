"""Write new V6 description and hypothesis mapping; preserve prior versions."""
from build_offline import OUT, OLD, read, write, inventory
from datetime import datetime, timezone


def main():
    reviews=read(OUT/'MANUAL_INFORMATION_FLOW_REVIEWS_V6.json')['reviews']
    by={(r['dataset'],r['review_index']):r for r in reviews}
    def refs(pairs):
        return [{'dataset':ds,'review_index':idx,'id':by[(ds,idx)]['id'],
                 'review':'MANUAL_INFORMATION_FLOW_REVIEWS_V6.json#'+by[(ds,idx)]['id']}
                for ds,idx in pairs]
    mapping=read(OUT/'REPAIR_HYPOTHESIS_EXPERIMENT_MAPPING_V5.json')
    mapping['utc']=datetime.now(timezone.utc).isoformat()
    mapping['review_scope']='150materially reviewed:40seeded fullscore+110ordered/initial nonfullscore;146declared-scope complete,4pending. One current Codex reviewer; no population or causal claim.'
    for m in mapping['mappings']:
        for c in m.get('evidence_cases',[]):
            c['review']=c['review'].replace('_V5.json#','_V6.json#')
    mm={m['hypothesis_id']:m for m in mapping['mappings']}
    mm['H_GOAL_OPERATOR_AND_RELATION']['evidence_cases']+=refs([('2wiki',362),('2wiki',376),('2wiki',390),('2wiki',392),('2wiki',403),('hotpotqa',119)])
    mm['H_GOAL_OPERATOR_AND_RELATION']['distinct_failures']+=[
        'Wiki362/376/390/392: both operands already visible; nonempty shared-country intersection changed into full country-set equality.',
        'Wiki403: correct MaryClifton grandmother chain overwritten by CatherineWalmesley mother from original biography.',
        'HP119: goal has Helmand->primarywatershedfor->SistanBasin but final returns relation subject; original wording remains awkward.'
    ]
    mm['H_GOAL_CORRECTS_BAD_PRIOR']['evidence_cases']+=refs([('2wiki',371),('hotpotqa',107),('hotpotqa',133)])
    mm['H_GOAL_CORRECTS_BAD_PRIOR']['limits']+=[
        'Wiki371 exact correct-generation chain is visible; not every ancestor name is interchangeable.',
        'HP107 shows Youngstown predecessor in reader despite wrong Newark NJ->Ohio binding; true Newark/Licking county-seat relation must not become a fresh factual-error count.',
        'HP133 missing target director and wrong actor-film join both matter; a role-check alone does not prove full recovery.'
    ]
    mm['H_GOAL_REWRITE_FACT_GAIN_VS_BINDING']['evidence_cases']+=refs([('hotpotqa',126),('hotpotqa',107),('2wiki',403)])
    mm['H_GOAL_REWRITE_FACT_GAIN_VS_BINDING']['limits']+=[
        'HP126 current goal reader gains named writer after ordinary no-known-author error. A no-goal-retrieval contrast may lose useful correction, even though fromNYC does not explicitly prove birth.',
        'Wiki403 rewrite already names correct MaryClifton; wrong synthesis still selects mother. Rewrite text correctness alone is not a downstream guarantee.'
    ]
    final_key=next(k for k in mm if k.startswith('H_FINAL') and k!='H_FINAL_FACT_VISIBILITY')
    mm[final_key]['evidence_cases']+=refs([('2wiki',419),('hotpotqa',119),('2wiki',403)])
    mm[final_key]['limits']+=[
        'Wiki419 already exposes Thailand-born/BritishAmerican distinction; adding facts is not the demonstrated missing factor.',
        'HP119 surface grammar invites bridge-river parsing; relation-object failure is conditional on native intended interpretation.',
        'Wiki403 correct grandmother is already in helper; increased visibility alone may leave conflicting goal authority unresolved.'
    ]
    mm['H_REFERENCE_AND_UNRESOLVED_GUARD']['evidence_cases']+=refs([('2wiki',361),('2wiki',375),('2wiki',386),('hotpotqa',114),('hotpotqa',123),('hotpotqa',104)])
    mm['H_REFERENCE_AND_UNRESOLVED_GUARD']['limits']+=[
        'HP114 reference1864 describes CDP within Richmond town, not proven town2000 population.',
        'Wiki361 nativeAmerican is nationality rather than an established birthplace; Wiki375 politicalWestminster mention does not prove birthplace.',
        'HP123 CigaretteRock is explicitly another summit satisfying county condition; a single reference does not refute it.',
        'Wiki386 entire diagnosis timeline remains existing pending workitem; HP104 translation versus modern-figure semantics not newly adjudicated.'
    ]
    mapping['no_new_prompt_or_method_change']=True
    mapping['no_experiment_launched_by_this_artifact']=True
    assert not (OUT/'REPAIR_HYPOTHESIS_EXPERIMENT_MAPPING_V6.json').exists()
    write(OUT/'REPAIR_HYPOTHESIS_EXPERIMENT_MAPPING_V6.json',mapping)
    text='''# P02 信息流离线追加审阅 V6

本版在 V5 基础上，严格从冻结队列按各数据集 review_index 递增追加 20 条，共 40 条。逐条阅读既有 reader、QA、goal 和 final；没有调用 API、GPU、网络或新检索，没有修改原阶段事实标签、原生 F1/EM、主评方案或方法实现。

## 当前完成范围

- 累计亲读 150 条：40 条固定 seed 满分对照、110 条非满分（2Wiki50、HotpotQA60）。
- 146 条完成了每条记录所声明的必要信息/路径检查；4 条保留待核工作项。完成声明不等于对所有无关附加事实重新作独立金标。
- 待核为 2Wiki317、254、319，以及本批纳入的既有386诊断时间问题；不强行增加第三个正确性标签，不更改旧标签。
- 主270队列尚有120条非满分未审；另有8条历史满分补充案例未启动，共128条尚未开始。
- 满分对照是固定 seed 抽样；非满分含最初案例及递增前缀，并非随机失败样本，数据集比例也不同。不能从本审阅给出总体原因占比、总体条件概率或因果排名。

## 本批可核对的实际错误边界

1. **已有双方事实，但比较运算做错。** 2Wiki362/376 分别已有 Turkish-French/French、French/French-American；390/392已有共同 US/British。普通 QA 保留两侧属性，goal 把“有共同国籍/国家”变成“完整集合相同/唯一来源相同”，final 跟随 No。390 的 goal 全句事实标签仍为 True，因为它也准确说出了共同US；事实真不等于执行对了所问运算。这组案例适合映射 goal 综合，不需要先假定更多检索。
2. **正确关系已可见，仍被错误层级或属性覆盖。** 403 ordinary2 已给 MaryClifton 为祖母，goal 却用原传记中的母亲 CatherineWalmesley 覆盖，final 跟随。371 问 Richard（William之子）的祖父，却多追一代到 RichardII；William父亲RobertI事实也在最终输入中。419 goal区分 Thailand-born 与 British-American，final取出生国家；“from”表面有歧义，错误判断明确限于原数据集的国籍目标。
3. **检索到桥梁也可能误用。** HP107 的第二个 reader 已包含 YoungstownPuddlers 后称 LittleGiants，却沿 Newark 路径并把NJ球队与Ohio同名城市关联，最后取 Licking。后续 Newark 是 Licking 县治这一句对实际改写问题属真；本版不因上游带偏而新增该句的事实错误计数。原标签保持不动。
4. **goal检索也有纠错价值。** HP126 ordinary2说没有已知作者，但goal reader拿到JohnFrazee与故事关系后，goal/final恢复作者所在城市。材料中的 artist fromNYC不等于明确 borninNYC；本版保留既有正确标签，并把“事实来源的力度”单列，不用金标字符串替代出生关系证明。

## 与实际错误分开的参考与证据问题

- HP114 同时读到 Richmond town2010人口3411，以及 town内部同名CDP2000人口1864。参考1864的字符串可见，但行政单位不同；不能据此把回答town2000未知判为阅读失误。
- HP123 reader明确支持 CigaretteRock 是 LewisClarkCounty 的一个峰；参考 ScapegoatMountain 是另一座。单一参考无法排除有效替代答案。
- Wiki361原问题问出生地，传记只有American国籍描述，参考也为American；Wiki375传记里Westminster是议会地点，不能当出生地证明。保持原指标，同时明确其证据/字段局限。
- 349、352、357、370、378、384、389、391及HP99、100、110、116、124、129、131等，分别记录头衔、别名、地点粒度、多演员/多奖项/多雇主、计数单位等现象。没有将全部非满分统称格式问题：每条都保留其具体范围；389与126还明确读入材料未直接建立目标关系。
- HP104两份实际材料分别给Finnish名的YuleGoat直译、YuleGoat稻草形象，final用Finnish名而参考用英文名；本版记录该选择和语义界限，不重新强判现代Santa形象与草羊形象所有属性等同。
- Wiki386既有Alzheimer目标值已传到最终答案，但附加确诊三年前与公开披露时间尚未核清，保留待核，不能仅凭疾病词命中强判整句。

## 修复假设映射

`REPAIR_HYPOTHESIS_EXPERIMENT_MAPPING_V6.json` 把新案例追加到已有 goal综合、goal改写检索、final可见性/读出、参考解释等假设下。只是案例到假设的映射，没有改 prompt、方法或已批准实验。尤其403正确祖母已在helper，419属性区分已在goal，因而“增加可见事实”本身不能解释为必然修复；需观察冻结对照中的具体分叉。

## 文件与保护

- 本批：`MANUAL_INFORMATION_FLOW_REVIEWS_BATCH006.json`；累计：`MANUAL_INFORMATION_FLOW_REVIEWS_V6.json`。
- 单条证据含源文件哈希、step、route、doc_id、rank和精确摘录；摘录匹配只验证位置，不自动证明语义充分性。
- `REVIEW_INDEX_V6.jsonl` 是当前状态覆盖层；`REMAINING_NONFULLSCORE_QUEUE_V6.jsonl` 继续冻结递增顺序。
- `CURRENT_REVIEW_VERSION.json` 指向 V6，原V5指针保存为 `CURRENT_REVIEW_VERSION_V5.json`；旧V1–V5记录、索引、报告和原诊断64文件逐字节保留。
- `VALIDATION_V6.json` 记录追加及保护检查。原40张统计表及四组主表均未重算或改写；本版只追加离线信息流审阅。
'''
    assert not (OUT/'README_V6.md').exists()
    (OUT/'README_V6.md').write_text(text,encoding='utf-8')
    assert read(OUT/'HISTORICAL_INPUT_HASHES.json')==inventory(OLD)
    print({'version':6,'review_notes_written':True,'hypothesis_families':len(mapping['mappings'])})


if __name__=='__main__':main()
