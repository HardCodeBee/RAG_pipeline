"""Append the next queue-ordered 20 manually inspected information-flow items."""
from collections import Counter
from datetime import datetime, timezone
from build_offline import ROOT, OUT, OLD, read, rows, write, jsonl, inventory
from first_manual_review import packet, node, source_doc, ev, entry


def reviewed(p, requirements, evidence, category, detail, final_ok=True, limit=None):
    finding = {'location': 'reader to QA to goal/final', 'category': category, 'confirmed': True, 'detail': detail}
    if limit:
        finding['limit'] = limit
    return entry(p, requirements, [finding], evidence, True, final_ok)


def main():
    batch = []
    for idx, f1, d1, y1, f2, d2, y2, winner, operation in [
        (397, 'The Last of the Unjust', 'Claude Lanzmann', '1925', 'Parachute Battalion', 'Leslie Goodwins', '1899', 'Parachute Battalion', 'earlier birth'),
        (692, 'Gremlins 2: The New Batch', 'Joe Dante', '1946', 'Petulia', 'Richard Lester', '1932', 'Gremlins 2: The New Batch', 'later birth'),
        (723, 'Forbidden Dreams', 'Karel Kachyňa', '2004', 'If I Were Free', 'Elliott Nugent', '1980', 'Forbidden Dreams', 'later death')]:
        p = packet('2wiki', idx)
        evidence = [ev(step, 'reader_packet', source_doc(p, step, 'reader_packet', title), quote) for step, title, quote in [
            (1, f1, d1), (2, f2, d2), (3, d1, y1), (4, d2, y2)]]
        assert p['trace']['prediction'] == winner
        assert y1 in p['trace']['final_context'] and y2 in p['trace']['final_context']
        batch.append(reviewed(p, [f'{f1} director {d1}, relevant date {y1}.', f'{f2} director {d2}, relevant date {y2}.', f'Apply {operation} and return associated film.'], evidence,
            'correct_relational_binding_and_temporal_operation', f'The actual reader supplies both film-director bindings and both dates; ordinary QA and goal preserve them and final chooses the film in the requested {operation} direction.'))

    p = packet('2wiki', 512)
    evidence = [ev(1, 'reader_packet', source_doc(p, 1, 'reader_packet', 'Citizen USA: A 50 State Road Trip'), 'directed by Alexandra Pelosi'),
                ev(2, 'reader_packet', source_doc(p, 2, 'reader_packet', 'Alexandra Pelosi'), 'a daughter of the Speaker of the United States House of Representatives Nancy Pelosi and Paul Pelosi')]
    assert p['trace']['prediction'] == 'Nancy Pelosi'
    batch.append(reviewed(p, ['Film director is Alexandra Pelosi.', 'Her mother is Nancy Pelosi, not her father Paul Pelosi.'], evidence,
        'correct_parent_role_binding', 'Goal reader supplies the daughter/parents relation; answer and final choose the mother. Nancy Pelosi is also named in original-query material, so goal is not claimed to be the exclusive source.'))

    p = packet('2wiki', 317)
    evidence = [ev(3, 'reader_packet', source_doc(p, 3, 'reader_packet', 'Andrew V. McLaglen'), 'born American film and television director'),
                ev(4, 'reader_packet', source_doc(p, 4, 'reader_packet', 'Irvin Willat'), 'American film director')]
    r = reviewed(p, ['Determine whether from the same country means origin/birth or citizenship/nationality.', 'Bind Chisum to Andrew V. McLaglen and The Law of the North to Irvin Willat.'], evidence,
        'origin_and_nationality_both_present_criterion_not_fixed', 'The ordinary answer preserves British-born and American for McLaglen. Goal says No while restating both. Frozen dataset triples encode British versus American, so native No is full score; the reader does not by itself fix a single meaning of from.', final_ok=None,
        limit='Do not change frozen labels or infer a categorical factual error. This flow/criterion question remains a work item.')
    r['review_status'] = 'pending_work_item_after_material_review'
    r['pending_work_item'] = {'id': 'WIKI317_COUNTRY_ORIGIN_VS_NATIONALITY', 'question': 'How should an under-specified from-the-same-country comparison be interpreted when the same passage says British-born American?',
        'changes_binary_truth_label': False, 'needs_network_now': False, 'reason': 'Interpretation ambiguity, not a missing webpage fact.'}
    batch.append(r)

    p = packet('2wiki', 359)
    evidence = [ev(1, 'reader_packet', source_doc(p, 1, 'reader_packet', 'Haldor Lillenas'), '18 August 1959'),
                ev(2, 'reader_packet', source_doc(p, 2, 'reader_packet', 'Holly Broadbent Sr.'), '23 December 1977')]
    assert p['trace']['prediction'] == 'Holly Broadbent Sr.'
    batch.append(reviewed(p, ['Haldor Lillenas died in 1959.', 'Holly Broadbent Sr. died in 1977.', 'Choose later death.'], evidence,
        'two_dates_preserved_correct_comparison', 'Both named-person dates are in their actual readers and ordinary answers; final preserves Sr. and selects 1977 as later.'))

    p = packet('2wiki', 679)
    evidence = [ev(1, 'reader_packet', source_doc(p, 1, 'reader_packet', 'Yekaterinovka, Kulundinsky District, Altai Krai'), 'Kulundinsky District, Altai Krai, Russia'),
                ev(2, 'reader_packet', source_doc(p, 2, 'reader_packet', 'Nizhnetroitsky'), 'Bashkortostan, Russia')]
    assert p['trace']['prediction'] == 'Yes'
    batch.append(reviewed(p, ['Specified Yekaterinovka in Kulundinsky District is in Russia.', 'Nizhnetroitsky is in Russia.', 'Compare country equality.'], evidence,
        'disambiguated_location_country_preserved', 'Reader contains the fully qualified Yekaterinovka entity despite same-name locality distractors; QA and final preserve country equality.'))

    p = packet('hotpotqa', 130)
    d = source_doc(p, 2, 'reader_packet', 'Tempo')
    assert 'cannot be determined' in node(p, 1)['answer']
    assert p['trace']['prediction'] == 'tempo'
    batch.append(reviewed(p, ['Identify the musical term defined by speed or pace of a piece: tempo.'],
        [ev(2, 'reader_packet', d, 'is the speed or pace of a given piece')],
        'direct_definition_path_despite_supporting_abstention', 'Ordinary answer abstains about the song classification. Goal/final obtain tempo directly from the definition present in the original question and reader. The song-specific mid-tempo fact is not asserted to have entered the reader.'))

    p = packet('hotpotqa', 191)
    evidence = [ev(1, 'reader_packet', source_doc(p, 1, 'reader_packet', 'Disporum'), 'about 20 species'),
                ev(2, 'reader_packet', source_doc(p, 2, 'reader_packet', 'Boltonia'), 'one species in eastern Asia')]
    assert p['trace']['prediction'] == 'Disporum'
    batch.append(reviewed(p, ['Disporum has about 20 species found in Asia.', 'Boltonia has one in eastern Asia.', 'Compare counts in the specified region.'], evidence,
        'regional_count_scope_preserved', 'Both sources support counts in Asia rather than confusing global and regional totals; ordinary QA retains 20 versus one and final selects Disporum.'))

    p = packet('hotpotqa', 69)
    evidence = [ev(1, 'reader_packet', source_doc(p, 1, 'reader_packet', 'Hovsep Pushman'), 'Grand Central Art Galleries'),
                ev(2, 'reader_packet', source_doc(p, 2, 'reader_packet', 'Armen Chakmakian'), 'musician, composer, recording artist, and producer')]
    assert p['trace']['prediction'] == 'Hovsep Pushman'
    batch.append(reviewed(p, ['Pushman is a visual artist represented by galleries.', 'Chakmakian is described as a musician/composer.', 'Compare likelihood of works in an art gallery, not an absolute absence claim.'], evidence,
        'positive_gallery_evidence_and_occupation_contrast', 'Reader and final retain explicit gallery representation for Pushman. Second ordinary answer abstains about likelihood, while goal still selects the supported gallery artist.',
        limit='This does not prove Chakmakian has never exhibited art; no universal negative is inferred.'))

    p = packet('hotpotqa', 10)
    evidence = [ev(1, 'reader_packet', source_doc(p, 1, 'reader_packet', 'VisionPLUS'), 'from First Data Corporation'),
                ev(2, 'reader_packet', source_doc(p, 2, 'reader_packet', 'First Data'), 'headquartered in Atlanta, Georgia, United States')]
    assert p['trace']['prediction'] == 'Atlanta, Georgia, United States'
    batch.append(reviewed(p, ['VisionPLUS is from First Data Corporation.', 'First Data headquarters in frozen source are Atlanta, Georgia, United States.'], evidence,
        'historical_company_headquarters_binding_preserved', 'The answer follows the asked company relation and frozen-time HQ statement; no current corporate change is substituted into the old result.'))

    p = packet('hotpotqa', 67)
    evidence = [ev(1, 'reader_packet', source_doc(p, 1, 'reader_packet', 'Palm Springs, Florida'), 'a minor city of the Miami metropolitan area'),
                ev(3, 'reader_packet', source_doc(p, 3, 'reader_packet', 'Palm Beach County, Florida'), 'make up the Miami metropolitan area')]
    assert p['trace']['prediction'] == 'Miami'
    batch.append(reviewed(p, ['Identify Palm Springs in Florida rather than California.', 'Frozen locality material associates it and its county with the Miami metropolitan area.'], evidence,
        'direct_locality_evidence_bypasses_unnecessary_counting_branch', 'The second ordinary question about the three most-populated counties is unresolved and not necessary for the dataset target. Goal/final use the matching Florida locality metropolitan-area fact.',
        limit='Near is not turned into a measured distance; this records the frozen dataset metropolitan-area interpretation.'))

    p = packet('hotpotqa', 177)
    title = next(d['source'] for d in node(p, 3)['reader_packet']['docs'] if d['source'].startswith('Division of Cook (1906'))
    d = source_doc(p, 3, 'reader_packet', title)
    assert 'created in 1906' in d['text'] and 'suburbs of Alexandria' in d['text']
    assert p['trace']['prediction'] == 'Division of Cook'
    batch.append(reviewed(p, ['One electoral division must satisfy both created in 1906 and Alexandria coverage.', 'Historical Cook division meets both constraints.'],
        [ev(3, 'reader_packet', d, 'created in 1906'), ev(3, 'reader_packet', d, 'suburbs of Alexandria, Redfern and Surry Hills')],
        'direct_goal_evidence_recovers_object_missing_from_partial_ordinary_lists', 'Ordinary answers mention Calare and South Sydney separately and do not expose the satisfying shared object. Goal reader includes historical Cook with both properties, and final selects Cook. True partial ordinary answers need not already contain the target object.'))

    p = packet('hotpotqa', 128)
    evidence = [ev(1, 'reader_packet', source_doc(p, 1, 'reader_packet', 'Cinderella (1950 film)'), 'originally released by RKO Radio Pictures'),
                ev(2, 'reader_packet', source_doc(p, 2, 'reader_packet', "The Emperor's New Groove"), 'released by Walt Disney Pictures')]
    assert p['trace']['prediction'] == 'No'
    batch.append(reviewed(p, ['For dataset-target Cinderella 1950, original release is RKO Radio Pictures.', "The Emperor's New Groove release is Walt Disney Pictures."], evidence,
        'dataset_version_specific_release_facts_retained_with_extra_version', 'Actual reader supports the 1950-versus-2000 company difference. Ordinary/goal also mention a 2015 Cinderella; final No matches the frozen 1950 target.',
        limit='Goal changes wording to not all versions; that is not the same logical question as a single disambiguated film comparison. No truth label is changed here.'))

    # Next six as-yet-unreviewed failures in the existing cohort order.
    p = packet('hotpotqa', 6)
    d = source_doc(p, 2, 'reader_packet', 'Province of New Jersey')
    ny = source_doc(p, 2, 'reader_packet', 'Province of New York')
    assert 'proprietary colony' in d['text'] and 'royal colony in 1702' in d['text']
    assert p['trace']['prediction'] == 'Province of New Jersey'
    batch.append(reviewed(p, ['Identify the two border-conflict colonies.', 'Identify one colony with proprietary and later royal status.'],
        [ev(2, 'reader_packet', d, 'proprietary colony'), ev(2, 'reader_packet', d, 'royal colony in 1702'), ev(2, 'reader_packet', ny, 'proprietary colony and later royal colony')],
        'multiple_supported_targets_native_reference_selects_one', 'Actual reader supports proprietary-to-royal status for both New Jersey and New York. The partial ordinary answer narrows goal to New Jersey and final keeps it; reference is New York, producing F1 .75.',
        limit='The original wording supplies no unique distinction between the two satisfying colonies; no categorical final factual error is assigned.'))

    p = packet('hotpotqa', 13)
    d = source_doc(p, 2, 'reader_packet', 'Partners (Barbra Streisand album)')
    assert '47-year-old son, Jason Gould' in d['text'] and 'Emanuel' not in p['trace']['final_context']
    assert p['trace']['prediction'] == 'Jason Gould'
    batch.append(reviewed(p, ['Find Streisand child singing duet on Partners: Jason Gould.'],
        [ev(2, 'reader_packet', d, 'first studio-recorded duet with her now 47-year-old son, Jason Gould')],
        'correct_target_short_name_without_reference_middle_name_in_final_input', 'Reader, ordinary/goal QA and final consistently supply Jason Gould. Reference expects Jason Emanuel Gould, but Emanuel is absent from actual final input; native F1 .8 is retained.'))

    p = packet('hotpotqa', 15)
    d = source_doc(p, 1, 'reader_packet', 'Smurfs: The Lost Village')
    assert 'Rainn Wilson' in d['text'] and 'Rainn Wilson' in node(p, 2)['answer']
    assert 'Rainn Wilson' in p['trace']['final_context'] and p['trace']['prediction'] == 'Rainn Wilson'
    batch.append(reviewed(p, ['Identify an actor in both Smurfs: The Lost Village and The Office; the intersection can contain multiple people.'],
        [ev(1, 'reader_packet', d, 'Demi Lovato, Rainn Wilson'),
         {'route': 'inherited frozen factual review', 'path': 'offline_review_v2/reviews/s001_015.json',
          'detail': 'Existing review records local corpus doc2798502 identifying Rainn Wilson as Dwight in The Office; reused as historical factual corroboration, not a new external lookup.'}],
        'valid_alternative_intersection_member_not_native_reference', 'Ordinary QA transmits Rainn Wilson as member of both casts and final returns it. Frozen reference chooses Ellie Kemper. Flow is preserved; the already-reviewed alternative-answer finding is retained.',
        limit='The Office membership corroboration is inherited from the prior frozen local-corpus check, not newly found in this query reader.'))

    p = packet('hotpotqa', 16)
    d = source_doc(p, 2, 'reader_packet', 'Fall Out Boy')
    assert p['trace']['prediction'] == 'Wilmette, Illinois'
    batch.append(reviewed(p, ['Album Folie à Deux belongs to Fall Out Boy.', 'Band formed in Wilmette, Illinois.'],
        [ev(2, 'reader_packet', d, 'formed in Wilmette, Illinois')],
        'correct_location_with_extra_state_qualifier', 'Goal retrieves the exact band formation location and carries city plus state to final. Reference only says Wilmette; F1 2/3 reflects additional true location qualifier rather than lost city.'))

    p = packet('hotpotqa', 17)
    d1 = source_doc(p, 1, 'reader_packet', 'Vladimir Arnold')
    d2 = source_doc(p, 2, 'reader_packet', 'Georg Cantor')
    assert 'Igorevich' in p['trace']['final_context'] and p['trace']['prediction'] == 'Vladimir Arnold'
    batch.append(reviewed(p, ['Vladimir Arnold died 2010; Georg Cantor died 1918.', 'Choose later death and identify that person.'],
        [ev(1, 'reader_packet', d1, '3 June 2010'), ev(2, 'reader_packet', d2, 'January 6, 1918')],
        'correct_comparison_short_name_despite_full_name_visible', 'Dates are correctly retained and compared. Full source name Vladimir Igorevich Arnold is visible in actual final context, but final follows shorter query/QA name; native reference includes Igorevich, F1 .8.'))

    p = packet('hotpotqa', 20)
    d1 = source_doc(p, 1, 'reader_packet', 'Dan Bejar')
    d2 = source_doc(p, 2, 'reader_packet', 'Makoto Koshinaka')
    assert p['trace']['prediction'] == 'Makoto Koshinaka'
    batch.append(reviewed(p, ['Dan Bejar born 1972, Makoto Koshinaka born 1980.', 'Younger means later birth date, keeping the correct Makoto entity.'],
        [ev(1, 'reader_packet', d1, 'born October 4, 1972'), ev(2, 'reader_packet', d2, 'born July 15, 1980')],
        'correct_entity_and_comparison_reference_contains_extra_date', 'Readers and QA preserve 1972 versus 1980 despite many Makoto distractors, and final correctly identifies Makoto Koshinaka. Reference is Makoto, born July 15, 1980; native F1 .2857 is retained as matching sensitivity.'))

    assert len(batch) == 20 and len({r['id'] for r in batch}) == 20
    old = read(OUT / 'MANUAL_INFORMATION_FLOW_REVIEWS.json')['reviews']
    assert not {r['id'] for r in old} & {r['id'] for r in batch}
    cohort = rows(OUT / 'INFORMATION_FLOW_COHORT.jsonl')
    required_success_ids = {r['id'] for ds in ['2wiki', 'hotpotqa'] for r in [v for v in cohort if v['dataset'] == ds and v['review_selection'] == 'seeded_fullscore_control'][:10]}
    all_reviews = old + batch
    assert {r['id'] for r in all_reviews if r['selection'] == 'seeded_fullscore_control'} == required_success_ids
    ordered_failures = [r['id'] for r in cohort if r['review_selection'] == 'all_nonfullscore' and r['id'] not in {v['id'] for v in old}][:6]
    assert [r['id'] for r in batch if r['selection'] == 'all_nonfullscore'] == ordered_failures
    pending = [r['pending_work_item'] | {'id_of_query': r['id']} for r in all_reviews if r.get('pending_work_item')]
    write(OUT / 'MANUAL_INFORMATION_FLOW_REVIEWS_BATCH002.json', {'utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Next seven seeded fullscore controls per dataset, then next six nonfullscore items in existing cohort order.', 'reviewed_items': 20, 'reviews': batch})
    write(OUT / 'MANUAL_INFORMATION_FLOW_REVIEWS_V2.json', {'utc': datetime.now(timezone.utc).isoformat(), 'status': 'partial_followup', 'material_reviewed_items': 30,
        'completed_for_stated_checks': 29, 'pending_work_items': 1, 'reviews': all_reviews,
        'limits': 'Original binary fact labels and official endpoints unchanged. These are one-Codex stated-scope material checks, not independent gold labels or exhaustive attribution.'})
    write(OUT / 'INFORMATION_FLOW_PENDING_WORK_ITEMS.json', {'items': pending, 'not_a_third_correctness_label': True, 'frozen_labels_changed': False})
    index = rows(OUT / 'REVIEW_INDEX.jsonl')
    by_id = {r['id']: r for r in all_reviews}
    for row in index:
        if row['id'] in by_id:
            row['followup_review_status'] = by_id[row['id']]['review_status']
            row['review_file'] = 'MANUAL_INFORMATION_FLOW_REVIEWS_V2.json#' + row['id']
            pp = ROOT / row['packet']; pp_data = read(pp)
            pp_data['followup_review_status'] = row['followup_review_status']
            pp_data['followup_review_file'] = row['review_file']
            write(pp, pp_data)
    jsonl(OUT / 'REVIEW_INDEX.jsonl', index)
    historical = {r['id'] for r in read(OLD / 'ROOT_CAUSE_CASES.json')['cases']}
    complete = sum(r['review_status'] == 'completed_for_stated_information_flow_checks' for r in all_reviews)
    progress = read(OUT / 'REVIEW_PROGRESS.json')
    progress.update(material_reviewed_items=30, followup_semantic_reviews_completed=complete,
        pending_fact_or_interpretation_work_items=len(pending), pending_followup_reviews=len(index) - complete,
        not_yet_started_items=len(index) - len(all_reviews),
        reviewed_selections=dict(Counter(r['selection'] for r in all_reviews)),
        historical_36_newly_followup_checked=sum(r['id'] in historical for r in all_reviews),
        historical_36_pending_followup=len(historical - set(by_id)), first_fullscore_controls_per_dataset=10,
        note='30 packets materially reviewed in queue order: 29 completed for stated checks, 1 interpretation work item; 248 not yet started. Prior first batch retained. Do not infer full-cohort prevalence.')
    write(OUT / 'REVIEW_PROGRESS_V2.json', progress)
    write(OUT / 'REVIEW_PROGRESS.json', progress)
    assert read(OUT / 'HISTORICAL_INPUT_HASHES.json') == inventory(OLD)
    v = read(OUT / 'VALIDATION.json')
    v.update(material_reviewed_items=30, manual_review_rows=30, stated_checks_completed=complete,
        pending_interpretation_work_items=len(pending), seeded_fullscore_reviewed_per_dataset=10,
        fixed90_completed_variants=7, packet_review_statuses_consistent=True)
    write(OUT / 'VALIDATION.json', v)
    lines = ['# 信息流后续诊断：当前进展v2', '',
        '本次只读既有轨迹、冻结材料及分数，写独立新目录。API/新检索/GPU/RAG重跑均为0；原64个诊断文件哈希未变，原事实标签、分数与主评计划均未改。', '',
        '- 阶段0：7个已完成fixed90变体及A/B真实对照已汇总，包含最后完成的minimal4与compact v2；使用最终完成目录，详见FIXED90_DIVERGENCE.md/json。three-prompts v1有1条已计分算法失败，无完整轨迹，因此轨迹分母89。',
        '- 统计修订：新副本仅补HP236 goal实际绑定step1；HotpotQA绑定补充表160/179→161/180。39张表未变，两个数据集四类主表逐字段不变。见DIAGNOSTIC_V3_TABLE_DIFF.json。',
        '- 审阅准备：230条非满分+每集20条seed固定满分=270条主队列；8条历史满分案例另列，共278包。',
        '- 已亲读30包：固定成功对照每集前10条共20包，另10条非满分；29条完成明确列出的信息流检查，1条解释边界待核；248包尚未开始。原36例中本轮已扩展复核数量见REVIEW_PROGRESS_V2.json，其余保留历史发现但不算新完成。', '',
        '首批保存于MANUAL_INFORMATION_FLOW_REVIEWS.json；后续20条追加于BATCH002，合并视图为MANUAL_INFORMATION_FLOW_REVIEWS_V2.json。审阅只覆盖每条声明的信息需求，不代表所有附带事实均再次核验。', '',
        '已确认的位置包括：HP46所存候选没覆盖桥接对象、HP7命中后裁掉、HP236正确字段进入final却误选。成功对照HP130/67/177说明：合理弃答、冗余问题或不完整中间列表不一定阻断答案，goal/原路证据可以另行取得目标信息；不能只按事实标签或单一路径排序组件。', '',
        '新非满分队列中，HP13 Jason Gould少中间名且Emanuel未进final；HP17全名已可见但输出短名；HP16附加州名；HP20参考混入出生日期；HP6/15涉及多个可满足对象。这些为具体匹配/多解案例，分数均保留，不推广为所有部分F1都只是格式。HP98的目标时间也已保留到final。', '',
        '待核2Wiki317：British-born American与American在from-the-same-country问句中的比较标准不唯一，原gold取British。保留既有满分与事实标签，不强行给新语义结论；该待核属于工作项，不新增真假第三标签。', '',
        '当前结果为单一Codex审阅者的部分信息流诊断；文字变化不是错误率，观察路径不是组件修复的因果收益。', '']
    (OUT / 'README.md').write_text('\n'.join(lines), encoding='utf-8')
    print({'appended': len(batch), 'material_reviewed': 30, 'completed': complete, 'pending_work_items': len(pending), 'not_started': 248, 'old_inputs_unchanged': True})


if __name__ == '__main__':
    main()
