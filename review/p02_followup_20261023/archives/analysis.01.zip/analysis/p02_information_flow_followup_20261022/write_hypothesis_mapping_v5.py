"""Write hypotheses and review progress only; do not implement or run pilots."""
from build_offline import OUT, read, write


def main():
    reviews = read(OUT/'MANUAL_INFORMATION_FLOW_REVIEWS_V5.json')['reviews']
    keys = {(r['dataset'],r['review_index']):r for r in reviews}

    def cases(*pairs):
        return [{'dataset':ds,'review_index':idx,'id':keys[ds,idx]['id'],
                 'review':'MANUAL_INFORMATION_FLOW_REVIEWS_V5.json#'+keys[ds,idx]['id']} for ds,idx in pairs]

    mapping = [
        {'hypothesis_id':'H_GOAL_OPERATOR_AND_RELATION', 'contrast_family':'goal synthesis',
         'hypothesis':'Preserving operands while explicitly executing the requested relation/operator can reduce wrong comparison, exclusivity substitution and answer-to-the-bridge instead of answer-to-the-target.',
         'evidence_cases':cases(('hotpotqa',21),('2wiki',296),('hotpotqa',86)),
         'distinct_failures':['HP21 has correct78/67 but wrong longer comparison.','Wiki296 has shared Bolivia but changes condition to exclusive country-set equality.','HP86 rewritten reader already supplies God of Israel, but goal repeats Jehovah inventor relation.'],
         'freeze':['ordinary QA','goal original and rewritten candidates and actual reader packet','question','generation options and output limit','final rendering/protocol'],
         'change_only':'The approved goal synthesis treatment, with relation/operator information retained; exact wording belongs to the separately frozen pilot protocol.',
         'what_to_measure':['Paired native F1/EM and improved/harmed/tied','Whether the specific requested relation/operator is preserved','Whether target information remains available to final','Complete-flow tokens/estimated expense under approved accounting'],
         'limits':['This does not show generic prompt expansion works.','Inputs are already sufficient for HP21/86 at goal, but Wiki296 factual labels remain unchanged; diagnostic utility is separate from fact truth.','No new prompt or experiment is implemented by this mapping.']},
        {'hypothesis_id':'H_GOAL_CORRECTS_BAD_PRIOR', 'contrast_family':'goal synthesis',
         'hypothesis':'A goal reader that explicitly confronts prior role claims with matching current evidence may avoid retaining false extra candidates.',
         'evidence_cases':cases(('hotpotqa',31),('hotpotqa',27),('2wiki',273)),
         'freeze':['ordinary answers including their errors','goal reader packet','all entity/source identities','final protocol'],
         'change_only':'Approved goal synthesis handling of role-specific evidence and retained prior answers.',
         'what_to_measure':['Retention/removal of false extra roles without removing true ones','Whether fact correction reaches final','Paired overall native results, not only chosen error cases'],
         'limits':['HP31 goal packet directly says Wills shortstop, so there is corrective evidence.','HP27 current packet can correct developer identity but may still lack Verifone HQ.','Wiki273 correct William IV is supplied but first-spouse father is absent; do not force abstention on every unsupported but factually correct answer under the user-approved truth rule.']},
        {'hypothesis_id':'H_GOAL_REWRITE_FACT_GAIN_VS_BINDING', 'contrast_family':'goal rewrite retrieval',
         'hypothesis':'Goal rewritten retrieval has both new-fact benefits and wrong-binding costs; turning it off measures their net effect under the actual merge rule.',
         'evidence_cases':cases(('hotpotqa',236),('hotpotqa',86),('hotpotqa',26),('hotpotqa',27),('hotpotqa',93)),
         'freeze':['all ordinary stages and answers','original goal query and its Top10','saved rewrite text','reader limit10 and merge implementation','generation protocol and final rendering'],
         'change_only':'Whether the already recorded goal rewritten route participates in the goal reader; use the approved protocol for any necessary downstream generations.',
         'what_to_measure':['Useful facts gained or lost (HP236 seat count; HP86 referent)','Wrong-entity routing and downstream answer changes','Paired F1/EM improvements and harms across the whole fixed cohort','Actual retained reader documents, not rewrite correctness alone'],
         'limits':['This is rewritten-route augmentation plus current merge, not an isolated estimate of text rewriting quality.','HP26 GregHertz and HP93 Bigelow never enter saved candidates; no evidence proves simply disabling goal rewrite will solve them.','No new retrieval/API is authorized or executed by this file.']},
        {'hypothesis_id':'H_FINAL_FACT_VISIBILITY', 'contrast_family':'final visibility',
         'hypothesis':'Some useful reader facts are absent from saved QA/helper; preserving selected facts rather than only conclusions could help final, but addition must be isolated from changing all evidence.',
         'evidence_cases':cases(('2wiki',248),('hotpotqa',86),('hotpotqa',31),('hotpotqa',182),('hotpotqa',236)),
         'freeze':['ordinary and goal outputs','original-query Top10','final prompt and generation protocol','source candidate documents'],
         'change_only':'The exact final-visible material contrast frozen for the approved pilot; distinguish removal of whole goal QA from controlled fact/conclusion separation.',
         'what_to_measure':['Which necessary facts actually enter final prompt','Whether changed visibility improves or harms fixed queries','Token/context size differences and preserved provenance'],
         'limits':['Removing whole goal QA also removes unique seat-count facts in HP236; it is an overall marginal effect, not pure de-biasing.','HP182 narrow actor answer drops unasked Prada attribute but goal successfully reads it again; omission is not always harmful.','Human selecting necessary facts using gold is an oracle diagnostic and must not be presented as a deployable method.','Any evidence addition changes context volume; keep its budget explicit and do not silently substitute union20.']},
        {'hypothesis_id':'H_FINAL_ATTRIBUTE_AND_SCOPE', 'contrast_family':'final visibility',
         'hypothesis':'When needed facts are already visible, selecting the asked attribute/scope rather than adding documents may address the observed error.',
         'evidence_cases':cases(('hotpotqa',236),('2wiki',288),('hotpotqa',23),('hotpotqa',49),('hotpotqa',52)),
         'freeze':['all saved final inputs','original question','generation protocol'],
         'change_only':'If separately approved, a final readout treatment; do not mix it into a pure goal-visibility contrast without stating the extra factor.',
         'what_to_measure':['seated versus total capacity','birthplace versus nationality','city versus neighborhood','target portrait versus bridge person','relationship phrase versus whole copied QA'],
         'limits':['HP236 andWiki288 already contain the correct field in final helper.','Shortening every answer is not justified: some references are shorter, some require full names, and some are wrong homonyms.','This remains an interpretation of cases, not a prediction of net overall gain.']},
        {'hypothesis_id':'H_EVIDENCE_SELECTION_BOUNDARY', 'contrast_family':'separate evidence-selection follow-up, not implemented',
         'hypothesis':'Useful complementary candidates can be dropped by original-first interleaving; compare selection over the same candidate union and fixed reader budget before assuming more documents helps.',
         'evidence_cases':cases(('hotpotqa',7),('hotpotqa',26)),
         'freeze':['both candidate route lists and document texts','retrieval output budget','reader limit10','generation prompt/options'],
         'change_only':'A separately reviewed evidence-selection policy over the same candidates.',
         'what_to_measure':['Retention of necessary complementary facts','Diversity and competing/distracting documents','Paired final outcomes and cost'],
         'limits':['HP7 has all needed actors/year in one pruned document.','HP26 losing Polson is only one gap; representative evidence is still absent.','No blanketTop20 conclusion; prior union20 development comparison did not establish a benefit.']},
        {'hypothesis_id':'H_REFERENCE_AND_UNRESOLVED_GUARD', 'contrast_family':'interpretation across all contrasts',
         'hypothesis':'Native score gains can reward alias shortening or even wrong reference identities; retain factual and reference interpretation alongside unchanged official metrics.',
         'evidence_cases':cases(('2wiki',274),('hotpotqa',83),('hotpotqa',53),('hotpotqa',28),('2wiki',319),('2wiki',254)),
         'freeze':['native F1/EM and original answers','stage truth labels','pending work items'],
         'change_only':'No method change; report evidence-supported endpoint limitations and leave unresolved facts unforced.',
         'what_to_measure':['Known name/role mismatches and valid alternate descriptions','True failures with partialF1, not assuming all partial matches are formatting','Pending factual/interpretation status separately'],
         'limits':['Country/source ambiguity or birthplace conflict is not solved by matching a reference string.','Do not silently rescore or drop problematic queries to improve reported treatment results.','The current ordered failure-prefix review is not a random prevalence sample.']}
    ]
    write(OUT/'REPAIR_HYPOTHESIS_EXPERIMENT_MAPPING_V5.json',{'status':'hypotheses_only_no_implementation_or_new_evaluation','review_scope':'110materially reviewed queries, one Codex reviewer, including40seeded fullscore and70ordered/initial nonfullscore; no population causal claim',
        'requires_alignment_to_separately_approved_frozen_pilot_protocol':True,'mappings':mapping})
    text=['# 信息流诊断V5：新增40条及受控对照假设', '',
          '当前视图：MANUAL_INFORMATION_FLOW_REVIEWS_V5.json、REVIEW_INDEX_V5.jsonl、REVIEW_PROGRESS_V5.json。V4及更早文件均保持原字节，旧版本指针另存。BATCH005固定沿各集递增队列取20条，不按答案或F1挑选。', '',
          '累计亲读110包：固定成功40，非满分70（Wiki30、HP40）；107条完成声明的信息范围检查，3条待核。尚未开始168包，其中160条为非满分，另8条为主队列之外的历史成功案例。原36案例本轮复核覆盖数见进展JSON。', '',
          '三项清楚的新边界：Wiki288正确goal包含Indian-born/NewZealand却final取India；Wiki296正确地理事实共享Bolivia，goal却擅加exclusively条件再输出No；HP86改写及goal reader已经给Jehovah→GodofIsrael，goal却复述发明词语，未把所问指称关系传到final。这三类应分别针对final字段选择、goal运算条件、goal关系综合。', '',
          '信息不足也有具体区分：Wiki292没有第二部电影来源；Wiki312/314读到正确人物却没有出生/安葬关系，不能拿统治地或住地代替；Wiki329漏读已可见Mozart音乐引用且下游仍缺死亡地；Wiki347缺第二部影片制作人列表，不能用演员名单或有限gold三元组补真实总数。HP45/84/93把描述绑定到Sheol/oak/WoodsHole，目标材料从未命中；仅改goal/final不等于已证明能修好。', '',
          '同时，HP47普通阶段弃答后原题goal直接找到Brea；HP92普通错误Greenland分支被goal原路Russia最大country纠正。HP83正确论文正式名与BFH简称、HP53正确centre却参考附带国籍职业、HP28仅答所问州却参考附带城市等仍造成未满分；不能把所有非满分都当事实错误，也不能反过来把所有部分F1都当格式。', '',
          '待核：保留Wiki317/254，再纳入原本已获准待核的Wiki319（Galanta与Pressburg出生地冲突）。继承领地/头衔不能证明出生地，旧goal None与原0分均不改。本轮没有新联网。', '',
          '修复假设已映射到接下来的goal综合、goal改写检索、final可见性对照，详见REPAIR_HYPOTHESIS_EXPERIMENT_MAPPING_V5.json。文件只列假设、应冻结项、应观察的受益/损害和混杂因素，没有实现方法改动或启动新评估。尤其：关闭改写同时改变补充材料及merge；删整条goal同时删独有事实；人工按gold挑必要证据只能称oracle诊断。', '',
          '剩余失败固定顺序见REMAINING_NONFULLSCORE_QUEUE_V5.jsonl。当前失败样本是有序前缀/最初案例，成功是按集抽样，覆盖与数据集混合仍不同，不估总体率、不做组件因果排名。API、检索、GPU为0；旧事实标签、原生F1/EM与评估主方案不变。', '']
    (OUT/'README_V5.md').write_text('\n'.join(text),encoding='utf-8')
    print({'hypotheses':len(mapping),'implemented':False,'new_API_requests':0})


if __name__=='__main__':main()
