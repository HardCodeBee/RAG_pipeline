"""Manual next frozen 40-case review; input quotes anchor locations only."""
from datetime import datetime, timezone
from hashlib import sha256
from build_offline import OUT, OLD, read, write
from first_manual_review import packet, entry
from complete_success_controls import evidence


def main():
    batch=[]
    def add(ds,idx,required,category,detail,quotes=(),sufficient=True,use=True,limit=None):
        p=packet(ds,idx)
        f={'location':'actual child QA question, reader, QA, goal and final alignment',
           'category':category,'confirmed':True,'detail':detail}
        if limit:f['limit']=limit
        r=entry(p,required,[f],[evidence(p,*q) for q in quotes],sufficient,use)
        r['actual_qa_input_checks']=[]
        for n in p['trace']['nodes']:
            prompt=n['child_prompt'];actual=prompt.split('Actual task:\n')[-1]
            current=actual.split('Current subquestion #'+str(n['step_id'])+':\n')[-1].split('\n\nRetrieved passages:')[0]
            assert current==n['request']
            r['actual_qa_input_checks'].append({'step_id':n['step_id'],'current_subquestion':current,
                'retrieval_rewrite_separate':n['rewritten_query'],'child_prompt_sha256':sha256(prompt.encode()).hexdigest()})
        batch.append(r)
        return p,r
    def frozen(r,idx):
        r['evidence'].append({'route':'prior frozen fact check; no new network',
          'path':'offline_review_v2/WEB_FACT_CHECKS.json#'+str(idx),
          'verified_fact':next(c['verified_fact'] for c in read(OLD/'WEB_FACT_CHECKS.json')['checks'] if c['review_index']==idx)})

    add('2wiki',423,['Director RichardAttenborough.','Education RADA; distinguish actual reader support from accepted factual answer.'],
        'correct_school_with_extra_alias_city_despite_reader_education_gap',
        'Ordinary identifies correct director. Goal reader instead contains other Richards, Kubrick and DavidAttenborough; no examined paragraph establishes Richard RADA education. Goal still supplies accepted native school plus RADA/London and final preserves it. Nonfull score reflects extra alias/city, but this is not claimed as retrieved education proof.',
        [(1,'Oh! What a Lovely War','directed by Richard Attenborough')],
        limit='Correct factual label retained under user rule; knowledge supplied by goal is distinct from evidence actually read.')
    add('2wiki',426,['Padmavati spouse Ashoka.','Indian descriptor and MauryaDynasty historical state/dynasty are distinct target forms.'],
        'source_indian_descriptor_vs_native_historical_dynasty',
        'Actual Ashoka biography calls him Indian emperor ofMauryaDynasty. First QA preserves both, goal/final chooseIndia. Native reference isMauryaDynasty. No spouse identity loss; nationality/origin versus historical dynasty target distinction explains disagreement without changing factual labels.',
        [(1,'Padmavati (wife of Ashoka)','queen of the Mauryan Emperor, Ashoka'),(2,'Ashoka','Indian emperor of the Maurya Dynasty')],
        limit='No modern legal citizenship is imposed on ancientIndia; native reference unchanged.')
    add('2wiki',427,['Father ValentineMott.','Columbia professorship and NewYork medicalcollege founding employment.'],
        'multiple_supported_employers_historical_school_name_vs_native_parent',
        'Actual biography gives Columbia professorship and later founding faculty of universitymedicalcollegeNY nowNYUSchoolMedicine. Goal preserves this history, final lists both historical institutions. Reference selects onlyNYU. This is not fabricated extra employment or wrong father.',
        [(1,'Thaddeus P. Mott','son of the eminent surgeon Valentine Mott'),(2,'Valentine Mott','professor of surgery in Columbia College'),(2,'Valentine Mott','now New York University School of Medicine')])
    add('2wiki',432,['Father CharlesI Bourbon not otherMargarets.','Death ChateauMoulins, not daughters PontDAin.'],
        'correct_death_building_qualifier_reference_city',
        'Actual father biography dated death gives ChateauMoulins; goal/final preserve that building name. Native referenceMoulins is broader. Daughter deathPontDAin and CharlesII Lyon are not transferred.',
        [(1,'Margaret of Bourbon (1438–1483)','daughter of Charles I'),(2,'Charles I, Duke of Bourbon','4 December 1456, Château de Moulins')])
    add('2wiki',433,['FiveEasyPieces American.','ParkIsMine CanadianAmerican.','SharedUS is present despite native selectingCanadian only.'],
        'shared_country_answer_supported_by_multicountry_source_native_omits_origin',
        'Both actual film paragraphs and ordinary answers reach goal. Goal correctly uses commonUS and finalYes, while nativeNo derives from triplesAmerican versusCanadian only. Unlike362/376, this goal executes intersection correctly; zero native match is not evidence that this intersection reasoning failed.',
        [(1,'Five Easy Pieces','1970 American drama film'),(2,'The Park Is Mine (1986 film)','Canadian- American drama television film')])
    add('2wiki',438,['Performer EasonChan.','HongKong descriptor in source versus nativeChina citizenship.'],
        'regional_origin_descriptor_vs_native_country_citizenship',
        'Song and biography identify EasonChan asHongKong singer. Goal preservesHongKong and finalHongKonger; nativeChina uses country citizenship field. Existing accepted regional descriptor truth stays; no mistaken JackieChan is selected.',
        [(1,'Life Marathon (Eason Chan)','sung by Eason Chan'),(2,'Eason Chan','Hong Kong singer and actor')],
        limit='Regional self-description and sovereign citizenship target are different granularity, not interchangeable strings; no new citizenship fact is asserted.')
    add('2wiki',440,['Director AxelvonAmbesser.','Need death location, notHamburg birth or Munich theater employment.'],
        'correct_director_biography_missing_deathplace_native_workplace_token',
        'Actual director biography gives death date but no death place, thenHamburg birth and several theater jobs includingMunchnerKammerspiele. Goal/final abstain. NativeMunchner token occurs as employment adjective; occurrence alone does not establish death location.',
        [(1,'Marry Me, Cherie','directed by Axel von Ambesser'),(2,'Axel von Ambesser','the Münchner Kammerspiele')],sufficient=False,use=None)
    p,r=add('2wiki',456,['Father FriedrichWilhelm correctgeneration.','Death17Feb1831; sourceKarl paragraph instead states27Feb.'],
        'incorrect_date_explicit_in_read_source_propagated_source_conflict',
        'Actual sonKarl paragraph explicitly says father died27Feb1831. Goal/final reproduce27, while native17 and existing frozen factcheck identify27 as local source error. Retrieved alternateWilhelmFriedrich is1891–1965 namesake, not correct father. This error is source-supported misinformation, not a date invented without any passage.',
        [(1,'Karl, Duke of Schleswig-Holstein-Sonderburg-Glücksburg',"father's death on 27 February 1831")],sufficient=False,use=False)
    frozen(r,456)
    add('2wiki',460,['University founder ManuelAntin.','BirthLasPalmas Chaco withcountry.'],
        'correct_birth_city_province_with_extra_country',
        'Founder and biography provide correctLasPalmasChaco birth; goal/final retain province andArgentina. Native dropsProvince/Argentina, producing partial match.',
        [(1,'Fundación Universidad del Cine','founded in 1991 by Manuel Antin'),(2,'Manuel Antín','was born in Las Palmas, Chaco Province')])
    p,r=add('2wiki',463,['Director PauloFigueiredo is filmmaker, not same-name1972Angolan footballer.','Film-country cue alone would not prove director nationality.'],
        'correct_director_answer_native_reference_joins_footballer_homonym',
        'Actual goal reader pairsBrazilian film with anAngolan footballer biography of same name. Goal/finalBrazil is accepted by frozen prior filmmaker checks: directorbornSaoPaulo1940 versus footballer1972. NativeAngolan follows wrong person. Preserve truth; do not newly claim film origin itself proves director origin.',
        [(1,'E a Vida Continua...','Brazilian drama film directed by Paulo Figueiredo'),(2,'Paulo Figueiredo','Angolan retired footballer')])
    frozen(r,463)
    add('2wiki',468,['Father JeanII dEstrees.','BirthSolothurnSwitzerland, not deathParis.'],
        'correct_birth_city_plus_country',
        'Actual father biography explicitly gives1624SolothurnSwitzerland birth and1707Paris death. Goal/final preserve correctbirth city pluscountry. Native onlySolothurn.',
        [(1,"Jean II d'Estrées",'3 November 1624 in Solothurn, Switzerland')])
    add('2wiki',474,['Director MarcelVarnel.','DeathnearRake WestSussex.'],
        'correct_death_locality_plus_native_region',
        'Actual biography explicitly gives carcrashnearRakeWestSussex. Goal/final retain locality/near qualifier; native onlyWestSussex.',
        [(1,'This Man Is Mine (1946 film)','directed by Marcel Varnel'),(2,'Marcel Varnel','car crash near Rake, West Sussex')])
    add('2wiki',475,['Performer TimBuckley not livingcoverartist.','Heroinoverdose cause.'],
        'correct_specific_overdose_substance_reference_generic',
        'Song identifiesTimBuckley and biography directly states heroinoverdose. Goal/final retain substance, native generic overdose; no mixing withJeffBuckley death observed.',
        [(2,'Tim Buckley','from a heroin overdose')])
    add('2wiki',481,['DirectorLasseAberg.','Konstfack graphicdesign education; study versus degree graduation distinction.'],
        'school_department_qualifier_with_study_graduation_entailment_limit',
        'Actual biography says studiedKonstfack departmentgraphicdesign1960–64. Goal calls thisgraduated, final returnsdepartment. NativeKonstfack matches institution but not qualifier. Existing true label preserved; study paragraph establishes attendance, not independently graduation qualification.',
        [(1,'The Stig-Helmer Story','directed by Lasse Åberg'),(2,'Lasse Åberg','studied at the Konstfack department of graphic design')],
        limit='No new graduation truth judgment is made from attendance alone.')
    add('2wiki',488,['Shrimati420 composerOPNayyar notShree420 composer.','FilmfareBestMusicDirector1958 award.'],
        'correct_detailed_award_year_category_reference_award_family',
        'Actual biography explicitly gives1958FilmfareBestMusicDirector forNayaDaur. Goal/final preserveyear/category, native onlyFilmfareAward. Similar420 titles do not derail correctcomposer.',
        [(1,'Shrimati 420','music was composed by O. P. Nayyar'),(2,'O. P. Nayyar','1958 Filmfare Award for Best Music Director')])
    add('2wiki',497,['DirectorShaadAli.','SchoolattendanceWelham andLawrenceSanawar.'],
        'multiple_supported_schools_single_school_reference',
        'Actual biography explicitly says studiedWelhamBoys andLawrenceSanawar; goalpreservesstudied wording, final returnsboth. Native picksLawrence only. Additionaltrue schooling is not forcedfalse or excluded.',
        [(1,'Jhoom Barabar Jhoom','directed and co-produced by Shaad Ali'),(2,'Shaad Ali',"Welham Boys' School and the Lawrence School, Sanawar")])
    add('2wiki',500,['TargetFatherAndBoys differs fromFatherAndSons2003.','JoeDeGrasse director birthplace nativeNewBrunswick, notBoujenah path.'],
        'film_title_variant_misidentification_propagates_director_birthplace',
        'First actual QA receivesFatherAndBoys but readsFatherAndSons2003 and answersMichelBoujenah. Goal retrieval bindsBoujenah and returnsTunisia; actualgoalcurrentquestion remainsoriginaltarget. This is not merely correctanswer to an actuallyreplacedQAquestion: it fails originalfilm constraint and priorfilm identity remains wrong.',
        [(1,'Father and Sons','2003 French- Canadian comedy film directed by Michel Boujenah'),(2,'Michel Boujenah','French- Tunisian')],sufficient=False,use=False)
    add('2wiki',501,['CorrectdirectorJerzySkolimowski.','BirthcityLodz, not filmSchool location alone.'],
        'coarse_birth_country_without_explicit_birth_city_relation',
        'Actual biography identifiesPolish director andLodz filmSchool graduation; it does not tieLodz tobirth. Goal/finalgive accepted broaderPoland; nativecityLodz not established byschool location. Preserve oldtruecountry fact and flagmissingfinerrelation rather than gold-token extractionfailure.',
        [(1,'King, Queen, Knave (film)','directed by Jerzy Skolimowski'),(2,'Jerzy Skolimowski','National Film School in Łódź')],sufficient=False,use=None)
    add('2wiki',503,['SpouseBMSuhara.','BirthThikkodi nearCalicut.'],
        'correct_birth_locality_extra_nearby_city_qualifier',
        'Actual spouse biography explicitly saysbornThikkodinearCalicut. Goal/final preservequalifier; nativeonlyThikkodi.',
        [(1,'M. M. Basheer','B. M. Suhara is his wife'),(2,'B. M. Suhara','born in Thikkodi near Calicut')])
    p,r=add('2wiki',506,['EmpressLiuE spouseLiuCong.','LiuCong fatherLiuYuan; LiuYin isEmpress ownfather, notfatherinlaw.'],
        'ordinary_reader_correct_father_relation_replaced_by_wifes_father_then_lost',
        'Step2 actualreader LiuCong explicitly says hisfatherLiuYuan. QAinsteadtakesLiuYin fromEmpress ownfather relationship and calls himLiuCongfather. GoalrewriteWhoisLiuYin furtherretrieves unrelatedSouthernHanLiuYin, andgoal/finalretainwrongfatherinlaw. CorrectLiuYuan relation is not retained in finalhelper/context.',
        [(2,'Liu Cong (Han Zhao)',"his father Liu Yuan's reign"),(1,'Empress Liu E',"Liu E was the daughter of")],sufficient=False,use=False)
    assert 'Liu Yuan' not in p['trace']['final_context']

    p,r=add('hotpotqa',137,['HeikkiSeppa trainedGeorgJensenfactory.','FounderGeorgArthurJensen fullidentifyingname.'],
        'correct_founder_common_name_full_name_lost_before_final',
        'Goalreader explicitly givesGeorgArthurJensen founder. Goal compresses toGeorgJensen, andfinalsame; fullmiddle name notpresent in finalcontext. NativeGeorgArthurJensen partialmatch. Thefactory-founder relation iscorrect; finername detail is lost atQA/helperboundary.',
        [(1,'Heikki Seppa','Georg Jensen silver factory'),(2,'Georg Jensen','Georg Arthur Jensen'),(2,'Georg Jensen','founder of Georg Jensen A/S')])
    assert 'Georg Arthur Jensen' not in p['trace']['final_context']
    add('hotpotqa',140,['DistinguishBharatpur1805 failedstorming from1825–26 captureunderCombermere.','Original asks onepersonwithbothcareercommands, notseparateofficesforcedsimultaneously.'],
        'siege_version_and_temporal_scope_binding_wrong_despite_visible_alternate',
        'Ordinaryquestions imposeCommanderIreland/India duringSiege; answersanchor1805GerardLake. Actualreaderalsoexplicitlycontains1825–26Combermere fortressstormed/captured, whereas1805paragraphsaysfourtimesrepulsed. Goalretains1805Lake andfinalselectsLake, missingintendedsuccessfulsiegeversion. Correcteventalternativeisread, thoughfullCombermerecareerbothcommandsisnotestablishedbytheseexaminedpassages.',
        [(2,'Siege of Bharatpur (1805)','four times repulsed'),(2,'Siege of Bharatpur','British troops under Lord Combermere')],sufficient=False,use=False,
        limit='Avoidtreating allLordCombermere career facts asalreadyread, or everyfailedstormingattemptasnoattempt; observederrorisfrozenquestionintendedversion/scope.')
    add('hotpotqa',141,['Bothfilms horror; matchedVoice2005Koreanversion atgoal.','UnqualifiedVoice ordinary canrefertoTurkish2010title.'],
        'ambiguous_title_alternative_goal_corrects_version_plural_metric',
        'Ordinary2readsexplicitTurkish2010horror andanswersaccordingly, existingtruealternative labelretained. GoalreaderretrievesVoice2005SouthKoreanhorror andgoal/finalusebothKoreanfilms. Native singularfilmversuspluralfilms producesnonfullscore; ordinaryambiguitydidnotstopgoalrecovery.',
        [(2,'The Voice (2010 film)','2010 Turkish horror film'),(3,'Voice (film)','2005 South Korean horror film')])
    p,r=add('hotpotqa',143,['BigJohnStudd correctringname.','NeedDisneyappearanceDoubleAgent1987, notgenericDisneyfilmwithBig title.'],
        'unsupported_actor_film_join_with_missing_actual_cast_relation',
        'OrdinaryidentifiesBigJohnStuddcorrectly. GoalreaderBigRed1962onlystatesDisneyfilmstarringWalterPidgeon, notStuddappearance; goaladdsStuddcastclaimandfinalBigRed. Priorfrozencastcheckrejectedthisappearance. DistinguishrealDisneyfilmfrommissingactor-to-filmrelation.',
        [(1,'Big John Studd','John William Minton'),(2,'Big Red (film)','film starred Walter Pidgeon')],sufficient=False,use=False)
    frozen(r,143)
    add('hotpotqa',145,['BassistSeanYseult.','SpouseChrisLee fromSupagroup; TommyLee differentmusician; nativeanswerbassistitselfalso problematic.'],
        'correct_bassist_wrong_spouse_binding_and_native_bridge_answer_issue',
        'ActualSeanreaderidentifiesbassistbutnospouse. GoalreaderTommyLeemarriagesspecifyotherwomen; nothinglinksSean. Goal/finalclaimTommyLee, whilefrozendatasetSupagrouptext identifiesChrisLeemarriedSean. NativeSeanYseultreturnsbridgebassist, so nativezero andactualwrongspouse mustbeseparateobservations.',
        [(1,'Sean Yseult','plays bass in the band Star & Dagger'),(2,'Tommy Lee','married to model Elaine Starchuk')],sufficient=False,use=False)
    add('hotpotqa',147,['FilmRogueOne.','RachelleBeinart role stuntperformer.'],
        'goal_reader_confirms_bridge_and_stunt_role_morphological_reference',
        'FirstreaderdoesnotestablishspecificRogueOnebutacceptedQA suppliesit. GoalactualreaderRachellebioexplicitlystatesstuntperformancesforRogueOne, confirmingfilm-role relation. Goal/finalstuntperformer versusreferencestuntperformances isgrammaticalrolewording, notwrongjob.',
        [(2,'Rachelle Beinart','done stunt performances for films including "Rogue One"')])
    add('hotpotqa',149,['FrankTalk pseudonymownedbySteveBiko.','PublishedtitleIWriteWhatILike.','Magazinewithsamename doesnotexclude pseudonymusage.'],
        'same_name_magazine_type_replaces_pseudonym_and_universal_absence',
        'ActualreaderFrankTalkdescribesapoliticalmagazine. Ordinaryturnsthatinto notapersonpseudonym, andrewritechangesownerofpseudonymtoownerofmagazine. Goalassertsnosuchowner/title; finalabstains. ExaminedreaderslackSteveBikopseudonymandbookrelations. Onehomonymdocumentdoesnotproveglobalnonexistence.',
        [(2,'Frank Talk','political magazine established in 1984')],sufficient=False,use=None)
    add('hotpotqa',150,['RedBendCollegeinForbes.','OriginalpopulationconstraintdifferentfromCowra10063; correctcollegecanrecovercity.'],
        'goal_corrects_wrong_population_city_via_direct_college_evidence',
        'OrdinaryreturnsCowradespiteexplicit10063not7560; rewritebindsCowra. Actualgoalcurrentquestionretainsoriginalcollegeconstraint, andactualRedBendparagraphgivesForbesplus800students. GoalcorrectsForbesandfinalcity; nativeaddsfullregionaldescription. Population7560comesfromoriginalquestion/frozenreference, notfromexaminedcollegeparagraph.',
        [(1,'Cowra','population of 10,063'),(2,'Red Bend Catholic College','located in Forbes'),(2,'Red Bend Catholic College','approximately 800 students')])
    p,r=add('hotpotqa',152,['FiersSharksandAstros.', 'FiersBrewers affiliation.','Actualordinary3asksAstrosplayers, notallthreeintersection.'],
        'goal_recovers_complete_affiliation_after_nonresponsive_added_filter',
        'Ordinary2truepartialBrewerslistomitsFiersandordinary3imposesunaskedallthreefilter/absence. ActualgoalreadergivesFiersBrewersandAstros; Sharksparagraphprovidescollegeaffiliation. Goal/finalcorrectMikeFiers. FullMichaelBruceFiersremainsinfinalcontextbutfinalusescommonnameagainstfullnamereference.',
        [(1,'Nova Southeastern Sharks baseball','Mike Fiers of the Houston Astros'),(4,'Mike Fiers','Michael Bruce Fiers'),(4,'Mike Fiers','also played in MLB for the Milwaukee Brewers')])
    assert 'Michael Bruce Fiers' in p['trace']['final_context']
    add('hotpotqa',155,['AuthorELJames.','EnglishdescriptorandBritishdescriptorbothinsource.'],
        'source_supported_british_vs_english_national_descriptor',
        'NovelpassagecallsELJamesBritish; personalbiographycallsEnglish. Goal/finalBritishconsistentwithfirstsourceandacceptedtruth, nativeEnglishdoesnotmatchtokens. Noauthoridentityorcountryfabrication.',
        [(1,'Fifty Shades Freed','British author E. L. James'),(2,'E. L. James','English author')])
    add('hotpotqa',158,['LakeLouisvillaOldhamrelation.', 'Population60316needsOldhamcountybiography; neighborhoodrelationalone notallconstraints.'],
        'county_candidate_visible_population_constraint_unestablished',
        'Ordinary2andactualgoalreaderidentifyOldhamamongneighborhoodlocations, butpopulationbranchandgoalreadersneverestablish60316. GoaldropspopulationfromretrievalrewriteyetactualQAquestionstillrequiresit; goal/finaldecline. Do notdeclareOldhamtokenalonecompleteevidence.',
        [(2,'Lake Louisvilla, Louisville','KY 22 in Oldham County')],sufficient=False,use=None)
    add('hotpotqa',159,['TreasureIslanddevelopedbyWynn.', 'Pirate-themepropertyrequiresadditionalrelationship.'],
        'known_developer_candidate_missing_theme_relation',
        'Ordinary2andgoalactualWynnbioincludeTreasureIslandamongdevelopments, but noexaminedreaderestablishespitratetheme. PolynesianthemebelongsMirage, notinterchangeable. Goal/finaldeclineinsteadselectinganyWynnresort; needthemefactratherthanmerelyrecovercandidate name.',
        [(2,'Steve Wynn','The Mirage, Treasure Island, the Bellagio'),(1,'The Mirage','Polynesian-themed')],sufficient=False,use=None)
    add('hotpotqa',167,['FirstJesuitpopeFrancis.','Bishopresignedbecauseage, notBenedicthealthdetails.'],
        'correct_resignation_reason_extra_citing_verb',
        'ActualbishopparagraphdirectlystatesresignedtoFranciscitinghisage. Goal/finalpreservereason; nativeonlyhisage. NocrosspersonreasontransferfromBenedictresignationdocument.',
        [(1,'Pope Francis','first Jesuit pope'),(2,'Gustavo Rodolfo Mendoza Hernández','resigned to Pope Francis citing his age')])
    add('hotpotqa',176,['Filmreleased14June2011mustbeidentified, nativeConArtist.', 'ThenCanadianactorDonaldSutherland; manyCanadianactorsaloneareinsufficient.'],
        'release_date_to_film_bridge_missing_with_native_truncated_actor_name',
        'ActualreaderscoverCanadianfilms2011andseveralactorsbutnot14Junerelease-to-ConArtistrelation. Goal/finalreasonablydecline. FrozenreferenceConArtistexplicitdateandDonaldSutherlandisoutsideexaminedreader; nativeDonaldMcNicholomitsSutherland,aseparateendpointnamingissue, notthereasonmethodabstained.',
        [(1,'List of Canadian films of 2011','films which were released in 2011')],sufficient=False,use=None)
    add('hotpotqa',180,['BothStoneandCapoteAmerican.', 'CommondescriptorAmericanratherthanCapoteonlynonfictionwork.'],
        'correct_shared_nationality_with_profession_noun_extra',
        'ActualbiographiesandQAcarryAmericanforboth. Goal/finalAmericanNovelistsretainscorrectsharedattribute; nativeonlyAmerican. AdditionalCapotenonfictionnoteingoaldoesnotcorruptfinalintersection.',
        [(1,'Robert Stone (novelist)','American novelist'),(2,'Truman Capote','American novelist')])
    add('hotpotqa',181,['53-yearrulerDeiocesidentityconstraint.', 'CyaxaresgrandsonofDeioces; relationdirectionmatters.', 'HTML-corruptednativeanswercannotbeassumedcleansemanticgold.'],
        'ruler_duration_bridge_missing_plus_corrupted_relation_reference',
        'GoalreaderCyaxaresparagraphexplicitlysayshisgrandfatherDeioces, butnoexaminedreaderestablishesDeiocesgoverned53years. Goal/finaldeclineunknown53-yearman. Native rgrandfather<a hr includesbrokenHTMLanddirectionambiguity; do notturnitsstringintoaresolvedrelationgoldorclaimallnecessaryfactswereavailable.',
        [(2,'Cyaxares','grandfather <a href="Deioces">Deioces</a>')],sufficient=False,use=None)
    add('hotpotqa',186,['BothFranaandKoch tennisplayers.', 'Formerqualifierretainedfrombothactualbios.'],
        'correct_shared_occupation_extra_former_qualifier',
        'Bothactualbiossayformertennisplayer; goal/finalpreservethatsharedqualifier. Nativeonlytennisplayer. FranaseparatecommentatorjobnotincorrectlysharedwithKoch.',
        [(1,'Javier Frana','former tennis player'),(2,'Thomaz Koch','former tennis player')])
    p,r=add('hotpotqa',187,['ArmySalvationArmy.', 'ReligiouscategoryProtestantChristianistargetratherthanarmybridge.'],
        'final_returns_bridge_organization_despite_goal_target_category_visible',
        'GoaleretrievalrewritewronglyfillsunknownsectslotwithknownSalvationArmy, butactualgoalQAquestionstillaskssect. ReaderexplicitlyProtestantChristianandgoalcorrectlypreservescategory. FinalreturnsSalvationArmy, notrequestedcategory, despiteProtestantChristianinhelper. Thisisfinaltargetselectionerror, notmissingsectfact.',
        [(1,'Erik Wickberg','General of The Salvation Army'),(2,'The Salvation Army','Protestant Christian movement')],use=False)
    assert 'Protestant Christian' in p['trace']['final_context']
    add('hotpotqa',189,['FindingKraftlanddocumentary, notfrozendrink.', 'Shikashikashavedicedrink.','BothdrinkbooleanNo versusnativeoneentitydescription.'],
        'goal_ignores_new_film_evidence_final_corrects_boolean_native_scope_mismatch',
        'Ordinary1firstreader lacksFindingKraftland andlegitimatelyabstains. Goalreaderthenexplicitlyretrievesdocumentaryidentity, butgoalretainsuncertainty, alreadyFalseunderoldlabels. Finaloriginalcontextalsocontainsdocumentary andreturnsNo, correctbooleanresponseunderactualevidence. NativeShikashikaisashavedicedrinkisnotayesnocomparisonanswer.',
        [(2,'Shikashika','shaved ice drink'),(3,'Finding Kraftland','independent documentary')])
    add('hotpotqa',190,['DOCsecondalbumHelterSkelter.', 'Mansonscenario/songbridge.', 'McCartneyattemptloudanddirtysound.'],
        'goal_reader_supports_full_chain_despite_answer_leaking_retrieval_rewrite',
        'Goalretrievalrewriteinsertsunprovidedloudchaoticsound, anunfaithfulanswerleak; actualQAquestionstillasksoriginalsound. Actualalbumandsongreadersthenexplicitlyprovideallbridgefactsandloudanddirtyphrase. Goal/finalcorrectphrase, nativeomitssoundnoun. Unfaithfulrewriteisnotautomaticallyfinalfactualfailure.',
        [(3,'Helter Skelter (album)','second studio album by The D.O.C.'),(3,'Helter Skelter (song)','a sound as loud and dirty as possible')])

    assignment=read(OUT/'ASSIGNMENT_BATCH007.json')['items']
    assert len(batch)==40 and [r['id'] for r in batch]==[r['id'] for r in assignment]
    assert all(r['original_source_sha256']==a['source_sha256'] for r,a in zip(batch,assignment))
    assert not (OUT/'MANUAL_INFORMATION_FLOW_REVIEWS_BATCH007.json').exists()
    write(OUT/'MANUAL_INFORMATION_FLOW_REVIEWS_BATCH007.json',{
       'utc':datetime.now(timezone.utc).isoformat(),'batch':'007','selection':'ASSIGNMENT_BATCH007.json frozen40',
       'status':'completed_for_declared_case_scopes','material_reviewed':40,'reviewer':'current Codex single reviewer, not independent human gold',
       'API_requests':0,'new_retrieval':0,'GPU':False,'reviews':batch})
    print({'batch':'007','material_reviewed':len(batch),'actual_QA_prompt_checks':sum(len(r['actual_qa_input_checks']) for r in batch)})


if __name__=='__main__':main()
