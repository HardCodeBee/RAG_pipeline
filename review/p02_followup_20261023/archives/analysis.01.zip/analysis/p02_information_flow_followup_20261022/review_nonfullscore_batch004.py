"""Append first ten unreviewed failures per dataset in fixed review-index order."""
from collections import Counter
from datetime import datetime, timezone
from build_offline import ROOT, OUT, OLD, read, rows, write, jsonl, inventory, sha
from first_manual_review import packet, node, entry
from extend_manual_review import reviewed
from complete_success_controls import evidence


def main():
    before = inventory(OUT)
    prior = read(OUT / 'MANUAL_INFORMATION_FLOW_REVIEWS_V3.json')['reviews']
    batch = []
    p = packet('2wiki', 240)
    anne = next(d['source'] for d in node(p, 2)['reader_packet']['docs'] if d['source'].startswith('Anne de Laval (1385'))
    es = [evidence(p, 1, 'André de Laval-Montmorency', 'maternal grandmother, Jeanne de Laval'),
          evidence(p, 2, anne, 'Tinténiac')]
    assert 'Tinténiac' in p['trace']['final_context']
    batch.append(reviewed(p, ['Andre mother is Anne de Laval.', 'Maternal grandmother is the Jeanne de Laval associated with Anne, fully identified as Laval-Tinténiac.'], es,
        'correct_kinship_referent_shortened_identifier_visible', 'Reader supports the two-generation relation and contains the fuller Jeanne name. Ordinary/goal and final use Jeanne de Laval; reference contains Tinténiac. Final context still contains the fuller identifier, so this is not missing candidate evidence.',
        limit='The checked identity follows the specific family relation, not merely the matching name string among unrelated Jeanne distractors.'))

    p = packet('2wiki', 246)
    movie = next(d['source'] for d in node(p, 1)['reader_packet']['docs'] if 'Snowroller' in d['source'])
    es = [evidence(p, 1, movie, 'Lasse Åberg and Peter Hald'),
          evidence(p, 2, 'Lasse Åberg', 'studied at the Konstfack department of graphic design')]
    batch.append(reviewed(p, ['Film has Lasse Åberg and Peter Hald as directors.', 'Lasse education institution is Konstfack, graphic-design department.'], es,
        'specific_supported_institution_description_native_reference_shorter', 'Goal keeps the supported Konstfack department and explicitly lacks information for Peter Hald. Final returns institution plus department; native reference contains only Konstfack, F1 .5.',
        limit='The literal source says studied between 1960 and 1964. This review verifies institution identity, not a separately documented graduation event.'))

    p = packet('2wiki', 248)
    es = [evidence(p, 3, 'Claude Chabrol', '12 September 2010'),
          evidence(p, 4, 'Alexandre Tsutsunava', '25 October 1955')]
    assert p['existing_labels_and_native_score_unchanged']['ordinary_answers_all_correct'] is False
    assert 'cannot be determined' in node(p, 4)['answer'] and '1955' not in p['trace']['final_context']
    batch.append(entry(p, ['Bind both films to Chabrol and Tsutsunava.', 'Chabrol death 2010 versus Tsutsunava death 1955; choose earlier.'],
        [{'location': 'step4 reader to ordinary answer', 'category': 'required_date_visible_but_answer_abstains_and_omits_it', 'confirmed': True,
          'detail': 'The correct named-director reader includes 25 October 1955 (with malformed missing birth date); frozen dataset confirms it as death date. Step4 says no date and fails to carry it forward. Old ordinary-answer label already marks an error.'},
         {'location': 'goal/final visibility', 'category': 'upstream_reader_fact_not_available_at_final', 'confirmed': True,
          'detail': 'Goal reader and original-query final evidence lack 1955; history only supplies the earlier abstention. Goal/final inability to compare is locally consistent with their inputs, not proof that the final reader ignored visible 1955.'}], es, False, None))

    p = packet('2wiki', 254)
    es = [evidence(p, 2, 'Richard Óg de Burgh, 2nd Earl of Ulster', 'powerful Irish nobles'),
          evidence(p, 2, 'Richard Óg de Burgh', 'Anglo- Irish noble and soldier')]
    r = reviewed(p, ['Bind John died1313 to Richard Og second Earl of Ulster.', 'Distinguish nationality/descriptor for that Earl from another same-name early13th-century Richard.'], es,
        'nationality_descriptor_and_same_name_source_ambiguity', 'Reader contains target Earl described as Irish and another same-name Richard described as Anglo-Irish. Goal/final return Anglo-Irish, native reference Irish gives F1 zero. The old goal factual label is retained as True.', final_ok=None,
        limit='The saved output does not reveal whether a valid target descriptor or the other Richard supplied Anglo-Irish. Do not call this pure formatting or definitely wrong-entity transfer.')
    r['review_status'] = 'pending_work_item_after_material_review'
    r['pending_work_item'] = {'id': 'WIKI254_ANGLO_IRISH_DESCRIPTOR_SOURCE',
        'question': 'Separate valid target Anglo-Irish descriptor from possible transfer from the other same-name Richard; local saved material does not decide the generation source.',
        'changes_binary_truth_label': False, 'needs_network_now': False,
        'reason': 'Mechanism/descriptor ambiguity; truth label is not overwritten and generation provenance is not inferable from text alone.'}
    batch.append(r)

    p = packet('2wiki', 258)
    es = [evidence(p, 1, 'Sibylla of Burgundy, Duchess of Burgundy', 'daughter of William I, Count of Burgundy'),
          evidence(p, 2, 'William I, Count of Burgundy', 'died in Besançon, Prince-Archbishopric of Besançon, Holy Roman Empire')]
    batch.append(reviewed(p, ['Select specified Sibylla, whose father is William I.', 'His death place is Besancon with historical jurisdiction qualifiers.'], es,
        'correct_death_place_with_additional_historical_jurisdiction', 'Goal reader obtains the correct father death-place relation; goal/final preserve city plus historical jurisdictions. Native reference is only Besancon, F1 .25. No evidence loss or wrong death/burial substitution is observed.'))

    p = packet('2wiki', 260)
    title = next(d['source'] for d in node(p, 2)['reader_packet']['docs'] if d['source'].startswith("Maddalena de' Medici (1473"))
    es = [evidence(p, 1, 'Lorenzo Cybo', "Maddalena de' Medici"), evidence(p, 2, title, "buried in St. Peter's Basilica")]
    batch.append(reviewed(p, ['Mother is specified Maddalena de Medici.', 'Her burial place is St Peters Basilica in Rome.'], es,
        'correct_burial_place_plus_city_qualifier', 'Actual mother biography distinguishes died in Rome from buried in St Peters Basilica. Goal/final retain the basilica and add Rome; native reference omits city, F1 .75.'))

    p = packet('2wiki', 264)
    es = [evidence(p, 1, 'Charles Skeffington Clements', 'Nathaniel Clements, 2nd Earl of Leitrim'),
          evidence(p, 2, 'Nathaniel Clements, 2nd Earl of Leitrim', 'private school in Portarlington and Oriel College, Oxford')]
    batch.append(reviewed(p, ['Bind father Nathaniel second Earl.', 'Education locations include private school Portarlington and Oriel College Oxford.'], es,
        'multiple_supported_education_locations_reference_single_institution', 'Reader and goal preserve both actual education locations. Final lists them, whereas reference selects only Oriel College; native F1 .5455 is retained. Additional source-supported school is not marked false.'))

    p = packet('2wiki', 270)
    es = [evidence(p, 1, 'On the Trail of Igor Rizzi', 'directed by Noël Mitrani'), evidence(p, 2, 'Noël Mitrani', 'French film director')]
    batch.append(reviewed(p, ['Film director is Noel Mitrani.', 'Source describes Canadian-born French director; separate birthplace qualifier and French descriptor.'], es,
        'birthplace_qualifier_added_to_supported_nationality', 'Goal/final preserve the source Canadian-born French phrase; native reference contains only French, F1 2/3. This is distinguished from a comparison that misuses Canadian as a different nationality.'))

    p = packet('2wiki', 273)
    christine = next(d['source'] for d in node(p, 2)['reader_packet']['docs'] if d['source'].startswith('Christine of Hesse-Kassel (1578'))
    es = [evidence(p, 2, christine, 'William IV, Landgrave of Hesse-Kassel')]
    old_fact = next(c for c in read(OLD / 'WEB_FACT_CHECKS.json')['checks'] if c['review_index'] == 273)
    assert old_fact['correct'] is False
    es.append({'route': 'prior frozen targeted fact check, no new network lookup', 'path': 'offline_review_v2/WEB_FACT_CHECKS.json#273', 'verified_fact': old_fact['verified_fact']})
    assert p['existing_labels_and_native_score_unchanged']['goal_answer_correct'] is False
    batch.append(entry(p, ['John Ernest has two recorded spouses; father role must remain linked to each.', 'Christine father William IV is supported; Elisabeth father must not be invented as Christoph.'],
        [{'location': 'ordinary step2 to goal/final', 'category': 'true_parent_fact_combined_with_wrong_extra_parent', 'confirmed': True,
          'detail': 'William IV is in the actual Christine reader. Step2 also adds Christoph for first spouse; saved prior fact check established John/Johann, not Christoph. Goal and final retain both. Nonzero F1 here includes a real false assertion, not only answer verbosity.'}], es, True, False))

    p = packet('2wiki', 274)
    es = [evidence(p, 1, 'De Dannan', 'Frankie Gavin (fiddle)'), evidence(p, 2, 'Frankie Gavin (boxer)', 'British professional boxer')]
    old_fact = next(c for c in read(OLD / 'WEB_FACT_CHECKS.json')['checks'] if c['review_index'] == 274)
    assert old_fact['correct'] is True
    es.append({'route': 'prior frozen fact check, no new network', 'path': 'offline_review_v2/WEB_FACT_CHECKS.json#274', 'verified_fact': old_fact['verified_fact']})
    batch.append(reviewed(p, ['Use De Dannan fiddler Frankie Gavin, not same-name boxer.', 'Musician Irish descriptor is the retained correct target fact; reference British comes from boxer.'], es,
        'reference_homonym_role_mismatch_despite_correct_pipeline_target', 'Reader includes an unrelated British boxer, but goal/final retain Irish for the fiddler. Frozen targeted check confirms musician identity/nationality. Native F1 zero is kept; changing output to British would learn the wrong person.'))

    p = packet('hotpotqa', 21)
    es = [evidence(p, 1, 'Owen Wister', 'July 14, 1860'), evidence(p, 2, 'Owen Wister', 'July 21, 1938'),
          evidence(p, 3, 'Lucy Maud Montgomery', 'November 30, 1874'), evidence(p, 4, 'Lucy Maud Montgomery', 'April 24, 1942')]
    assert '78 years' in node(p, 5)['answer'] and '67 years' in node(p, 5)['answer']
    batch.append(entry(p, ['Compare lifespan durations, not latest calendar death.', 'Owen lived about78 years; Lucy about67.'],
        [{'location': 'goal comparison', 'category': 'correct_operands_wrong_lifespan_comparison', 'confirmed': True, 'detail': 'Four dates are correctly read and transmitted. Goal itself states78 and67 but calls67 longer.'},
         {'location': 'final', 'category': 'wrong_goal_conclusion_retained_despite_visible_correct_operands', 'confirmed': True, 'detail': 'Final input has the correct dates and erroneous goal conclusion; final chooses Lucy. This is misuse of available facts, not candidate evidence absence.'}], es, True, False))

    p = packet('hotpotqa', 23)
    es = [evidence(p, 1, 'Big Stone Gap (film)', 'directed by Adriana Trigiani'),
          evidence(p, 2, 'Adriana Trigiani', 'based in Greenwich Village, New York City')]
    assert 'New York City' in p['trace']['final_context'] and p['trace']['prediction'] == 'Greenwich Village'
    batch.append(entry(p, ['Identify director Adriana Trigiani.', 'Asked city is New York City; Greenwich Village is its more specific neighbourhood in source location.'],
        [{'location': 'goal to final', 'category': 'visible_city_component_dropped_from_location', 'confirmed': True, 'detail': 'Goal explicitly preserves Greenwich Village, New York City; final selects only Greenwich Village despite the question asking city. Reference contains both; this is target-granularity omission as well as partial matching, not a wholly wrong location.'}], es, True, False))

    p = packet('hotpotqa', 26)
    ron = evidence(p, 1, 'Ronan, Montana', 'lies on the Flathead Indian Reservation')
    polson = next(d for d in node(p, 2)['original_retrieval']['docs'] if d['source'] == 'Polson, Montana')
    assert polson['rank'] == 10 and polson['doc_id'] not in {d['doc_id'] for d in node(p, 2)['reader_packet']['docs']}
    assert all(d['source'] != 'Greg Hertz' for n in p['trace']['nodes'] for route in ['original_retrieval', 'rewritten_retrieval'] for d in (n.get(route) or {}).get('docs', []))
    batch.append(entry(p, ['Need a reservation city and its representative relation.', 'Ronan is a true city candidate; reference path uses Polson and Greg Hertz.'],
        [{'location': 'partial city answer and later rewrite', 'category': 'true_city_candidate_narrows_search_without_representative_relation', 'confirmed': True, 'detail': 'Ordinary Ronan answer is true. Later rewrite asks who represents Ronan and retrieves politicians named Ronan from unrelated jurisdictions; representative relation is not established.'},
         {'location': 'step2 original candidates to reader', 'category': 'alternative_bridge_candidate_dropped', 'confirmed': True, 'detail': 'Polson city paragraph is present at original rank10 but is dropped in merged reader.'},
         {'location': 'saved candidate coverage', 'category': 'representative_evidence_not_retrieved', 'confirmed': True, 'detail': 'Greg Hertz representation paragraph never enters saved candidate routes. Keeping Polson alone is not shown to solve the question; missing representative relation and candidate pruning coexist.'}],
        [ron, {'step_id': 2, 'route': 'original_retrieval', 'doc_id': polson['doc_id'], 'source': polson['source'], 'rank': polson['rank'], 'verified_quote': polson['text']}], False, None))

    p = packet('hotpotqa', 27)
    es = [evidence(p, 1, 'Speedpass', 'introduced in 1997 by Mobil Oil Corp.'), evidence(p, 1, 'Speedpass', 'originally developed by Verifone')]
    assert 'Mobil' in node(p, 2)['rewritten_query'] and 'Verifone' in p['trace']['final_context']
    batch.append(entry(p, ['Created/developed Speedpass company is Verifone, not introducer Mobil.', 'Bind headquarters query to that developer, whose reference headquarters are San Jose California.'],
        [{'location': 'ordinary company-role extraction', 'category': 'visible_developer_introducer_role_confused', 'confirmed': True, 'detail': 'The actual first reader distinguishes developer Verifone and introducer Mobil in adjacent sentences, but answer selects Mobil.'},
         {'location': 'rewrite to goal/final', 'category': 'wrong_role_entity_binding_propagates', 'confirmed': True, 'detail': 'Goal rewrite asks Mobil headquarters and final returns Fairfax. The original Speedpass paragraph still visible in final can correct company identity, but the correct company headquarters evidence is not among original final docs.'}], es, False, False))

    p = packet('hotpotqa', 28)
    es = [evidence(p, 2, 'Micro Instrumentation and Telemetry Systems', 'founded in Albuquerque, New Mexico')]
    batch.append(reviewed(p, ['MITS founded in Albuquerque, New Mexico.', 'Question specifically asks state, so New Mexico is sufficient.'], es,
        'correct_requested_state_reference_includes_city', 'Goal states both city and state; final correctly returns requested state New Mexico. Native reference also includes Albuquerque, resulting F1 .8. City deletion is appropriate to the asked attribute, unlike HP23 which asked a city.'))

    p = packet('hotpotqa', 29)
    es = [evidence(p, 1, 'William Bainbridge', 'presidents beginning with John Adams'), evidence(p, 2, 'John Adams', 'his wife and closest advisor Abigail')]
    batch.append(reviewed(p, ['Frozen text links Bainbridge early naval service to President John Adams.', 'Adams wife is Abigail.'], es,
        'correct_spouse_full_name_reference_shorter', 'Ordinary answers preserve president identity and goal supplies Abigail Adams; final returns full identifying surname whereas reference says Abigail, producing F1 2/3.',
        limit='This checks the dataset naval-career interpretation; it does not newly research every possible definition of the start of his career.'))

    p = packet('hotpotqa', 31)
    es = [evidence(p, 1, 'Race for the Pennant', 'Bob Gibson, Maury Wills'),
          evidence(p, 2, 'Maury Wills', 'as a shortstop and switch-hitter'),
          evidence(p, 3, 'Bob Gibson', 'retired American baseball pitcher')]
    assert 'Maury Wills' in node(p, 2)['answer'] and p['existing_labels_and_native_score_unchanged']['ordinary_answers_all_correct'] is False
    batch.append(entry(p, ['Choose a show host who satisfies pitcher role.', 'Bob/Robert Gibson is a pitcher; Maury Wills is a shortstop, not a valid extra pitcher.'],
        [{'location': 'ordinary role filtering', 'category': 'visible_role_evidence_not_used_to_filter_candidate', 'confirmed': True, 'detail': 'Step2 reader explicitly says Wills shortstop, but answer includes him as pitcher.'},
         {'location': 'goal', 'category': 'wrong_extra_candidate_preserved_despite_contradicting_biography', 'confirmed': True, 'detail': 'Goal reader again has Wills shortstop and correct Bob Gibson pitcher; its rewrite weakens to names of Bob or Maury. Goal/final still return both. Partial F1 includes a real false extra candidate plus Bob/Robert naming difference.'}], es, None, False))

    p = packet('hotpotqa', 32)
    es = [evidence(p, 1, "These Boots Are Made for Walkin'", 'written by Lee Hazlewood')]
    assert 'cannot be determined' in node(p, 2)['answer'] and 'died in 2007' in node(p, 3)['answer']
    assert all(d['source'] != 'Lee Hazlewood' for n in p['trace']['nodes'] for d in n['reader_packet']['docs'])
    batch.append(reviewed(p, ['Song writer is Lee Hazlewood.', 'Additional death2007 condition is true in frozen dataset; broad independent2007 query fails to bind person.'], es,
        'goal_adds_verified_condition_without_direct_reader_biography_then_short_name_match', 'Step2 retrieves generic monthly death-list introductions and reasonably abstains. Goal states correct death2007 condition despite no Lee biography in its reader; final returns Lee Hazlewood. Reference expects Barton Lee Hazlewood, F1 .8.',
        limit='The new condition is verified against frozen reference, but its generation source is not observable; do not claim that goal retrieved the missing biography.'))

    p = packet('hotpotqa', 34)
    es = [evidence(p, 1, 'Moby Dick—Rehearsed', 'Joan Plowright'), evidence(p, 2, 'Joan Plowright', 'won two Golden Globe Awards')]
    batch.append(reviewed(p, ['Identify actress Joan Plowright.', 'Asked Golden Globe count is two, excluding other award types.'], es,
        'correct_requested_count_reference_repeats_award_unit', 'Actual reader and goal explicitly identify two Golden Globes, distinct from one Tony and nominations. Final Two answers how many; reference repeats award name, native F1 .4.'))

    p = packet('hotpotqa', 37)
    es = [evidence(p, 1, 'Jesse Williams (actor)', 'Rev. James Lawson'), evidence(p, 2, 'Jackson Avery', 'season six, episode 5')]
    batch.append(reviewed(p, ['Bind Butler Rev Lawson to Jesse Williams and Grey Anatomy role Jackson Avery.', 'Debut is season6 episode5, titled Invasion, not promotion to regular in season7.'], es,
        'correct_debut_episode_reference_additional_title', 'Reader distinguishes introduction in season6 episode5 from later regular status. Goal retains episode title Invasion; final uses season/episode identification without title. Reference includes title, F1 .8889; no wrong debut season is observed.'))

    assert len(batch) == 20 and len({r['id'] for r in batch}) == 20
    cohort = rows(OUT / 'INFORMATION_FLOW_COHORT.jsonl')
    done = {r['id'] for r in prior}
    expected = [r['id'] for ds in ['2wiki', 'hotpotqa'] for r in sorted([q for q in cohort if q['dataset'] == ds and q['review_selection'] == 'all_nonfullscore' and q['id'] not in done], key=lambda q: q['review_index'])[:10]]
    assert [r['id'] for r in batch] == expected
    all_reviews = prior + batch
    completed = sum(r['review_status'] == 'completed_for_stated_information_flow_checks' for r in all_reviews)
    pending = [r['pending_work_item'] | {'query_id': r['id']} for r in all_reviews if r.get('pending_work_item')]
    assert len(all_reviews) == 70 and completed == 68 and len(pending) == 2
    assert not (OUT / 'MANUAL_INFORMATION_FLOW_REVIEWS_V4.json').exists()
    write(OUT / 'MANUAL_INFORMATION_FLOW_REVIEWS_BATCH004.json', {'utc': datetime.now(timezone.utc).isoformat(), 'selection': 'First10 not-yet-reviewed nonfullscore per dataset, increasing original review_index. No answer/F1-based choice.', 'reviewed_items': 20, 'reviews': batch})
    write(OUT / 'MANUAL_INFORMATION_FLOW_REVIEWS_V4.json', {'utc': datetime.now(timezone.utc).isoformat(), 'status': 'partial_nonfullscore_review_in_progress', 'material_reviewed_items': 70, 'completed_stated_checks': completed, 'pending_work_items': len(pending), 'reviews': all_reviews,
        'limits': 'Existing binary labels and native endpoints unchanged. Declared-scope material review by one Codex reviewer, not exhaustive factual gold or causal attribution.'})
    write(OUT / 'INFORMATION_FLOW_PENDING_WORK_ITEMS_V4.json', {'not_a_third_correctness_label': True, 'frozen_labels_changed': False, 'items': pending})
    index = rows(OUT / 'REVIEW_INDEX_V3.jsonl');by = {r['id']: r for r in all_reviews}
    for row in index:
        if row['id'] in by:
            row['followup_review_status'] = by[row['id']]['review_status']
            row['review_file'] = 'MANUAL_INFORMATION_FLOW_REVIEWS_V4.json#' + row['id']
    jsonl(OUT / 'REVIEW_INDEX_V4.jsonl', index)
    queue = [q for ds in ['2wiki', 'hotpotqa'] for q in sorted([r for r in cohort if r['dataset'] == ds and r['review_selection'] == 'all_nonfullscore' and r['id'] not in by], key=lambda r: r['review_index'])]
    assert len(queue) == 200
    jsonl(OUT / 'REMAINING_NONFULLSCORE_QUEUE_V4.jsonl', [{'id': q['id'], 'dataset': q['dataset'], 'review_index': q['review_index'], 'review_order': i + 1} for i, q in enumerate(queue)])
    historical = {r['id'] for r in read(OLD / 'ROOT_CAUSE_CASES.json')['cases']}
    progress = read(OUT / 'REVIEW_PROGRESS_V3.json')
    progress.update(material_reviewed_items=70, followup_semantic_reviews_completed=completed, pending_fact_or_interpretation_work_items=len(pending),
        pending_followup_reviews=278 - completed, not_yet_started_items=208, reviewed_selections={'seeded_fullscore_control': 40, 'all_nonfullscore': 30},
        reviewed_nonfullscore_per_dataset={'2wiki': 10, 'hotpotqa': 20}, remaining_nonfullscore=200,
        historical_36_newly_followup_checked=len(historical & set(by)), historical_36_pending_followup=len(historical - set(by)),
        note='V4 overlay is current; V3 and earlier files unchanged. 40 success controls plus30 failures materially reviewed, 68 completed declared scope,2 work items. Remaining failures maintain ascending review_index within dataset. No population prevalence inferred.')
    write(OUT / 'REVIEW_PROGRESS_V4.json', progress)
    groups = {}
    for selection in ['seeded_fullscore_control', 'all_nonfullscore']:
        rr = [r for r in all_reviews if r['selection'] == selection]
        groups[selection] = {'materially_reviewed': len(rr), 'dataset_counts': dict(Counter(r['dataset'] for r in rr)),
            'completed': sum(r['review_status'] == 'completed_for_stated_information_flow_checks' for r in rr),
            'pending': sum(r['review_status'] == 'pending_work_item_after_material_review' for r in rr),
            'final_information_for_stated_scope': dict(Counter(str(r['final_has_sufficient_information_for_target']) for r in rr)),
            'final_use_for_stated_scope': dict(Counter(str(r['final_uses_target_information_correctly']) for r in rr)),
            'nonexclusive_categories': dict(Counter(f['category'] for r in rr for f in r['findings']))}
    write(OUT / 'REVIEWED_SUCCESS40_NONFULLSCORE30_DESCRIPTIVE.json', {'scope': 'Reviewed packets only; success sample seeded per dataset, failure review consists of initial cases plus ordered prefixes, not random failure sample.', 'population_prevalence_or_causal_effect_claims': False, 'groups': groups,
        'failure_dataset_mix_still_unequal': True, 'warning': '30 reviewed failures are 10Wiki/20HP, and partial F1 has both real content errors and matching/reference differences. No single-cause or global percentage is assigned.'})
    assert read(OUT / 'HISTORICAL_INPUT_HASHES.json') == inventory(OLD)
    old_pointer = OUT / 'CURRENT_REVIEW_VERSION.json'
    pointer_bytes = old_pointer.read_bytes()
    (OUT / 'CURRENT_REVIEW_VERSION_V3.json').write_bytes(pointer_bytes)
    assert all(sha(ROOT / name) == value for name, value in before.items())
    write(OUT / 'VALIDATION_V4.json', {'utc': datetime.now(timezone.utc).isoformat(), 'old_diagnostic_64_files_unchanged': True, 'prior_followup_files_unchanged_before_pointer_update': len(before),
        'V3_pointer_preserved_as': 'CURRENT_REVIEW_VERSION_V3.json', 'materially_reviewed': 70, 'completed': 68, 'pending_work_items': 2,
        'new_batch_failure_per_dataset': 10, 'fixed_success_controls_per_dataset': 20,
        'new_API_requests': 0, 'new_retrieval_searches': 0, 'new_GPU_work': False, 'original_truth_labels_or_native_scores_changed': False})
    text = ['# 信息流诊断进展V4：新增各集10条非满分', '',
        '当前视图：MANUAL_INFORMATION_FLOW_REVIEWS_V4.json、REVIEW_INDEX_V4.jsonl、REVIEW_PROGRESS_V4.json。先前V3各文件保留原字节；版本指针旧内容另存CURRENT_REVIEW_VERSION_V3.json。', '',
        '本批按各数据集review_index递增固定取最前10条未审非满分，不按答案或F1选取。累计亲读70包：满分40、非满分30（Wiki10/HP20），68条完成声明范围检查、2条待核；208包未开始，其中200条为剩余非满分。下一轮顺序见REMAINING_NONFULLSCORE_QUEUE_V4.jsonl。', '',
        '已有材料新确认的失效位置：', '',
        '- Wiki248：1955日期已经进入普通step4 reader，却在弃答中没有传递；goal/final没有该日期。旧普通标签已判错误，最终不能据此归因为忽略可见日期。',
        '- HP26：Ronan是真城市，但后续搜索落入同名政治家；Polson虽在原路候选第10被裁，Greg Hertz代表关系仍未命中。缺代表关系和桥接候选裁剪并存，保留Polson不等于已证明能修好。',
        '- HP27：Speedpass同一段落明确区分developer Verifone与introducer Mobil，普通回答混淆角色，改写与goal传播；final仍有原始关系句，却没有正确总部关系材料。',
        '- HP21：正确生卒日期与78/67年龄均可见，goal反向比较，final沿用。HP31则把实际reader中的shortstop Maury Wills误当pitcher并带到final。这两条部分/零分都不是单纯匹配问题。',
        '- HP23：goal含Greenwich Village, New York City，final却只取社区名，缺了所问城市。与HP28按问题只返回州New Mexico、参考却含城市的情况分开。', '',
        '其它记录分别标识合法附加粒度、名称限定符、参考混入额外字段和参考同名实体。Wiki274的British参考来自同名拳击手；管道返回Irish对应小提琴手，沿用原冻结事实核验，不重跑网页。Wiki273既包含正确William IV，也额外带入已被旧事实核查证伪的Christoph，不能把其部分F1当纯格式损失。', '',
        '待核维持Wiki317，并新增Wiki254：正确Earl的Irish与另一个同名Richard的Anglo-Irish同时在reader，无法只凭输出确定合法描述还是属性串接；保留原goal True与原分数，不强行给新结论。', '',
        '只审本条声明的信息范围，多路径、合理弃答、真实不完整列表旧标签不变。30条失败的覆盖仍少且不是随机样本，描述性对照不代表总体发生率或组件因果收益。API、检索、GPU均为0。', '']
    (OUT / 'README_V4.md').write_text('\n'.join(text), encoding='utf-8')
    write(old_pointer, {'version': 4, 'readme': 'README_V4.md', 'reviews': 'MANUAL_INFORMATION_FLOW_REVIEWS_V4.json', 'index': 'REVIEW_INDEX_V4.jsonl', 'progress': 'REVIEW_PROGRESS_V4.json',
        'descriptive_comparison': 'REVIEWED_SUCCESS40_NONFULLSCORE30_DESCRIPTIVE.json', 'remaining_failures': 'REMAINING_NONFULLSCORE_QUEUE_V4.jsonl', 'previous_versions_preserved': True})
    print({'appended': 20, 'total_materially_reviewed': 70, 'completed': completed, 'pending': len(pending), 'remaining_nonfullscore': len(queue), 'V3_preserved': True})


if __name__ == '__main__':
    main()
