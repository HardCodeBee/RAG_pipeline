"""Append the frozen next 20 nonfullscore cases per dataset, after offline reading.

Per-case conclusions are manually authored. Exact quote assertions verify saved
locations, not semantic correctness or evidence sufficiency by token matching.
No original truth label, native score, or RAG execution is changed.
"""
from collections import Counter
from datetime import datetime, timezone
from build_offline import ROOT, OUT, OLD, read, rows, write, jsonl, inventory, sha
from first_manual_review import packet, entry
from complete_success_controls import evidence


def main():
    before = inventory(OUT)
    prior = read(OUT/'MANUAL_INFORMATION_FLOW_REVIEWS_V5.json')['reviews']
    batch = []

    def add(ds, idx, required, category, detail, quotes=(), sufficient=True, use=True, limit=None):
        p = packet(ds, idx)
        es = [evidence(p, *q) for q in quotes]
        finding = {'location':'saved reader, QA, goal and final alignment',
                   'category':category, 'confirmed':True, 'detail':detail}
        if limit: finding['limit'] = limit
        r = entry(p, required, [finding], es, sufficient, use)
        batch.append(r)
        return p, r

    add('2wiki',349, ['Saw Pale daughter Min Hla Myat.', 'Daughter spouse Tarabya of Ava.'],
        'correct_child_in_law_plus_king_title',
        'Child reader identifies Min Hla Myat and next reader explicitly identifies King Tarabya as spouse. Goal/final retain correct relation; King is additional title versus native reference. Extra spouse-children branch abstains without blocking the two-hop solution.',
        [(1,'Saw Pale of Yamethin','mother of Queen Min Hla Myat'),(2,'Min Hla Myat of Ava','King Tarabya of Ava')])
    add('2wiki',352, ['Sturla Gunnarsson directed specified film.', 'Birth city Reykjavik.'],
        'correct_birth_city_plus_country',
        'Actual director biography explicitly gives Reykjavik birth. Goal/final preserve city with Iceland qualifier; native reference has city only.',
        [(1,'Beowulf & Grendel','directed by Sturla Gunnarsson'),(2,'Sturla Gunnarsson','Gunnarsson was born in Reykjavík')])
    add('2wiki',356, ['Need origin of both I Am Because We Are and Our Man Flint.', 'One known US origin alone cannot establish shared country.'],
        'missing_first_film_origin_comparison_operand',
        'First reader consists of generic disambiguations, and goal reader covers Our Man Flint and unrelated titles. No passage in the examined readers establishes first film origin; ordinary, goal and final preserve uncertainty instead of inventing a comparison.',
        [(2,'Our Man Flint','1966 American action film')], sufficient=False,use=None)
    add('2wiki',357, ['Dear Future Husband performer Meghan Trainor.', 'Awards earned rather than merely a list of unrelated performers.'],
        'multiple_supported_awards_single_award_reference',
        'Performer biography supplies Grammy, four ASCAP and two Billboard awards; goal/final list all three award categories. Frozen reference includes only Grammy. Additional categories remain under existing factual labels, not silently treated as extra false facts.',
        [(1,'Dear Future Husband','Meghan Trainor'),(2,'Meghan Trainor','including a Grammy Award, four ASCAP Pop Music Awards')])
    add('2wiki',361, ['Director Brent Maddock.', 'A birthplace relation is needed; nationality adjective is a different field.'],
        'birthplace_abstention_with_reference_nationality_field_issue',
        'Correct director biography says American screenwriter but supplies no birth location. Goal/final decline birthplace. Native reference American is a nationality adjective, not a source-supported birthplace; do not count its token presence as proof of a reader failure.',
        [(1,'Tremors 3: Back to Perfection','directed by Brent Maddock'),(2,'Brent Maddock','American screenwriter')],sufficient=False,use=None)
    add('2wiki',362, ['Mustang director Turkish-French.', 'Erotissimo director French.', 'Shared nationality is nonempty intersection.'],
        'goal_ignores_shared_nationality_inside_compound_descriptor',
        'Both identities and Turkish-French/French attributes reach ordinary QA and final helper. Goal nevertheless concludes no shared nationality; final follows No. Required French intersection is visible rather than lost during retrieval.',
        [(3,'Deniz Gamze Ergüven','Turkish-French film director'),(4,'Gérard Pirès','French film director')],use=False)
    add('2wiki',366, ['Film has multiple credited directors.', 'Native selected director Capellani death place must be an explicit death relation.'],
        'director_biography_present_deathplace_relation_missing',
        'Saved director biography gives Capellani death in1931, diabetes, studies and employment in Paris, but not death in Paris. Goal correctly preserves unknown death places; final abstains. Reference Paris cannot be justified by its occurrence as school/work city.',
        [(1,'Quatre-vingt-treize (film)','Albert Capellani'),(2,'Albert Capellani','He died of diabetes in 1931')],sufficient=False,use=None)
    add('2wiki',370, ['Song performed by Sofia Arvaniti and Bonnie Tyler.', 'Greek/Welsh descriptors apply to different performers; Wales and UK differ in granularity.'],
        'two_true_performers_and_country_granularity_single_reference',
        'Song reader explicitly supplies two singers and their Greek/Welsh descriptors. Goal/final return Greece and Wales. Native reference selects only UK through Tyler. This combines multiple valid performers and geographic granularity; it is not proof that singer identity was wrong.',
        [(1,'The Desert Is in Your Heart','Greek singer Sofia Arvaniti and Welsh singer Bonnie Tyler')])
    p,r=add('2wiki',371, ['Richard is William the Conqueror son.', 'William father RobertI is Richard paternal grandfather; RichardII is one generation too far.'],
        'generation_shift_propagates_despite_visible_correct_chain',
        'Ordinary1 correctly names William father RobertI. Ordinary2 asks RobertI father, retrieves RichardII, then falsely calls that person Richard son-of-William paternal grandfather. Goal rewrite replaces target with RichardII identity question. Final follows wrong generation, despite correct RobertI fact and Richard-to-William relation in saved material.',
        [(1,'William the Conqueror','William was the son of the unmarried Robert I'),(3,'Richard, son of William the Conqueror','second son of William the Conqueror')],use=False)
    assert 'Robert I' in p['trace']['final_context']
    add('2wiki',375, ['Florence husband Ivo Bligh8thEarl.', 'Birthplace Westminster cannot be inferred from sitting there in parliament.'],
        'coarse_place_answer_missing_city_birth_relation_reference_support_issue',
        'Correct husband reader calls Ivo British and says he sat at Westminster as a peer; it does not say born there. Goal/final give accepted broader England, while native city Westminster has no saved birth relation. Preserve old true label and distinguish finer target evidence gap from proven factual error.',
        [(1,'Florence Bligh, Countess of Darnley','wife of Ivo Bligh'),(2,'Ivo Bligh, 8th Earl of Darnley','sat at Westminster as an elected Irish representative peer')],sufficient=False,use=None)
    add('2wiki',376, ['Tourneur French.', 'Florey French-American.', 'Shared French is enough for shared nationality.'],
        'goal_ignores_shared_nationality_inside_compound_descriptor',
        'Ordinary nationality answers and actual biographies preserve French and French-American. Goal changes shared nationality into equal full descriptor and returns No; final copies No even though shared French is available in helper.',
        [(3,'Jacques Tourneur','French film director'),(4,'Robert Florey','French- American director')],use=False)
    add('2wiki',378, ['WarDogs1943 directors Hanna and Barbera.', 'Employment has multiple historical values; distinguish earlier VanBeuren from MGM collaboration.'],
        'multiple_time_indexed_employers_single_historical_reference',
        'Film and Barbera biography support MGM collaboration; biography separately names earlier VanBeuren employment. Goal/final select MGM in film-directing period while native reference selects VanBeuren. This is a source-supported employer/time-scope difference, not loss of company information.',
        [(1,'War Dogs (1943 film)','William Hanna and Joseph Barbera'),(2,'Joseph Barbera','Barbera joined Van Beuren Studios'),(2,'Joseph Barbera','while working at Metro-Goldwyn-Mayer')],
        limit='No exclusive employer or fixed time is added to the original question; existing truth labels remain unchanged.')
    add('2wiki',384, ['Elisabeth mother Mary/Marie ofBurgundy.', 'Death place Cleves, present-day Monterberg Kalkar, as actual source states.'],
        'historical_and_present_place_qualifiers_single_city_reference',
        'Actual correct-mother paragraph explicitly states died in Cleves in present-day Monterberg, Kalkar. Goal/final preserve that source wording rather than confuse birth Dijon or another Elisabeth. Native reference only Kalkar yields partial match.',
        [(2,'Mary of Burgundy, Duchess of Cleves','She died in Cleves in present- day Monterberg, Kalkar')])
    p,r=add('2wiki',386, ['Director Rivette.', 'Alzheimer disease and death date are separate from exact diagnosis timing.'],
        'correct_target_disease_retained_extra_diagnosis_timeline_pending',
        'Goal/final preserve native disease value but copy a complete death/date/three-years-earlier diagnosis sentence. Saved biography says public revelation three years after2009 retirement; it does not settle exact diagnosis date. Existing approved diagnosis-versus-revelation workitem remains open; do not force whole-answer truth from disease token match.',
        [(2,'Jacques Rivette',"it was revealed three years later that he had Alzheimer's disease")],sufficient=None,use=None)
    r['review_status']='pending_work_item_after_material_review'
    r['pending_work_item']={'id':'WIKI386_EXISTING_DIAGNOSIS_TIMELINE','query_id':r['id'],
        'question':'Existing exact diagnosis timing versus public revelation/rounding remains unsettled; disease value is preserved.',
        'source_existing_workitem':'offline_review_v2/PENDING_FACTS.json#386',
        'changes_binary_truth_label':False,'needs_network_now':False}
    add('2wiki',389, ['MarieTherese husband Felix.', 'Native death city Yamoussoukro; residence/hometown alone is not a death relation.'],
        'native_death_city_retained_with_country_reader_relation_not_explicit',
        'Goal/final give native Yamoussoukro plus CoteDIvoire. Examined biography says hometown/capital Yamoussoukro but does not explicitly establish death there. Existing true factual label and dataset death triple are retained; final helper carries accepted target fact, without claiming that hometown text proves death location.',
        [(1,'Félix Houphouët-Boigny','his hometown of Yamoussoukro')],
        limit='Source support and retained dataset factual label are distinct; no new birth/death inference from city occurrence.')
    add('2wiki',390, ['MyFatherHero1994 FranceUS.', 'WyomingRoundup US.', 'Asked common country, not exclusive identical origin sets.'],
        'goal_adds_exclusive_set_equality_despite_explicit_shared_country',
        'Goal explicitly says they share US but are not from the same country exclusively. Final returns No despite the needed US intersection in ordinary and goal answers. Existing goal factual label remains true because both geographic statements are true; task utility fails at changed criterion.',
        [(1,'My Father the Hero (1994 film)','French- American'),(2,'Wyoming Roundup','1952 American Western')],use=False)
    add('2wiki',391, ['Mother correct MariaImmaculata1844 not1874 namesake.', 'Birth Naples rather than death Vienna.'],
        'correct_dated_namesake_and_birth_city_extra_historical_country',
        'Although earlier ranked namesake1874 is present, answer correctly uses1844 mother biography with explicit Naples birth and Vienna death. Goal/final retain Naples with historical kingdom qualifier; native only Naples.',
        [(2,'Princess Maria Immaculata of Bourbon-Two Sicilies (1844–1899)','14 April 1844, Naples, Kingdom of the Two Sicilies')])
    add('2wiki',392, ['WomanFifth FrenchBritishPolish.', 'Evensong British.', 'Shared British origin versus identical complete origin sets.'],
        'goal_ignores_shared_country_inside_multicountry_descriptor',
        'Both source origins reach ordinary answers and helper. Goal concludes No because first film is multinational and second solely British. Final follows No; shared British is visible, so this specific failure does not require new retrieval.',
        [(1,'The Woman in the Fifth','French-British-Polish'),(2,'Evensong (film)','1934 British musical film')],use=False)
    p,r=add('2wiki',403, ['Robert8th father Robert7th.', 'Robert7th mother MaryClifton; CatherineWalmesley is Robert8th mother, not grandmother.'],
        'goal_overwrites_correct_chain_with_wrong_generation_mother',
        'Ordinary2 reader explicitly says Robert7th son of Thomas6th and MaryClifton, and QA correctly names grandmother Mary. Goal rewrite is Who is MaryClifton but goal uses Robert8th mother Catherine from original biography. Final selects Catherine despite correct Mary QA remaining visible.',
        [(2,'Robert Petre, 7th Baron Petre','his wife Mary Clifton'),(1,'Robert Petre, 8th Baron Petre','his wife Catherine Walmesley')],use=False)
    assert 'Mary Clifton' in p['trace']['final_context']
    add('2wiki',419, ['Founder AdamOsborne.', 'Distinguish Thailand birthplace from BritishAmerican nationality descriptor.'],
        'final_selects_birth_country_from_correct_dual_attribute_goal',
        'Reader and goal explicitly distinguish Thailand-born and British-American nationality. Final selects Thailand while native asks American via nationality relation. Same source facts could support a nationality answer; loss occurs at attribute selection, not founder identity.',
        [(1,'Adam Osborne','Thailand-born British-American')],use=False,
        limit='Surface wording from can be ambiguous; comparison is to frozen native nationality target, not a new universal definition of origin.')

    add('hotpotqa',99, ['Kennedy brother Ted.', 'TrueCompass publication date14Sep2009 distinguishes brother.'],
        'correct_person_alias_plus_given_name',
        'Memoir reader identifies TrueCompass by TedKennedy with required date; goal/final preserve Edward TedKennedy. Native TedKennedy omits Edward, giving partial match without a wrong brother.',
        [(2,'Ted Kennedy','Edward Moore "Ted" Kennedy'),(2,'True Compass','September 14, 2009')])
    add('hotpotqa',100, ['Specified score composer ThomasNewman.', 'Distinguish soundtrack identity and composership.'],
        'correct_common_name_reference_adds_middle_name',
        'Actual score passage explicitly credits ThomasNewman and goal/final retain it. Native reference ThomasMontgomeryNewman adds middle name. No mistaken composer or failed intermediate dependency is observed.',
        [(1,'American Beauty: Original Motion Picture Score','composed by Thomas Newman')])
    add('hotpotqa',104, ['Joulupukki literal name meansYuleGoat.', 'YuleGoat straw representation is explicitly documented.', 'Translation identity and modern figure predicate transfer are distinct checks.'],
        'literal_name_translation_vs_single_reference_output_form',
        'Both required source paragraphs are actual readers: Joulupukki name literallyYuleGoat and YuleGoat straw forms. Ordinary answers preserve each; goal merges them and final chooses Finnish name, native English YuleGoat yields zero. This review records translation-based answer choice without assuming every modern Santa predicate transfers to straw-goat representations.',
        [(1,'Joulupukki','literally means "Christmas goat" or "Yule Goat"'),(2,'Yule Goat','Modern representations of the Yule goat are typically made of straw')],sufficient=None,use=None,
        limit='Existing True goal label unchanged; exact semantic equivalence of modern figures is not newly adjudicated. This is not asserted as a proven final factual error.')
    add('hotpotqa',105, ['Need mountain southeast of Jacabamba, native Auqui/Awki.', 'Then identify its transnational Andes range.'],
        'range_visible_but_required_southeast_mountain_relation_missing',
        'Goal reader contains Andes extending through seven countries, but Jacabamba passage only gives Copap north/Chinchey south. Required Auqui southeast relation is absent from examined readers. Goal/final abstain; Andes occurrence alone is not a complete two-hop proof.',
        [(1,'Jacabamba','Copap to the north and Chinchey to the south'),(3,'Andes','seven South American countries')],sufficient=False,use=None)
    add('hotpotqa',107, ['YoungstownPuddlers later calledLittleGiants.', 'Do not join NewarkNJ team to NewarkOhio county.', 'Mahoning is native county; Newark seatLicking is true about a wrong entity path.'],
        'wrong_team_and_city_homonym_join_despite_visible_predecessor',
        'First answer binds NewarkLittleGiants. Step2 reader actually contains YoungstownPuddlers later namedLittleGiants, yet joins Newark team to NewarkOhio/Licking. Later rewrite confirms Licking; goal/final follow. Step3 Newark county-seat answer is factually true for its actual rewritten question; this flow review does not newly count that true relation as an independent factual error.',
        [(2,'Youngstown Puddlers','Eventually the team would also be named the Little Giants'),(2,'Newark, Ohio','county seat of Licking County'),(3,'Licking County, Ohio','Its county seat is Newark')],sufficient=False,use=False,
        limit='Old labels preserved even where their original responsiveness judgment differs from actual-question factual correctness. Missing Mahoning link remains distinct from ignored predecessor evidence.')
    add('hotpotqa',110, ['CactusAlBum by3rdBass.', 'Initial career studio album count two.'],
        'correct_count_reference_includes_unit',
        'Actual group biography and goal explicitly supply two studio albums in initial career. Final Two is count requested; native includes studioalbums, so nonfull score is not evidence of a counting failure.',
        [(1,'The Cactus Album','hip hop trio 3rd Bass'),(2,'3rd Bass','released two studio albums in their initial career')])
    add('hotpotqa',113, ['Last active ruler CleopatraVII.', 'Need military commander relationship, not any loyal follower.'],
        'correct_ruler_target_commander_relation_not_retrieved',
        'Correct ruler source is read; goal reader covers Ptolemaic family and Apollodorus loyal follower but no Athenion military-command relation. Goal/final preserve locally justified uncertainty; no candidate name is substituted solely for being a follower.',
        [(1,'Cleopatra','last active ruler of the Ptolemaic Kingdom')],sufficient=False,use=None)
    add('hotpotqa',114, ['3411in2010 identifies Richmond town.', 'Town2000 population differs in administrative unit from RichmondCDP.'],
        'reference_crosses_town_to_same_name_cdp_population',
        'Actual reader includes Richmond town3411in2010 AND RichmondCDP1864in2000. CDP is explicitly in the town, not identical administrative unit. Goal declines town2000 and final abstains; treating native1864 string as sufficient town proof would collapse units. Existing justified-abstention truth retained.',
        [(1,'Richmond, Maine','population was 3,411 at the 2010 census'),(2,'Richmond (CDP), Maine','census-designated place (CDP) in the town of Richmond'),(2,'Richmond (CDP), Maine','population was 1,864 at the 2000 census')],sufficient=False,use=None)
    add('hotpotqa',115, ['Sportingfacility in CoosCounty.', 'Target formal name NansenSkiJump.'],
        'facility_target_missing_geography_only_readers',
        'Saved readers are town/county intros. LoonMountain appears only under Lincoln in GraftonCounty and cannot satisfy Coos constraint. No examined passage supplies target sporting-facility relation; goal/final decline rather than choose a wrong-county ski site.',
        [(2,'Lincoln, New Hampshire','Grafton County'),(2,'Lincoln, New Hampshire','Loon Mountain ski resort')],sufficient=False,use=None)
    add('hotpotqa',116, ['Prelude composed byPenderecki.', 'Final task asks opera count four; ordinary best-known-work list is a separate task.'],
        'nonresponsive_list_subanswer_still_carries_requested_final_count',
        'Biography explicitly includes namedworks and fouroperas. Ordinary2 only repeats fouroperas rather than answering requested titles, retaining prior nonresponsive False. Goal/final correctly extract four for original count question; reference adds operas. A false stage responsiveness label does not imply missing downstream count.',
        [(1,'Prelude for Clarinet (Penderecki)','Krzysztof Penderecki'),(2,'Krzysztof Penderecki','four operas, eight symphonies')])
    add('hotpotqa',117, ['Compare southward lake locations.', 'Latitude-first decomposition asks for numeric facts unavailable in saved snippets.', 'Dal namesake ambiguity must be kept separate.'],
        'numeric_latitude_plan_unfilled_with_coarse_geography_present',
        'Readers give Kashmir/Srinagar or HimachalDal and Alberta/MontanaWaterton locations but no numeric latitude; Waterton geocoordinates sentence has blank value. Both ordinary answers abstain and goal/final retain uncertainty. Existing valid-abstention labels unchanged; coarse place names are not relabelled sufficient purely by gold answer.',
        [(2,'Waterton Lake','The United States Geological Survey gives the geocoordinates of for Upper Waterton Lake'),(3,'Dal Lake','lake in Srinagar')],sufficient=False,use=None,
        limit='No new map or world-knowledge inference is called. A direct regional-comparison strategy is a hypothesis, not demonstrated recovery.')
    add('hotpotqa',118, ['Actor ElliotFletcher.', 'Brother Connor from motherJuliaFletcher relation, not unrelated Elliot athlete brother.'],
        'correct_actor_short_biography_missing_family_bridge',
        'Actual actor passage supplies birthdate and FakingIt role only. Other retrieved brother facts concern ElliotLee or Bennett, not actor. Goal/final correctly preserve family uncertainty; frozen JuliaFletcher reference provides brother relation outside the examined reader input.',
        [(1,'Elliot Fletcher','MTV comedy series "Faking It"')],sufficient=False,use=None)
    p,r=add('hotpotqa',119, ['Sangin inHelmand valley.', 'Helmand is primary watershed forSistanBasin.', 'Native intended target is relation object basin, not bridge river.'],
        'final_selects_relation_subject_despite_goal_containing_target_object',
        'Actual reader and complete goal state HelmandRiver primarywatershed forSistanBasin. Goal rewrite drops primarywatershed relation into malformed river-valley question. Final chooses HelmandRiver despite goal objectSistanBasin remaining visible. This is relation-direction/answer-target selection under frozen native interpretation, not missing basin evidence.',
        [(1,'Sangin','valley of the Helmand River'),(2,'Helmand River','primary watershed for the endorheic Sistan Basin')],use=False,
        limit='Original wording is awkward and can invite river-as-answer parsing; do not present native intended target as an unambiguous natural-language reading.')
    assert 'Sistan Basin' in p['trace']['final_context']
    add('hotpotqa',122, ['Butautas attempted and failed to deposeAlgirdas.', 'Native interval1345–1377 is Algirdas reign.'],
        'ordinary_modality_error_goal_restores_attempt_dates_match',
        'Reader explicitly says failed attempt but ordinary1 says deposed, already False. Goal restores tried and gives1345/1377, the reader reign endpoints; final preserves bothyears. Native from/to versus and causes partial match. Retain temporal-scope caveat rather than prove failed ordinary modality had no risk.',
        [(1,'Butautas','attempted to depose his uncle Algirdas'),(1,'Butautas','but failed'),(2,'Algirdas','from 1345 to 1377')],
        limit='Goal phrases endpoints as attempted-between interval, not exact attempt date; existing factual label retained.')
    add('hotpotqa',123, ['Helena countyLewisClark.', 'Any summit satisfying county constraint can answer under broad surface wording.'],
        'source_supported_alternative_summit_single_reference',
        'Actual county reader identifies Helena and actual CigaretteRock reader explicitly calls it summit inLewisClarkCounty. Goal/final return that valid summit. Native ScapegoatMountain is another summit, not proof that CigaretteRock is factually wrong.',
        [(1,'Lewis and Clark County, Montana','county seat is Helena'),(2,'Cigarette Rock','summit in Lewis and Clark County')])
    add('hotpotqa',124, ['Heritage-listed CookLandingPlace atSeventeenSeventy.', 'JamesCook connection.'],
        'correct_document_title_alias_reference_body_name',
        'Actual site document title is CooksLandingPlaceTownofSeventeenSeventy; body calls same site CaptainCooksLandingPlace and explicitly names landing. Goal/final choose title form, native body-name form. No lost explorer binding.',
        [(1,"Cook's Landing Place, Town of Seventeen Seventy","Captain Cook's Landing Place is a heritage-listed site")])
    add('hotpotqa',126, ['ButteredCatParadox story.', 'WriterJohnFrazee and NewYorkCity association.', 'From-city phrase is weaker than explicit birth relation.'],
        'goal_retrieval_recovers_named_writer_after_false_no_author_answer',
        'Ordinary2 claims no known creator. Goal reader retrieves JohnFrazee explicitly known for story inOMNI and fromNewYorkCity; goal/final recover name/city and native city with shorter geographic qualifier. Local paragraph says artistfrom rather than explicitly borninNYC, so retained truth is not independently proven from residence/origin phrasing.',
        [(3,'John Frazee','artist from New York City, New York'),(3,'John Frazee','science humor story he wrote in OMNI')],
        limit='Existing true birth answer retained; reader entails writer and city association, not necessarily birthplace.')
    add('hotpotqa',129, ['Hindemith1895.', 'Bartok1881.', 'Earlierbirth selectsBartok.'],
        'correct_date_comparison_common_name_reference_full_name',
        'Actual biographies give1895and1881; goal/final correctly selectBartok. Reference includes ViktorJanos middle names; no comparison-direction error observed.',
        [(1,'Paul Hindemith','16 November 1895'),(2,'Béla Bartók','25 March 1881')])
    add('hotpotqa',131, ['FatherDavidWalkerabolitionist.', 'ResidenceBoston while publishingAppeal, not birthplace.'],
        'correct_time_bound_residence_city_plus_state',
        'Actual father bio explicitly says1829 whilelivingBostonMassachusetts publishedAppeal. Goal/final preserve residence and state qualifier; native onlyBoston.',
        [(1,'Edward G. Walker','son of Eliza and David Walker'),(2,'David Walker (abolitionist)','while living in Boston, Massachusetts')])
    p,r=add('hotpotqa',133, ['JohnArledge actor differs fromJohnGarfield.', 'GrapesWrath1940 directorJohnFord.', 'Wrong film and invented director are separate errors.'],
        'wrong_actor_film_join_followed_by_unsupported_director',
        'Actual Arledge bio namesGrapesWrath but ordinary selectsFlowingGold whose reader starsJohnGarfield. Goal faithfully binds wrongfilm and outputsRalphMurphy although saved FlowingGold body supplies no director. Frozen prior AFI check already verified AlfredEGreen for that film, so this is not merely another valid1940film path.',
        [(1,'John Arledge','including "The Grapes of Wrath"'),(2,'Flowing Gold','starring John Garfield')],sufficient=False,use=False)
    r['evidence'].append({'route':'prior frozen primary fact check; no new network',
        'path':'offline_review_v2/WEB_FACT_CHECKS.json#133',
        'verified_fact':next(c['verified_fact'] for c in read(OLD/'WEB_FACT_CHECKS.json')['checks'] if c['review_index']==133)})

    assert len(batch)==40 and len({r['id'] for r in batch})==40
    assert [r['id'] for r in batch]==[r['id'] for r in read(OUT/'BATCH006_SELECTION.json')['items']]
    assert not {r['id'] for r in batch}&{r['id'] for r in prior}
    all_reviews=prior+batch
    pending=[r['pending_work_item']|{'query_id':r['id']} for r in all_reviews if r.get('pending_work_item')]
    complete=sum(r['review_status']=='completed_for_stated_information_flow_checks' for r in all_reviews)
    assert len(all_reviews)==150 and complete==146 and len(pending)==4
    assert not (OUT/'MANUAL_INFORMATION_FLOW_REVIEWS_V6.json').exists()
    write(OUT/'MANUAL_INFORMATION_FLOW_REVIEWS_BATCH006.json',{'utc':datetime.now(timezone.utc).isoformat(),'selection':'Frozen next20 per dataset ascending review_index','reviews':batch})
    write(OUT/'MANUAL_INFORMATION_FLOW_REVIEWS_V6.json',{'utc':datetime.now(timezone.utc).isoformat(),'status':'partial_offline_information_flow_review','material_reviewed':150,'completed_declared_scope':complete,'pending_work_items':len(pending),'reviews':all_reviews,'limits':'Only declared necessary information and paths reviewed; old truth labels/native scores unchanged. No causal ranking or population attribution.'})
    write(OUT/'INFORMATION_FLOW_PENDING_WORK_ITEMS_V6.json',{'not_a_third_truth_label':True,'items':pending})
    index=rows(OUT/'REVIEW_INDEX_V5.jsonl');by={r['id']:r for r in all_reviews}
    for r in index:
        if r['id'] in by:r.update(followup_review_status=by[r['id']]['review_status'],review_file='MANUAL_INFORMATION_FLOW_REVIEWS_V6.json#'+r['id'])
    jsonl(OUT/'REVIEW_INDEX_V6.jsonl',index)
    cohort=rows(OUT/'INFORMATION_FLOW_COHORT.jsonl')
    queue=[r for ds in ['2wiki','hotpotqa'] for r in sorted([q for q in cohort if q['dataset']==ds and q['review_selection']=='all_nonfullscore' and q['id'] not in by],key=lambda q:q['review_index'])]
    assert len(queue)==120
    jsonl(OUT/'REMAINING_NONFULLSCORE_QUEUE_V6.jsonl',[{'id':r['id'],'dataset':r['dataset'],'review_index':r['review_index'],'review_order':i+1} for i,r in enumerate(queue)])
    historical={r['id'] for r in read(OLD/'ROOT_CAUSE_CASES.json')['cases']}
    progress=read(OUT/'REVIEW_PROGRESS_V5.json')
    progress.update(material_reviewed_items=150,followup_semantic_reviews_completed=complete,pending_fact_or_interpretation_work_items=len(pending),
        pending_followup_reviews=278-complete,not_yet_started_items=128,reviewed_selections={'seeded_fullscore_control':40,'all_nonfullscore':110},
        reviewed_nonfullscore_per_dataset={'2wiki':50,'hotpotqa':60},remaining_nonfullscore=120,
        historical_36_newly_followup_checked=len(historical&set(by)),historical_36_pending_followup=len(historical-set(by)),
        note='V6 overlay current:40success+110nonfullscore materially read;146declared-scope complete;4workitems. Failure prefixes ordered, not random.')
    write(OUT/'REVIEW_PROGRESS_V6.json',progress)
    groups={}
    for selection in ['seeded_fullscore_control','all_nonfullscore']:
        rr=[r for r in all_reviews if r['selection']==selection]
        groups[selection]={'material_reviewed':len(rr),'dataset_counts':dict(Counter(r['dataset'] for r in rr)),
            'completed':sum(r['review_status']=='completed_for_stated_information_flow_checks' for r in rr),
            'pending':sum(r['review_status']=='pending_work_item_after_material_review' for r in rr),
            'nonexclusive_findings':dict(Counter(f['category'] for r in rr for f in r['findings']))}
    write(OUT/'REVIEWED_SUCCESS40_NONFULLSCORE110_DESCRIPTIVE.json',{'scope':'Reviewed material only. Success is seeded sample; failure cases are initial cases plus ordered prefixes with unequal dataset mix. No cause percentages, prevalence, independence or causal ranking.','groups':groups})
    assert read(OUT/'HISTORICAL_INPUT_HASHES.json')==inventory(OLD)
    assert all(sha(ROOT/name)==value for name,value in before.items())
    (OUT/'CURRENT_REVIEW_VERSION_V5.json').write_bytes((OUT/'CURRENT_REVIEW_VERSION.json').read_bytes())
    write(OUT/'VALIDATION_V6.json',{'utc':datetime.now(timezone.utc).isoformat(),'old_diagnostic64_unchanged':True,
        'all_prior_followup_files_unchanged_before_pointer_update':len(before),'V5_pointer_preserved':True,
        'new_material_reviews':40,'total_material_reviews':150,'declared_scope_complete':complete,'pending_work_items':len(pending),
        'API_requests':0,'new_retrieval':0,'GPU':False,'stage_truth_labels_or_scores_changed':False})
    write(OUT/'CURRENT_REVIEW_VERSION.json',{'version':6,'readme':'README_V6.md','reviews':'MANUAL_INFORMATION_FLOW_REVIEWS_V6.json','index':'REVIEW_INDEX_V6.jsonl','progress':'REVIEW_PROGRESS_V6.json','remaining_failures':'REMAINING_NONFULLSCORE_QUEUE_V6.jsonl','hypotheses':'REPAIR_HYPOTHESIS_EXPERIMENT_MAPPING_V6.json','previous_versions_preserved':True})
    print({'appended':40,'material_reviewed':150,'completed':complete,'pending':len(pending),'remaining_failures':120})


if __name__=='__main__':main()
