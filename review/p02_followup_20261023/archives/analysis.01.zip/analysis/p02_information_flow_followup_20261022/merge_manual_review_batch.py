"""Single-writer, append-only merger for the three frozen final review batches."""
import argparse
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
from build_offline import ROOT, OUT, OLD, read, rows, write, jsonl, inventory, sha
from first_manual_review import packet


def actual_question(n):
    actual=n['child_prompt'].split('Actual task:\n')[-1]
    return actual.split('Current subquestion #'+str(n['step_id'])+':\n')[-1].split('\n\nRetrieved passages:')[0]


def main(batch_tag, check_only=False):
    version=int(batch_tag);previous=version-1
    ptrpath=OUT/'CURRENT_REVIEW_VERSION.json';ptr=read(ptrpath)
    if not check_only:assert ptr['version']==previous, (ptr['version'],previous)
    before=inventory(OUT)
    prior=read(OUT/ptr['reviews'])['reviews'] if check_only else read(OUT/f'MANUAL_INFORMATION_FLOW_REVIEWS_V{previous}.json')['reviews']
    assignment=read(OUT/f'ASSIGNMENT_BATCH{batch_tag}.json')
    batchwrap=read(OUT/f'MANUAL_INFORMATION_FLOW_REVIEWS_BATCH{batch_tag}.json')
    batch=batchwrap['reviews']
    assert len(batch)==40 and [r['id'] for r in batch]==[a['id'] for a in assignment['items']]
    assert len({r['id'] for r in batch})==40
    assert not {r['id'] for r in prior}&{r['id'] for r in batch}
    quote_count=0;qa_count=0;source_count=0
    required=['id','dataset','review_index','selection','review_status','original_source_sha256',
       'required_information_manually_identified','findings','evidence','final_has_sufficient_information_for_target',
       'final_uses_target_information_correctly','existing_fact_labels_changed','native_score_changed','original_native_score']
    for r,a in zip(batch,assignment['items']):
        assert all(k in r for k in required),(r['id'],'missing required field')
        p=packet(r['dataset'],r['review_index'])
        assert r['id']==p['id']==a['id'] and r['dataset']==a['dataset'] and r['review_index']==a['review_index']
        assert r['original_source_sha256']==a['source_sha256']==p['source_sha256']==sha(ROOT/p['source'])
        source_count+=1
        assert r['selection']=='all_nonfullscore'
        assert r['existing_fact_labels_changed'] is False and r['native_score_changed'] is False
        native=p['existing_labels_and_native_score_unchanged']
        assert r['original_native_score']=={k:native[k] for k in ['f1','em','final_correct']}
        assert r['review_status'] in ['completed_for_stated_information_flow_checks','pending_work_item_after_material_review']
        assert r['required_information_manually_identified'] and r['findings']
        if r['review_status']=='pending_work_item_after_material_review':assert r.get('pending_work_item')
        nodes={n['step_id']:n for n in p['trace']['nodes']}
        for n in nodes.values():
            assert actual_question(n)==n['request']
            qa_count+=1
        for check in r.get('actual_qa_input_checks',[]):
            n=nodes[check['step_id']]
            assert check['current_subquestion']==n['request']
            assert check['retrieval_rewrite_separate']==n['rewritten_query']
            assert check['child_prompt_sha256']==sha256(n['child_prompt'].encode()).hexdigest()
        for e in r['evidence']:
            if e.get('route') in ['reader_packet','original_retrieval','rewritten_retrieval']:
                n=nodes[e['step_id']]
                ds=[d for d in n[e['route']]['docs'] if d['doc_id']==e['doc_id'] and d['source']==e['source'] and d['rank']==e['rank']]
                assert any(e['verified_quote'] in d['text'] for d in ds),(r['id'],e)
                quote_count+=1
                if 'quote_visible_in_actual_child_prompt' in e:
                    assert e['quote_visible_in_actual_child_prompt']==(e['verified_quote'] in n['child_prompt']),(r['id'],'child quote visibility',e)
            elif e.get('route')=='goal_answer_and_actual_final_context':
                n=nodes[e['step_id']]
                assert n['role']=='goal' and e['verified_quote'] in n['answer'],(r['id'],'goal answer quote',e)
                quote_count+=1
            if 'quote_visible_in_final_context' in e:
                assert e['quote_visible_in_final_context']==(e['verified_quote'] in p['trace']['final_context']),(r['id'],'final quote visibility',e)
        if r.get('pending_work_item') and not isinstance(r['pending_work_item'],dict):
            original=r['pending_work_item']
            r['pending_work_item']={'id':r['dataset'].upper()+str(r['review_index'])+'_INFORMATION_FLOW_SCOPE',
                'query_id':r['id'],'question':' '.join(f['detail'] for f in r['findings']),
                'changes_binary_truth_label':False,'needs_network_now':False,
                'source_batch':f'MANUAL_INFORMATION_FLOW_REVIEWS_BATCH{batch_tag}.json',
                'source_batch_sha256':sha(OUT/f'MANUAL_INFORMATION_FLOW_REVIEWS_BATCH{batch_tag}.json'),
                'verbatim_pending_note_from_batch':original,
                'schema_normalization_only_original_batch_bytes_preserved':True}
    if check_only:
        print({'batch':batch_tag,'check_only':True,'source_checks':source_count,'QA_checks':qa_count,'quote_checks':quote_count,
               'IDs_and_order_exact':True,'no_files_written':True})
        return
    all_reviews=prior+batch;by={r['id']:r for r in all_reviews}
    cohort=rows(OUT/'INFORMATION_FLOW_COHORT.jsonl');cohort_ids={r['id'] for r in cohort}
    assert len(all_reviews)==150+40*(version-6) and set(by)<=cohort_ids
    pending=[r['pending_work_item']|{'query_id':r['id']} for r in all_reviews if r.get('pending_work_item')]
    priorpending={r['query_id']:r for r in read(OUT/f'INFORMATION_FLOW_PENDING_WORK_ITEMS_V{previous}.json')['items']}
    assert all(next(x for x in pending if x['query_id']==qid)==x for qid,x in priorpending.items())
    complete=sum(r['review_status']=='completed_for_stated_information_flow_checks' for r in all_reviews)
    queue=[r for ds in ['2wiki','hotpotqa'] for r in sorted([q for q in cohort if q['dataset']==ds and q['review_selection']=='all_nonfullscore' and q['id'] not in by],key=lambda q:q['review_index'])]
    assert len(queue)==120-40*(version-6)
    assert len(all_reviews)+len(queue)==270
    nfail=sum(r['selection']=='all_nonfullscore' for r in all_reviews)
    failures={ds:sum(r['selection']=='all_nonfullscore' and r['dataset']==ds for r in all_reviews) for ds in ['2wiki','hotpotqa']}
    assert sum(r['selection']=='seeded_fullscore_control' for r in all_reviews)==40
    assert not (OUT/f'MANUAL_INFORMATION_FLOW_REVIEWS_V{version}.json').exists()
    write(OUT/f'MANUAL_INFORMATION_FLOW_REVIEWS_V{version}.json',{
      'utc':datetime.now(timezone.utc).isoformat(),'status':'full_primary_cohort_material_reviewed_with_pending_workitems' if len(all_reviews)==270 else 'partial_offline_information_flow_review',
      'material_reviewed':len(all_reviews),'completed_declared_scope':complete,'pending_work_items':len(pending),
      'reviews':all_reviews,'limits':'Declared necessary-information scopes only. Existing truth/native scores unchanged; actual child_prompt governs QA target interpretation. No population prevalence or causal ranking.'})
    write(OUT/f'INFORMATION_FLOW_PENDING_WORK_ITEMS_V{version}.json',{'not_a_third_truth_label':True,'items':pending})
    index=rows(OUT/f'REVIEW_INDEX_V{previous}.jsonl')
    for r in index:
        if r['id'] in by:r.update(followup_review_status=by[r['id']]['review_status'],review_file=f'MANUAL_INFORMATION_FLOW_REVIEWS_V{version}.json#'+r['id'])
    jsonl(OUT/f'REVIEW_INDEX_V{version}.jsonl',index)
    jsonl(OUT/f'REMAINING_NONFULLSCORE_QUEUE_V{version}.jsonl',[{'id':r['id'],'dataset':r['dataset'],'review_index':r['review_index'],'review_order':i+1} for i,r in enumerate(queue)])
    historical={r['id'] for r in read(OLD/'ROOT_CAUSE_CASES.json')['cases']}
    progress=read(OUT/f'REVIEW_PROGRESS_V{previous}.json')
    progress.update(material_reviewed_items=len(all_reviews),followup_semantic_reviews_completed=complete,
      pending_fact_or_interpretation_work_items=len(pending),pending_followup_reviews=278-complete,
      not_yet_started_items=len(queue)+8,reviewed_selections={'seeded_fullscore_control':40,'all_nonfullscore':nfail},
      reviewed_nonfullscore_per_dataset=failures,remaining_nonfullscore=len(queue),
      historical_36_newly_followup_checked=len(historical&set(by)),historical_36_pending_followup=len(historical-set(by)),
      primary_cohort_material_review_complete=len(all_reviews)==270,
      supplemental_8_status='not_reviewed; explicitly outside completed primary270',
      note=f'V{version} overlay current;{len(all_reviews)} material reviewed;{complete} declared-scope complete;{len(pending)} pending workitems. No old labels/scores changed; no population causal share.')
    write(OUT/f'REVIEW_PROGRESS_V{version}.json',progress)
    groups={}
    for selection in ['seeded_fullscore_control','all_nonfullscore']:
        rr=[r for r in all_reviews if r['selection']==selection]
        groups[selection]={'material_reviewed':len(rr),'dataset_counts':dict(Counter(r['dataset'] for r in rr)),
          'completed':sum(r['review_status']=='completed_for_stated_information_flow_checks' for r in rr),
          'pending':sum(r['review_status']=='pending_work_item_after_material_review' for r in rr),
          'nonexclusive_findings':dict(Counter(f['category'] for r in rr for f in r['findings']))}
    write(OUT/f'REVIEWED_SUCCESS40_NONFULLSCORE{nfail}_DESCRIPTIVE.json',{'scope':'Reviewed material only; success is fixed seeded sample; failure strata/history differ. Counts of manually described findings are not independent causal attribution or population prevalence.','groups':groups})
    mapping=read(OUT/ptr['hypotheses'])
    mapping['review_scope']=f'{len(all_reviews)} material reviewed:40seeded fullscore+{nfail}nonfullscore;{complete} declared-scope complete,{len(pending)} pending. No causal ranking.'
    for m in mapping['mappings']:
        for c in m.get('evidence_cases',[]):c['review']=c['review'].split('.json#')[0].rsplit('_V',1)[0]+f'_V{version}.json#'+c['id']
    if version==7:
        mapping['batch007_manual_followup_notes']=[
          {'cases':['2wiki506'],'contrast_family':'QA relation preservation and goal confrontation of bad prior','observation':'LiuCong actual reader explicitly gives fatherLiuYuan, but QA transfers wifesfatherLiuYin; fact absent final. Mere more retrieval is not demonstrated cure.'},
          {'cases':['hotpotqa187'],'contrast_family':'final requested field readout','observation':'ProtestantChristian already in goal/helper but final returns bridge SalvationArmy; visibility-only addition does not isolate missing factor.'},
          {'cases':['hotpotqa141','hotpotqa150','hotpotqa152','hotpotqa189'],'contrast_family':'preserve existing correction pathways','observation':'Goal/new readers or final correct earlier ambiguity/wrong candidate/abstention; check regressions when changing synthesis. Route-specific gain not inferred without inspecting which retrieval supplied each fact.'},
          {'cases':['2wiki433','2wiki456','2wiki463','hotpotqa145','hotpotqa181','hotpotqa189'],'contrast_family':'reference/source interpretation','observation':'Shared-country omitted in native, source date conflict, wrong-person gold, bridge-as-answer, HTML corruption, and boolean-vs-description reference are separate. No rescore is performed.'}
        ]
    write(OUT/f'REPAIR_HYPOTHESIS_EXPERIMENT_MAPPING_V{version}.json',mapping)
    notes='''
本批新增实证：Wiki506 在ordinary reader中已经出现LiuCong的父亲LiuYuan，QA却取Empress自己的父亲LiuYin，并通过goal传播；正确父亲未保留到final。HP187的goal/helper已给Protestant Christian，final仍返回桥梁组织SalvationArmy。HP140同时读到1805失败围城与1826Combermere攻克，却沿错事件版本。

另有保留纠错能力的实例：HP141从未限定Voice的土耳其版本回到正确韩国版本；HP150从Cowra改回Forbes；HP152补全Fiers跨队关系；HP189 goal忽略新纪录片事实但final正确输出No。不能将“所有上游错误必传播”或“统一删goal一定更好”视为已证明。

参考与来源问题分列：Wiki433片段明确Canadian-American，原参考只取Canadian并给No；456原读入传记有27/17Feb冲突，冻结核验已判27错误；463参考连接同名足球员而非导演。HP145原参考是bassist本身，但方法输出的TommyLee亦不是真配偶；189问布尔而参考为单实体描述。原标签及原生分数均不修改。
''' if version==7 else '\n本版按冻结任务包追加另一位代理亲读的40条记录；合并执行逐字段、原始sourcehash、原生分数保留、实际QA问题及证据摘录位置验证。详见本批逐条记录；此页不自动从关键词生成原因结论。\n'
    md=f'''# P02 信息流离线审阅 V{version}

追加 `MANUAL_INFORMATION_FLOW_REVIEWS_BATCH{batch_tag}.json` 的40条，严格匹配 `ASSIGNMENT_BATCH{batch_tag}.json` 的ID与顺序。累计亲读{len(all_reviews)}条：固定seed满分对照40、非满分{nfail}（2Wiki{failures['2wiki']}、HotpotQA{failures['hotpotqa']}）。{complete}条完成各自声明的必要信息/路径范围，{len(pending)}条保留待核。并非对每个无关附加事实重新制作独立金标。

主270队列剩余非满分{len(queue)}条。8条补充包明确尚未审阅，不计入主cohort完成数。所有先前待核项原样保留；新歧义允许追加待核，不强行判标签。

{notes}

## 实际QA输入口径

以 `child_prompt` 的 Current subquestion 为准。`rewritten_query` 是检索查询，不能直接视作替换了回答器问题。HP107澄清见 `HP107_ACTUAL_QA_INPUT_CLARIFICATION.md/.json`；原V6字节保留。独立真命题、对检索改写响应、对实际问题响应分开。

## 验证与文件

- 累计：`MANUAL_INFORMATION_FLOW_REVIEWS_V{version}.json`；状态：`REVIEW_INDEX_V{version}.jsonl`、`REVIEW_PROGRESS_V{version}.json`。
- 剩余：`REMAINING_NONFULLSCORE_QUEUE_V{version}.jsonl`；待核：`INFORMATION_FLOW_PENDING_WORK_ITEMS_V{version}.json`。
- 描述性对照：`REVIEWED_SUCCESS40_NONFULLSCORE{nfail}_DESCRIPTIVE.json`。成功对照是固定seed样本，非满分此前有初始案例与递增前缀；本页不提供总体原因占比或因果排名。
- 本次合并校验40条sourcehash、{qa_count}个实际QA问题，以及{quote_count}条证据/goal摘录位置。摘录检查只证明位置，不自动判语义充分；语义结论来自逐条亲读记录。
- `VALIDATION_V{version}.json` 证明原诊断64文件及全部先前已有文件保持原字节（仅当前指针更新），原指针保存为 `CURRENT_REVIEW_VERSION_V{previous}.json`。旧truth、原生F1/EM、四组主表及主评价计划不改。
- 无API、网络、新检索、GPU或RAG重跑。假设映射仅整理已有案例，不实施新实验。
'''
    (OUT/f'README_V{version}.md').write_text(md,encoding='utf-8')
    assert read(OUT/'HISTORICAL_INPUT_HASHES.json')==inventory(OLD)
    assert all(sha(ROOT/name)==value for name,value in before.items())
    back=OUT/f'CURRENT_REVIEW_VERSION_V{previous}.json';assert not back.exists();back.write_bytes(ptrpath.read_bytes())
    write(OUT/f'VALIDATION_V{version}.json',{'utc':datetime.now(timezone.utc).isoformat(),
       'old_diagnostic64_unchanged':True,'all_prior_followup_files_unchanged_before_pointer_update':len(before),
       'previous_pointer_preserved':back.name,'new_material_reviews':40,'total_material_reviews':len(all_reviews),
       'declared_scope_complete':complete,'pending_work_items':len(pending),'sourcehashes_checked':source_count,
       'actual_QA_questions_checked':qa_count,'evidence_quote_locations_checked':quote_count,
       'quotes_are_location_validation_not_semantic_judges':True,'API_requests':0,'new_retrieval':0,'GPU':False,
       'stage_truth_labels_or_scores_changed':False,'old_review_prefix_exactly_equal':all_reviews[:len(prior)]==prior,
       'frozen_assignment_ID_and_order_exact':True,'primary_cohort_reviewed':len(all_reviews),'supplemental8_not_reviewed':True})
    ptr.update(version=version,readme=f'README_V{version}.md',reviews=f'MANUAL_INFORMATION_FLOW_REVIEWS_V{version}.json',
      index=f'REVIEW_INDEX_V{version}.jsonl',progress=f'REVIEW_PROGRESS_V{version}.json',remaining_failures=f'REMAINING_NONFULLSCORE_QUEUE_V{version}.jsonl',
      hypotheses=f'REPAIR_HYPOTHESIS_EXPERIMENT_MAPPING_V{version}.json',previous_versions_preserved=True)
    write(ptrpath,ptr)
    assert all(sha(ROOT/name)==value for name,value in before.items() if ROOT/name!=ptrpath)
    print({'version':version,'material_reviewed':len(all_reviews),'complete':complete,'pending':len(pending),
           'remaining_nonfullscore':len(queue),'supplemental_not_reviewed':8,'source_checks':source_count,'QA_checks':qa_count,'quote_checks':quote_count})


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--batch',required=True,choices=['007','008','009']);ap.add_argument('--check-only',action='store_true')
    args=ap.parse_args();main(args.batch,args.check_only)
