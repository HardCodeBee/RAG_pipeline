"""Save a small human-readable Codex review of inspected frozen packets.

The judgments below were authored after reading the actual node passages and
answers; the assertions check provenance/quoted evidence, not semantic truth.
No inherited truth label or native endpoint is changed.
"""
from collections import Counter
from datetime import datetime, timezone
from build_offline import ROOT, HERE, OUT, OLD, read, rows, write, jsonl, inventory


def packet(ds, index):
    return read(OUT / 'review_packets' / f'{ds}_{index:03d}.json')


def node(p, step):
    return p['trace']['nodes'][step - 1]


def source_doc(p, step, route, title):
    found = [d for d in node(p, step)[route]['docs'] if d['source'] == title]
    assert found, (p['id'], step, route, title)
    return found[0]


def ev(step, route, doc, quote):
    assert quote in doc['text']
    return {'step_id': step, 'route': route, 'doc_id': doc['doc_id'],
            'source': doc['source'], 'rank': doc['rank'], 'verified_quote': quote}


def entry(p, requirements, findings, evidence, final_sufficient, final_use_correct):
    return {'id': p['id'], 'dataset': p['trace']['dataset'],
            'review_index': p['existing_labels_and_native_score_unchanged']['review_index'],
            'selection': p['selection'], 'reviewer': 'current Codex, one reviewer; not independent human gold',
            'review_status': 'completed_for_stated_information_flow_checks',
            'review_scope': 'Only stated information requirements and transfer checks; not an exhaustive fresh fact check of every incidental assertion.',
            'original_source_sha256': p['source_sha256'],
            'required_information_manually_identified': requirements,
            'findings': findings, 'evidence': evidence,
            'final_has_sufficient_information_for_target': final_sufficient,
            'final_uses_target_information_correctly': final_use_correct,
            'existing_fact_labels_changed': False, 'native_score_changed': False,
            'original_native_score': {k: p['existing_labels_and_native_score_unchanged'][k] for k in ['f1', 'em', 'final_correct']}}


def main():
    reviews = []
    p = packet('hotpotqa', 7)
    d = source_doc(p, 2, 'rewritten_retrieval', 'Doomsday Prophecy')
    assert d['rank'] == 10 and d['doc_id'] not in {x['doc_id'] for x in node(p, 2)['reader_packet']['docs']}
    assert 'Doomsday Prophecy' not in p['trace']['final_context']
    reviews.append(entry(p,
        ['Kaylee Frye actor is Jewel Staite.', 'Film with Jewel Staite and Alan Dale is Doomsday Prophecy, released in 2011.'],
        [{'location': 'step2 candidate to reader selection', 'category': 'necessary_evidence_found_then_not_retained',
          'confirmed': True, 'detail': 'A single saved candidate supplies both actors and the requested year. It is absent from reader packet and later actual context; reasonable abstention labels stay unchanged.'}],
        [ev(2, 'rewritten_retrieval', d, 'Doomsday Prophecy is a 2011 sci-fi disaster television film by Jason Bourque starring Jewel Staite, Alan Dale and A.J. Buckley.')], False, None))

    p = packet('hotpotqa', 46)
    gold = p['frozen_reference_material_for_review_only']['gold_documents']
    missing = {str(d['_id']) for d in gold}
    all_docs = [d for n in p['trace']['nodes'] for route in ['original_retrieval', 'rewritten_retrieval', 'reader_packet'] for d in (n.get(route) or {}).get('docs', [])]
    assert not missing & {str(d['doc_id']) for d in all_docs}
    assert 'wendigo' not in str(p['trace']).lower() and 'windigo' not in str(p['trace']).lower()
    reviews.append(entry(p,
        ['Identify a Hasbro-show enemy with the relevant name: Wendigos.', 'Connect that name to Wendigo psychosis, not Decepticons or Inhumanoids.'],
        [{'location': 'saved candidate retrieval and partial ordinary answers', 'category': 'required_bridge_not_covered_in_saved_routes',
          'confirmed': True, 'detail': 'Neither the Equestria/Wendigo reference documents nor Wendigo naming relation appear in saved routes. True lists of alternative shows/enemies narrow subsequent rewrite without supplying the needed object.',
          'limit': 'This is not proof that the full corpus lacks the evidence, and is not uniquely attributable to the decomposer.'}],
        [{'route': 'frozen dataset reference only', 'source': d['title'], 'doc_id': d['_id'], 'verified_quote': d['text']} for d in gold], False, None))

    p = packet('hotpotqa', 236)
    d = source_doc(p, 2, 'rewritten_retrieval', 'Androscoggin Bank Colisée')
    assert '4,000 capacity (3,677 seated)' in d['text']
    assert '3,677 seated' in node(p, 2)['answer'] and '3,677 seated' in p['trace']['final_context']
    assert p['trace']['prediction'] == '4,000'
    assert all('3,677' not in x['text'] for x in p['trace']['original_retrieval']['docs'])
    reviews.append(entry(p,
        ['Lewiston Maineiacs home arena is Androscoggin Bank Colisée.', 'Seated count is 3,677; total capacity 4,000 is a different attribute.'],
        [{'location': 'goal rewrite to goal answer to final', 'category': 'goal_supplies_unique_needed_fact', 'confirmed': True,
          'detail': 'Seat count arrives in goal rewritten retrieval and is preserved in goal answer; original-query Top10 lacks that number.'},
         {'location': 'final answer', 'category': 'visible_correct_fact_wrong_attribute_selected', 'confirmed': True,
          'detail': 'Final picks total capacity although seated count and its label are visible.'}],
        [ev(2, 'rewritten_retrieval', d, '4,000 capacity (3,677 seated)')], True, False))

    # The first three seeded full-score controls in each dataset, not selected
    # for interesting outcomes, were read together with their relation evidence.
    for idx, film1, director1, year1, film2, director2, year2, winner in [
        (703, 'Agent for H.A.R.M.', 'Gerd Oswald', '1919', 'The Hard Ride', 'Burt Topper', '1928', 'Agent For H.A.R.M.'),
        (630, 'The Tortured', 'Robert Lieberman', '1947', 'The Emperor and His Brother', 'Chor Yuen', '1934', 'The Emperor and His Brother')]:
        p = packet('2wiki', idx)
        evidence = []
        for step, title, part in [(1, film1, director1), (2, film2, director2), (3, director1, year1), (4, director2, year2)]:
            d = source_doc(p, step, 'reader_packet', title)
            evidence.append(ev(step, 'reader_packet', d, part))
        assert year1 in node(p, 3)['answer'] and year2 in node(p, 4)['answer']
        assert year1 in p['trace']['final_context'] and year2 in p['trace']['final_context']
        assert p['trace']['prediction'] == winner
        assert not any(x['source'] in [director1, director2] for x in p['trace']['original_retrieval']['docs'])
        reviews.append(entry(p,
            [f'{film1} director is {director1}, born {year1}.', f'{film2} director is {director2}, born {year2}.', 'Compare director birth dates, return the associated film.'],
            [{'location': 'ordinary answers through goal/final', 'category': 'required_relation_and_dates_preserved_and_used', 'confirmed': True,
              'detail': 'Director DOB passages are absent from final original-query Top10, but their dates are carried in ordinary QA and goal, and comparison direction is correct.',
              'limit': 'This does not establish whether goal is necessary; ordinary QA already carries both dates.'}], evidence, True, True))

    p = packet('2wiki', 662)
    evidence = [ev(step, 'reader_packet', source_doc(p, step, 'reader_packet', title), quote) for step, title, quote in [
        (1, 'Bernard J. Ganter', 'was an American clergyman'), (2, 'Ronnie Eldridge', 'is an American activist')]]
    assert p['trace']['prediction'] == 'Yes'
    reviews.append(entry(p, ['Both identified people are American / from the United States.', 'Compare country equality.'],
        [{'location': 'ordinary to goal/final', 'category': 'operand_country_facts_and_equality_preserved', 'confirmed': True,
          'detail': 'Both reader passages identify the correct named person as American; ordinary answers and final retain country equality.'}], evidence, True, True))

    p = packet('hotpotqa', 127)
    evidence = [ev(step, 'reader_packet', source_doc(p, step, 'reader_packet', title), quote) for step, title, quote in [
        (1, 'Mikhail Glinka', 'Russian composer'), (2, 'Jean-Baptiste Lully', 'French composer')]]
    assert p['trace']['prediction'] == 'Yes'
    reviews.append(entry(p, ['Mikhail Glinka is a composer.', 'Jean-Baptiste Lully is a composer.', 'Apply conjunction.'],
        [{'location': 'ordinary to goal/final', 'category': 'two_supported_properties_correctly_combined', 'confirmed': True,
          'detail': 'Distinct named-person source passages supply the asked property; both answers and final preserve it.'}], evidence, True, True))

    p = packet('hotpotqa', 156)
    evidence = [ev(step, 'reader_packet', source_doc(p, step, 'reader_packet', title), quote) for step, title, quote in [
        (1, "Hey Pa! There's a Goat on the Roof", 'issued by Parker Brothers in 1966'), (2, 'Poleconomy', 'first published in 1980')]]
    assert p['trace']['prediction'] == '"Hey Pa! There\'s a Goat on the Roof"'
    reviews.append(entry(p, ['First board game issued 1966.', 'Poleconomy first published 1980.', 'Compare market dates.'],
        [{'location': 'ordinary to goal/final', 'category': 'dates_and_requested_temporal_direction_preserved', 'confirmed': True,
          'detail': 'Two correctly bound game dates are stated in reader, QA and goal; final returns the game associated with the earlier date.'}], evidence, True, True))

    p = packet('hotpotqa', 175)
    d1 = source_doc(p, 1, 'reader_packet', '1992 FA Cup Final')
    d2 = source_doc(p, 3, 'reader_packet', 'Ian Rush')
    assert all(d['source'] != 'Ian Rush' for d in node(p, 2)['reader_packet']['docs'])
    assert p['trace']['prediction'] == 'Ian Rush'
    reviews.append(entry(p, ['1992 final scorers include Ian Rush.', 'Ian Rush is Welsh.', 'Return the player satisfying both conditions, not a scorer from another round/year.'],
        [{'location': 'ordinary step2 and goal reader', 'category': 'correct_intermediate_without_direct_local_support_later_supported', 'confirmed': True,
          'detail': 'Step2 says Ian Rush is Welsh but its ten reader passages contain no direct Ian-Rush nationality statement. Dataset reference verifies it; goal reader subsequently includes the Ian Rush passage. Ordinary factual label remains correct.'},
         {'location': 'goal/final', 'category': 'correct_entity_and_event_scope_despite_distractor', 'confirmed': True,
          'detail': 'Steve Watkin third-round 1992 material ranks before Ian Rush in goal reader, but final correctly uses 1992 Final scorer scope. This is a success control, not a failure attribution.'}],
        [ev(1, 'reader_packet', d1, 'with goals from Michael Thomas and Ian Rush'), ev(3, 'reader_packet', d2, 'is a retired Welsh professional footballer')], True, True))

    p = packet('hotpotqa', 98)
    d1 = source_doc(p, 1, 'reader_packet', 'The Voyage that Shook the World')
    d2 = source_doc(p, 5, 'reader_packet', 'Young Earth creationism')
    assert 'less than 10,000 years ago' in node(p, 5)['answer']
    assert 'less than 10,000 years ago' in p['trace']['prediction']
    assert all('10,000 years ago' not in n['answer'] for n in p['trace']['nodes'] if n['role'] == 'ordinary')
    reviews.append(entry(p,
        ['Commissioning organisation is Creation Ministries International, a Young Earth creationist organisation.', 'Its stated belief places creation less than 10,000 years ago; duration in six days is a separate temporal description.'],
        [{'location': 'ordinary answers to goal', 'category': 'goal_adds_requested_timescale_beyond_ordinary_answers', 'confirmed': True,
          'detail': 'Ordinary temporal answers mention six-day duration only; goal also states the requested elapsed-time condition supplied in its reader.'},
         {'location': 'final native matching', 'category': 'target_fact_preserved_with_extra_temporal_description', 'confirmed': True,
          'detail': 'Final retains less-than-10,000-years-ago and adds six-day/Genesis description. Frozen reference is 10,000 years ago; native F1 remains 0.3157894736842105, not reclassified or rescored.',
          'limit': 'Only the stated target-time transfer was newly checked. Do not interpret every partial-F1 case as formatting.'}],
        [ev(1, 'reader_packet', d1, 'commissioned by Creation Ministries International, a Christian Young Earth creationist organisation'),
         ev(5, 'reader_packet', d2, 'the universe, Earth, and all life on Earth were created by direct acts of God less than 10,000 years ago')], True, True))

    assert len(reviews) == 10 and len({r['id'] for r in reviews}) == 10
    write(OUT / 'MANUAL_INFORMATION_FLOW_REVIEWS.json', {'utc': datetime.now(timezone.utc).isoformat(),
        'status': 'first_batch_only', 'reviewed_queries': len(reviews), 'source': 'saved raw trajectories and frozen dataset material; no web/API/model judging',
        'reviewer': 'one current Codex reviewer; not independent human gold', 'reviews': reviews})
    by_id = {r['id']: r for r in reviews}
    index = rows(OUT / 'REVIEW_INDEX.jsonl')
    for row in index:
        if row['id'] in by_id:
            row['followup_review_status'] = 'completed_for_stated_information_flow_checks'
            row['review_file'] = 'MANUAL_INFORMATION_FLOW_REVIEWS.json#' + row['id']
            saved_packet = ROOT / row['packet']
            packet_data = read(saved_packet)
            packet_data['followup_review_status'] = row['followup_review_status']
            packet_data['followup_review_file'] = row['review_file']
            write(saved_packet, packet_data)
        elif row['historical_finding_available']:
            row['followup_review_status'] = 'prior_case_finding_retained_followup_pending'
    jsonl(OUT / 'REVIEW_INDEX.jsonl', index)
    selections = Counter(r['selection'] for r in reviews)
    historical = {r['id'] for r in read(OLD / 'ROOT_CAUSE_CASES.json')['cases']}
    progress = read(OUT / 'REVIEW_PROGRESS.json')
    progress.update(followup_semantic_reviews_completed=len(reviews), pending_followup_reviews=len(index) - len(reviews),
        reviewed_selections=dict(selections), historical_36_newly_followup_checked=sum(r['id'] in historical for r in reviews),
        historical_36_pending_followup=sum(r['id'] not in by_id for r in read(OLD / 'ROOT_CAUSE_CASES.json')['cases']),
        first_fullscore_controls_per_dataset=3,
        note='10 queries checked only for stated information-flow requirements: 3 historical cases, 6 first seeded success controls, 1 additional nonfullscore. Remaining prepared packets are pending. No full-cohort failure percentages inferred.')
    write(OUT / 'REVIEW_PROGRESS.json', progress)
    assert read(OUT / 'HISTORICAL_INPUT_HASHES.json') == inventory(OLD)
    validation = read(OUT / 'VALIDATION.json')
    validation.update(first_manual_batch=10, full_semantic_review_complete=False, old_diagnostic_all_64_file_bytes_unchanged=True)
    write(OUT / 'VALIDATION.json', validation)
    lines = ['# 信息流后续诊断：当前已完成范围', '',
        '本次只使用既有轨迹、冻结数据集材料和既有分数；没有API、检索、GPU或RAG重跑。原64个诊断文件逐字节哈希未变，主评未恢复。', '',
        '- 阶段0：汇总6个已完成fixed90变体及A/B真实对照，详见FIXED90_DIVERGENCE.md/json。',
        '- 诊断修订：新副本只修HP236 goal实际绑定step1。HotpotQA实际绑定补充表160/179→161/180，错误历史组仍3/17；39张表不变，两个数据集的四类主表逐字段不变。',
        '- 审阅包：230条全部非满分+每集固定20条满分，共270条主队列；另保留8条队列之外的历史满分案例作补充。抽样规则和ID见SAMPLING.json。',
        '- 人工信息流核查：当前10条，仅覆盖每条明确列出的信息需求；3条历史案例、6条按固定次序取的成功对照、1条新非满分。其余268条待审；既有36例中33条尚待这轮扩展复核。', '',
        '首批证据支持三类不同位置：HP46所存候选未覆盖目标桥接对象；HP7改写候选已命中但合并裁掉；HP236目标字段已到final但抽错属性。三者不能合并为最终阅读器失败。', '',
        '成功对照2Wiki703/630显示：原题Top10没有导演出生日期文段，普通QA仍保留了两人的日期并支持正确比较。HP175显示：真实但本地子reader未直接支持的中间回答可以在goal阶段取得明确证据，且系统能排除同年不同轮次的干扰。', '',
        '新非满分HP98显示：普通回答仅给六天的创世持续时间，goal从阅读文段补入less than 10,000 years ago并传到final；final保留目标时间同时附加描述，原生F1为0.3158。这是一条具体的目标事实已保留而匹配未满分的记录，不推广到全部部分F1。', '',
        '事实真假标签和原生F1/EM均保留。文本/文档变化计数不等于错误率；本批案例不构成全队列归因或因果收益估计。', '']
    (OUT / 'README.md').write_text('\n'.join(lines), encoding='utf-8')
    print({'manual_information_flow_reviews': len(reviews), 'pending': len(index) - len(reviews), 'old_inputs_unchanged': True})


if __name__ == '__main__':
    main()
