"""Build authorized offline follow-up artifacts. No generation, retrieval, or API.

Historical artifacts are read-only. All writes are confined to this follow-up's
analysis/output directories. Text/packet differences are not semantic errors.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import difflib
import hashlib
import json
import shutil
import sqlite3
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OUT = ROOT / 'outputs/query_decomposition/p02_information_flow_followup_20261022'
OLD = ROOT / 'outputs/query_decomposition/p02_error_propagation_diagnostic_20261021/offline_review_v2'
RUNS = ROOT / 'outputs/query_decomposition/hotpot_formal_eval_v1'
SEED = 20261021


def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))


def rows(p):
    return [json.loads(l) for l in Path(p).read_text(encoding='utf-8-sig').splitlines() if l.strip()]


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def write(p, data):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def jsonl(p, records):
    Path(p).write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in records), encoding='utf-8')


def rel(p):
    return Path(p).relative_to(ROOT).as_posix()


def inventory(p):
    return {rel(f): sha(f) for f in sorted(p.rglob('*')) if f.is_file()}


def predictions(folder):
    result, provenance = {}, []
    for ds in ['hotpotqa', '2wiki', 'musique']:
        p = folder / 'candidate' / ds / 'checkpoint.sqlite3'
        with sqlite3.connect(p.resolve().as_uri() + '?mode=ro', uri=True) as db:
            found = {k: json.loads(v) for k, v in db.execute("SELECT key,value FROM data WHERE kind='prediction'")}
        assert len(found) == 30
        result.update(found)
        provenance.append({'path': rel(p), 'sha256_main_sqlite_file': sha(p), 'prediction_rows': len(found)})
    return result, provenance


def doc_ids(packet):
    return [d['doc_id'] for d in packet['docs']] if packet else None


def doc_payload(packet):
    return [(d['doc_id'], d['text']) for d in packet['docs']] if packet else None


def trajectory_comparison(left, right, left_scores, right_scores):
    details = []
    totals = {'ordinary': Counter(), 'goal': Counter()}
    first_behavior, first_inputs = Counter(), Counter()
    final_counts = Counter()
    for cid, a in left.items():
        b = right[cid]
        entry = {'id': cid, 'dataset': a['dataset'], 'question': a['question'],
                 'before_status': a['status'], 'after_status': b['status'],
                 'before_score': left_scores[cid], 'after_score': right_scores[cid],
                 'before_prediction': a['prediction'], 'after_prediction': b['prediction']}
        entry['delta_F1'] = right_scores[cid]['f1'] - left_scores[cid]['f1']
        if not a.get('nodes') or not b.get('nodes'):
            entry.update(trajectory_comparable=False, reason='Missing full node trajectory; scored algorithm failure retained, not imputed.')
            details.append(entry)
            continue
        assert a['question'] == b['question'] and a['supporting_questions'] == b['supporting_questions']
        assert len(a['nodes']) == len(b['nodes'])
        changes, first_b, first_i = [], None, None
        for x, y in zip(a['nodes'], b['nodes']):
            assert x['step_id'] == y['step_id'] and x['request'] == y['request'] and x['role'] == y['role']
            flags = {
                'rewrite_prompt_changed': x.get('rewrite_prompt') != y.get('rewrite_prompt'),
                'rewrite_query_changed': x['rewritten_query'] != y['rewritten_query'],
                'rewritten_docs_changed': doc_ids(x['rewritten_retrieval']) != doc_ids(y['rewritten_retrieval']),
                'original_docs_changed': doc_ids(x['original_retrieval']) != doc_ids(y['original_retrieval']),
                'reader_docs_changed': doc_ids(x['reader_packet']) != doc_ids(y['reader_packet']),
                'reader_text_changed': doc_payload(x['reader_packet']) != doc_payload(y['reader_packet']),
                'prior_answers_changed': x['prior_complete_answers'] != y['prior_complete_answers'],
                'child_prompt_changed': x['child_prompt'] != y['child_prompt'],
                'answer_changed': x['answer'] != y['answer'],
                'initial_answer_changed': x['initial_answer'] != y['initial_answer'],
            }
            counter = totals[x['role']]
            counter['nodes'] += 1
            for key, value in flags.items():
                counter[key] += int(value)
            # These are chronology markers, not estimates of causal influence.
            if first_i is None:
                for key in ['rewrite_prompt_changed', 'child_prompt_changed']:
                    if flags[key]:
                        first_i = {'step_id': x['step_id'], 'role': x['role'], 'field': key}
                        break
            if first_b is None:
                for key in ['rewrite_query_changed', 'reader_docs_changed', 'reader_text_changed', 'answer_changed']:
                    if flags[key]:
                        first_b = {'step_id': x['step_id'], 'role': x['role'], 'field': key}
                        break
            if any(flags.values()):
                changes.append({'step_id': x['step_id'], 'role': x['role'], 'request': x['request'], **flags,
                    'before_rewrite': x['rewritten_query'], 'after_rewrite': y['rewritten_query'],
                    'before_answer': x['answer'], 'after_answer': y['answer'],
                    'before_reader_doc_ids': doc_ids(x['reader_packet']), 'after_reader_doc_ids': doc_ids(y['reader_packet'])})
        final = {key + '_changed': a.get(key) != b.get(key) for key in ['helper', 'final_context', 'final_prompt', 'prediction']}
        for key, value in final.items():
            final_counts[key] += int(value)
        first_behavior[str(first_b)] += 1
        first_inputs[str(first_i)] += 1
        entry.update(trajectory_comparable=True, first_changed_prompt=first_i, first_behavior_difference=first_b,
                     stage_differences=changes, **final)
        details.append(entry)
    comparable = sum(d['trajectory_comparable'] for d in details)
    return {'planned_and_scored': len(details), 'trajectory_comparable': comparable,
            'not_comparable': len(details) - comparable,
            'semantic_error_labels_assigned_by_comparison': False,
            'prompt_equality_is_not_full_request_equality': True,
            'counts': {k: dict(v) for k, v in totals.items()}, 'final_counts': dict(final_counts),
            'first_behavior_distribution': dict(first_behavior), 'first_prompt_distribution': dict(first_inputs),
            'improved_tied_harmed': dict(Counter('improved' if d['delta_F1'] > 1e-12 else 'harmed' if d['delta_F1'] < -1e-12 else 'tied' for d in details)),
            'mean_F1_delta': sum(d['delta_F1'] for d in details) / len(details), 'details': details}


def compare_completed_variants():
    folders = {
        'selfcontained': RUNS / 'p02_childprompt_selfcontained_quick90_v1_20261021/approved_recovery004',
        'no_refs': RUNS / 'p02_frozen_no_refs_quick90_v1_20261021/automatic_recovery003',
        'A_no_only': RUNS / 'p02_prompt_minimal_ablation_quick90_v1_20261021/A_no_only',
        'B_no_resolve': RUNS / 'p02_prompt_minimal_ablation_quick90_v1_20261021/B_no_resolve',
        'three_prompts_v1': RUNS / 'p02_three_prompts_quick90_v1_20261021/approved_unknown_recovery003',
        'minimal4': RUNS / 'p02_childprompt_minimal4_quick90_v1_20261021/approved_resume002_20261022',
        'three_prompts_compact_v2': RUNS / 'p02_three_prompts_compact_quick90_v2_20261021/delegated_recovery003',
    }
    controls = rows(RUNS / 'p02_childprompt_selfcontained_quick90_v1_20261021/control90.jsonl')
    variants = {'original_frozen': {v['id']: v['trajectory'] for v in controls}}
    scores = {'original_frozen': {v['id']: v['baseline'] for v in rows(folders['selfcontained'] / 'PAIRED_DETAILS.jsonl')}}
    sources = {}
    for name, folder in folders.items():
        report = read(folder / 'REPORT.json')
        assert report['status'] == 'completed' and report['metrics']['overall']['complete'] == 90
        variants[name], pins = predictions(folder)
        assert set(variants[name]) == set(variants['original_frozen'])
        scores[name] = {v['id']: v['candidate'] for v in rows(folder / 'PAIRED_DETAILS.jsonl')}
        sources[name] = {'final_directory': rel(folder), 'report_sha256': sha(folder / 'REPORT.json'),
                         'statuses': dict(Counter(v['status'] for v in variants[name].values())), 'sqlite_inputs': pins,
                         'mean_native_F1': sum(v['f1'] for v in scores[name].values()) / 90}
    contrasts = {}
    for name in folders:
        contrasts['original_to_' + name] = trajectory_comparison(variants['original_frozen'], variants[name], scores['original_frozen'], scores[name])
    for name in ['A_no_only', 'B_no_resolve']:
        contrasts['selfcontained_to_' + name] = trajectory_comparison(variants['selfcontained'], variants[name], scores['selfcontained'], scores[name])
    result = {'scope': 'Completed exposed fixed90 variants only; latest finalized directories, not stale root reports. No new evaluation.',
              'control_F1': sum(v['f1'] for v in scores['original_frozen'].values()) / 90,
              'sources': sources, 'contrasts': contrasts,
              'limitations': ['Text changes are not errors or causal attribution.',
                  'Full downstream runs permit answers to change later rewrites and evidence; identical upstream packets are checked per node.',
                  'Three-prompts V1 has 89 successful trajectories and one scored algorithm failure with no nodes; trajectory denominator is 89.',
                  'Three-prompts V1 final artifacts include a user-approved one-query goal-cap512 recovery; consult its frozen recovery records before interpreting a pure-prompt effect.',
                  'No repeated fresh generation or independent confirmation sample; generation variability is not estimated.']}
    write(OUT / 'FIXED90_DIVERGENCE.json', result)
    lines = ['# 已完成fixed90变体离线分叉核查', '', '变化是文字或材料差异，不是错误数量；使用最终完成目录，保留原评分。', '',
             '| 对照 | 已计分/可比轨迹 | 首次行为分叉：普通/goal/无 | 普通回答变化 | goal回答变化 | final文字变化 | F1变化百分点 |',
             '|---|---:|---:|---:|---:|---:|---:|']
    for name, data in contrasts.items():
        fs = Counter(d['first_behavior_difference']['role'] if d['first_behavior_difference'] else 'none' for d in data['details'] if d['trajectory_comparable'])
        lines.append(f"| {name} | {data['planned_and_scored']}/{data['trajectory_comparable']} | {fs['ordinary']}/{fs['goal']}/{fs['none']} | {data['counts']['ordinary'].get('answer_changed', 0)} | {data['counts']['goal'].get('answer_changed', 0)} | {data['final_counts'].get('prediction_changed', 0)} | {100*data['mean_F1_delta']:+.4f} |")
    lines += ['', 'three_prompts_v1中的无nodes算法失败保留评分，不强行补成完整轨迹。A/B同时提供相对其真实selfcontained对照的分叉与相对原冻结P02的比较。',
              'no_refs同时删除解析句、history/current编号并扩展两个示例的描述短语；不是#字符的单因素实验。', '']
    (OUT / 'FIXED90_DIVERGENCE.md').write_text('\n'.join(lines), encoding='utf-8')


def corrected_diagnostic():
    new = OUT / 'diagnostic_v3'
    shutil.copytree(OLD, new)
    target = 'hotpotqa:5a87ab905542996e4f3088c1'
    patched = []
    for f in sorted((new / 'reviews').glob('*.json')):
        review = read(f)
        for label in review['labels']:
            if label.get('id') == target and label.get('step_id') == 2:
                assert label['explicit_binding_answer_step_ids'] == []
                label['explicit_binding_answer_step_ids'] = [1]
                label['binding_amendment_v3'] = 'Goal rewrite explicitly replaces arena description by Androscoggin Bank Colisee supplied in ordinary answer step1. Truth labels unchanged.'
                patched.append(rel(f))
                write(f, review)
    assert len(patched) == 1
    old_code = ROOT / 'analysis/p02_error_propagation_diagnostic_20261021/aggregate_diagnostic.py'
    source = old_code.read_text(encoding='utf-8')
    source = source.replace('from prepare_inventory import ROOT,OUT,read,rows,write,sha',
        'from build_offline import ROOT,OUT,read,rows,write,sha')
    source = source.replace("run=OUT/'offline_review_v2'", "run=OUT/'diagnostic_v3'")
    code = HERE / 'aggregate_diagnostic_v3.py'
    code.write_text(source, encoding='utf-8')
    (HERE / 'AGGREGATOR_PATH_CHANGE.diff').write_text(''.join(difflib.unified_diff(old_code.read_text(encoding='utf-8').splitlines(True), source.splitlines(True), fromfile=rel(old_code), tofile=rel(code))), encoding='utf-8')
    proc = subprocess.run([sys.executable, str(code)], cwd=ROOT, capture_output=True, text=True, encoding='utf-8')
    (OUT / 'AGGREGATION_LOG.json').write_text(json.dumps({'exit_code': proc.returncode, 'stderr': proc.stderr}, ensure_ascii=False, indent=2), encoding='utf-8')
    if proc.returncode:
        raise RuntimeError(proc.stderr)
    old, current = read(OLD / 'CONDITIONAL_PROBABILITIES.json'), read(new / 'CONDITIONAL_PROBABILITIES.json')
    before = {(v['dataset'], v['table']): v for v in old['tables']}
    after = {(v['dataset'], v['table']): v for v in current['tables']}
    changed = [key for key in before if before[key] != after[key]]
    assert changed == [('hotpotqa', 'A_bound_to_R')]
    mains = ['D_to_Y', 'A_history_to_R', 'A_to_Y_query', 'R_to_Y_query']
    assert all(before[ds, name] == after[ds, name] for ds in ['2wiki', 'hotpotqa'] for name in mains)
    events = rows(new / 'REWRITE_EVENTS.jsonl')
    unequal = [v for v in events if v['rewrite_correct'] != v['rewrite_target_correct']]
    assert not unequal
    amend = {'id': 'HP236_GOAL_ACTUAL_BINDING_STEP1', 'old_diagnostic_untouched': True, 'target_id': target,
        'step_id': 2, 'field': 'explicit_binding_answer_step_ids', 'before': [], 'after': [1],
        'evidence': {'prior_answer_step1': 'Lewiston Maineiacs played at Androscoggin Bank Colisee.',
                     'effective_goal_rewrite': 'How many people can the Androscoggin Bank Colisee seat?'},
        'semantic_truth_labels_changed': False, 'patched_review_copy': patched[0],
        'aggregator_original_sha256': sha(old_code), 'aggregator_new_sha256': sha(code)}
    write(OUT / 'DIAGNOSTIC_V3_AMENDMENT.json', amend)
    write(OUT / 'DIAGNOSTIC_V3_TABLE_DIFF.json', {'all_tables': len(before), 'changed': changed,
        'eight_dataset_main_tables_exactly_unchanged': True, 'unaffected_tables': 39,
        'before': before['hotpotqa', 'A_bound_to_R'], 'after': after['hotpotqa', 'A_bound_to_R'],
        'R_T_vs_conjunction_disagreeing_events': len(unequal),
        'definition': 'Retain frozen main endpoint R_F AND R_T; name it explicitly. R_T alone is a separate target-validity sensitivity endpoint, numerically equal on these saved events only.'})
    (new / 'VERSION_NOTE.md').write_text('# 离线诊断v3副本\n\n本目录继承旧诊断资料。只有HP236 goal实际绑定前序step1字段修正，以及由同seed2000次query聚类bootstrap重新生成的锁定标签与统计产物发生变化。旧REPORT/DESIGN是历史原件副本，当前解释以外层DIAGNOSTIC_V3_TABLE_DIFF.json和REWRITE_ENDPOINT_DEFINITION.md为准；不是新的模型评估。\n', encoding='utf-8')
    (OUT / 'REWRITE_ENDPOINT_DEFINITION.md').write_text('# 改写口径统一说明（新版本）\n\n保留既有四张主表的实际端点：生效改写正确=R_F∧R_T。R_F表示忠实保留当前所问关系与前序输入，R_T表示事实指代及目标有效；只按R_T的表明确命名为目标有效性补充表。旧设计将R_T称主口径的文字与实际统计不一致，本次以实际冻结计算作清晰命名，不静默改旧口径。\n\n全部1361个既有生效改写事件中，两端点无不一致项，因此本批数值相同，不代表概念相同。HP236只补充实际绑定step1，不变更两轴或子回答事实标签。受影响的仅HotpotQA A_bound_to_R补充表；四类主表在两个数据集上均逐字段保持一致。bootstrap原样保留query聚类、seed20261021、2000次及原抽样实现。\n', encoding='utf-8')


def prepare_review_packets():
    queries = rows(OLD / 'QUERY_LABELS_AND_OUTCOMES.jsonl')
    prior_cases = read(OLD / 'ROOT_CAUSE_CASES.json')['cases']
    prior = {v['id']: v for v in prior_cases}
    facts = {v['id']: v for v in rows(OLD / 'FACT_REFERENCE_PACKETS.jsonl')}
    failures = [v for v in queries if not v['final_correct']]
    assert len(failures) == 230
    successes = []
    for ds in ['2wiki', 'hotpotqa']:
        available = [v for v in queries if v['dataset'] == ds and v['final_correct']]
        available.sort(key=lambda v: hashlib.sha256(f'{SEED}|information-flow|{ds}|{v["id"]}'.encode()).hexdigest())
        successes += available[:20]
    cohort = [{**v, 'review_selection': 'all_nonfullscore' if not v['final_correct'] else 'seeded_fullscore_control'} for v in failures + successes]
    assert len(cohort) == 270 and len({v['id'] for v in cohort}) == 270
    supplemental = [{**next(q for q in queries if q['id'] == v['id']), 'review_selection': 'historical_case_outside_probability_sample'} for v in prior_cases if v['id'] not in {q['id'] for q in cohort}]
    all_items = cohort + supplemental
    jsonl(OUT / 'INFORMATION_FLOW_COHORT.jsonl', cohort)
    jsonl(OUT / 'SUPPLEMENTAL_HISTORICAL_CASES.jsonl', supplemental)
    index = []
    for q in all_items:
        p = ROOT / q['source']
        assert sha(p) == q['source_sha256']
        trace = read(p)
        fp = facts[q['id']]
        support_ids = set(map(str, fp.get('gold_doc_ids', [])))
        support_titles = set(fp.get('supporting_facts', {}).get('title', [])) if isinstance(fp.get('supporting_facts'), dict) else {v[0] for v in fp.get('supporting_facts', [])}
        if not support_titles and fp.get('gold_documents'):
            support_titles = {v['title'] for v in fp['gold_documents']}
        coverage = []
        for node in trace['nodes']:
            coverage.append({'step_id': node['step_id'], 'role': node['role'],
                'reference_document_id_overlap_only_not_sufficiency': {
                    route: sorted(support_ids & {str(d['doc_id']) for d in (node.get(route) or {}).get('docs', [])})
                    for route in ['original_retrieval', 'rewritten_retrieval', 'reader_packet']},
                'reference_document_title_overlap_only_not_sufficiency': {
                    route: sorted(support_titles & {d['source'] for d in (node.get(route) or {}).get('docs', [])})
                    for route in ['original_retrieval', 'rewritten_retrieval', 'reader_packet']}})
        name = f"{q['dataset']}_{q['review_index']:03d}.json"
        path = OUT / 'review_packets' / name
        packet = {'id': q['id'], 'selection': q['review_selection'], 'source': q['source'], 'source_sha256': q['source_sha256'],
            'existing_labels_and_native_score_unchanged': q, 'trace': trace, 'frozen_reference_material_for_review_only': fp,
            'reference_doc_id_coverage_hints': coverage,
            'historical_case_finding': prior.get(q['id']),
            'followup_review_status': 'pending',
            'warning': 'String/document-ID overlap is an index hint, not proof of correct entity, relation, time, completeness or sufficient evidence.'}
        write(path, packet)
        index.append({'id': q['id'], 'dataset': q['dataset'], 'review_index': q['review_index'],
                      'selection': q['review_selection'], 'existing_native_fullscore': q['final_correct'],
                      'packet': rel(path), 'historical_finding_available': q['id'] in prior,
                      'followup_review_status': 'pending'})
    jsonl(OUT / 'REVIEW_INDEX.jsonl', index)
    write(OUT / 'SAMPLING.json', {'seed': SEED, 'population': '723 completed nonempty P02 formal historical flows',
        'nonfullscore': 230, 'fullscore_controls': 40, 'primary_cohort': 270,
        'sampling': 'Take 20 smallest SHA256(seed|information-flow|dataset|id) within each dataset native-fullscore stratum.',
        'uses_question_or_failure_type_for_success_selection': False,
        'fullscore_ids': [v['id'] for v in successes], 'historical_cases': len(prior_cases),
        'historical_case_overlap_primary': len(prior_cases) - len(supplemental), 'supplemental_historical_cases': len(supplemental),
        'denominators_separate': True, 'new_inference': False})
    write(OUT / 'REVIEW_PROGRESS.json', {'primary_cohort': len(cohort), 'supplemental': len(supplemental),
        'packets_prepared': len(index), 'historical_cases_with_prior_findings': len(prior_cases),
        'followup_semantic_reviews_completed': 0, 'pending_followup_reviews': len(index),
        'note': 'Packet preparation and inherited case findings are not newly completed reviews.'})


def main():
    resume = sys.argv[1:] == ['--resume-packets']
    if resume:
        before = read(OUT / 'HISTORICAL_INPUT_HASHES.json')
        assert read(OUT / 'DIAGNOSTIC_V3_TABLE_DIFF.json')['eight_dataset_main_tables_exactly_unchanged']
    else:
        assert not sys.argv[1:]
        OUT.mkdir(parents=True, exist_ok=False)
        before = inventory(OLD)
        write(OUT / 'HISTORICAL_INPUT_HASHES.json', before)
        compare_completed_variants()
        corrected_diagnostic()
    prepare_review_packets()
    after = inventory(OLD)
    assert before == after
    write(OUT / 'VALIDATION.json', {'utc': datetime.now(timezone.utc).isoformat(), 'old_diagnostic_all_64_file_bytes_unchanged': before == after,
        'historical_files_checked': len(before), 'new_API_requests': 0, 'new_retrieval_searches': 0,
        'new_GPU_work': False, 'main_evaluation_not_resumed': True, 'original_evaluation_plan_not_written': True,
        'stage0_and_packet_preparation_completed': True, 'semantic_review_not_complete': True})
    print(json.dumps({'built': rel(OUT), 'historical_files_unchanged': len(before), 'new_API_requests': 0}))


if __name__ == '__main__':
    main()
