"""Append fixed next20 nonfullscore per dataset, with explicit scope per query.

All findings below are authored after reading saved readers and final contexts.
Quote assertions verify locations only. No gold-string overlap is a semantic
sufficiency rule, and no existing truth labels or endpoints are changed.
"""
from collections import Counter
from datetime import datetime, timezone
from build_offline import ROOT, OUT, OLD, read, rows, write, jsonl, inventory, sha
from first_manual_review import packet, node, entry
from complete_success_controls import evidence


def main():
    before = inventory(OUT)
    prior = read(OUT / 'MANUAL_INFORMATION_FLOW_REVIEWS_V4.json')['reviews']
    batch = []

    def add(ds, idx, requirements, category, detail, quotes=(), sufficient=True, use=True, limit=None):
        p = packet(ds, idx)
        es = [evidence(p, *q) for q in quotes]
        f = {'location': 'saved reader, QA, goal and final alignment', 'category': category, 'confirmed': True, 'detail': detail}
        if limit:
            f['limit'] = limit
        r = entry(p, requirements, [f], es, sufficient, use)
        batch.append(r)
        return p, r

    add('2wiki', 275, ['Claudia Myers directed the specified Kettle of Fish.', 'Employer is American University, specifically its School of Communication.'],
        'supported_employer_subunit_reference_parent_institution', 'Actual biography supplies associate professor role at American University School of Communication. Goal/final retain school subunit; reference only parent university, producing partial match.',
        [(1, 'Kettle of Fish (film)', 'directed by Claudia Myers'), (2, 'Claudia Myers', "American University's School of Communication")])
    add('2wiki', 284, ['John Beal composed Terror in the Aisles.', 'His birthplace is Santa Monica, California.'],
        'supported_birth_city_state_reference_state_only', 'Goal reader obtains explicit birthplace, goal/final keep city plus state; reference only California. This is extra source-supported specificity, not confusion with the director.',
        [(1, 'Terror in the Aisles', 'composed by John Beal'), (2, 'John Beal (composer)', 'born in Santa Monica, California')])
    p, r = add('2wiki', 288, ['Composer is Mikey McCleary.', 'Distinguish Indian-born birthplace from New Zealand nationality descriptor.'],
        'final_selects_birth_country_instead_of_nationality', 'Actual composer reader and goal both say Indian-born New Zealand composer. Final outputs India although the requested nationality/country descriptor New Zealand is present in goal. Correct intermediate facts do not prevent final attribute selection error.',
        [(1, 'Margarita with a Straw', 'composed by Mikey McCleary'), (2, 'Mikey McCleary', 'Indian-born New Zealand')], use=False)
    assert 'New Zealand' in p['trace']['final_context'] and p['trace']['prediction'] == 'India'
    add('2wiki', 290, ['Song performer Ola is Ola Svensson / Brother Leo.', 'Birth city Lund with Skane qualifier.'],
        'correct_performer_alias_and_birthplace_extra_region', 'Reader connects Ola Svensson to Brother Leo and Lund, Skane; goal/final preserve both city and region. Native reference only Lund.',
        [(1, 'S.O.S. (Ola song)', 'Swedish singer Ola Svensson'), (2, 'Brother Leo (musician)', 'in Lund, Skåne')])
    add('2wiki', 292, ['Need origin countries of both films, preserving 1939 Flying Fifty-Five version.', 'Country for Approaching Midnight is required for comparison.'],
        'one_comparison_operand_origin_never_obtained', 'Flying Fifty-Five British origin is explicit. No Approaching Midnight document enters any saved candidate route, ordinary answer abstains and goal/final retain that absence. A different film origin cannot substitute.',
        [(1, 'Flying Fifty-Five', '1939 British sports-drama film')], sufficient=False, use=None)
    add('2wiki', 293, ['She Who Must Burn director is Larry Kent.', 'Source distinguishes Canadian filmmaker descriptor from Johannesburg South Africa birthplace.'],
        'reference_birth_origin_vs_source_nationality_descriptor', 'Actual biography calls Kent Canadian and separately states South African birthplace. Goal/final use Canadian; native reference South Africa corresponds to the birthplace field. Existing factual labels retained; this is an origin/nationality reference distinction, not evidence that final invented Canada.',
        [(1, 'She Who Must Burn', 'directed by Larry Kent'), (2, 'Larry Kent (filmmaker)', 'Canadian filmmaker')],
        limit='This review preserves quoted source descriptors and does not independently establish a complete formal citizenship history.')
    add('2wiki', 296, ['Pichaqani is in Bolivia.', 'Pukintika lies on Bolivia/Chile border.', 'Check whether there is a shared country, not whether country sets are identical.'],
        'common_country_test_changed_to_exclusive_set_equality', 'Both country facts reach actual reader, QA and final. Goal explicitly acknowledges shared Bolivia but adds not exclusively same; final No follows the changed exclusivity criterion. Existing goal factual label stays True because the full sentence still states true geography.',
        [(1, 'Pichaqani (Quillacollo-Tapacarí)', 'Bolivian Andes'), (2, 'Pukintika', 'border of Bolivia and Chile')], use=False)
    add('2wiki', 304, ['Charles Younger father is Charlemagne.', 'Distinguish Frankish people descriptor from state name Carolingian Empire.'],
        'historical_people_vs_state_name_native_reference', 'Reader ties Charlemagne to Franks/Frankish state and Carolingian Empire; goal/final use Frankish. Reference uses the empire name. Existing true descriptor label retained; no lost father identity is observed.',
        [(1, 'Charles the Younger', 'second son of Charlemagne'), (2, 'Charlemagne', 'Frankish state')],
        limit='This does not introduce a modern legal citizenship criterion for the medieval question.')
    add('2wiki', 307, ['Claudio Silva spouse is Juliana Freire.', 'Her undergraduate studies Ceara and doctorate Stony Brook must stay linked to education level.'],
        'multiple_supported_education_levels_reference_doctorate_only', 'Source/goal distinguish undergraduate studies at Federal University of Ceara from doctorate Stony Brook. Final returns both institutions; reference only Stony Brook. Additional true education location is preserved rather than declared false.',
        [(1, 'Claudio Silva (computer scientist)', 'his wife Juliana Freire'), (2, 'Juliana Freire', 'earned her doctorate from Stony Brook University')])
    add('2wiki', 312, ['Father Charles Fat must be selected rather than Charles Martel etc.', 'Birthplace, not birthdate or territory he later ruled, is needed.'],
        'birthplace_relation_not_present_despite_correct_person_document', 'Correct father and his biography are read. Biography supplies13 June839 and later East Francia rule but no explicit birthplace relation. Goal preserves date and honest place uncertainty; final abstains. Mere occurrence of East Francia elsewhere is not enough.',
        [(1, 'Bernard (son of Charles the Fat)', 'only child of Emperor Charles the Fat'), (2, 'Charles the Fat', '13 June 839')], sufficient=False, use=None)
    add('2wiki', 314, ['John Mason planter father is George Mason IV.', 'Need burial location, not birthplace, residence Gunston Hall, or unrelated Hancock burial.'],
        'burial_relation_not_obtained_from_correct_biography', 'Reader correctly identifies George Mason but supplies no matching burial statement. A buried keyword occurs only in an unrelated candidate John Hancock. Goal/final abstention is retained as locally reasonable.',
        [(1, 'John Mason (planter)', 'son of George Mason'), (2, 'George Mason', 'built Gunston Hall')], sufficient=False, use=None)
    p, r = add('2wiki', 319, ['Father is Ferenc Esterhazy1533–1604.', 'Birthplace must be a birth relation, not inherited Galanta estate/title.'],
        'inherited_estate_used_as_birthplace_existing_fact_workitem', 'Father biography supports inheritance of Galanta and title, not birth there. Goal infers birthplace from inheritance; final Galanta spelling differs from frozen reference. Prior approved birthplace conflict Galanta versus Pressburg remains unresolved; do not classify pure accent matching before truth is settled.',
        [(1, 'Tamás Esterházy (1570–1616)', 'Ferenc Esterházy'), (2, 'Ferenc Esterházy (1533–1604)', 'inherited the lordship of Galánta')], sufficient=None, use=None)
    assert p['existing_labels_and_native_score_unchanged']['goal_answer_correct'] is None
    r['review_status'] = 'pending_work_item_after_material_review'
    r['pending_work_item'] = {'id': 'WIKI319_EXISTING_BIRTHPLACE_CONFLICT', 'query_id': r['id'],
        'question': 'Existing approved Galanta versus Pressburg birthplace conflict remains; inheritance does not settle it.',
        'source_existing_workitem': 'offline_review_v2/PENDING_FACTS.json', 'changes_binary_truth_label': False, 'needs_network_now': False}
    add('2wiki', 326, ['Song has multiple listed composers.', 'Avicii is the deceased composer with death place Muscat Oman; do not transfer place to live co-composers.'],
        'valid_deceased_composer_selected_extra_country', 'Reader lists three composers, and Avicii biography explicitly says died in Muscat Oman. Goal distinguishes the living co-composers; final city plus country versus reference city yields partial match.',
        [(1, 'We Write the Story', 'Avicii'), (2, 'Avicii', 'died by suicide in Muscat, Oman')])
    add('2wiki', 327, ['Inside Pop documentary maker is David Oppenheim.', 'Employment dates distinguish CBS and NYU School of Arts.'],
        'supported_employer_school_unit_reference_university', 'Goal preserves CBS1962–67 and NYU1969–91 roles. Final returns NYU School of Arts; native reference only NYU. No mistaken filmmaker or omitted target university is observed.',
        [(1, 'Inside Pop: The Rock Revolution', 'by David Oppenheim'), (2, 'David Oppenheim (clarinetist)', 'New York University School of the Arts')])
    add('2wiki', 329, ['A Man Escaped soundtrack uses Mozart Great Mass.', 'Need Mozart death location Vienna after correct composer extraction.'],
        'visible_composer_music_reference_not_extracted_missing_downstream_death_relation', 'Actual film passage names Mozart soundtrack, but ordinary answer says composer not identified. Goal reader also contains the Mozart music reference yet repeats inability. No Mozart death-place biography reaches saved readers; final needs more than simply recognizing the visible name.',
        [(1, 'A Man Escaped', "Mozart's")], sufficient=False, use=None)
    add('2wiki', 331, ['11PM performer Maluma.', 'Birth city Medellin with Colombia country qualifier.'],
        'correct_artist_birth_city_with_extra_country', 'Actual artist reader states born/raised Medellin and Colombian identity; goal/final retain Medellin Colombia. Native reference only city.',
        [(1, '11 PM (song)', 'Colombian singer Maluma'), (2, 'Maluma (singer)', 'Born and raised in Medellín')])
    add('2wiki', 332, ['Boris father is specified Prince Karl.', 'Birthplace at city granularity Coburg is the native target; ancestral Saxe-Coburg names are not birth-place proof.'],
        'coarse_birth_country_returned_without_reference_city_relation', 'Father identity is correct. Saved father biography lacks an explicit birth-place statement; Coburg appears as ancestral title only. Goal/final return Germany, the already-accepted broader place fact, but no city relation reaches final. Native Coburg gives zero; do not treat every Coburg token as evidence.',
        [(1, 'Prince Boris of Leiningen', 'Prince Karl of Leiningen'), (2, 'Prince Karl of Leiningen', '2 January 1928')], sufficient=False, use=None)
    add('2wiki', 346, ['Machi composer Reihana.', 'Children include GV Prakash Kumar and Bhavani Sree.'],
        'multiple_true_children_reference_single_child', 'Actual biography explicitly names both children and goal/final preserve both; reference only GV Prakash Kumar. Existing incomplete/collection rule retained; additional named child is true rather than a factual error.',
        [(1, 'Machi (film)', 'musical score by A. R. Reihana'), (2, 'A. R. Reihana', 'mother of G. V. Prakash Kumar and Bhavani Sree')])
    add('2wiki', 347, ['Need producer counts/credits for both films, not cast membership.', 'Baahubali named producers two; Manhattan cast is not producer list.'],
        'missing_second_producer_list_blocks_comparison', 'Reader gives two named Baahubali producers but Manhattan Night passage only writer/director and cast. Ordinary/goal correctly decline unknown producer count; final abstains. Native triples are not assumed exhaustive real-world film credits.',
        [(1, 'Baahubali 2: The Conclusion', 'produced by Shobu Yarlagadda and Prasad Devineni'), (2, 'Manhattan Night', 'film stars Adrien Brody')], sufficient=False, use=None)
    p, r = add('2wiki', 348, ['The Pledge US origin.', 'Mother of George can have Nigerian and US production origin; need shared-country relation.'],
        'partial_country_descriptor_used_as_disjoint_origin_proof', 'Second ordinary reader lacks target and abstains. Goal subsequently reads Nigerian descriptor and says No. Prior frozen festival-catalog check established US origin too, so a true Nigerian label cannot prove no shared US. Final context has only the partial descriptor; more source-complete origin information is needed.',
        [(1, 'The Pledge (film)', '2001 American'), (3, 'Mother of George', '2013 Nigerian drama film')], sufficient=False, use=False)
    r['evidence'].append({'route': 'prior frozen primary festival fact check, no new network', 'path': 'offline_review_v2/WEB_FACT_CHECKS.json#348', 'verified_fact': next(c['verified_fact'] for c in read(OLD/'WEB_FACT_CHECKS.json')['checks'] if c['review_index']==348)})

    add('hotpotqa', 39, ['Contemporary champion is Phil Hill.', 'Distinction is only American-born winner; exact birthdate not needed.'],
        'target_birth_distinction_preserved_despite_unneeded_date_abstention', 'Pollack and Hill sources explicitly support unique American-born champion. Unneeded Pollack birthdate branch abstains; goal/final still preserve requested distinction. Reference American-born versus longer answer gives partial match.',
        [(1, 'Bill Pollack', 'first and only U.S. born world grand prix champion'), (3, 'Phil Hill', 'only American-born driver')])
    add('hotpotqa', 45, ['Identify physical cliff dwellings called dwelling place of dead, with construction duration.', 'Conceptual Sheol is not the physical target.'],
        'scope_ambiguous_description_bound_to_wrong_type_and_propagated', 'Step1 reader mentions Sheol realm in Heaven in Judaism; answer binds phrase to it. Later rewrites ask when/over centuries Sheol was built, retrieving even Sheol album. Reference cliff dwelling/Montezuma documents never enter saved candidates; goal concludes not built and final abstains.',
        [(1, 'Heaven in Judaism', 'realm of the dead')], sufficient=False, use=None)
    add('hotpotqa', 47, ['Torrid first location Brea Mall in Brea California.', 'Return asked California city.'],
        'goal_direct_original_evidence_recovers_target_after_ordinary_abstention', 'Ordinary first-location reader lacks the fact and abstains. Goal original-query reader directly supplies Brea Mall in Brea California; final Brea satisfies asked city, reference adds California.',
        [(2, 'Torrid (clothing retailer)', 'first location opened in the Brea Mall in Brea, California')])
    add('hotpotqa', 48, ['An unspecified1993-born golfer is not uniquely identified.', 'Native selected path uses Spieth and2015 FedEx Cup; alternatives need golfer-to-tournament binding.'],
        'underconstrained_golfer_candidate_set_missing_reference_path', 'Ordinary answer lists several true1993 golfers but omits Spieth. Goal supplies other true tournament participations and Justin Thomas2017PGA Championship; final abstains. Native reference2015FedExCup follows Spieth, a path not covered. Do not claim all true alternative tournaments answer the hidden selected target or that the original wording uniquely selected one.',
        [], sufficient=None, use=None,
        limit='Goal facts retain old True label; this scope review identifies under-specification and route coverage, not a new factual judge.')
    add('hotpotqa', 49, ['Smithsonian portrait person Mary OConnell, alias Sister Anthony.', 'Florence Nightingale is descriptive bridge, not an additional requested answer person.'],
        'correct_portrait_alias_plus_unasked_bridge_in_final', 'Ordinary first answer is generic gallery background, not the asked portrait. Goal finds Mary OConnell and actual source supplies Sister Anthony alias; final returns Mary portrait AND Florence Nightingale. Alias mismatch explains no overlap with Sister Anthony reference, and extra bridge also violates answer scope.',
        [(3, "Mary O'Connell", 'better known as Sister Anthony'), (2, 'Florence Nightingale', 'founder of modern nursing')], use=False)
    add('hotpotqa', 50, ['Need pack-hunting property for both breeds.', 'Cretan Hound being a hunting breed alone does not imply pack use or absence.'],
        'second_boolean_property_not_established', 'First reader explicitly says pack hunting. Cretan Hound snippet is truncated after hunting-breed identity with no pack statement. Ordinary/goal retain uncertainty and final abstains; native No is not inferred simply from missing wording.',
        [(1, 'Chien Français Blanc et Orange', 'used for hunting in packs'), (2, 'Cretan Hound', 'hunting breed of dog')], sufficient=False, use=None)
    add('hotpotqa', 52, ['Institute namesake Louis Mountbatten.', 'Kinship to ElizabethII second cousin once removed, not his uncle relationship to Philip.'],
        'correct_kinship_answer_full_sentence_instead_of_relation_only', 'Reader explicitly distinguishes uncle of Philip and second cousin once removed of Elizabeth. Goal/final preserve correct relation but final copies full identifying sentence; reference only relation phrase.',
        [(1, 'Mountbatten Institute', 'Named in honour of Louis Mountbatten'), (2, 'Louis Mountbatten, 1st Earl Mountbatten of Burma', 'second cousin once removed of Elizabeth II')])
    add('hotpotqa', 53, ['Away captain2015game Jonathan Toews, not home captainFoligno.', 'Requested hockey position centre.'],
        'correct_requested_position_reference_includes_nationality_profession', 'Reader identifies away captain and his centre position; goal/final preserve centre. Native reference Canadian professional ice hockey centre adds attributes not requested as the position.',
        [(1, '60th National Hockey League All-Star Game', 'Jonathan Toews'), (1, 'Jonathan Toews', 'professional ice hockey centre')])
    p, r = add('hotpotqa', 54, ['Programme airs AdultSwim block of CartoonNetwork.', 'Founder attribution has a verified Turner alternative to single Cohen reference.'],
        'verified_alternative_founder_attribution_native_single_reference', 'Programme reader binds AdultSwim to channelCartoonNetwork. Goal/final Ted Turner differs from Betty Cohen reference. Prior frozen contemporary launch/cofounder check accepted Turner; no new lookup or label reversal.',
        [(1, 'The Greatest Event in Television History', "Cartoon Network's late night programming block Adult Swim")])
    r['evidence'].append({'route':'prior frozen fact check','path':'offline_review_v2/WEB_FACT_CHECKS.json#54','verified_fact':next(c['verified_fact'] for c in read(OLD/'WEB_FACT_CHECKS.json')['checks'] if c['review_index']==54)})
    add('hotpotqa', 65, ['Gifford band1980–87 MidnightOil.', 'Name selection method drawing out of hat, not incidental member move/date.'],
        'correct_name_selection_method_with_extra_source_context', 'Goal reader explicitly states name drawn out of a hat. Goal/final retain the method but copy full Farm/name-change chronology too; reference only concise method.',
        [(1, 'Peter Gifford', 'Midnight Oil'), (2, 'Midnight Oil', 'drawing the name out of a hat')])
    add('hotpotqa', 68, ['Christian-influenced derived category AfroAmerican religions is useful bridge.', 'Need creolized Kongo-language relation, not any African religion description.'],
        'visible_religion_bridge_not_extracted_target_language_unretrieved', 'Step1 actual reader identifies AfroAmerican religion derived from traditional religions with Christian influence, but answer says unspecified. Subsequent broad questions never acquire Kongo material; final lacks target language. Both useful bridge extraction and target coverage are missing.',
        [(1, 'Afro-American religion', 'some influence from Christianity')], sufficient=False, use=None)
    add('hotpotqa', 72, ['NorthernLights is GoldenCompass NorthAmerican title.', 'BBC participates in audiobook recording; keep organization naming scope.'],
        'company_name_extension_reference_parent_bbc', 'Reader names BBC and Cavalcade recording and final context also has AudioGO. Goal specifies BBC Audiobooks later AudioGO; final BBC Audiobooks versus reference BBC yields partial match. Existing factual label retained; this is not evidence that the novel title was lost.',
        [(1, 'Northern Lights (novel)', 'The Golden Compass'), (2, 'Northern Lights Audio', 'BBC and Cavalcade audiobook')])
    add('hotpotqa', 75, ['Airline fits Terminal2Narita and ValueAlliance: VanillaAir.', 'Wholly-owned parent AllNipponAirways.'],
        'correct_parent_company_full_name_reference_abbreviated', 'Actual airline reader supplies both office location and ownership; goal/final retain AllNipponAirways. Native reference AllNippon omits Airways.',
        [(1, 'Vanilla Air', 'wholly owned by All Nippon Airways')])
    add('hotpotqa', 78, ['Expedition includes Garry ofSpokanes among multiple members.', 'Spokane reservation total237square miles, not615square kilometres.'],
        'multi_candidate_tribal_path_correct_area_units_retained', 'Ordinary answers retain several true tribe candidates. Goal reader supplies Spokane237sqmi/615sqkm and final selects237square miles, correct unit. Reference237 omits unit.',
        [(1, 'Walla Walla expeditions', 'Garry of the Spokanes'), (3, 'Spokane people', '237 square miles')])
    p, r = add('hotpotqa', 83, ['Astronomer FredHoyle.', 'Landmark paper formal title Synthesis ofElements inStars equals B2FH/BFH label.'],
        'correct_formal_paper_title_alias_without_direct_saved_reader_paper', 'Goal supplies correct formal paper title and coauthors, validated in frozen dataset. Saved readers have Hoyle/nucleosynthesis material but no paper-title/B2FH passage. Final chooses formal title; native BFH gives zero. Do not call this retrieved paper evidence or fact error just because aliases have no token overlap.',
        [(1, 'Fred Hoyle', 'formulated the theory of stellar nucleosynthesis')])
    r['evidence'].append({'route':'frozen reference material only','source':'B2FH paper','detail':'Reference packet explicitly states formal title Synthesis of the Elements in Stars and BFH label.'})
    add('hotpotqa', 84, ['Target tree cottonwood/Populus and Alamorio name alamo+rio relation.', 'Oak is a distracting alternative, not the tree part of this community name.'],
        'wrong_tree_binding_and_unretrieved_name_etymology', 'Step1 general geography yields oaks; partial community list gives Imperial/Felicity. Goal rewrite binds oak and retrieves other places; neither Alamorio nor Populus enters saved candidates. Goal makes unsupported universal No; final abstains rather than copying that negative.',
        [(1, 'Oak', 'genus')], sufficient=False, use=None)
    p, r = add('hotpotqa', 86, ['First identify invented termJehovah.', 'Then answer term referent GodofIsrael, not repeat inventor or term.'],
        'goal_repeats_bridge_term_despite_visible_referent_relation', 'Rewrite correctly asks Jehovah referent and actual goal reader explicitly says name ofGodofIsrael. Goal repeats Galatino inventorJehovah and final outputs term instead of requested referent. Relation evidence reaches goal reader but not its answer/helper.',
        [(1, 'Pietro Colonna Galatino', 'Latinized term Jehovah'), (2, 'Jehovah', 'proper names of the God of Israel')], sufficient=None, use=False)
    assert 'God of Israel' not in p['trace']['final_context']
    add('hotpotqa', 88, ['IfThen roles: librettoBrianYorkey, scoreTomKitt, directorMichaelGreif.', 'Creator question should not silently collapse distinct roles.'],
        'multiple_true_musical_creation_roles_native_single_creator', 'Goal reader states all three roles and goal preserves them. Final returns book/music authorsBrianYorkey andTomKitt; reference onlyBrianYorkey. Scope of made is broad, so this is not automatically a false extra composer.',
        [(3, 'If/Then', 'libretto by Brian Yorkey and a theatrical score by Tom Kitt')],
        limit='No new exclusive meaning of made is imposed; frozen native reference remains unchanged.')
    add('hotpotqa', 92, ['Rossiya locatedRussia.', 'Asked largest-what category country, not a generic largest island.'],
        'goal_original_evidence_bypasses_wrong_malformed_subquestion', 'Ordinary second question malformed largest-largest elicitsGreenland island, already labelledFalse. Goal reader explicitly states Russia largestcountry and goal/final country correctly follow original question. Reference repeats largestcountry and yields partial match.',
        [(1, 'Rossiya Airlines', 'Saint Petersburg'), (3, 'Russian presidential aircraft', 'Russia is the largest country on Earth')])
    add('hotpotqa', 93, ['60000sqft campus must identify Bigelow laboratory, not any marine lab.', 'Its target state Maine, not WoodsHoleMassachusetts.'],
        'distinctive_campus_constraint_ignored_wrong_lab_bound', 'Reader contains MarineBiologicalLaboratory WoodsHole but not Bigelow or60000sqft relation. Ordinary answer binds wrong campus based on generic laboratory overlap. Goal rewrite asks WoodsHole state and final Massachusetts follows that binding; target site never retrieved.',
        [(1, 'Marine Biological Laboratory', 'Woods Hole, Massachusetts')], sufficient=False, use=False)

    assert len(batch)==40 and len({r['id'] for r in batch})==40
    selection=read(OUT/'BATCH005_SELECTION.json')['items']
    assert [r['id'] for r in batch]==[r['id'] for r in selection]
    assert not {r['id'] for r in batch}&{r['id'] for r in prior}
    all_reviews=prior+batch
    pending=[r['pending_work_item']|{'query_id':r['id']} for r in all_reviews if r.get('pending_work_item')]
    complete=sum(r['review_status']=='completed_for_stated_information_flow_checks' for r in all_reviews)
    assert len(all_reviews)==110 and complete==107 and len(pending)==3
    assert not (OUT/'MANUAL_INFORMATION_FLOW_REVIEWS_V5.json').exists()
    write(OUT/'MANUAL_INFORMATION_FLOW_REVIEWS_BATCH005.json',{'utc':datetime.now(timezone.utc).isoformat(),'selection':'Frozen next20 per dataset ascending review_index','reviews':batch})
    write(OUT/'MANUAL_INFORMATION_FLOW_REVIEWS_V5.json',{'utc':datetime.now(timezone.utc).isoformat(),'status':'partial_offline_information_flow_review','material_reviewed':110,'completed_declared_scope':complete,'pending_work_items':len(pending),'reviews':all_reviews,'limits':'Existing stage truth labels and native endpoints unchanged; evidence/interpretation/coverage stated per query, not independent gold or causal attribution.'})
    write(OUT/'INFORMATION_FLOW_PENDING_WORK_ITEMS_V5.json',{'not_a_third_truth_label':True,'items':pending})
    index=rows(OUT/'REVIEW_INDEX_V4.jsonl');by={r['id']:r for r in all_reviews}
    for r in index:
        if r['id'] in by:r.update(followup_review_status=by[r['id']]['review_status'],review_file='MANUAL_INFORMATION_FLOW_REVIEWS_V5.json#'+r['id'])
    jsonl(OUT/'REVIEW_INDEX_V5.jsonl',index)
    cohort=rows(OUT/'INFORMATION_FLOW_COHORT.jsonl')
    queue=[r for ds in ['2wiki','hotpotqa'] for r in sorted([q for q in cohort if q['dataset']==ds and q['review_selection']=='all_nonfullscore' and q['id'] not in by],key=lambda q:q['review_index'])]
    assert len(queue)==160
    jsonl(OUT/'REMAINING_NONFULLSCORE_QUEUE_V5.jsonl',[{'id':r['id'],'dataset':r['dataset'],'review_index':r['review_index'],'review_order':i+1} for i,r in enumerate(queue)])
    historical={r['id'] for r in read(OLD/'ROOT_CAUSE_CASES.json')['cases']}
    progress=read(OUT/'REVIEW_PROGRESS_V4.json')
    progress.update(material_reviewed_items=110,followup_semantic_reviews_completed=complete,pending_fact_or_interpretation_work_items=len(pending),
        pending_followup_reviews=278-complete,not_yet_started_items=168,reviewed_selections={'seeded_fullscore_control':40,'all_nonfullscore':70},
        reviewed_nonfullscore_per_dataset={'2wiki':30,'hotpotqa':40},remaining_nonfullscore=160,
        historical_36_newly_followup_checked=len(historical&set(by)),historical_36_pending_followup=len(historical-set(by)),
        note='V5 overlay current;40success+70nonfullscore materially read,107declared-scope complete,3workitems. Failure prefixes are ordered, not random; remaining order fixed.')
    write(OUT/'REVIEW_PROGRESS_V5.json',progress)
    groups={}
    for selection in ['seeded_fullscore_control','all_nonfullscore']:
        rr=[r for r in all_reviews if r['selection']==selection]
        groups[selection]={'material_reviewed':len(rr),'dataset_counts':dict(Counter(r['dataset'] for r in rr)),
            'completed':sum(r['review_status']=='completed_for_stated_information_flow_checks' for r in rr),
            'pending':sum(r['review_status']=='pending_work_item_after_material_review' for r in rr),
            'nonexclusive_findings':dict(Counter(f['category'] for r in rr for f in r['findings']))}
    write(OUT/'REVIEWED_SUCCESS40_NONFULLSCORE70_DESCRIPTIVE.json',{'scope':'Reviewed material only; seeded success sample and ordered/initial failure cases have different selection and dataset mix. No prevalence or causal ranking.','groups':groups})
    assert read(OUT/'HISTORICAL_INPUT_HASHES.json')==inventory(OLD)
    assert all(sha(ROOT/name)==value for name,value in before.items())
    (OUT/'CURRENT_REVIEW_VERSION_V4.json').write_bytes((OUT/'CURRENT_REVIEW_VERSION.json').read_bytes())
    write(OUT/'VALIDATION_V5.json',{'utc':datetime.now(timezone.utc).isoformat(),'old_diagnostic64_unchanged':True,'all_prior_followup_files_unchanged_before_pointer_update':len(before),
        'V4_pointer_preserved':True,'new_material_reviews':40,'total_material_reviews':110,'declared_scope_complete':complete,'pending_work_items':len(pending),
        'API_requests':0,'new_retrieval':0,'GPU':False,'stage_truth_labels_or_scores_changed':False})
    write(OUT/'CURRENT_REVIEW_VERSION.json',{'version':5,'readme':'README_V5.md','reviews':'MANUAL_INFORMATION_FLOW_REVIEWS_V5.json','index':'REVIEW_INDEX_V5.jsonl','progress':'REVIEW_PROGRESS_V5.json','remaining_failures':'REMAINING_NONFULLSCORE_QUEUE_V5.jsonl','hypotheses':'REPAIR_HYPOTHESIS_EXPERIMENT_MAPPING_V5.json','previous_versions_preserved':True})
    print({'appended':40,'material_reviewed':110,'completed':complete,'pending':len(pending),'remaining_failures':160})


if __name__=='__main__':main()
