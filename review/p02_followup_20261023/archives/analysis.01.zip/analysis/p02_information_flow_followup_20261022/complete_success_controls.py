"""Append the remaining 20 seeded success controls; preserve all prior versions.

Judgments concern the explicitly listed information requirements. Native
full-score is a selection stratum, not a newly assigned factual correctness
label. Frozen binary labels and scores are never rewritten.
"""
from collections import Counter
from datetime import datetime, timezone
from build_offline import ROOT, OUT, OLD, read, rows, write, jsonl, inventory, sha
from first_manual_review import packet, node, ev, entry
from extend_manual_review import reviewed


def evidence(p, step, title, quote):
    docs = [d for d in node(p, step)['reader_packet']['docs'] if d['source'] == title and quote in d['text']]
    assert docs, (p['id'], step, title, quote)
    return ev(step, 'reader_packet', docs[0], quote)


def main():
    before_followup = inventory(OUT)
    prior = read(OUT / 'MANUAL_INFORMATION_FLOW_REVIEWS_V2.json')['reviews']
    batch = []

    p = packet('2wiki', 526)
    es = [evidence(p, 1, "It's Great When You're Straight...Yeah", 'Released in 1995'),
          evidence(p, 2, 'The Beginning (The Black Eyed Peas album)', 'released on November 26, 2010')]
    batch.append(reviewed(p, ['First specified album released 1995.', 'Black Eyed Peas album The Beginning released 2010.', 'Return earlier album, distinguishing album date from single dates.'], es,
        'album_dates_preserved_correct_earlier_selection', 'Reader, ordinary answers and goal retain 1995 versus 2010. Final selects the 1995 album; later listed single releases do not replace the album date.'))

    p = packet('2wiki', 587)
    es = [evidence(p, 1, 'The Terror of Tiny Town', 'directed by Sam Newfield'),
          evidence(p, 2, 'The Champagne Murders', 'directed by Claude Chabrol'),
          evidence(p, 3, 'Sam Newfield', 'December 6, 1899'),
          evidence(p, 4, 'Claude Chabrol', '24 June 1930')]
    batch.append(reviewed(p, ['Film-director bindings are Newfield and Chabrol.', 'Their birth years are 1899 and 1930.', 'Older director means earlier birth; return corresponding film.'], es,
        'four_fact_binding_and_age_direction_preserved', 'The two film bindings and birth dates enter the actual readers and remain in QA/final. Goal and final use earlier birth for older and select The Terror of Tiny Town.'))

    p = packet('2wiki', 305)
    es = [evidence(p, 1, 'This World, Then the Fireworks', 'directed by Michael Oblowitz'),
          evidence(p, 2, 'Fort Yuma (film)', 'directed by Lesley Selander'),
          evidence(p, 3, 'Michael Oblowitz', 'South African filmmaker'),
          evidence(p, 4, 'Lesley Selander', 'American film director')]
    batch.append(reviewed(p, ['Bind each specified film to its director.', 'Oblowitz is described as South African and Selander as American.', 'Compare the countries.'], es,
        'film_director_country_difference_preserved', 'Both correctly bound country descriptors reach ordinary answers, goal and final No. Final original-query Top10 is mostly film material, so helper QA preserves the country facts.'))

    p = packet('2wiki', 271)
    es = [evidence(p, 1, 'The Indian Love Lyrics', 'directed by Sinclair Hill'),
          evidence(p, 2, 'Untitled (2011 film)', 'directed by Shaun Troke'),
          evidence(p, 3, 'Sinclair Hill', 'British film director'),
          evidence(p, 4, 'Shaun Troke', 'British director')]
    batch.append(reviewed(p, ['Bind The Indian Love Lyrics to Sinclair Hill and Untitled 2011 to Shaun Troke.', 'Both directors are described as British.'], es,
        'version_specific_director_country_equality_preserved', 'The 2011 Untitled film, not the 2009 title also in final candidates, is used. Both British properties are preserved in ordinary answers and final Yes.'))

    p = packet('2wiki', 394)
    es = [evidence(p, 1, 'Racing Extinction', 'Louie Psihoyos'),
          evidence(p, 2, 'Madame Butterfly (1995 film)', 'directed by Frédéric Mitterrand'),
          evidence(p, 3, 'Louie Psihoyos', 'Greek-American'),
          evidence(p, 4, 'Frédéric Mitterrand', 'French politician')]
    batch.append(reviewed(p, ['Correct directors for the two film versions.', 'Psihoyos has Greek-American descriptor; Mitterrand is French.', 'Compare asked countries without substituting the films nationalities.'], es,
        'director_identity_and_distinct_country_descriptors_preserved', 'Ordinary QA and goal retain the two director identities and different descriptors and final says No.',
        limit='Greek-American alone is not treated as proof of two formal citizenships; this flow check does not refine the old from-country truth label.'))

    p = packet('2wiki', 247)
    es = [evidence(p, 1, 'Louis, Dauphin of France (son of Louis XV)', 'Queen Marie Leszczyńska'),
          evidence(p, 2, 'Marie Leszczyńska', 'Catherine Opalińska')]
    batch.append(reviewed(p, ['Select Louis son of Louis XV, not another Dauphin.', 'His mother is Marie Leszczyńska; her mother is Catherine Opalińska.', 'Compose maternal grandmother relation.'], es,
        'maternal_two_generation_chain_preserved', 'Actual matching Louis source states his mother, and the Marie source names both her parents. Ordinary step2 and final select Catherine, preserving female parent role and two generations despite same-name Dauphin distractors.'))

    p = packet('2wiki', 379)
    sophie_title = next(d['source'] for d in node(p, 1)['reader_packet']['docs'] if d['source'].startswith('Sophie of France (1734'))
    es = [evidence(p, 1, sophie_title, 'Marie Leszczyńska'),
          evidence(p, 2, 'Marie Leszczyńska', 'Stanisław Leszczyński')]
    batch.append(reviewed(p, ['Identify Sophie of France 1734–1782.', 'Her mother Marie Leszczyńska has father Stanisław Leszczyński.', 'Compose maternal grandfather, not paternal grandfather.'], es,
        'maternal_grandfather_chain_and_entity_disambiguator_preserved', 'Reader supports Sophie mother and mother father; ordinary/goal QA carry the correct maternal grandfather into final despite another Sophie of France in candidates.'))

    p = packet('2wiki', 698)
    film2 = 'The Twentieth Century Tramp; or, Happy Hooligan and His Airship'
    es = [evidence(p, 1, 'The Breach (film)', '1970 film'), evidence(p, 2, film2, 'released in 1902')]
    batch.append(reviewed(p, ['Specified The Breach has year 1970.', 'Specified Twentieth Century Tramp film released 1902.', 'Compare earlier release.'], es,
        'correct_version_years_and_earlier_operator_preserved', 'Reader/QA preserve 1970 and 1902 while final candidates contain other Breach/airship titles; goal and final select the correct 1902 film.'))

    p = packet('2wiki', 308)
    es = [evidence(p, 1, 'Legend of a Fighter', 'Directed by Yuen Woo-ping'),
          evidence(p, 2, 'Yuen Woo-ping', 'a son of Yuen Siu-tien')]
    batch.append(reviewed(p, ['Film director is Yuen Woo-ping.', 'His father is Yuen Siu-tien.'], es,
        'director_then_father_relation_preserved', 'Goal reader obtains the biographical parent relation absent from most original-query film candidates; the role-correct father is retained in goal and final.'))

    p = packet('2wiki', 561)
    es = [evidence(p, 1, 'Colin Bibby', 'British ornithologist'), evidence(p, 2, 'Edwin J. Collins', 'British film director')]
    batch.append(reviewed(p, ['Identify both specified people.', 'Both are described as British.', 'Compare country equality.'], es,
        'two_british_descriptors_preserved', 'Both sources supply the country descriptor; ordinary answers map British to United Kingdom and final Yes preserves equality without mixing the nearby different Bibby/Collins names.'))

    p = packet('hotpotqa', 170)
    es = [evidence(p, 1, 'Charles Burnett (director)', 'film director, film producer, writer, editor'),
          evidence(p, 2, 'Alan J. Pakula', 'film director, writer and producer')]
    batch.append(reviewed(p, ['Use Charles Burnett the director, not the RAF/Army/officer-of-arms namesakes.', 'Intersect two occupation lists: director, producer, writer.'], es,
        'correct_entity_occupation_intersection', 'Reader has the correct Burnett source at rank5 despite namesake candidates; ordinary QA retain both lists. Goal/final compute their shared occupations instead of copying the entire longer Burnett list.'))

    p = packet('hotpotqa', 182)
    es = [evidence(p, 1, 'Cherokee Rose (The Walking Dead)', 'Daryl Dixon (Norman Reedus) continues to search for Sophia Peletier'),
          evidence(p, 2, 'Norman Reedus', 'most recognizably Prada in the 1990s')]
    batch.append(reviewed(p, ['Episode character is Daryl Dixon, played by Norman Reedus.', 'The actor modeled most recognizably for Prada.'], es,
        'character_actor_company_chain_preserved', 'The episode reader binds role to actor and the later actor reader supplies Prada. This attribute already enters ordinary step2 reader but not its narrow actor-name answer; goal retrieves/reads actor evidence again and carries Prada to final.',
        limit='Omitting an unasked company from ordinary actor answer is not newly marked as an error; goal still obtains it.'))

    p = packet('hotpotqa', 216)
    es = [evidence(p, 1, 'Jeff Martin (Canadian musician)', 'fronting the rock band The Tea Party'),
          evidence(p, 2, 'Kyle Patrick', 'lead singer of Boston power pop band, The Click Five')]
    batch.append(reviewed(p, ['Maintain dataset-identified Jeff Martin rather than nearby musicians with the same name.', 'Kyle Patrick is Click Five lead singer; the retained prior fact says Jeff Martin is not a member.', 'Apply both-in-band conjunction.'], es,
        'positive_band_member_and_retained_negative_answer_combined', 'Actual reader supports Kyle positive membership and identifies the intended Jeff with The Tea Party. Ordinary negative membership assertion is carried into goal and final No; old factual label is retained.',
        limit='Fronting another band is not by itself a proof of never belonging to Click Five. This flow review does not silently turn absence into an independently verified negative.'))

    p = packet('hotpotqa', 208)
    es = [evidence(p, 1, 'Lionheart (1990 film)', 'starring Jean-Claude Van Damme'),
          evidence(p, 2, 'Jean-Claude Van Damme', 'best known for his martial arts action films')]
    batch.append(reviewed(p, ['Use Lionheart 1990, not 1987/2016.', 'Bind lead actor Jean-Claude Van Damme to known film genre martial arts action.'], es,
        'film_version_actor_genre_chain_preserved', 'Actor reader supplies requested genre at goal rank3. Goal and final retain the requested category instead of returning the actor or a different Lionheart lead.'))

    p = packet('hotpotqa', 209)
    es = [evidence(p, 1, 'Konstantin Novoselov', 'Russian-British physicist'),
          evidence(p, 2, 'Graphene Research Centre', 'at the National University of Singapore'),
          evidence(p, 2, 'Graphene Research Centre', 'under the scientific advice')]
    batch.append(reviewed(p, ['Physicist Novoselov fits the question identity.', 'Research centre advised by the Nobel laureates is at National University of Singapore.', 'Return Singapore country.'], es,
        'research_centre_location_with_qualified_establishment_role_preserved', 'The intermediate answer preserves the source qualification under scientific advice rather than inventing sole founder identity; goal/final keep the location Singapore.'))

    p = packet('hotpotqa', 154)
    es = [evidence(p, 1, "Governor's House, Knutsford", 'designed by the Lancaster architect Edmund Sharpe'),
          evidence(p, 2, 'Edmund Sharpe', 'Following his graduation from Cambridge University')]
    batch.append(reviewed(p, ['Knutsford Governor house architect is Edmund Sharpe.', 'He graduated from Cambridge University, distinct from other schools/localities.'], es,
        'architect_then_graduation_institution_preserved', 'Matching house reader supplies architect and goal reader supplies explicit graduation, not only attendance. Goal/final retain Cambridge University.'))

    p = packet('hotpotqa', 231)
    es = [evidence(p, 2, 'Incubus (band)', 'American rock band')]
    even = next(d for d in p['frozen_reference_material_for_review_only']['gold_documents'] if d['title'] == 'Even (band)')
    assert all(d['source'] != 'Even (band)' for n in p['trace']['nodes'] for d in n['reader_packet']['docs'])
    assert p['existing_labels_and_native_score_unchanged']['goal_answer_correct'] is False
    assert p['trace']['prediction'] == 'No'
    es.append({'route': 'frozen dataset reference only, not seen by the pipeline', 'source': even['title'], 'doc_id': even['_id'], 'verified_quote': even['text']})
    r = entry(p, ['Resolve Even as the Australian indie rock band, not Evenus mythology or butterflies.', 'Resolve Incubus as the rock band.', 'Assess the actual asked known-for-classical predicate; retain conjunction scope.'],
        [{'location': 'saved retrieval and goal explanation', 'category': 'native_fullscore_with_wrong_goal_entity', 'confirmed': True,
          'detail': 'Even band evidence is missing from the saved reader. Ordinary answer reasonably says not found; goal falsely replaces Even with non-musical mythological/historical/biological entities. Old goal label already says False; final No is native-fullscore.',
          'limit': 'A short correct No does not expose its reasoning. Rock-band description alone is not treated as formal proof of no classical skill; final mechanism and sufficiency remain unassigned.'}], es, None, None)
    batch.append(r)

    p = packet('hotpotqa', 146)
    es = [evidence(p, 1, 'Universidad de Oriente', 'universities of Venezuela'),
          evidence(p, 2, 'California State University, Dominguez Hills', 'within the 23-school California State University (CSU) system')]
    batch.append(reviewed(p, ['Use Venezuela Universidad de Oriente in frozen dataset.', 'CSU Dominguez Hills belongs to the CSU system.', 'Compare system identity.'], es,
        'different_institution_system_identity_preserved', 'Reader identifies the Venezuela institution and explicit CSU membership; retained QA maps these to different systems and final says No.',
        limit='The Venezuela passage alone does not name a formal nationwide system or prove all public-university governance details. Only institution/system comparison information was checked.'))

    p = packet('hotpotqa', 120)
    es = [evidence(p, 1, 'Hot toddy', 'traditionally drunk before retiring for the night'),
          evidence(p, 2, 'Kir (cocktail)', 'popular French cocktail')]
    batch.append(reviewed(p, ['For the two named choices, identify explicit traditional bedtime beverage evidence.'], es,
        'positive_requested_tradition_preserved', 'Hot toddy reader explicitly states the asked tradition; ordinary/goal answers and final preserve Hot toddy.',
        limit='Kir ingredients without bedtime wording are not used to prove a universal negative about every drinking tradition; the positive Hot toddy relation is the inspected supporting fact.'))

    p = packet('hotpotqa', 12)
    es = [evidence(p, 1, 'Francesca Caccini', 'daughter of Giulio Caccini'),
          evidence(p, 2, 'Giulio Caccini', 'buried 10 December 1618')]
    batch.append(reviewed(p, ['Francesca father is Giulio Caccini.', 'Frozen reference uses 1618 for father death year; retrieved date is burial in 1618.'], es,
        'father_binding_and_1618_year_preserved_with_date_type_qualification', 'Both readers preserve father identity and the visible 1618 date; goal/final output 1618, matching the frozen endpoint.',
        limit='The literal source says buried 10 December 1618. This check does not relabel that as an explicitly stated exact death date.'))

    assert len(batch) == 20 and len({r['id'] for r in batch}) == 20
    assert not {r['id'] for r in prior} & {r['id'] for r in batch}
    all_reviews = prior + batch
    cohort = rows(OUT / 'INFORMATION_FLOW_COHORT.jsonl')
    success_ids = {r['id'] for r in cohort if r['review_selection'] == 'seeded_fullscore_control'}
    assert {r['id'] for r in all_reviews if r['selection'] == 'seeded_fullscore_control'} == success_ids
    assert Counter(r['dataset'] for r in batch) == {'2wiki': 10, 'hotpotqa': 10}
    assert all(r['selection'] == 'seeded_fullscore_control' for r in batch)
    assert len(all_reviews) == 50
    batch_file = OUT / 'MANUAL_INFORMATION_FLOW_REVIEWS_BATCH003.json'
    merged_file = OUT / 'MANUAL_INFORMATION_FLOW_REVIEWS_V3.json'
    assert not batch_file.exists() and not merged_file.exists()
    write(batch_file, {'utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Each dataset seeded success items 11 through 20, no outcome-based replacement.', 'material_reviewed_items': 20, 'reviews': batch})
    write(merged_file, {'utc': datetime.now(timezone.utc).isoformat(), 'status': 'partial_followup_success_controls_materially_reviewed',
        'material_reviewed_items': 50, 'completed_for_stated_checks': 49, 'pending_work_items': 1, 'reviews': all_reviews,
        'limits': 'All 40 native-fullscore controls have stated-scope material review; this does not certify every incidental claim or every reasoning step. Binary labels and scores unchanged.'})

    index = rows(OUT / 'REVIEW_INDEX.jsonl')
    by_id = {r['id']: r for r in all_reviews}
    for row in index:
        if row['id'] in by_id:
            row['followup_review_status'] = by_id[row['id']]['review_status']
            row['review_file'] = merged_file.name + '#' + row['id']
    jsonl(OUT / 'REVIEW_INDEX_V3.jsonl', index)
    historical = {r['id'] for r in read(OLD / 'ROOT_CAUSE_CASES.json')['cases']}
    progress = read(OUT / 'REVIEW_PROGRESS_V2.json')
    progress.update(material_reviewed_items=50, followup_semantic_reviews_completed=49,
        pending_fact_or_interpretation_work_items=1, pending_followup_reviews=229, not_yet_started_items=228,
        reviewed_selections={'seeded_fullscore_control': 40, 'all_nonfullscore': 10}, first_fullscore_controls_per_dataset=20,
        historical_36_newly_followup_checked=len(set(by_id) & historical), historical_36_pending_followup=len(historical - set(by_id)),
        note='40 success controls materially reviewed (39 completed stated checks, 1 pending country interpretation), plus 10 nonfullscore (10 completed). 228 packets not started. Per-packet creation status is historical; REVIEW_INDEX_V3 is the active overlay.')
    write(OUT / 'REVIEW_PROGRESS_V3.json', progress)

    descriptions = {}
    for selection in ['seeded_fullscore_control', 'all_nonfullscore']:
        group = [r for r in all_reviews if r['selection'] == selection]
        descriptions[selection] = {
            'materially_reviewed_queries': len(group),
            'completed_stated_checks': sum(r['review_status'] == 'completed_for_stated_information_flow_checks' for r in group),
            'pending_work_items': sum(r['review_status'] == 'pending_work_item_after_material_review' for r in group),
            'dataset_counts': dict(Counter(r['dataset'] for r in group)),
            'final_information_sufficiency_for_stated_scope': dict(Counter(str(r['final_has_sufficient_information_for_target']) for r in group)),
            'final_use_for_stated_scope': dict(Counter(str(r['final_uses_target_information_correctly']) for r in group)),
            'nonexclusive_recorded_findings': dict(Counter(f['category'] for r in group for f in r['findings'])),
            'query_ids': [r['id'] for r in group]}
    comparison = {'scope': 'Descriptive counts of reviewed packets only; success controls fixed per-dataset random-order sample, failures are 4 initial cases plus next 6 queue items, not probability sampled.',
        'do_not_estimate_population_conditional_probabilities_or_causal_effects': True,
        'dataset_mix_warning': 'The reviewed 10 failures are all HotpotQA; the 40 success controls are HotpotQA20 plus 2Wiki20. Pooled comparison confounds dataset mix as well as selection.',
        'groups': descriptions,
        'contrasts_supported': [
            'Missing or incomplete ordinary support can coexist with a full-score endpoint when a later/direct path supplies the asked information (HP130,67,177).',
            'A native full-score endpoint can coexist with an already-labelled wrong goal entity (HP231).',
            'The inspected failure group includes missing candidate information, candidate-to-reader pruning, wrong field selection and native matching/multiple valid target issues; these are different locations.',
            'Comparison counts concern explicitly declared information requirements. A True does not certify every sentence, and a None leaves mechanism/sufficiency unassigned.'
        ]}
    write(OUT / 'REVIEWED_SUCCESS40_NONFULLSCORE10_DESCRIPTIVE.json', comparison)
    assert read(OUT / 'HISTORICAL_INPUT_HASHES.json') == inventory(OLD)
    assert all(sha(ROOT / name) == value for name, value in before_followup.items())
    write(OUT / 'VALIDATION_V3.json', {'utc': datetime.now(timezone.utc).isoformat(), 'old_diagnostic_64_files_unchanged': True,
        'prior_followup_files_unchanged': len(before_followup), 'material_reviewed': 50, 'completed_stated_checks': 49,
        'pending_work_items': 1, 'fixed_success_controls_per_dataset': 20, 'reviewed_nonfullscore': 10,
        'new_API_requests': 0, 'new_retrieval_searches': 0, 'new_GPU_work': False, 'frozen_truth_labels_or_native_scores_changed': False})
    lines = ['# 信息流诊断：成功对照补完后的进展v3', '',
        '当前活跃审阅视图：MANUAL_INFORMATION_FLOW_REVIEWS_V3.json、REVIEW_INDEX_V3.jsonl及REVIEW_PROGRESS_V3.json。先前V1/V2、审阅包创建状态和全部旧诊断文件均保留原字节；本轮状态通过独立V3覆盖视图表达。', '',
        '已按既定seed顺序补完每集20条满分对照，共40条；其中39条完成声明范围检查，2Wiki317原解释工作项保持待核。另10条非满分已完成声明范围检查。合计亲读50包、49完成、1待核，228包未开始。', '',
        '本批20条与证据见BATCH003；必要信息范围逐条声明，不认证所有附带断言。没有新API、检索或GPU，原真假标签和原生F1/EM不变。', '',
        '成功样本中可见：电影/导演/日期或亲属链能被正确保留；目标属性可在goal重新获取，普通狭窄回答没有保留未问属性也未必导致损失。HP182的演员reader已含Prada，普通演员姓名回答未带公司，goal再次读取并最终输出Prada；这次遗漏未造成实际失败。', '',
        'HP231是关键反例：Even乐队没有进入保存reader，goal错指神话/生物且旧goal标签本为错误，最终No仍满分。短答案满分不能证明中间对象或综合解释正确，也不能据此确认最终使用了哪一路依据。', '',
        '样本内对照见REVIEWED_SUCCESS40_NONFULLSCORE10_DESCRIPTIVE.json。成功40按每集固定抽样，失败10是先前案例加队列前项，来源不同且失败覆盖很少；只报告这些已审包的描述性计数，不估总体条件概率、普遍发生率或组件因果收益。', '',
        '附带限定：另一支乐队经历不能独自证明从未入过目标乐队；Kir材料缺少 bedtime 不能证明绝对没有此习俗；Caccini材料字面是1618安葬；Greek-American也不等于正式双重国籍。本轮保留可见文字与已有标签，未用这些推断强行改真伪。', '']
    (OUT / 'README_V3.md').write_text('\n'.join(lines), encoding='utf-8')
    write(OUT / 'CURRENT_REVIEW_VERSION.json', {'version': 3, 'readme': 'README_V3.md', 'reviews': merged_file.name, 'index': 'REVIEW_INDEX_V3.jsonl',
        'progress': 'REVIEW_PROGRESS_V3.json', 'descriptive_comparison': 'REVIEWED_SUCCESS40_NONFULLSCORE10_DESCRIPTIVE.json', 'previous_versions_preserved': True})
    print({'new_reviews': 20, 'success_controls_materially_reviewed': 40, 'total_materially_reviewed': 50, 'completed': 49, 'pending_work_items': 1, 'prior_files_unchanged': len(before_followup)})


if __name__ == '__main__':
    main()
