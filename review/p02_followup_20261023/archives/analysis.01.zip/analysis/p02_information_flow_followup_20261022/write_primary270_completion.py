"""Completion note for material coverage, preserving pending facts and old bytes."""
from datetime import datetime, timezone
from collections import Counter
from build_offline import ROOT, OUT, OLD, read, rows, write, sha, inventory


def main():
    before=inventory(OUT);ptr=read(OUT/'CURRENT_REVIEW_VERSION.json');assert ptr['version']==9
    rr=read(OUT/'MANUAL_INFORMATION_FLOW_REVIEWS_V9.json')['reviews']
    cohort=rows(OUT/'INFORMATION_FLOW_COHORT.jsonl');ids={r['id'] for r in cohort}
    assert len(rr)==270 and {r['id'] for r in rr}==ids
    assert not rows(OUT/'REMAINING_NONFULLSCORE_QUEUE_V9.jsonl')
    assert Counter(r['selection'] for r in rr)=={'all_nonfullscore':230,'seeded_fullscore_control':40}
    by={(r['dataset'],r['review_index']):r for r in rr}
    vals=[read(OUT/f'VALIDATION_V{i}.json') for i in [7,8,9]]
    assert all(v['old_diagnostic64_unchanged'] and not v['stage_truth_labels_or_scores_changed'] for v in vals)
    pending=read(OUT/'INFORMATION_FLOW_PENDING_WORK_ITEMS_V9.json')['items'];assert len(pending)==12
    assert read(OUT/'HISTORICAL_INPUT_HASHES.json')==inventory(OLD)
    supp=[r for r in rows(OUT/'REVIEW_INDEX_V9.jsonl') if r['id'] not in ids];assert len(supp)==8
    assert all(r['followup_review_status'] in ['not_started','prior_case_finding_retained_followup_pending'] for r in supp)
    assert rr[:150]==read(OUT/'MANUAL_INFORMATION_FLOW_REVIEWS_V6.json')['reviews']
    for tag,a,b in [('007',150,190),('008',190,230),('009',230,270)]:
        srcrows=read(OUT/f'MANUAL_INFORMATION_FLOW_REVIEWS_BATCH{tag}.json')['reviews']
        for src,dst in zip(srcrows,rr[a:b]):
            assert {k:v for k,v in src.items() if k!='pending_work_item'}=={k:v for k,v in dst.items() if k!='pending_work_item'}
            if isinstance(src.get('pending_work_item'),str):assert dst['pending_work_item']['verbatim_pending_note_from_batch']==src['pending_work_item']
            else:assert src.get('pending_work_item')==dst.get('pending_work_item')
    families=[
      ('candidate_to_reader_loss',[('hotpotqa',7),('2wiki',721)],'必要事实在候选中但被既有Top10合并选择丢弃；这不证明一律增加文档会提升F1。'),
      ('reader_relation_misread_or_not_passed',[('2wiki',506),('2wiki',248)],'reader已有正确父亲或日期关系，QA却取错角色或弃答，必要信息未保留到helper/final。'),
      ('goal_operator_or_generation_error',[('2wiki',362),('2wiki',376),('2wiki',390),('2wiki',392),('2wiki',528),('2wiki',566)],'双方属性或日期已知，goal仍改变交集条件、反向比较或多追一代。'),
      ('target_visible_final_wrong_field',[('hotpotqa',187),('hotpotqa',222),('2wiki',550),('2wiki',541),('2wiki',403)],'目标属性或关系已在goal/helper，final仍取桥梁组织、错误国家、发布商或相反结论；部分含冲突goal，不能仅用增加可见文本解释。'),
      ('unasked_work_specific_award_scope',[('2wiki',517),('2wiki',527),('2wiki',533),('2wiki',719)],'人物奖项被增加只限特定作品的条件，或正确奖项已可见仍被final弃答；533还含reader到goal传递丢失。'),
      ('downstream_recovery_to_preserve',[('hotpotqa',141),('hotpotqa',150),('hotpotqa',152),('hotpotqa',189),('hotpotqa',126)],'goal或final也会纠正上游错误/歧义；这些恢复是后续改动必须检查的回归面。'),
      ('reference_source_and_scope',[('hotpotqa',114),('hotpotqa',123),('hotpotqa',145),('hotpotqa',181),('hotpotqa',189),('hotpotqa',237),('2wiki',433),('2wiki',456),('2wiki',463)],'行政单位、有效替代答案、错误桥梁参考、HTML破损、布尔范围、物种证据、来源冲突和同名身份分列；不重写原指标。')]
    features=[]
    for key,pairs,detail in families:
        features.append({'finding_family':key,'description':detail,'causal_effect_established':False,
          'examples':[{'dataset':ds,'review_index':idx,'id':by[(ds,idx)]['id'],
             'review':'MANUAL_INFORMATION_FLOW_REVIEWS_V9.json#'+by[(ds,idx)]['id']} for ds,idx in pairs]})
    obj={'utc':datetime.now(timezone.utc).isoformat(),'status':'primary270_material_review_complete_with12_pending_fact_or_scope_workitems',
      'primary_scope':{'material_reviewed':270,'nonfullscore':230,'seeded_fullscore_controls':40,'declared_scope_complete':258,'pending_work_items':12,'unreviewed_nonfullscore':0,'dataset_counts':dict(Counter(r['dataset'] for r in rr))},
      'supplemental8':{'new_material_reviews':0,'status':'prior_findings_retained_but_new_followup_not_started_outside_primary270',
          'items':[{'id':r['id'],'review_index':r['review_index'],'dataset':r['dataset'],'followup_review_status':r['followup_review_status']} for r in supp]},
      'frozen_assignment_batches':[{'batch':tag,'assignment':f'ASSIGNMENT_BATCH{tag}.json','result':f'MANUAL_INFORMATION_FLOW_REVIEWS_BATCH{tag}.json','result_sha256':sha(OUT/f'MANUAL_INFORMATION_FLOW_REVIEWS_BATCH{tag}.json')} for tag in ['007','008','009']],
      'last120_merge_validation':{'raw_source_hashes':sum(v['sourcehashes_checked'] for v in vals),'actual_child_QA_current_questions':sum(v['actual_QA_questions_checked'] for v in vals),'exact_reader_candidate_or_goal_quote_locations':sum(v.get('evidence_quote_locations_checked',v.get('reader_quote_locations_checked',0)) for v in vals)},
      'prior150_review_records_exactly_unchanged':True,'original_batch_result_bytes_preserved':True,
      'pending_schema_normalization':'Batch strings wrapped into structured objects only in new aggregate; original strings and batch SHA retained; all other review fields exact.',
      'pending_indices':[next(r['review_index'] for r in rr if r['id']==p['query_id']) for p in pending],
      'mechanism_examples':features,'claims_not_established':['causal stage importance ranking','overall population cause shares','new method F1 improvement','corrected decomposition used by historical formal traces'],
      'decomposition_provenance':{'formal_trace_binding':'R02_expanded plus v12','batch007_raw_arrays_exact_match_count':40,'artifact':'DECOMPOSITION_SOURCE_BINDING_BATCH007.json','separate_manual_corrections':'Historical same60 query-only corrections and revision46 separate; root confirms future target entry.'},
      'preservation':{'old_diagnostic64_unchanged':True,'old_labels_native_scores_main_tables_unchanged':True,'main_eval_remains_paused':True,'API_calls':0,'new_retrieval_calls':0,'new_training_or_GPU':False},
      'limits':'Targeted information-flow cohort from existing723 diagnosed traces; not new official evaluation or independent human gold. Necessary-information/path scope stated per case; pending remains unresolved; no gold-string sufficiency rule.'}
    jn='PRIMARY270_REVIEW_COMPLETION.json';mn='PRIMARY270_REVIEW_COMPLETION.md'
    assert not (OUT/jn).exists() and not (OUT/mn).exists();write(OUT/jn,obj)
    lines=['# P02 主270条信息流离线复查完成说明','',
      '主cohort的材料复查现已全覆盖：**230条非满分＋40条固定seed满分对照＝270条**。其中258条完成各自声明的必要信息/路径检查，12条保留事实或口径待核。剩余非满分为0。8条补充包只保留原有案例发现，本轮复查尚未启动，不计入270完成数。','',
      '这是对既有723条诊断轨迹中目标cohort的离线复查，不是新的正式RAG评估，也不代表所有附加事实都已重新做独立金标。原F1/EM、truth标签与主评保持不动。','',
      '## 三批交付与验证','',
      'V7追加007、V8追加008、V9追加009，每批40条，与V6冻结任务包逐ID和顺序相同。新120条校验120个原始sourcehash、281个actual child_prompt当前题、270条reader/候选/goal摘录位置。摘录匹配只核位置，语义结论来自逐条亲读，不能以关键词命中代替充分证据。','',
      '原V6的150条记录在V9中逐字段完全一致；原64诊断与先前follow-up文件保留原字节。008/009的字符串待核备注只在新聚合版封装为结构化对象，原文及来源batchhash保留，原batch文件不改。','',
      '## 已核对的具体边界','']
    for f in features:
        label='、'.join(('HP' if c['dataset']=='hotpotqa' else 'Wiki')+str(c['review_index']) for c in f['examples'])
        lines.append('- '+label+'：'+f['description'])
    lines+=['','这些案例支持将修复方向拆到证据选择、QA关系保留、goal综合、final目标字段选择等冻结对照中验证；复查本身不能推出某环节因果效应最大，也不能声称已有修复带来F1提升。','',
      '## 待核及真实QA输入','',
      '待核12条，保留已有truth/原生分数：Wiki'+'、'.join(str(x) for x in obj['pending_indices'])+'。涵盖既有出生/死亡地点与附加职业事实，以及历史国籍、国家归一化、创作credit、雇主时间和同名身份等范围问题，详见 `INFORMATION_FLOW_PENDING_WORK_ITEMS_V9.json`。','',
      'HP107以独立澄清为准：`child_prompt` Current subquestion仍是原描述问题，检索`rewritten_query`不是实际QA题。Licking县治Newark是真命题，不等于正确响应真实球队限定题；旧ordinary3=False保持。','',
      '## 分解来源与未来目标','',
      '007的40条已逐ID核对正式remote_raw：历史RAG的supporting_questions与R02_expanded/v12原始输出数组完全一致，没有语义修复。详见 `DECOMPOSITION_SOURCE_BINDING_BATCH007.json`。历史same60人工query-only修正及revision46另存，不能称当前270正式轨迹已使用修正分解。未来“修正后的分解”具体入口由root确认；本复查没有训练、推理、调用API或恢复主评。','',
      '## 当前入口','',
      '- `CURRENT_REVIEW_VERSION.json` 指向V9，保留HP107澄清。','- `MANUAL_INFORMATION_FLOW_REVIEWS_V9.json`：270条逐条范围、证据和信息流观察。','- `REVIEW_PROGRESS_V9.json` / `REVIEW_INDEX_V9.jsonl`：状态；`REMAINING_NONFULLSCORE_QUEUE_V9.jsonl`为空。','- `PRIMARY270_REVIEW_COMPLETION.json`：完成范围、互斥批次、校验数字、待核与案例索引。','- `REVIEWED_SUCCESS40_NONFULLSCORE230_DESCRIPTIVE.json`：描述性分组；不输出总体原因占比或因果排名。','']
    (OUT/mn).write_text('\n'.join(lines),encoding='utf-8')
    assert all(sha(ROOT/name)==value for name,value in before.items())
    back=OUT/'CURRENT_REVIEW_VERSION_V9_BEFORE_COMPLETION.json';assert not back.exists();back.write_bytes((OUT/'CURRENT_REVIEW_VERSION.json').read_bytes())
    ptr.update(completion=jn,completion_readme=mn);write(OUT/'CURRENT_REVIEW_VERSION.json',ptr)
    assert all(sha(ROOT/name)==value for name,value in before.items() if ROOT/name!=OUT/'CURRENT_REVIEW_VERSION.json')
    print({'primary':obj['primary_scope'],'pending_indices':obj['pending_indices'],'supplemental_not_started':8,'checks':obj['last120_merge_validation']})


if __name__=='__main__':main()
