"""Read-only T54 recount. Writes only the independent root audit JSON."""
from pathlib import Path
from contextlib import closing
from collections import Counter
from datetime import datetime,timezone
import hashlib,json,sqlite3,sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from src.p02_multigrain_timing_cachefix_v1.core.llm import build_payload
from src.p02_multigrain_timing_cachefix_v1.core.cache import canonical
from experiments.query_decomposition.p02_goal_fact_role_probe_v1_20261022 import templates
from experiments.query_decomposition.comprehensive_eval_v1_20261015.scoring import metric
P=ROOT/'outputs/query_decomposition/p02_goal_fact_role_probe_v1_20261022/fact27'
B=ROOT/'experiments/query_decomposition/p02_goal_fact_role_probe_v1_20261022'
O=ROOT/'outputs/query_decomposition/p02_goal_composition_challenge_v1_20261022/challenge27'
PACKAGE=ROOT/'src/p02_multigrain_timing_cachefix_v1'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def rows(p):return [json.loads(s) for s in p.read_text(encoding='utf-8-sig').splitlines() if s.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(v):return hashlib.sha256(canonical(v).encode('utf8')).hexdigest()
def rel(p):return str(p.relative_to(ROOT)).replace('\\','/')
def snapshot(directory):
    with closing(sqlite3.connect((directory/'checkpoint.sqlite3').resolve().as_uri()+'?mode=ro',uri=True)) as db:
        current={i:dict(payload=p,status=s,result=json.loads(v)) for i,p,s,v in db.execute('SELECT id,payload,status,result FROM requests')}
        retired={i:dict(payload=p,status=s,result=json.loads(v)) for i,p,s,v in db.execute('SELECT id,payload,status,result FROM retired_requests')}
        conditions=[json.loads(v) for(v,) in db.execute("SELECT value FROM data WHERE kind='condition'")]
    return current,retired,conditions

def main():
    files=[P/'DETAILS.scored.local.jsonl',P/'REPORT.json',P/'root_blind_review/SEMANTIC_JOIN.json',B/'inputs27.frozen.jsonl',B/'references27.local.frozen.jsonl',B/'PROTOCOL.frozen.json',B/'templates.py',O/'DETAILS.scored.local.jsonl',O/'REPORT.json']
    before={rel(p):sha(p) for p in files}
    data=rows(files[0]);report=read(files[1]);joined=read(files[2])
    index={(x['id'],x['arm']):x for x in data};sem={(x['case_id'],x['arm']):x for x in joined['records']}
    inputs={x['id']:x for x in rows(B/'inputs27.frozen.jsonl')};refs={x['id']:x for x in rows(B/'references27.local.frozen.jsonl')}
    assert len(data)==len(index)==len(sem)==joined['reviewed_records']==54
    assert set(index)==set(sem)=={(i,a) for i in inputs for a in ['T0','T1']}
    locks=[]
    for batch in sorted((P/'root_blind_review').glob('batch*')):
        lock=read(batch/'ROOT_REVIEW_LOCK.json')
        assert sha(batch/'SEMANTIC_REVIEWS.blinded.jsonl')==lock['review_sha256']
        assert sha(batch/'PACKET.json')==lock['packet_sha256'] and lock['locked_before_root_method_join']
        locks.append(dict(batch=batch.name,**lock))
    assert sum(x['records'] for x in locks)==54
    protocol=read(B/'PROTOCOL.frozen.json')
    for path,expected in protocol['pins'].items():assert sha(ROOT/path)==expected,path
    config=read(PACKAGE/'config.json');model=config['generation']['model'];examples=read(B/'FINAL_EXAMPLES.frozen.json')
    assert config['generation']==read(B/'GENERATION.frozen.json')
    scorers={d:metric(d) for d in ['hotpotqa','2wiki']}
    current,retired,saved=snapshot(P)
    assert (len(current),len(retired),len(saved))==(97,3,54)
    for rid,x in current.items():
        r=x['result'];u=r.get('usage') or {};payload=json.loads(x['payload'])
        assert x['status']==r['status']=='success' and r['finish_reason']=='stop' and r['answer'].strip() and not r.get('refusal'),rid
        assert r['requested_model']==r['returned_model']==payload['model']==model,rid
        assert all(type(u.get(k)) is int and u[k]>=0 for k in ['prompt_tokens','completion_tokens','total_tokens']),rid
        assert u['total_tokens']==u['prompt_tokens']+u['completion_tokens'] and canonical(payload)==x['payload'],rid
    for s in saved:assert all(index[s['id'],s['arm']][k]==v for k,v in s.items())
    stage_checks=[];native_checks=[]
    for x in data:
        n=scorers[x['dataset']](x['prediction'],refs[x['id']]);assert n==x['native_metrics']
        gp=templates.goal_prompt(inputs[x['id']],x['arm'])
        fp,fc=templates.final_prompt(inputs[x['id']],x['goal_text'],config,examples)
        assert fp==x['final_prompt'] and fc==x['final_context']
        if x['arm']=='T1':assert gp.replace('\n'+templates.ROLE+templates.MARKER,templates.MARKER,1)==templates.goal_prompt(inputs[x['id']],'T0')
        usage=[]
        for stage,prompt,cap,key,text in [('goal',gp,512,'goal_request_id',x['goal_text']),('final',fp,64,'final_request_id',x['prediction'])]:
            receipt=current[x[key]]
            assert receipt['payload']==canonical(build_payload(config['generation'],prompt,cap)) and receipt['result']['answer'].strip()==text
            usage.append(receipt['result']['usage'])
            stage_checks.append(dict(id=x['id'],arm=x['arm'],stage=stage,request_id=x[key],payload_sha256=digest(json.loads(receipt['payload'])),cap=cap,full_wire_exact=True,model_stop_all3_usage_valid=True))
        pt=sum(u['prompt_tokens'] for u in usage);ct=sum(u['completion_tokens'] for u in usage)
        assert x['usage_complete'] and pt==x['goal_final_input_tokens'] and ct==x['goal_final_output_tokens'] and abs(pt*.8e-6+ct*2e-6-x['goal_final_estimated_CNY'])<1e-12
        native_checks.append(dict(id=x['id'],arm=x['arm'],native=n,usage_and_cost_exact=True))
    for rid,x in retired.items():
        assert x['payload'] in {r['payload'] for r in current.values()} and x['status']==x['result']['status']=='unknown'
        assert not any(x['result'].get(k) is not None for k in ['usage','response_id','raw_response','returned_model'])
    attempts=Counter(x['payload'] for x in list(current.values())+list(retired.values()));assert max(attempts.values())==3
    recomputed={}
    for arm in ['T0','T1']:
        recomputed[arm]={}
        for ds,n in [('hotpotqa',10),('2wiki',17),('all',27)]:
            rr=[x for x in data if x['arm']==arm and(ds=='all' or x['dataset']==ds)];assert len(rr)==n and all(x['status']=='success' for x in rr)
            expected=dict(planned=n,resolved=n,normal_complete=n,algorithm_terminal=0,held_or_pending=0,terminal_reasons={})
            for suffix,endpoint in [('F1','f1'),('EM','em')]:
                for prefix in ['fixed_denominator_','known_outcome_','complete_only_']:expected[prefix+suffix]=sum(x['native_metrics'][endpoint] for x in rr)/n
            for k in ['goal_final_input_tokens','goal_final_output_tokens','goal_final_estimated_CNY']:expected[k]=sum(x[k] for x in rr)
            for k,v in expected.items():
                y=report['by_arm_dataset'][arm][ds][k]
                assert abs(v-y)<1e-12 if isinstance(v,(int,float)) else v==y,(arm,ds,k)
            recomputed[arm][ds]=expected
    pairs=[dict(id=i,f1=index[i,'T1']['native_metrics']['f1']-index[i,'T0']['native_metrics']['f1'],em=index[i,'T1']['native_metrics']['em']-index[i,'T0']['native_metrics']['em']) for i in inputs]
    for endpoint in ['f1','em']:
        d=[x[endpoint] for x in pairs]
        expected=dict(improved=sum(x>1e-12 for x in d),harmed=sum(x< -1e-12 for x in d),tied=sum(abs(x)<=1e-12 for x in d),mean_delta=sum(d)/27)
        assert expected==report['paired']['T0_to_T1'][endpoint]
    with closing(sqlite3.connect(Path(config['budget']['ledger']).resolve().as_uri()+'?mode=ro',uri=True)) as db:
        charges=[dict(id=i,reserved_CNY=r,actual_CNY=a,status=s) for i,r,a,s in db.execute('SELECT id,reserved,actual,status FROM charges WHERE namespace=?',('p02_prompt_research_v1_20261022/'+str(P.resolve()),))]
    assert len(charges)==100 and {c['id'] for c in charges}==set(current)|set(retired)
    assert {c['id']:c for c in charges}=={c['id']:c for c in report['charges']}
    known=sum(c['actual_CNY'] or 0 for c in charges);reserved=sum(c['reserved_CNY'] for c in charges if c['actual_CNY'] is None)
    assert abs(known-report['known_receipt_CNY'])<1e-12 and abs(reserved-report['unknown_or_unresolved_reserved_CNY'])<1e-12
    assert {c['id'] for c in charges if c['actual_CNY'] is None}==set(retired)
    notes={
        '2wiki:aabc42040baf11ebab90acde48001122':('grounded_generation_repair','Andronikos之父Isaac、祖父Alexios I；原题Alexios是Andronikos之子。T0多走一代，T1恢复正确祖父Isaac。',[1,3,7]),
        '2wiki:e53937d00bae11ebab90acde48001122':('grounded_generation_repair','Robert8之母Catherine被错当祖母；T1恢复父Robert7之母Mary Clifton，ordinary及家谱材料均支持。',[1,3,5,7]),
        '2wiki:acb9940c0bdd11eba7f7acde48001122':('native_apostrophe_surface_gain','U+2019的Parkinson’s改ASCII撇号Parkinson\'s提分；导演与同名球员身份桥未成立，两臂阶段/信息仍待核。',[1,2,3,4]),
        'hotpotqa:5ab7f0015542992aa3b8c88b':('token_overlap_with_reference_direction_issue','reference为贝斯手本人Sean Yseult；Sean Lowe因共享Sean得.5。reader只给Catherine Lowe嫁Sean Lowe，未给Yseult婚姻；不能称配偶关系修复。',[2,4,5])}
    improved=[]
    for pair in pairs:
        if pair['f1']<=1e-12:continue
        i=pair['id'];kind,reason,ranks=notes[i]
        improved.append(dict(id=i,question=inputs[i]['question'],reference_answer=refs[i]['answer'],classification=kind,interpretation=reason,F1_delta=pair['f1'],
            T0=dict(goal=index[i,'T0']['goal_text'],final=index[i,'T0']['prediction'],native=index[i,'T0']['native_metrics'],locked_stage=sem[i,'T0']),
            T1=dict(goal=index[i,'T1']['goal_text'],final=index[i,'T1']['prediction'],native=index[i,'T1']['native_metrics'],locked_stage=sem[i,'T1']),
            goal_reader_evidence=[{k:d[k] for k in ['rank','source','text']} for d in inputs[i]['goal_reader_packet']['docs'] if d['rank'] in ranks],
            goal_text_visible_to_final={a:index[i,a]['goal_text'] in index[i,a]['final_context'] for a in ['T0','T1']}))
    assert len(improved)==4
    transitions=Counter();stage_changes=[]
    for i in inputs:
        a,b=sem[i,'T0'],sem[i,'T1'];transitions[str(a['stage_correct'])+'->'+str(b['stage_correct'])]+=1
        if a['stage_correct']!=b['stage_correct']:
            stage_changes.append(dict(id=i,question=inputs[i]['question'],T0_locked_stage=a,T1_locked_stage=b,T0_goal=index[i,'T0']['goal_text'],T1_goal=index[i,'T1']['goal_text'],T0_final=index[i,'T0']['prediction'],T1_final=index[i,'T1']['prediction'],native_F1_delta=index[i,'T1']['native_metrics']['f1']-index[i,'T0']['native_metrics']['f1']))
    assert transitions['False->True']==3 and transitions['True->False']==1
    oldrows={(x['id'],x['arm']):x for x in rows(O/'DETAILS.scored.local.jsonl')};oldreq,_,_=snapshot(O);repeat=[]
    for i in inputs:
        a,b=oldrows[i,'G0'],index[i,'T0'];assert scorers[a['dataset']](a['prediction'],refs[i])==a['native_metrics']
        og,ng=oldreq[a['goal_request_id']],current[b['goal_request_id']];of,nf=oldreq[a['final_request_id']],current[b['final_request_id']]
        assert og['payload']==ng['payload']
        repeat.append(dict(id=i,question=inputs[i]['question'],goal_full_wire_identical=True,final_full_wire_identical=of['payload']==nf['payload'],goal_text_changed=a['goal_text']!=b['goal_text'],final_text_changed=a['prediction']!=b['prediction'],old_G0_goal=a['goal_text'],new_T0_goal=b['goal_text'],old_G0_final=a['prediction'],new_T0_final=b['prediction'],old_native=a['native_metrics'],new_native=b['native_metrics'],F1_delta=b['native_metrics']['f1']-a['native_metrics']['f1']))
    oldmean=sum(x['old_native']['f1'] for x in repeat)/27;newmean=sum(x['new_native']['f1'] for x in repeat)/27
    oldgroup=read(O/'REPORT.json')['by_arm_dataset']['G0']
    assert abs(oldmean-sum(x['F1']*x['planned'] for x in oldgroup.values())/27)<1e-12
    assert abs(oldmean-.45162738496071825)<1e-12 and abs(newmean-.32817059483726146)<1e-12
    repeat_summary=dict(cases=27,identical_goal_full_wire=27,goal_text_changed=sum(x['goal_text_changed'] for x in repeat),identical_final_full_wire=sum(x['final_full_wire_identical'] for x in repeat),final_text_changed=sum(x['final_text_changed'] for x in repeat),final_changed_with_identical_final_wire=sum(x['final_text_changed'] and x['final_full_wire_identical'] for x in repeat),old_G0_F1=oldmean,new_T0_F1=newmean,mean_F1_delta=newmean-oldmean,final_F1_improved=sum(x['F1_delta']>1e-12 for x in repeat),final_F1_harmed=sum(x['F1_delta']< -1e-12 for x in repeat),final_F1_tied=sum(abs(x['F1_delta'])<=1e-12 for x in repeat))
    result=dict(created_utc=datetime.now(timezone.utc).isoformat(),scope='Exposed selected27 development challenge,54 conditions; common512 facts+ROLE, not native128 P02 or concurrent factorial',source_hashes=before,locked_stage_records=54,semantic_locks=locks,frozen_protocol_pins_verified=len(protocol['pins']),
        native_audit=dict(predictions_recounted=54,detail_disagreements=0,all_report_groups_and_pairs_match=True,scorers_initialized_once_per_dataset=2,by_arm_dataset=recomputed,paired=report['paired'],checks=native_checks),
        receipt_payload_audit=dict(current_unique_complete_receipts=97,logical_stage_uses_checked=108,model_and_all3_integer_usage_sum_valid=True,all_current_stop_nonempty_no_refusal=True,goal512_final64_wire_exact=True,T1_only_ROLE_sentence=True,all_final_contexts_exact=True,exact_same_run_final_uses_reused=11,retired_unknown_records={i:dict(status=x['status'],result=x['result'],payload_sha256=digest(json.loads(x['payload']))) for i,x in retired.items()},maximum_attempts_per_unique_payload_observed=max(attempts.values()),known_receipt_CNY=known,unresolved_reserved_CNY=reserved,charges=charges,no_orphan_charges=True,checks=stage_checks),
        paired_F1_improvement_cases=improved,stage_transition_matrix=dict(transitions),stage_changes=stage_changes,
        stage_count_interpretation='4→6 comprises3 gains/1 loss. Wanda repairs the attribute type but both finals alreadyWanda. FindingKraftland regresses to uncertainty while documentary remains visible and bothfinalsNo; native0 involves a reference scope issue. Partial information and complete truth remain separate.',
        gain_accounting=dict(total_mean_F1_delta=sum(x['f1'] for x in pairs)/27,two_grounded_generation_repairs_mean_delta=sum(x['F1_delta'] for x in improved if x['classification']=='grounded_generation_repair')/27,two_surface_reference_gains_mean_delta=sum(x['F1_delta'] for x in improved if x['classification']!='grounded_generation_repair')/27,limit='Arithmetic description of4 observations only, not causal effects or population cause shares'),
        historical_G0_repeat=dict(summary=repeat_summary,cases=repeat,limit='Nonconcurrent repetition mixes time,service andgeneration variation; not pure stochastic variance or concurrent factorial. Identicalfinal-payload output drift is observed, not proof of its isolated cause.'),
        conclusion='T1 outperforms synchronousT0 onthis developmentchallenge, but only2/4native gains verifyrelationrepair. T1 remains belowhistoricalG0; nooverallP02 gain or format×ROLE confirmation.3retiredunknown reservations remain despite all54conditionsresolved.',
        original_reports_labels_unchanged=True,new_API_calls=0,no_new_retrieval_GPU=True,L_unrun_outputs_not_opened=True,main_evaluation_remains_paused=True)
    assert before=={rel(p):sha(p) for p in files}
    target=P/'ROOT_NATIVE_AND_PAIRED_AUDIT.json';assert not target.exists()
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps(dict(passed=True,native=54,logical_stage_contracts=108,current_complete=97,retired_unknown=3,known_CNY=known,reserved_CNY=reserved,repeat=repeat_summary,json_sha256=sha(target))))

if __name__=='__main__':main()
