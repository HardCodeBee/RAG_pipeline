"""Hash-authorized operational recovery for factor90 job160987; frozen science unchanged.

snapshot/auth-template/status are local and read-only against original evidence.
Only run may archive the one authorized hold/STOP, and only after CoT152 closes.
No automatic second allocation, unknown reservation removal, or quality selection.
"""
from contextlib import closing, contextmanager
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import shutil
import sqlite3
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "src"))
from p02_multigrain_timing_cachefix_v1.core.cache import utc, run_lock
from experiments.query_decomposition.p02_reference_binding_priority_fixed90_v1_20261022 import run as full
from experiments.query_decomposition.p02_reference_binding_priority_fixed90_v1_20261022 import remote_bridge
from experiments.query_decomposition.p02_shared_context_fixed90_v1_20261022.native_ask import any_returned, stage_success

OUT = full.OUT
INCIDENT = OUT / "incidents/job160987_logging_failure"
CONTINUATION = OUT / "continuations/recovery01"
AUTH = HERE / "FACTOR90_RUNTIME_RECOVERY_AUTHORIZATION.json"
DECISION = "P02_FACTOR90_LOGGER_RUNTIME_RECOVERY01_20261022"
JOB = "160987"
TASK = "hotpotqa:5a7fd95d5542992e7d278dc5/B1"
REQUEST = "898a4a415ca44e6f83bed2c6494308a8"
PAYLOAD_SHA = "38f7911f91b1294849232adad38d541eb8cdd329d1bf6879d84dafce56266881"
COT = ROOT / "experiments/query_decomposition/p02_local_cot_stage38_v1_20261022"
REMOTE_DIRECTORY = "/home/projects/u7830488/p02_prompt_small_evals_20261022/factor90_0988e8eccdc08419_recovery01"
NAMESPACE = "p02_prompt_research_v1_20261022/" + str(OUT.resolve())


def read(path): return full.read(path)
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def rows(path): return full.rows(path)
def rel(path): return Path(path).resolve().relative_to(ROOT).as_posix()
def ro(path): return sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True)
def write(path, value): full.atomic_json(Path(path), value)


def load_sibling(name):
    spec = importlib.util.spec_from_file_location("_factor90_recovery_" + name, HERE / (name + ".py"))
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def safe_event(value, output=None):
    """Preserve caller UTC if present; supply it otherwise. Never duplicate kwargs."""
    record = dict(value); record.setdefault("utc", utc())
    output = OUT if output is None else Path(output)
    output.mkdir(parents=True, exist_ok=True)
    with (output / "events.jsonl").open("a", encoding="utf8") as stream:
        stream.write(json.dumps(record, ensure_ascii=False) + "\n")


@contextmanager
def event_patch():
    original = full.event; full.event = safe_event
    try: yield
    finally: full.event = original


def held_path(): return OUT / "held" / (full.digest(TASK) + ".json")


def returnless_proof(checkpoint=None, held=None):
    checkpoint = OUT / "checkpoint.sqlite3" if checkpoint is None else Path(checkpoint)
    held = read(held_path()) if held is None else held
    assert held["task_id"] == TASK and held["status"] == "held_technical"
    assert held["error_type"] == "TechnicalHeld"
    config = read(full.PACKAGE / "config.json"); model = config["generation"]["model"]
    with closing(ro(checkpoint)) as db:
        db.execute("BEGIN")
        assert db.execute("SELECT count(*) FROM requests WHERE status='in_flight'").fetchone()[0] == 0
        record = db.execute("SELECT stage,payload,status,started,completed,result FROM retired_requests WHERE id=?", (REQUEST,)).fetchall()
        assert len(record) == 1
        stage, payload, status, started, completed, encoded = record[0]; receipt = json.loads(encoded)
        assert stage == "full8/" + TASK + "/legacy/answer/3" and status == "unknown"
        assert hashlib.sha256(payload.encode()).hexdigest() == PAYLOAD_SHA
        assert receipt["requested_model"] == model and not any_returned(receipt)
        assert db.execute("SELECT count(*) FROM requests WHERE payload=?", (payload,)).fetchone()[0] == 0
        attempts = db.execute("SELECT count(*) FROM retired_requests WHERE payload=?", (payload,)).fetchone()[0]
        assert attempts == 1
        prefixes = held["completed_stage_request_ids"]; assert len(prefixes) == len(set(prefixes)) == 4
        for rid in prefixes:
            row = db.execute("SELECT stage,status,result FROM requests WHERE id=?", (rid,)).fetchone()
            uses = [s for s, in db.execute("SELECT stage FROM request_stages WHERE request_id=?", (rid,))]
            assert row and any(s.startswith("full8/" + TASK + "/") for s in uses)
            assert stage_success(dict(json.loads(row[2]), status=row[1]), model, row[0])
    with closing(ro(config["budget"]["ledger"])) as ledger:
        charge = ledger.execute("SELECT namespace,actual,reserved,status FROM charges WHERE id=?", (REQUEST,)).fetchone()
    assert charge and charge[0] == NAMESPACE and charge[1] is None and charge[2] == 0.0054296 and charge[3] == "reserved"
    return dict(request_id=REQUEST, task_id=TASK, payload_sha256=PAYLOAD_SHA, status=status,
        started_utc=started, completed_utc=completed, requested_model=model, any_returned_evidence=False,
        retired_attempts=attempts, active_same_payload=0, successful_prefix_request_ids=prefixes,
        ledger_namespace=charge[0], ledger_actual_CNY=None, unresolved_reserved_CNY=charge[2],
        reservation_preserved=True, remaining_maximum_actual_attempts=4,
        note="No returned evidence does not prove no provider work occurred; retain the reservation.")


def snapshot():
    """Copy stable old evidence and SQLite online backup; never open original writable."""
    full.check()
    manifest = INCIDENT / "SNAPSHOT.json"
    if manifest.exists():
        value = read(manifest)
        assert all(sha(INCIDENT / name) == pin for name, pin in value["files"].items())
        return value
    proof = returnless_proof()
    watch = load_sibling("watch_factor90_scheduler")
    identity = watch.local_identity(); progress = watch.progress()
    assert identity["job_id"] == JOB and progress["attempted"] == 3 and progress["in_flight"] == 0
    terminal = read(OUT / "SCHEDULER_TERMINAL.json")
    assert watch.validate_terminal(identity, terminal["commands"])["state"] == "COMPLETED"
    INCIDENT.mkdir(parents=True, exist_ok=True)
    names = ["REMOTE_JOB_ID.json", "REMOTE_GPU_READY.json", "SCHEDULER_TERMINAL.json", "SCHEDULER_WATCH_HEARTBEAT.json",
        "STOP_REQUESTED", "ALLOCATION_CLOCK.json", "REMOTE_SUBMISSION_ATTEMPT.json", "events.jsonl", "REMOTE_EVENTS.jsonl"]
    names += [name for name in ("REMOTE_GPU_FINISHED.json", "REMOTE_WORKER_ERROR.json") if (OUT / name).exists()]
    paths = [(OUT / name, name) for name in names] + [(held_path(), "held_technical.json")]
    for source, name in paths:
        target = INCIDENT / name
        if target.exists(): assert sha(target) == sha(source)
        else: shutil.copyfile(source, target)
    with closing(ro(OUT / "checkpoint.sqlite3")) as source, closing(sqlite3.connect(INCIDENT / "checkpoint.sqlite3")) as destination:
        source.backup(destination)
    write(INCIDENT / "RETURNLESS_PROOF.json", proof)
    value = dict(utc=utc(), job_id=JOB, protocol_sha256=sha(full.PROTOCOL), attempted=3, in_flight=0,
        original_files_unchanged=True, read_only_original_checkpoint=True, quality_not_inspected=True,
        files={p.name: sha(p) for p in INCIDENT.iterdir() if p.is_file() and p.name != "SNAPSHOT.json"})
    write(manifest, value); return value


def cot_status():
    """Independent metadata barrier; no imported CoT runner or model/quality content."""
    output = ROOT / "outputs/query_decomposition" / COT.name
    try:
        protocol = COT / "PROTOCOL.frozen.json"
        expected = dict(protocol_sha256=sha(protocol), inputs_sha256=sha(COT / "INPUTS.frozen.jsonl"),
            order_sha256=sha(COT / "TASK_ORDER.frozen.jsonl"), historical_seed=None)
        ordered = rows(COT / "TASK_ORDER.frozen.jsonl"); planned = {r["task_id"] for r in ordered}
        assert len(ordered) == len(planned) == 152
        with closing(ro(output / "checkpoint.sqlite3")) as db:
            db.execute("BEGIN")
            row = db.execute("SELECT value FROM data WHERE kind='meta' AND key='identity'").fetchone()
            assert row and json.loads(row[0]) == expected
            done = dict(db.execute("SELECT key,json_extract(value,'$.status') FROM data WHERE kind='outcome'"))
            inflight = db.execute("SELECT count(*) FROM requests WHERE status='in_flight'").fetchone()[0]
        held = {read(p)["task_id"] for p in (output / "held").glob("*.json")}
        assert set(done) <= planned and held <= planned and not set(done).intersection(held)
        assert set(done.values()) <= {"success", "algorithm_failure"}
        return dict(finished=set(done) | held == planned and inflight == 0, attempted=len(set(done) | held),
            planned=152, in_flight=inflight, protocol_sha256=expected["protocol_sha256"], quality_not_a_gate=True)
    except (OSError, AssertionError, ValueError, TypeError, KeyError, sqlite3.Error) as error:
        return dict(finished=False, reason="cot_not_closed", error_type=type(error).__name__)


def authorization_template():
    return dict(approved=False, decision_id=DECISION, script_sha256=sha(__file__), protocol_sha256=sha(full.PROTOCOL),
        incident_snapshot_sha256=sha(INCIDENT / "SNAPSHOT.json"), cot_protocol_sha256=sha(COT / "PROTOCOL.frozen.json"),
        continuation_directory=rel(CONTINUATION), remote_directory=REMOTE_DIRECTORY,
        manual_recovery_task_ids=[TASK], returnless_request_ids=[REQUEST], maximum_technical_attempts=5,
        old_stop_sha256=sha(INCIDENT / "STOP_REQUESTED"), old_held_sha256=sha(INCIDENT / "held_technical.json"),
        only_event_timestamp_adapter=True, unknown_reservations_preserved=True, main_evaluation_resumed=False,
        predecessor_supplement_sha256=sha(HERE / "context90_scheduler_closure.py"),
        scheduler_watcher_sha256=sha(HERE / "watch_factor90_scheduler.py"))


def authorized():
    auth = read(AUTH); expected = authorization_template()
    assert auth.get("approved") is True
    assert all(auth.get(k) == v for k, v in expected.items() if k != "approved")
    decision = [r for r in rows(full.PLAN / "DECISIONS.jsonl") if r.get("id") == DECISION]
    assert len(decision) == 1 and decision[0].get("approved") is True
    assert decision[0].get("script_sha256") == auth["script_sha256"]
    assert decision[0].get("authorization_sha256") == sha(AUTH)
    assert all(sha(INCIDENT / name) == pin for name, pin in read(INCIDENT / "SNAPSHOT.json")["files"].items())
    full.authorized(); return auth


def release_one_held(auth):
    """Run-only, under deployment+checkpoint locks, after all152 CoT conditions close."""
    assert cot_status()["finished"]
    assert not (CONTINUATION / "RELEASED.json").exists(), "Release is one-shot; inspect a partial launch instead of repeating it"
    assert not (CONTINUATION / "REMOTE_SUBMISSION_ATTEMPT.json").exists()
    assert sha(OUT / "STOP_REQUESTED") == auth["old_stop_sha256"]
    assert sha(held_path()) == auth["old_held_sha256"]
    proof = returnless_proof()
    watch = load_sibling("watch_factor90_scheduler")
    assert watch.progress() == dict(valid=True, attempted=3, planned=360, in_flight=0, complete=False, checkpoint_available=True)
    CONTINUATION.mkdir(parents=True, exist_ok=True)
    for source, name in ((OUT / "STOP_REQUESTED", "old_STOP_REQUESTED"), (held_path(), "old_held_technical.json")):
        target = CONTINUATION / name
        assert not target.exists()
        source.rename(target)
    write(CONTINUATION / "RELEASED.json", dict(utc=utc(), decision_id=DECISION, protocol_sha256=sha(full.PROTOCOL),
        task_id=TASK, proof=proof, old_metadata_and_unknown_reservation_preserved=True, no_quality_selection=True))


def continuation_bridge_class():
    parent = remote_bridge.bridge_class()
    class RecoveryBridge(parent):
        def __init__(self, resources, output, authorization):
            super().__init__(resources, output, authorization)
            self.directory = REMOTE_DIRECTORY
    return RecoveryBridge


def record_failure(error):
    """Fail closed after any attempted release; never restore/reissue a held request."""
    CONTINUATION.mkdir(parents=True, exist_ok=True)
    write(CONTINUATION / "LAUNCH_OR_RUNTIME_FAILURE.json", dict(utc=utc(), error_type=type(error).__name__,
        protocol_sha256=sha(full.PROTOCOL), receipt_review_required=True, automatic_retry=False,
        checkpoint_and_held_records_not_modified_by_handler=True))
    for target in (OUT / "STOP_REQUESTED", CONTINUATION / "STOP_REQUESTED"):
        try:
            with target.open("x", encoding="utf8") as stream:
                stream.write("Factor90 recovery01 launch/runtime stopped; inspect preserved receipts before any continuation.\n")
        except FileExistsError: pass


def run(wait=False):
    auth = authorized()
    while not cot_status()["finished"]:
        if not wait: return dict(state="waiting_cot152", cot=cot_status(), new_API_SSH_GPU_requests=0)
        time.sleep(30)
        authorized()
    closure = load_sibling("context90_scheduler_closure")
    from experiments.query_decomposition.p02_reference_binding_priority_probe_v1_20261022 import run as stage
    original_guard = stage.context90_completion_status
    stage.context90_completion_status = lambda: closure.completion_status(original_guard, "full90")
    try:
        assert full.predecessor_status()["finished"]
        with run_lock(OUT / "remote_deployment_lock"):
            release_started = False
            try:
                with run_lock(OUT):
                    release_started = True
                    release_one_held(auth)
                bridge = continuation_bridge_class()(read(full.HERE / "RESOURCE_CONTRACTS.json"), CONTINUATION, full.authorized())
                try:
                    bridge.start()
                    with event_patch(): return full.run_with_bridge(bridge)
                finally: bridge.close()
            except BaseException as error:
                if release_started: record_failure(error)
                raise
    finally: stage.context90_completion_status = original_guard


def watch():
    """Reuse audited scheduler semantics with continuation receipts and main STOP."""
    authorized()
    module = load_sibling("watch_factor90_scheduler")
    original_progress = module.progress
    module.OUTPUT = CONTINUATION

    def main_progress():
        module.OUTPUT = OUT
        try: return original_progress()
        finally: module.OUTPUT = CONTINUATION

    def continuation_identity():
        job = read(CONTINUATION / "REMOTE_JOB_ID.json")
        assert str(job["job_id"]).isdigit() and job["job_id"] != JOB
        assert job["directory"] == REMOTE_DIRECTORY and job["protocol_sha256"] == sha(full.PROTOCOL)
        ready_path = CONTINUATION / "REMOTE_GPU_READY.json"
        if ready_path.exists():
            ready = read(ready_path)
            assert ready["job_id"] == job["job_id"] and ready["protocol_sha256"] == job["protocol_sha256"]
            assert ready["status"] == "ready" and ready["no_LLM_credentials_or_requests"] is True and "A6000" in ready["gpu"]
            assert {ds: r["identity"] for ds, r in ready["resources"].items()} == {
                ds: r["identity"] for ds, r in read(full.HERE / "RESOURCE_CONTRACTS.json").items()}
        return dict(**job, ready_available=ready_path.exists())

    def record_terminal(job, commands, terminal, counts):
        # Keep true counts in the receipt; suppress only the old helper's STOP
        # side effect so the signal goes to the live controller directory.
        assert terminal["verified"] and terminal["job_id"] == job["job_id"] and counts["valid"]
        receipt = dict(utc=utc(), experiment=full.HERE.name, protocol_sha256=job["protocol_sha256"], job_id=job["job_id"],
            remote_directory=job["directory"], host=module.HOST, read_only_remote=True, new_jobs=0, API_requests=0,
            commands=commands, terminal=terminal, progress=counts, graceful_worker_FINISHED_receipt=False)
        path = CONTINUATION / "SCHEDULER_TERMINAL.json"
        if path.exists(): assert read(path)["job_id"] == job["job_id"]
        else: module.write(path, receipt)
        stopped = False
        if not counts["complete"]:
            try:
                with (OUT / "STOP_REQUESTED").open("x", encoding="utf8") as stream:
                    stream.write("Verified scheduler terminal state for factor90 continuation job " + job["job_id"] + "; preserve partial work.\n")
                stopped = True
            except FileExistsError: pass
        return dict(stop_written=stopped, stop_exists=(OUT / "STOP_REQUESTED").exists(), terminal_receipt_recorded=True)

    module.progress, module.local_identity, module.record_terminal = main_progress, continuation_identity, record_terminal
    return module.watch()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("snapshot", "auth-template", "status", "run", "watch"))
    parser.add_argument("--wait", action="store_true")
    args = parser.parse_args()
    if args.wait and args.action != "run": parser.error("--wait is run-only")
    result = snapshot() if args.action == "snapshot" else authorization_template() if args.action == "auth-template" else (
        dict(cot=cot_status(), live_proof=returnless_proof(), new_API_SSH_GPU_requests=0) if args.action == "status" else watch() if args.action == "watch" else run(args.wait))
    print(json.dumps(result, ensure_ascii=True), flush=True)


if __name__ == "__main__": main()
