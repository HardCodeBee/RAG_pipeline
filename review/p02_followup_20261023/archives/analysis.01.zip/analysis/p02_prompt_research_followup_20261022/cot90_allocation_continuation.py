"""Conditional allocation02 only; default is read-only and never starts services.

snapshot/auth-template are explicit, post-closure operations. run additionally
needs root exact-hash AUTH. The original controller/cache/namespace are reused;
original job receipts, STOPs, reservations and science sources are never reset.
"""
from contextlib import closing
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from experiments.query_decomposition.p02_local_cot_fixed90_v1_20261022 import run as full
from experiments.query_decomposition.p02_local_cot_fixed90_v1_20261022 import preparation as p
from experiments.query_decomposition.p02_local_cot_fixed90_v1_20261022 import remote_bridge, predecessors
from p02_multigrain_timing_cachefix_v1.core.cache import run_lock

HERE = Path(__file__).resolve().parent
SELF = Path(__file__).resolve()
OUT = p.OUT
CONT = OUT / "continuations/allocation02"
SNAPSHOT = CONT / "PREDECESSOR_SNAPSHOT.json"
AUTH = HERE / "COT90_ALLOCATION02_AUTHORIZATION.json"
DECISION = "P02_COT90_ALLOCATION02_TECHNICAL_CONTINUATION_20261023"
OLD_JOB = "161325"
PROTOCOL = "222de9cd4f7dca8509ab6bf1e391a27634536d2cf0b0cdf0f0e42e9dcd256702"
OLD_DIRECTORY = "/home/projects/u7830488/p02_prompt_small_evals_20261022/cot90_222de9cd4f7dca85"
REMOTE_DIRECTORY = OLD_DIRECTORY + "_allocation02"
TEST = HERE / "test_cot90_allocation_continuation.py"


def read(path): return p.read(path)
def sha(path): return p.sha(Path(path))
def rel(path): return Path(path).resolve().relative_to(ROOT).as_posix()
def digest(value): return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()).hexdigest()
def namespace(output): return "p02_prompt_research_v1_20261022/" + str(Path(output).resolve())
def ro(path):
    db = sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True)
    db.execute("PRAGMA query_only=ON")
    return db


def priority_module():
    path = HERE / "cot90_priority_continuation.py"
    spec = importlib.util.spec_from_file_location("_cot90_priority_for_allocation02", path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


def status():
    """Metadata only: no Cache constructor, report(), writes or quality fields."""
    full.authorized()
    ordered = p.rows(p.ORDER); planned = {v["task_id"] for v in ordered}
    assert len(ordered) == len(planned) == 360 and sha(p.PROTOCOL) == PROTOCOL
    with closing(ro(OUT / "checkpoint.sqlite3")) as db:
        db.execute("BEGIN")
        assert json.loads(db.execute("SELECT value FROM data WHERE kind='meta' AND key='identity'").fetchone()[0]) == full.expected_identity()
        done = dict(db.execute("SELECT key,json_extract(value,'$.status') FROM data WHERE kind='outcome'"))
        inflight = db.execute("SELECT count(*) FROM requests WHERE status='in_flight'").fetchone()[0]
    held = [read(f)["task_id"] for f in (OUT / "held").glob("*.json")]
    assert len(held) == len(set(held)) and set(done) <= planned and set(held) <= planned
    assert not set(done).intersection(held)
    assert set(done.values()) <= {"success", "success_truncated", "algorithm_failure"}
    remaining = [v["task_id"] for v in ordered if v["task_id"] not in set(done) | set(held)]
    return dict(planned=360, attempted=len(done) + len(held), in_flight=inflight,
                remaining_task_ids=remaining, remaining=len(remaining), all_attempted=not remaining,
                quality_not_inspected=True, new_API_SSH_GPU_requests=0)


def table_fingerprint(db, table, *, where="", params=()):
    quoted = '"' + table.replace('"', '""') + '"'
    columns = [r[1] for r in db.execute("PRAGMA table_info(" + quoted + ")")]
    assert columns
    schema = db.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()[0]
    order = ",".join(str(i + 1) for i in range(len(columns)))
    h = hashlib.sha256(); count = 0
    for row in db.execute("SELECT * FROM " + quoted + where + " ORDER BY " + order, params):
        h.update((json.dumps(row, ensure_ascii=True, separators=(",", ":")) + "\n").encode()); count += 1
    return dict(schema=schema, columns=columns, rows=count, sha256=h.hexdigest())


def stable_state(checkpoint=None, ledger=None, output=None):
    """Full own DB rows; ledger fingerprint is ONLY this exact namespace."""
    output = OUT if output is None else Path(output)
    checkpoint = output / "checkpoint.sqlite3" if checkpoint is None else checkpoint
    ledger = read(p.PACKAGE / "config.json")["budget"]["ledger"] if ledger is None else ledger
    with closing(ro(checkpoint)) as db:
        db.execute("BEGIN")
        tables = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        assert {"data", "requests", "request_stages"} <= set(tables)
        fingerprints = {name: table_fingerprint(db, name) for name in tables}
        request_statuses = dict(db.execute("SELECT status,count(*) FROM requests GROUP BY status"))
    held = {f.name: sha(f) for f in sorted((output / "held").glob("*.json"))}
    with closing(ro(ledger)) as db:
        db.execute("BEGIN")
        charges = table_fingerprint(db, "charges", where=" WHERE namespace=?", params=(namespace(output),))
    return dict(tables=fingerprints, request_statuses=request_statuses, held=held,
                ledger_namespace=namespace(output), scoped_charges=charges)


def validate_scheduler_closure(job, receipt):
    """Require actual Slurm queue+accounting+owner/path evidence, not a boolean."""
    assert job == dict(job_id=OLD_JOB, directory=OLD_DIRECTORY, protocol_sha256=PROTOCOL)
    assert receipt["job_id"] == OLD_JOB and receipt["protocol_sha256"] == PROTOCOL
    assert receipt["remote_directory"] == OLD_DIRECTORY and receipt["experiment"] == p.HERE.name
    assert receipt["read_only_remote"] is True and receipt["API_requests"] == receipt["new_jobs"] == 0
    assert receipt["controller_exited"] is True and receipt["auxiliary_exited"] is True
    commands = receipt["commands"]
    expected = dict(squeue=["squeue", "-h", "-j", OLD_JOB, "-o", "%i|%T|%j"],
                    sacct=["sacct", "-n", "-P", "-j", OLD_JOB, "--format=JobIDRaw,JobName,State,ExitCode,Start,End,Timelimit,NodeList"],
                    scontrol=["scontrol", "show", "job", "-o", OLD_JOB])
    for name,args in expected.items():
        assert commands[name]["argv"] == args and commands[name]["code"] == 0 and not commands[name]["stderr"].strip()
    assert not commands["squeue"]["stdout"].strip()
    accounting = [x.split("|") for x in commands["sacct"]["stdout"].splitlines() if x.strip()]
    assert accounting and sum(x[0] == OLD_JOB for x in accounting) == 1
    assert all(len(x) >= 6 and (x[0] == OLD_JOB or x[0].startswith(OLD_JOB + "."))
               and x[2].split()[0].rstrip("+") in predecessors.TERMINAL and x[5] not in ("", "Unknown") for x in accounting)
    state = next(x[2].split()[0].rstrip("+") for x in accounting if x[0] == OLD_JOB)
    fields = dict(re.findall(r"(?:^|\s)([A-Za-z][A-Za-z0-9_:]*)=([^\s]*)", commands["scontrol"]["stdout"]))
    assert fields.get("JobId") == OLD_JOB and fields.get("JobName") == "p02-cot90"
    assert fields.get("UserId", "").split("(")[0] == "u7830488" and fields.get("WorkDir") == OLD_DIRECTORY
    assert fields.get("JobState") == state
    return dict(closed=True, state=state, job_id=OLD_JOB, scheduler_verified=True)


def closure_checks(path):
    full.authorized(); priority = priority_module(); priority.priority_status()
    assert not (OUT / "STOP_REQUESTED").exists(), "Preserve original STOP; separate explicit review required"
    assert not (CONT / "STOP_REQUESTED").exists(), "Continuation stopped; no blind restart"
    closed = validate_scheduler_closure(read(OUT / "REMOTE_JOB_ID.json"), read(path))
    ready = read(OUT / "REMOTE_GPU_READY.json")
    assert ready["job_id"] == OLD_JOB and ready["protocol_sha256"] == PROTOCOL and ready["status"] == "ready"
    assert ready["no_LLM_credentials_or_requests"] is True and "A6000" in ready["gpu"]
    assert {k: v["identity"] for k,v in ready["resources"].items()} == {k:v["identity"] for k,v in read(p.HERE / "RESOURCE_CONTRACTS.json").items()}
    finished = OUT / "REMOTE_GPU_FINISHED.json"
    if finished.exists():
        value = read(finished)
        assert value["status"] == "stopped" and value["no_LLM_requests"] is True
        assert type(value["retrieval_requests_processed"]) is int and value["retrieval_requests_processed"] >= 0
    elif closed["state"] == "COMPLETED":
        raise AssertionError("Normal completion needs owned worker FINISHED receipt")
    # A crashed/timed-out worker may have no FINISHED; preserve that distinction.
    closed["worker_FINISHED_available"] = finished.exists()
    for log in (OUT / "directory_visibility_auxiliary").glob("*.jsonl"):
        records = [json.loads(x) for x in log.read_text(encoding="utf8").splitlines() if x.strip()]
        assert records and records[0].get("job_id") == OLD_JOB and records[-1].get("event") == "local_stopped"
    gate = read(OUT / "ENGINEERING_GATE.json")
    assert gate["passed"] is True and gate["planned_conditions"] == 24 and gate["quality_not_a_gate"] is True
    current = status(); assert current["in_flight"] == 0
    return dict(scheduler=closed, metadata=current)


def snapshot(closure_path):
    """Explicit post-closure command; never invoked by default/status/prepare."""
    if status()["all_attempted"]: return dict(state="all360_attempted_no_continuation_needed", snapshot_created=False)
    rel(closure_path)  # Reject an out-of-workspace closure before creating files.
    assert not SNAPSHOT.exists() and not AUTH.exists()
    checks = closure_checks(closure_path)
    with run_lock(OUT / "remote_deployment_lock"), run_lock(OUT):
        assert closure_checks(closure_path) == checks
        before = stable_state()
        assert not before["request_statuses"].get("in_flight", 0)
        CONT.mkdir(parents=True, exist_ok=True)
        backup = CONT / "original_checkpoint.closed.sqlite3"
        assert not backup.exists()
        with closing(ro(OUT / "checkpoint.sqlite3")) as source, closing(sqlite3.connect(backup)) as target: source.backup(target)
        assert before == stable_state(), "Own namespace changed while snapshotting"
        files = [Path(closure_path), OUT / "REMOTE_JOB_ID.json", OUT / "REMOTE_GPU_READY.json", OUT / "ALLOCATION_CLOCK.json", OUT / "REMOTE_SUBMISSION_ATTEMPT.json", OUT / "ENGINEERING_GATE.json"]
        files += [f for f in (OUT / "REMOTE_GPU_FINISHED.json", OUT / "REMOTE_WORKER_ERROR.json") if f.exists()]
        files += list((OUT / "directory_visibility_auxiliary").glob("*.jsonl"))
        value = dict(utc=full.utc(), protocol_sha256=PROTOCOL,
                     closure_path=rel(closure_path), checks=checks, database=before,
                     backup_path=rel(backup), backup_sha256=sha(backup), pins={rel(f):sha(f) for f in files},
                     quality_not_inspected=True, original_files_modified=False)
        p.atomic_json(SNAPSHOT, value)
    return dict(snapshot=rel(SNAPSHOT), sha256=sha(SNAPSHOT), remaining=checks["metadata"]["remaining"])


def snapshot_check():
    value = read(SNAPSHOT)
    assert value["protocol_sha256"] == PROTOCOL and value["quality_not_inspected"] is True
    for path,pin in value["pins"].items(): assert sha(ROOT / path) == pin, path
    assert sha(ROOT / value["backup_path"]) == value["backup_sha256"]
    assert closure_checks(ROOT / value["closure_path"]) == value["checks"]
    assert stable_state() == value["database"], "Closed snapshot namespace drifted"
    return value


def auth_template():
    snapshot_check()
    return dict(approved=False, decision_id=DECISION, experiment=p.HERE.name,
                script_sha256=sha(SELF), offline_test_sha256=sha(TEST), protocol_sha256=PROTOCOL,
                snapshot_sha256=sha(SNAPSHOT), priority_authorization_sha256=sha(HERE / "COT90_PRIORITY_EXECUTION_AUTHORIZATION.json"),
                continuation_directory=rel(CONT), remote_directory=REMOTE_DIRECTORY,
                old_job_id=OLD_JOB, new_allocation_maximum=1, maximum_technical_attempts=5,
                same_checkpoint_and_ledger_namespace=True, current_namespace_returnless_recovery_only=True,
                unknown_reservations_preserved=True, retry_existing_held_conditions=False,
                scientific_inputs_changed=False, main_evaluation_resumed=False)


def authorized():
    full.authorized(); actual = read(AUTH); expected = auth_template()
    assert actual.get("approved") is True
    assert all(actual.get(k) == v for k,v in expected.items() if k != "approved")
    matches = [x for x in p.rows(p.PLAN / "DECISIONS.jsonl") if x.get("id") == DECISION]
    assert len(matches) == 1 and matches[0].get("approved") is True
    assert matches[0].get("authorization_sha256") == sha(AUTH) and matches[0].get("script_sha256") == sha(SELF)
    return actual


def allocation_preflight():
    assert not (CONT / "STOP_REQUESTED").exists()
    # One-shot fail closed: even a recorded live allocation needs reconciliation,
    # never a second call to sbatch following uncertain/failed submission.
    for name in ("EXECUTION_STARTED.json", "REMOTE_SUBMISSION_ATTEMPT.json", "REMOTE_JOB_ID.json", "ALLOCATION_CLOCK.json"):
        assert not (CONT / name).exists(), "Existing continuation allocation: inspect, never auto-resubmit"


def bridge_class():
    parent = remote_bridge.bridge_class()
    class ContinuationBridge(parent):
        def __init__(self, resources, output, authorization):
            assert Path(output) == CONT
            super().__init__(resources, output, authorization)
            self.directory = REMOTE_DIRECTORY
        def start(self):
            authorized()
            assert not (OUT / "STOP_REQUESTED").exists() and not (CONT / "STOP_REQUESTED").exists()
            return super().start()
        def can_start_condition(self):
            stopped = [rel(folder / "STOP_REQUESTED") for folder in (OUT, CONT) if (folder / "STOP_REQUESTED").exists()]
            if stopped:
                return dict(allowed=False, reason="local_continuation_stop", stop_markers=stopped)
            return super().can_start_condition()
    return ContinuationBridge


def run():
    if status()["all_attempted"]: return dict(state="all360_attempted_no_services", new_API_SSH_GPU_requests=0)
    auth = authorized(); allocation_preflight()
    priority = priority_module(); original = predecessors.status
    with run_lock(OUT / "remote_deployment_lock"):
        # Acquisition also proves the original allocating controller released it.
        with run_lock(OUT):
            authorized(); allocation_preflight()
            p.atomic_json(CONT / "EXECUTION_STARTED.json", dict(script_sha256=auth["script_sha256"],
                snapshot_sha256=auth["snapshot_sha256"], protocol_sha256=PROTOCOL,
                changed_only_allocation=True, original_namespace=namespace(OUT)))
        bridge = bridge_class()(read(p.HERE / "RESOURCE_CONTRACTS.json"), CONT, full.authorized())
        try:
            predecessors.status = priority.priority_status
            assert predecessors.status()["finished"]
            try:
                bridge.start()
                return full.run_with_bridge(bridge)
            finally: bridge.close()
        finally: predecessors.status = original


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", nargs="?", default="status", choices=("status", "prepare", "snapshot", "auth-template", "run"))
    parser.add_argument("--closure", type=Path)
    args = parser.parse_args()
    if args.action == "snapshot" and args.closure is None: parser.error("snapshot requires explicit --closure receipt")
    if args.action in ("status", "prepare"):
        value = dict(prepared_only=True, **status())
        value["remaining_task_ids_sha256"] = digest(value.pop("remaining_task_ids"))
    elif args.action == "snapshot": value = snapshot(args.closure.resolve())
    elif args.action == "auth-template": value = auth_template()  # Print only; root must explicitly create/approve AUTH.
    else: value = run()
    print(json.dumps(value,ensure_ascii=True),flush=True)


if __name__ == "__main__": main()
