"""Read-only monitoring and immutable, method-masked review packets for round two.

Never constructs the pipeline Cache, opens a provider session, or scores outputs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import random
import sqlite3
import sys
from collections import Counter
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))
REVIEW = ROOT / "experiments/query_decomposition/unified_rag_eval_v1_20261021/reviews/20261022_prompt_binding_goal_synthesis"
SPECS = {
    "ordinary": ("p02_ordinary_fewshot_probe_v1_20261022", "", "outcome", "INPUTS.frozen.jsonl", "probe_id", ("E0", "E1", "E2"), 90),
    "goal": ("p02_goal_scope_role_probe_v1_20261022", "scope27", "condition", "inputs27.frozen.jsonl", "id", ("S0", "S1", "S2"), 81),
    "actual": ("p02_actual_child_binding_probe_v1_20261022", "", "outcome", "INPUTS15.frozen.jsonl", "probe_id", ("R0", "R1", "R2"), 45),
    "final": ("p02_final_target_check_fixed90_v1_20261022", "", "outcome", "INPUTS90.frozen.jsonl", "id", ("W0", "W1"), 180),
    "factgoal": ("p02_goal_fact_role_probe_v1_20261022", "fact27", "condition", "inputs27.frozen.jsonl", "id", ("T0", "T1"), 54),
    "failure": ("p02_ordinary_failure_challenge8_v1_20261022", "", "outcome", "INPUTS8.frozen.jsonl", "probe_id", ("I0", "I1"), 16),
    "binding8": ("p02_failure8_actual_entity_probe_v1_20261022", "", "outcome", "INPUTS8.frozen.jsonl", "probe_id", ("B0", "B1", "B2"), 24),
    "native": ("p02_goal_native_role_fixed90_v1_20261022", "", "outcome", "INPUTS90.frozen.jsonl", "id", ("L0", "L1"), 180),
    "target8": ("p02_failure8_actual_target_probe_v1_20261022", "", "outcome", "INPUTS8.frozen.jsonl", "probe_id", ("C0", "C1"), 16),
    "dynamic8": ("p02_failure8_dynamic_target_fullrag_draft_20261022", "", "outcome", "INPUTS8.jsonl", "id", ("D0", "D1"), 16),
    "balanced20": ("p02_live_target_balanced20_dev_v1_20261022", "", "outcome", "INPUTS20.jsonl", "id", ("D0", "D1"), 40),
    "scope8": ("p02_ordinary_scope_input_probe8_v1_20261022", "", "outcome", "INPUTS8.frozen.jsonl", "probe_id", ("O0", "O1"), 16),
    "reader8": ("p02_m4_reader_stage_probe8_v1_20261022", "", "outcome", "INPUTS8.frozen.jsonl", "probe_id", ("M0", "M4"), 16),
    "m4full8": ("p02_m4_full8_dynamic_v1_20261022", "", "outcome", "INPUTS8.jsonl", "id", ("M0", "M4"), 16),
    "m4wiki20": ("p02_m4_wiki20_dynamic_dev_v1_20261022", "", "outcome", "INPUTS20.jsonl", "id", ("M0", "M4"), 40),
}


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def rows(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    temp.replace(path)


def snapshot(which):
    name, subdir, kind, input_file, ident, arms, planned = SPECS[which]
    run = ROOT / "outputs/query_decomposition" / name / subdir
    source = ROOT / "experiments/query_decomposition" / name / input_file
    if not (run / "checkpoint.sqlite3").exists():
        return run, rows(source) if source.exists() else [], [], {}
    with closing(sqlite3.connect((run / "checkpoint.sqlite3").resolve().as_uri() + "?mode=ro", uri=True)) as db:
        db.execute("BEGIN")
        outcomes = [json.loads(v) for (v,) in db.execute("SELECT value FROM data WHERE kind=? ORDER BY rowid", (kind,))]
        requests = dict(db.execute("SELECT status,count(*) FROM requests GROUP BY status").fetchall())
        db.commit()
    return run, rows(source), outcomes, requests


def status():
    config = read(ROOT / "src/p02_multigrain_timing_cachefix_v1/config.json")
    result = {"utc": datetime.now(timezone.utc).isoformat(), "main_evaluation_resumed": False, "experiments": {}}
    ledger_path = Path(config["budget"]["ledger"])
    if not ledger_path.is_absolute():
        ledger_path = ROOT / ledger_path
    with closing(sqlite3.connect(ledger_path.resolve().as_uri() + "?mode=ro", uri=True)) as ledger:
        for which, spec in SPECS.items():
            run, inputs, outcomes, requests = snapshot(which)
            known, reserved = ledger.execute(
                "SELECT coalesce(sum(actual),0),coalesce(sum(CASE WHEN actual IS NULL THEN reserved ELSE 0 END),0) FROM charges WHERE namespace=?",
                ("p02_prompt_research_v1_20261022/" + str(run.resolve()),),
            ).fetchone()
            seen = Counter(r["status"] for r in outcomes)
            alerts = []
            for event_name in ("trace.jsonl", "events.jsonl"):
                path = run / event_name
                if path.exists():
                    alerts += [r for r in rows(path) if r.get("event") == "expense_alert"]
            result["experiments"][which] = {
                "planned_conditions": spec[-1], "resolved_conditions": len(outcomes),
                "outcome_status": dict(seen), "request_status": requests,
                "returned_usage_estimate_CNY": known, "unknown_reserved_CNY": reserved,
                "expense_alerts": alerts,
                "native_component_accuracy_not_inferred": True,
            }
    current = read(ROOT / "outputs/query_decomposition/p02_information_flow_followup_20261022/CURRENT_REVIEW_VERSION.json")
    completion = read(ROOT / "outputs/query_decomposition/p02_information_flow_followup_20261022" / current["completion"])
    result["information_review"] = completion["primary_scope"]
    write(REVIEW / "ROUND2_LIVE_STATUS.json", result)
    tracker = read(REVIEW / "ROUND2_TRACKER.json")
    tracker.update(utc=result["utc"], offline_remaining={"current_primary_reviewed": completion["primary_scope"]["material_reviewed"],
        "remaining_nonfullscore": completion["primary_scope"]["unreviewed_nonfullscore"],
        "pending_work_items": completion["primary_scope"]["pending_work_items"], "supplemental8_unreviewed": True})
    for which, key in (("ordinary", "ordinary_fewshot"), ("goal", "goal_scope_role"), ("actual", "actual_child_binding"), ("final", "final_target_check"), ("factgoal", "fact_goal_role_followup"), ("failure", "ordinary_failure8_followup"), ("binding8", "actual_binding_failure8"), ("native", "native_goal_role90"), ("target8", "actual_target_failure8"), ("dynamic8", "dynamic_actual_target_full8")):
        s = result["experiments"][which]
        tracker["round2_experiments"].setdefault(key, {"planned": s["planned_conditions"]})
        tracker["round2_experiments"][key].update(resolved=s["resolved_conditions"],
            status="complete" if s["resolved_conditions"] == s["planned_conditions"] else "running_or_held")
    result["currently_inflight_requests"] = sum(s["request_status"].get("in_flight", 0) for s in result["experiments"].values())
    tracker["status"] = ("all_current_scoped_conditions_resolved_review_and_synthesis"
        if all(s["resolved_conditions"] == s["planned_conditions"] for s in result["experiments"].values()) else "running_scoped_small_research")
    tracker["main_evaluation_resumed"] = False
    tracker["next_preparations"] = ["evidence_selection_readonly_design"]
    write(REVIEW / "ROUND2_TRACKER.json", tracker)
    write(REVIEW / "ROUND2_LIVE_STATUS.json", result)
    lines = ["# 第二轮及后续自主探索进展", "", f"状态时间（UTC）：{result['utc']}。主评保持暂停。", "",
        "目标：保留冻结P02 R02/v12分解器及实际输出，解释下游未充分利用分解的原因，以同题完整RAG最终F1检验改进。人工修正60题不替换本轮输入。", "",
        "| 实验 | 已处理/计划条件 | 完整输出 | 算法终止 | 已知usage估费/元 | 尚未结算预留/元 |",
        "|---|---:|---:|---:|---:|---:|"]
    for which, label in (("ordinary", "普通QA：原引用/实体名/描述式少样例"), ("goal", "goal：综合说明/目标约束/角色核对"),
            ("actual", "实际子问：原题/重复题/已有改写候选"), ("final", "完整上游复用：原final/单句目标核对"),
            ("factgoal", "后续goal原事实句：原版/单句角色核对"), ("failure", "后续8个失效/弃答边界：原版/目标关系核对"),
            ("binding8", "同8节点：复用新控制/重复原题/已有实体改写候选"),
            ("native", "原生90：goal128原版/角色核对，原formatter与final64"),
            ("target8", "同8节点：原当前子问/已有改写作为实际QA目标"),
            ("dynamic8", "完整动态8题：新鲜原版/全部普通QA接入live改写")):
        s = result["experiments"][which]
        lines.append(f"| {label} | {s['resolved_conditions']}/{s['planned_conditions']} | {s['outcome_status'].get('success', 0)} | {s['outcome_status'].get('algorithm_failure', 0)} | {s['returned_usage_estimate_CNY']:.6f} | {s['unknown_reserved_CNY']:.6f} |")
    lines += ["", "预留包含运行中或缺少结算回执的请求，不等于已确认花费；退役未知请求及技术尝试账目均保留。", "",
        "信息流主270条材料均已读取：230条非满分、40条固定成功对照；258条完成声明范围检查，12条保留事实/口径待核。另8条补充包未开展新复核。", "",
        "必要信息标志只描述本次检查范围内的信息保留和使用，不是完整最终回答金标；不得把147条充分标志当成147条可修复错误。原始F1/EM及事实标签不改。", "",
        "实际子问接口严格复用本轮15条E0控制（费用已在少样例实验记账），9组相同候选条件也精确共享回执；45逻辑条件不等于45个新付费输出。final目标核对两臂独立保留原P02完整上游，不与子问或goal新变体混合。具体执行以各协议、授权和检查点为准。", "",
        "第一批246条件和两项旧fixed90实验结果保留于 RESULTS_SUMMARY.md；第二轮全部公开为开发证据，不声称独立确认，不替换正式主方法。", ""]
    (REVIEW / "ROUND2_PROGRESS.md").write_text("\n".join(lines), encoding="utf8")
    return result


def blind(which, batch):
    assert which in ("ordinary", "goal", "actual", "factgoal", "failure", "binding8", "target8", "scope8", "reader8"), "Use blind-final for final endpoint contrasts"
    spec = SPECS[which]
    run, inputs, outcomes, _ = snapshot(which)
    ident, arms = spec[4], spec[5]
    outdir = run / "root_blind_review" / batch
    assert not outdir.exists(), "Review batches are immutable; choose a new name"
    prior = set()
    for path in (run / "root_blind_review").glob("*/PACKET.json"):
        prior.update(r["case_id"] for r in read(path)["cases"])
    indexed = {(r[ident], r["arm"]): r for r in outcomes}
    rng = random.Random(2026102202)
    packets, key = [], []
    for item in inputs:
        case = item[ident]
        if case in prior or not all((case, a) in indexed for a in arms):
            continue
        if which in ("ordinary", "actual", "failure", "binding8", "target8", "scope8", "reader8"):
            base = {"case_id": case, "dataset": item["dataset"], "original_question": item["original_question"],
                "current_question": item["current_question"], "previous_QA": item["history"], "retrieved_passages": item["reader_packet"]}
            if which == "reader8":
                base["role"] = item["role"]
                base["retrieved_passages"] = "See each candidate's actual reader documents; no arm labels or policy metadata are included."
        else:
            base = {"case_id": case, "dataset": item["dataset"], "original_question": item["question"],
                "ordinary_nodes": item["ordinary_nodes"], "retrieved_passages": item["goal_reader_packet"]}
        order = list(arms)
        rng.shuffle(order)
        candidates = []
        for arm in order:
            outcome = indexed[case, arm]
            opaque = "c" + digest([which, batch, case, arm, "mask20261022"])[:12]
            text = outcome.get("answer", "") if which in ("ordinary", "actual", "failure", "binding8", "target8", "scope8", "reader8") else outcome.get("goal_text", "")
            candidates.append({"candidate_id": opaque, "text": text, "complete_output": outcome["status"] == "success"})
            if which == "reader8":
                from experiments.query_decomposition.p02_m4_reader_stage_probe8_v1_20261022 import templates as reader_templates
                candidates[-1].update(actual_reader_documents=[{k: d[k] for k in ("rank", "doc_id", "source", "text")} for d in reader_templates.reader(item, arm)["docs"]],
                    initial_answer=outcome.get("initial_answer"), formatter_triggered=outcome.get("formatter_triggered", False))
            key.append({"case_id": case, "candidate_id": opaque, "arm": arm, "outcome_sha256": digest(outcome),
                "source_request_id": outcome.get("request_id") if which in ("ordinary", "actual", "failure", "binding8", "target8", "scope8", "reader8") else outcome.get("goal_request_id")})
        packets.append({**base, "candidates": candidates})
    assert packets, "No new fully resolved triples"
    instruction = {
        "kind": which,
        "scope": "Stage semantic review; not final-answer scoring or independent human gold. Reviewer must disclose prior case exposure.",
        "constraints": "Do not open METHOD_KEY.local.json, native references, final predictions or F1 until review lock. Judge the actual question and retrieved dataset-time facts; do not infer correctness from method or original final outcome. Preserve unresolved facts as pending work items.",
        "fields": ["case_id", "candidate_id", "factual_correct", "addresses_actual_question", "necessary_information_retained", "entity_role_or_scope_error", "reason_with_input_evidence", "pending_work_items"],
        "truth_rule": "All stated facts must be correct; true but incomplete lists may be correct. True off-target background is an answer error. Reasonable insufficient-evidence abstention can be factually correct but loses necessary information; mark that separately. Distinguish unsupported from established false.",
        "cases": packets,
    }
    write(outdir / "PACKET.json", instruction)
    write(outdir / "METHOD_KEY.local.json", key)
    lock = {"cases": len(packets), "candidates": len(arms) * len(packets), "packet_sha256": hashlib.sha256((outdir / "PACKET.json").read_bytes()).hexdigest(),
        "method_key_sha256": hashlib.sha256((outdir / "METHOD_KEY.local.json").read_bytes()).hexdigest(), "no_native_or_final_in_packet": True}
    write(outdir / "PACKET_LOCK.json", lock)
    return {"packet": str((outdir / "PACKET.json").relative_to(ROOT)), **lock}


def lock_review(which, batch, expected_sha):
    run, _, _, _ = snapshot(which)
    folder = run / "root_blind_review" / batch
    path = folder / "SEMANTIC_REVIEWS.blinded.jsonl"
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected_sha
    packet = read(folder / "PACKET.json")
    expected = {(r["case_id"], c["candidate_id"]) for r in packet["cases"] for c in r["candidates"]}
    reviews = rows(path)
    assert len(reviews) == len(expected) and {(r["case_id"], r["candidate_id"]) for r in reviews} == expected
    for rec in reviews:
        for field in ("factual_correct", "addresses_actual_question", "necessary_information_retained", "entity_role_or_scope_error"):
            assert rec[field] is None or type(rec[field]) is bool
        assert rec["reason_with_input_evidence"]
        assert rec.get("reviewer_disclosure") or rec.get("reviewer_exposure_disclosure") or (rec.get("reviewer") and rec.get("prior_exposure"))
    value = {"review_sha256": expected_sha, "packet_sha256": hashlib.sha256((folder / "PACKET.json").read_bytes()).hexdigest(),
        "records": len(reviews), "locked_before_root_method_join": True, "not_independent_human_gold": True}
    target = folder / "ROOT_REVIEW_LOCK.json"
    if target.exists():
        assert read(target) == value
    else:
        write(target, value)
    return value


def blind_final(batch, which="final"):
    assert which in ("final", "native", "dynamic8", "balanced20", "m4full8", "m4wiki20")
    run, inputs, outcomes, _ = snapshot(which)
    arm_names = SPECS[which][5]
    if which == "native":
        from experiments.query_decomposition.p02_goal_native_role_fixed90_v1_20261022 import templates as native_templates
        config = read(ROOT / "src/p02_multigrain_timing_cachefix_v1/config.json")
        examples = read(ROOT / "src/p02_multigrain_timing_cachefix_v1/prompts/final_examples.json")
    folder = run / "root_blind_review" / batch
    assert not folder.exists(), "Immutable review batch"
    prior = set()
    for path in (run / "root_blind_review").glob("*/PACKET.json"):
        prior.update(r["case_id"] for r in read(path)["cases"])
    indexed = {(r["id"], r["arm"]): r for r in outcomes}
    rng = random.Random(2026102203)
    packets, key, identical = [], [], []
    for item in inputs:
        case = item["id"]
        if case in prior or not all((case, a) in indexed for a in arm_names):
            continue
        text_field = "prediction" if which in ("dynamic8", "balanced20", "m4full8", "m4wiki20") else "answer"
        if indexed[case, arm_names[0]][text_field] == indexed[case, arm_names[1]][text_field]:
            identical.append(case)
            continue
        if which not in ("dynamic8", "balanced20", "m4full8", "m4wiki20"):
            source = ROOT / item["source"]
            assert hashlib.sha256(source.read_bytes()).hexdigest() == item["source_sha256"]
            trajectory = read(source)
        arms = list(arm_names)
        rng.shuffle(arms)
        candidates = []
        for arm in arms:
            rec = indexed[case, arm]
            opaque = "c" + digest([batch, case, arm, "final-mask-20261022"])[:12]
            candidate = {"candidate_id": opaque, "text": rec[text_field], "complete_output": rec["status"] in ("success", "success_truncated")}
            if which == "native":
                candidate["final_visible_context"] = (native_templates.final_prompt(item, rec["goal_answer_used"], config, examples)[1]
                    if rec["status"] in ("success", "success_truncated") else None)
                candidate["terminal_stage"] = rec.get("terminal_stage")
            elif which in ("dynamic8", "balanced20", "m4full8", "m4wiki20"):
                candidate["final_visible_context"] = rec.get("trajectory", {}).get("final_context")
                candidate["terminal_stage"] = rec.get("terminal_stage")
            candidates.append(candidate)
            key.append({"case_id": case, "candidate_id": opaque, "arm": arm, "outcome_sha256": digest(rec),
                "source_request_id": rec.get("request_id") if which == "final" else rec["stages"][-1]["request_id"]})
        packets.append({"case_id": case, "dataset": item["dataset"], "original_question": item["question"] if which in ("dynamic8", "balanced20", "m4full8", "m4wiki20") else trajectory["question"],
            "final_visible_context": trajectory["final_context"] if which == "final" else "See each candidate's actual visible context; no hidden goal reader is added", "candidates": candidates})
    assert packets, "No new resolved text-different final pairs"
    packet = {"kind": "final_changed_text_pairs", "selection": "Every resolved text-different pair, regardless of native score; identical texts need no duplicate semantic review. No output-dependent execution changes.",
        "scope": "Method-masked final-answer interpretation; native references/F1 hidden. Previous case exposure must be disclosed; this is not independent human gold.",
        "fields": ["case_id", "candidate_id", "factual_correct", "addresses_actual_question", "necessary_information_retained", "entity_role_or_scope_error", "reason_with_input_evidence", "pending_work_items"],
        "truth_rule": "Interpret each short answer as answering the original question. Check requested entity/relation/attribute/conditions, not lexical overlap with a remembered gold. Distinguish a valid alternative or redundant qualifier from a false answer. Missing local verification is not proof of falsehood; retain concrete pending work items.",
        "cases": packets}
    write(folder / "PACKET.json", packet)
    write(folder / "METHOD_KEY.local.json", key)
    value = {"cases": len(packets), "candidates": 2 * len(packets), "packet_sha256": hashlib.sha256((folder / "PACKET.json").read_bytes()).hexdigest(),
        "method_key_sha256": hashlib.sha256((folder / "METHOD_KEY.local.json").read_bytes()).hexdigest(),
        "identical_text_pairs_already_resolved": identical, "no_native_or_method_labels_in_packet": True}
    write(folder / "PACKET_LOCK.json", value)
    return {"packet": str((folder / "PACKET.json").relative_to(ROOT)), **value}


def join(which):
    run, inputs, outcomes, _ = snapshot(which)
    ident, arms = SPECS[which][4:6]
    indexed = {(r[ident], r["arm"]): r for r in outcomes}
    items = {r[ident]: r for r in inputs}
    joined = []
    for folder in sorted((run / "root_blind_review").glob("*")):
        lock_path = folder / "ROOT_REVIEW_LOCK.json"
        if not lock_path.exists():
            continue
        lock = read(lock_path)
        review_path = folder / "SEMANTIC_REVIEWS.blinded.jsonl"
        assert hashlib.sha256(review_path.read_bytes()).hexdigest() == lock["review_sha256"]
        assert hashlib.sha256((folder / "PACKET.json").read_bytes()).hexdigest() == lock["packet_sha256"]
        assert hashlib.sha256((folder / "METHOD_KEY.local.json").read_bytes()).hexdigest() == read(folder / "PACKET_LOCK.json")["method_key_sha256"]
        method = {(r["case_id"], r["candidate_id"]): r for r in read(folder / "METHOD_KEY.local.json")}
        for rec in rows(review_path):
            key = method[rec["case_id"], rec["candidate_id"]]
            outcome = indexed[rec["case_id"], key["arm"]]
            assert digest(outcome) == key["outcome_sha256"]
            correct = (False if outcome["status"] not in ("success", "success_truncated") else
                False if rec["factual_correct"] is False or rec["addresses_actual_question"] is False else
                True if rec["factual_correct"] is True and rec["addresses_actual_question"] is True else None)
            joined.append({**rec, "arm": key["arm"], "outcome_status": outcome["status"], "stage_correct": correct,
                "group": items[rec["case_id"]].get("group", items[rec["case_id"]].get("interface_group", items[rec["case_id"]]["role"] if which == "reader8" else "m4_wiki20" if which == "m4wiki20" else "m4_full8" if which == "m4full8" else "balanced20" if which == "balanced20" else "dynamic_full8" if which == "dynamic8" else "native90" if which == "native" else "final90" if which == "final" else "failure8" if which in ("failure", "scope8") else "challenge27")), "review_batch": folder.name})
    assert len({(r["case_id"], r["arm"]) for r in joined}) == len(joined)
    groups = sorted({r["group"] for r in joined})
    sections = {}
    for group in ["all", *groups]:
        for arm in arms:
            recs = [r for r in joined if r["arm"] == arm and (group == "all" or r["group"] == group)]
            sections[group + "/" + arm] = {"reviewed": len(recs),
                "stage_correct": sum(r["stage_correct"] is True for r in recs),
                "stage_wrong": sum(r["stage_correct"] is False for r in recs),
                "pending_correctness": sum(r["stage_correct"] is None for r in recs),
                "necessary_information_retained": dict(Counter(str(r["necessary_information_retained"]) for r in recs)),
                "entity_role_or_scope_error": sum(r["entity_role_or_scope_error"] is True for r in recs)}
    value = {"reviewed_records": len(joined), "planned_records": SPECS[which][-1], "sections": sections,
        "component_review_is_not_final_RAG_F1": True, "not_independent_human_gold": True, "records": joined}
    write(run / "root_blind_review/SEMANTIC_JOIN.json", value)
    return {k: v for k, v in value.items() if k != "records"}


def audit_goal():
    from experiments.query_decomposition.comprehensive_eval_v1_20261015.scoring import metric
    from experiments.query_decomposition.p02_ordinary_fewshot_probe_v1_20261022.run import receipt_integrity
    import math

    run, _, outcomes, _ = snapshot("goal")
    assert len(outcomes) == 81 and all(r["status"] == "success" for r in outcomes)
    refs = {r["id"]: r for r in rows(ROOT / "experiments/query_decomposition/p02_goal_scope_role_probe_v1_20261022/references27.local.frozen.jsonl")}
    scorers = {ds: metric(ds) for ds in ("2wiki", "hotpotqa")}
    scored = {(r["id"], r["arm"]): scorers[r["dataset"]](r["prediction"], refs[r["id"]]) for r in outcomes}
    saved = rows(run / "DETAILS.scored.local.jsonl")
    for row in saved:
        for endpoint in ("f1", "em"):
            assert math.isclose(scored[row["id"], row["arm"]][endpoint], row["native_metrics"][endpoint], abs_tol=1e-12)
    assert len(saved) == 81
    model = read(ROOT / "src/p02_multigrain_timing_cachefix_v1/config.json")["generation"]["model"]
    old_path = ROOT / "outputs/query_decomposition/p02_goal_composition_challenge_v1_20261022/challenge27/checkpoint.sqlite3"
    with closing(sqlite3.connect((run / "checkpoint.sqlite3").resolve().as_uri() + "?mode=ro", uri=True)) as db, \
            closing(sqlite3.connect(old_path.resolve().as_uri() + "?mode=ro", uri=True)) as old:
        receipts = {rid: (json.loads(payload), {**json.loads(raw), "status": status}) for rid, payload, status, raw in db.execute("SELECT id,payload,status,result FROM requests")}
        assert all(receipt_integrity(r, model) and r["finish_reason"] == "stop" and r["answer"].strip() for _, r in receipts.values())
        previous = [json.loads(v) for (v,) in old.execute("SELECT value FROM data WHERE kind='prediction'")]
        previous = {r["id"]: r for r in previous if r["arm"] == "G2"}
        controls = []
        for now in [r for r in outcomes if r["arm"] == "S0"]:
            was = previous[now["id"]]
            old_payload = json.loads(old.execute("SELECT payload FROM requests WHERE id=?", (was["goal_request_id"],)).fetchone()[0])
            assert old_payload == receipts[now["goal_request_id"]][0]
            old_score = scorers[now["dataset"]](was["prediction"], refs[now["id"]])
            controls.append({"id": now["id"], "identical_goal_wire_request": True,
                "goal_text_changed": now["goal_text"] != was["goal_text"], "final_prediction_changed": now["prediction"] != was["prediction"],
                "old_metrics": old_score, "new_metrics": scored[now["id"], "S0"]})
    rng = random.Random(20261022)
    paired = {}
    for arm in ("S1", "S2"):
        deltas = [scored[ident, arm]["f1"] - scored[ident, "S0"]["f1"] for ident in refs]
        samples = sorted(sum(rng.choices(deltas, k=27)) / 27 for _ in range(10000))
        paired["S0_to_" + arm] = {"mean_delta": sum(deltas) / 27, "paired_bootstrap_95_percentile_interval": [samples[249], samples[9749]],
            "seed": 20261022, "resamples": 10000, "interpretation": "Exploratory exposed challenge; interval is descriptive and not independent confirmation."}
    value = {"native_predictions_recounted": 81, "native_disagreements": 0, "strict_complete_receipts_checked": len(receipts),
        "same_prompt_historical_control_repeat": {"matched": len(controls), "goal_text_changed": sum(r["goal_text_changed"] for r in controls),
            "final_prediction_changed": sum(r["final_prediction_changed"] for r in controls),
            "mean_final_F1_delta": sum(r["new_metrics"]["f1"] - r["old_metrics"]["f1"] for r in controls) / 27,
            "details": controls, "limits": "Nonconcurrent repeat, includes service/time variation; not a pure within-time stochastic variance estimate."},
        "paired_bootstrap": paired, "no_main_evaluation_resumed": True}
    write(run / "ROOT_NATIVE_AND_REPEAT_AUDIT.json", value)
    return {k: v for k, v in value.items() if k != "same_prompt_historical_control_repeat"} | {"control_repeat_summary": {k: v for k, v in value["same_prompt_historical_control_repeat"].items() if k != "details"}}


def supplement(which):
    assert which in ("ordinary", "actual")
    run, _, _, _ = snapshot(which)
    first = read(run / "root_blind_review/SEMANTIC_JOIN.json")
    records = {(r["case_id"], r["candidate_id"]): dict(r) for r in first["records"]}
    provenance = []
    for path in sorted((run / "root_blind_review").glob("*/SUPPLEMENTAL_FACT_VERIFICATION.local.json")):
        extra = read(path)
        source = ROOT / extra["first_blind_review_path"]
        assert hashlib.sha256(source.read_bytes()).hexdigest() == extra["first_blind_review_sha256"]
        assert extra["first_blind_review_changed"] is False
        for row in extra.get("prior_sources", []):
            assert hashlib.sha256((ROOT / row["path"]).read_bytes()).hexdigest() == row["sha256"]
        for entry in extra["entries"]:
            rec = records[entry["case_id"], entry["candidate_id"]]
            assert rec["factual_correct"] is entry["first_blind_factual_correct"]
            if entry.get("proof_path"):
                assert hashlib.sha256((ROOT / entry["proof_path"]).read_bytes()).hexdigest() == entry["proof_sha256"]
            rec["first_blind_labels"] = {k: rec[k] for k in ("factual_correct", "addresses_actual_question", "necessary_information_retained", "entity_role_or_scope_error")}
            for field in rec["first_blind_labels"]:
                if "supplemental_" + field in entry:
                    rec[field] = entry["supplemental_" + field]
            rec["supplemental_reason"] = entry["reason"]
            rec["supplemental_source"] = str(path.relative_to(ROOT))
            rec["stage_correct"] = (False if rec["outcome_status"] != "success" else
                False if rec["factual_correct"] is False or rec["addresses_actual_question"] is False else
                True if rec["factual_correct"] is True and rec["addresses_actual_question"] is True else None)
        provenance.append({"path": str(path.relative_to(ROOT)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "resolved_entries": len(extra["entries"])})
    sections = {}
    for arm in SPECS[which][5]:
        recs = [r for r in records.values() if r["arm"] == arm]
        sections[arm] = {"reviewed": len(recs), "stage_correct": sum(r["stage_correct"] is True for r in recs),
            "stage_wrong": sum(r["stage_correct"] is False for r in recs), "pending_correctness": sum(r["stage_correct"] is None for r in recs),
            "necessary_information_retained": dict(Counter(str(r["necessary_information_retained"]) for r in recs))}
    result = {"first_blinded_annotations_unchanged": True, "post_lock_local_fact_supplements": provenance,
        "sections": sections, "component_review_is_not_final_RAG_F1": True,
        "limits": "Informed Codex reviews with prior exposure; some facts remain pending. E and R reviewers differ in uncertainty/scope; these measurement differences are not method gains.", "records": list(records.values())}
    write(run / "root_blind_review/SEMANTIC_JOIN_POSTSUPPLEMENT.json", result)
    return {k: v for k, v in result.items() if k != "records"}


def report_round2():
    names = ("ordinary", "goal", "actual", "final")
    snapshots = {name: snapshot(name) for name in names}
    assert all(len(snapshots[name][2]) == SPECS[name][-1] for name in names)
    config = read(ROOT / "src/p02_multigrain_timing_cachefix_v1/config.json")
    actual_cost, reserved_cost = 0.0, 0.0
    with closing(sqlite3.connect(Path(config["budget"]["ledger"]).resolve().as_uri() + "?mode=ro", uri=True)) as db:
        for name in names:
            run = snapshots[name][0]
            known, unknown = db.execute("SELECT coalesce(sum(actual),0),coalesce(sum(CASE WHEN actual IS NULL THEN reserved ELSE 0 END),0) FROM charges WHERE namespace=?", ("p02_prompt_research_v1_20261022/" + str(run.resolve()),)).fetchone()
            actual_cost += known
            reserved_cost += unknown
    e = read(snapshots["ordinary"][0] / "root_blind_review/SEMANTIC_JOIN_POSTSUPPLEMENT.json")
    r = read(snapshots["actual"][0] / "root_blind_review/SEMANTIC_JOIN_POSTSUPPLEMENT.json")
    s = read(snapshots["goal"][0] / "REPORT.json")
    w = read(snapshots["final"][0] / "REPORT.json")
    assert w["quality_terminal"] == 180 and w["held_technical_tasks"] == 0
    value = {"utc": datetime.now(timezone.utc).isoformat(), "status": "four_round2_experiments_complete",
        "resolved_logical_conditions": sum(SPECS[name][-1] for name in names), "component_conditions_are_not_independent_queries_or_new_draws": True,
        "ordinary_fewshot_post_fact_verification": e["sections"], "actual_binding_post_fact_verification": r["sections"],
        "goal_challenge_native": {a: s["by_arm_dataset"][a]["all"] for a in ("S0", "S1", "S2")},
        "goal_challenge_pairs": s["paired"], "fixed90_final": {k: w[k] for k in ("arms", "by_dataset", "historical_original_P02", "paired")},
        "new_known_usage_estimated_CNY": actual_cost, "unresolved_reserved_CNY": reserved_cost,
        "candidate_promoted": False, "complete_RAG_F1_above_frozen_original_demonstrated": False,
        "reason": "E/R show no confirmed positive semantic effect; W1 does not exceed historical P02, and its sole native increase is not a confirmed factual repair. S gains are on exposed diagnostic-selected cases and include scope/metric tradeoffs.",
        "decomposition_lineage_report": "decomposition_lineage_audit/revision002/REPORT.md",
        "main_evaluation_resumed": False, "main_method_changed": False,
        "followup": {"goal_original_fact_role": "Separate54-condition followup; see live status and own authorization", "ordinary_failure_challenge8": "Separate16-condition failure-selected challenge; preparation/execution status recorded in its own files"}}
    write(REVIEW / "ROUND2_RESULTS.json", value)
    lines = ["# 第二轮完成结果", "", "保留冻结P02分解器的实际输出，追查下游QA未充分利用分解的原因。本轮4个实验的396个逻辑条件全部处理完成；它们包括复用控制和相同payload，不等于396个独立query或新推理。主评、正式计时、基线与发布保持暂停。", "",
        "**尚未验证出超过冻结旧P02的完整RAG F1改进，当前主方法不变。**", "",
        "普通QA的少样例表示对照（每臂30节点，包含15个无历史首节点）在锁后本地事实补证后如下。正确需事实正确且回应实际当前问题；合理弃答、必要信息缺失另分列，待核不强行计错。", "",
        "| 条件 | 正确 | 错误 | 待核 |", "|---|---:|---:|---:|"]
    for arm, label in (("E0", "原#引用少样例，新鲜控制"), ("E1", "少样例当前子问换成前答实体名"), ("E2", "少样例当前子问换成完整描述")):
        x = e["sections"][arm]
        lines.append(f"| {arm} {label} | {x['stage_correct']} | {x['stage_wrong']} | {x['pending_correctness']} |")
    lines += ["", "本组未确认语义改善；E1有一个无历史节点只答Judea地区而未回应所问城市。不能由此证明#字符必要，也没有依据将变量引用/实体绑定命名为新的提示范式。现有minimal4还改变过示例原题，不能与本单因素对照混为一项。", "",
        "实际当前子问题接口对照严格保留原问题，仅追加候选解释，候选分别重复原当前题或采用既有检索改写。三臂各15节点，均为11正确、1错误、3待核；其中6个描述式节点原控制已正确，存在明显的改善上限。9组相同候选payload共享真实回执，15条R0控制复用本轮E0，费用没有重复记账。这一组未确认正向语义变化。", "",
        "goal综合段落上的两个独立约束使用同27个已曝光挑战病例、同512/64接口，最终原生指标如下，不能与三数据集90题的分数直接相比。", "",
        "| 条件 | F1 | EM | 相对同期S0的改善/不变/下降 |", "|---|---:|---:|---:|"]
    for arm, label in (("S0", "原G2综合说明，新鲜控制"), ("S1", "目标/显式条件保持"), ("S2", "实体角色/关系方向核对")):
        x = s["by_arm_dataset"][arm]["all"]
        pair = s["paired"].get("S0_to_" + arm, {}).get("f1", {})
        counts = "—" if not pair else f"{pair['improved']}/{pair['tied']}/{pair['harmed']}"
        lines.append(f"| {arm} {label} | {100*x['fixed_denominator_F1']:.4f}% | {100*x['fixed_denominator_EM']:.4f}% | {counts} |")
    lines += ["", "共享国家的交集判断有真实修复迹象，但另有忽略state-run显式条件、答案粒度变化和合理弃答的native得失。完整陈述仍可能带额外错误。27题配对bootstrap区间包含零，病例也参与了开发。不能把5.56个百分点的挑战集差值说成整体P02提升。逐例解释见 [ROOT_PAIRED_INTERPRETATION](../../../../../outputs/query_decomposition/p02_goal_scope_role_probe_v1_20261022/scope27/ROOT_PAIRED_INTERPRETATION.md)。", "",
        "固定90题final对照完整复用各自原P02上游。W0为字节相同请求的新鲜控制，W1只在主指令末增加一句目标核对，不与新child或goal组合。", "",
        "| 条件 | F1 | EM |", "|---|---:|---:|"]
    h = w["historical_original_P02"]
    lines.append(f"| 冻结旧P02历史参考 | {100*h['F1']:.4f}% | {100*h['EM']:.4f}% |")
    for arm, label in (("W0", "原final新鲜控制"), ("W1", "final单句目标核对")):
        x = w["arms"][arm]
        lines.append(f"| {arm} {label} | {100*x['F1']:.4f}% | {100*x['EM']:.4f}% |")
    lines += ["", "W1对W0为1题native改善、89题不变、0题下降，平均仅+0.0202个百分点，未超过旧P02。全部文本差异先遮蔽审阅再关联：一题仅标题大小写，另一题是两种否定回答的表面重合差异，未确认事实修复。旧基线到新W0的一题年份/完整日期差异单列为非同期重复变化，不能自动归因方法或纯随机误差。材料复查发现该完整日期来自后续条约签署，不能当成同意NATO的同一事件更精确日期；正确月份在goal候选rank9已有、却未进入reader/final。因此也不能把该例当成纯粹无害的格式变化。独立审计见 [ROOT_NATIVE_AND_REPEAT_AUDIT](../../../../../outputs/query_decomposition/p02_final_target_check_fixed90_v1_20261022/ROOT_NATIVE_AND_REPEAT_AUDIT.md)。", "",
        "分解来源已逐条溯源：[修订002报告](decomposition_lineage_audit/revision002/REPORT.md)。W90使用同记录R02权重及v12提示词的历史远端原始输出，未套人工修正版；与formal1500没有同数据集共同题。旧推理wrapper未记录formal较新explicit greedy兼容合同的全部有效默认覆盖，不能称同一生成批次或完全相同解码合同。远端LF与本地CRLF分开说明，规范化后完整JSON与token IDs相同。", "",
        "后续聚焦实际失效机制：[普通QA证据表](../../../../../analysis/p02_prompt_research_followup_20261022/ORDINARY_FAILURE_MECHANISMS.md)包含父亲/祖父、妻父/夫父、开发者/引入者、投手/游击手、失败企图/成功事件和reader已有日期但未传递等实例。270条中426个ordinary节点没有触发短句格式化，不能把未观察到的格式化损害当作本轮原因。候选到reader的丢失、QA读入后的错误、goal/final的目标使用和原生评分粒度分别记录，不作总体因果占比分摊。", "",
        f"本4项新增已知usage估费共{actual_cost:.7f}元，未结算/未知预留{reserved_cost:.7f}元；既有账务与未知请求保留。完整逻辑流程tokens仅指可得的托管LLM回执（冻结上游加新final），不能冒充新测分解tokens或全流程时间。费用没有异常提醒。", "",
        "第一批246条件仍在 RESULTS_SUMMARY.md；新goal原事实句角色核对及8个普通QA失效挑战属于下一步单独协议，其状态见 ROUND2_PROGRESS.md 和 ROUND2_LIVE_STATUS.json，不提前算入本报告结果。", ""]
    (REVIEW / "ROUND2_RESULTS.md").write_text("\n".join(lines), encoding="utf8")
    return {k: value[k] for k in ("status", "resolved_logical_conditions", "candidate_promoted", "complete_RAG_F1_above_frozen_original_demonstrated", "new_known_usage_estimated_CNY", "unresolved_reserved_CNY")}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("action", choices=("status", "blind", "blind-final", "lock-review", "join", "audit-goal", "supplement", "report-round2"))
    parser.add_argument("--which", choices=tuple(SPECS))
    parser.add_argument("--batch")
    parser.add_argument("--review-sha")
    args = parser.parse_args()
    if args.action == "status":
        value = status()
    elif args.action == "blind":
        value = blind(args.which, args.batch)
    elif args.action == "blind-final":
        value = blind_final(args.batch, args.which or "final")
    elif args.action == "lock-review":
        value = lock_review(args.which, args.batch, args.review_sha)
    elif args.action == "join":
        value = join(args.which)
    elif args.action == "supplement":
        value = supplement(args.which)
    elif args.action == "report-round2":
        value = report_round2()
    else:
        value = audit_goal()
    print(json.dumps(value, ensure_ascii=False, indent=2))
