"""Offline-only contracts using temporary SQLite and injected services."""
from contextlib import ExitStack, contextmanager, closing
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import copy
import importlib.util
import json
import sqlite3
import tempfile
import hashlib

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("cot90_allocation02_offline", HERE / "cot90_allocation_continuation.py")
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)


@contextmanager
def open_db(path):
    with closing(sqlite3.connect(path)) as db:
        with db: yield db


def json_read(path): return json.loads(Path(path).read_text(encoding="utf8"))
def file_sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf8") as f: json.dump(value, f)


def create_db(output, ledger):
    output.mkdir(parents=True)
    with open_db(output / "checkpoint.sqlite3") as db:
        db.executescript("""CREATE TABLE data(kind TEXT,key TEXT,value TEXT,PRIMARY KEY(kind,key));
CREATE TABLE requests(id TEXT,stage TEXT,payload TEXT,status TEXT,result TEXT);
CREATE TABLE request_stages(request_id TEXT,stage TEXT);
CREATE TABLE retired_requests(id TEXT,stage TEXT,payload TEXT,status TEXT,result TEXT);""")
        db.execute("INSERT INTO data VALUES('meta','identity','{}')")
        db.execute("INSERT INTO requests VALUES('old','stage','payload','unknown','{}')")
    with open_db(ledger) as db:
        db.execute("CREATE TABLE charges(id TEXT,namespace TEXT,actual REAL,reserved REAL,status TEXT)")
        db.execute("INSERT INTO charges VALUES(?,?,?,?,?)", ("old", m.namespace(output), None, .05, "reserved"))
        db.execute("INSERT INTO charges VALUES('r03','other_namespace',.1,0,'returned_usage')")


def closure():
    job = dict(job_id=m.OLD_JOB, directory=m.OLD_DIRECTORY, protocol_sha256=m.PROTOCOL)
    def command(args, stdout): return dict(argv=args, stdout=stdout, stderr="", code=0)
    receipt = dict(job_id=m.OLD_JOB, protocol_sha256=m.PROTOCOL, remote_directory=m.OLD_DIRECTORY,
        experiment=m.p.HERE.name, read_only_remote=True, API_requests=0, new_jobs=0,
        controller_exited=True, auxiliary_exited=True, commands=dict(
            squeue=command(["squeue","-h","-j",m.OLD_JOB,"-o","%i|%T|%j"],""),
            sacct=command(["sacct","-n","-P","-j",m.OLD_JOB,"--format=JobIDRaw,JobName,State,ExitCode,Start,End,Timelimit,NodeList"],
                          m.OLD_JOB+"|p02-cot90|COMPLETED|0:0|2026-10-22T10:36:07|2026-10-22T16:00:00|06:00:00|weirdo\n"),
            scontrol=command(["scontrol","show","job","-o",m.OLD_JOB],
                             "JobId="+m.OLD_JOB+" JobName=p02-cot90 UserId=u7830488(1001) WorkDir="+m.OLD_DIRECTORY+" JobState=COMPLETED\n")))
    return job, receipt


def main():
    checks=[]
    with tempfile.TemporaryDirectory(prefix="cot90_allocation02_offline_") as tmp:
        root=Path(tmp);out=root/"original";cont=out/"continuations/allocation02";ledger=root/"ledger.sqlite3"
        create_db(out,ledger)
        before=m.stable_state(out/"checkpoint.sqlite3",ledger,out)
        with open_db(ledger) as db: db.execute("UPDATE charges SET actual=.9 WHERE namespace='other_namespace'")
        assert m.stable_state(out/"checkpoint.sqlite3",ledger,out)==before
        checks.append("parallel_r03_charge_changes_do_not_change_own_namespace_fingerprint")
        with open_db(ledger) as db: db.execute("UPDATE charges SET reserved=.06 WHERE id='old'")
        assert m.stable_state(out/"checkpoint.sqlite3",ledger,out)!=before
        checks.append("own_unknown_reservation_change_detected_not_removed")
        with open_db(out/"checkpoint.sqlite3") as db: db.execute("INSERT INTO retired_requests VALUES('r','s','p','unknown','{}')")
        after=m.stable_state(out/"checkpoint.sqlite3",ledger,out)
        assert after["tables"]["retired_requests"]["rows"]==1
        with open_db(out/"checkpoint.sqlite3") as db: db.execute("CREATE TABLE extra_runtime(id TEXT)")
        assert "extra_runtime" in m.stable_state(out/"checkpoint.sqlite3",ledger,out)["tables"]
        checks.append("all_own_tables_retired_attempts_and_schema_fingerprinted")

        job,good=closure();assert m.validate_scheduler_closure(job,good)["closed"]
        bads=[]
        for field in ("controller_exited","auxiliary_exited"):
            bad=copy.deepcopy(good);bad[field]=False;bads.append(bad)
        for field,old,new in (("squeue","","161325|RUNNING|p02-cot90\n"),
                              ("sacct","COMPLETED","RUNNING"),
                              ("scontrol","u7830488","another_user"),
                              ("scontrol",m.OLD_DIRECTORY,"/foreign")):
            bad=copy.deepcopy(good);bad["commands"][field]["stdout"]=bad["commands"][field]["stdout"].replace(old,new) if old else new;bads.append(bad)
        for bad in bads:
            try:m.validate_scheduler_closure(job,bad)
            except AssertionError:pass
            else:raise AssertionError("Unclosed/foreign allocation accepted")
        checks.append("real_raw_scheduler_closure_owner_path_and_controller_aux_exit_required")

        with patch.object(m,"OUT",out),patch.object(m,"CONT",cont):
            for name in ("EXECUTION_STARTED.json","REMOTE_SUBMISSION_ATTEMPT.json","REMOTE_JOB_ID.json","ALLOCATION_CLOCK.json","STOP_REQUESTED"):
                file=cont/name;write(file,{})
                try:m.allocation_preflight()
                except AssertionError:pass
                else:raise AssertionError("Existing/unknown submission accepted")
                file.unlink()
            checks.append("existing_or_unknown_continuation_submission_never_blindly_repeated")
            with patch.object(m.full,"authorized",lambda:{}),patch.object(m,"priority_module",lambda:SimpleNamespace(priority_status=lambda:dict(finished=True))):
                stop=out/"STOP_REQUESTED";stop.write_text("preserve")
                try:m.closure_checks(root/"unused_closure.json")
                except AssertionError as exc:assert "STOP" in str(exc)
                else:raise AssertionError("Original STOP bypassed")
                assert stop.read_text()=="preserve";stop.unlink()
            checks.append("original_STOP_blocks_before_closure_or_services_and_is_not_released")
            factory=m.bridge_class()
            bridge=factory({},cont,dict(protocol_sha256=m.PROTOCOL))
            assert bridge.output==cont and bridge.directory==m.REMOTE_DIRECTORY
            assert m.full.OUT==m.p.OUT
            checks.append("real_bridge_constructor_isolates_new_receipts_without_changing_controller_namespace")
            with patch.object(m,"ROOT",root):
                for stop in (out/"STOP_REQUESTED",cont/"STOP_REQUESTED"):
                    stop.write_text("boundary stop")
                    result=bridge.can_start_condition()
                    assert result["allowed"] is False and result["reason"]=="local_continuation_stop"
                    assert stop.read_text()=="boundary stop";stop.unlink()
            checks.append("original_or_continuation_STOP_blocks_next_condition_without_service_or_inflight_changes")

        # Exercise actual mode=ro status against a synthetic 360 task roster.
        order=[dict(task_id="task"+str(n)) for n in range(360)]
        fakep=SimpleNamespace(ORDER=root/"order",PROTOCOL=root/"protocol",rows=lambda _:order,read=json_read)
        with open_db(out/"checkpoint.sqlite3") as db:
            db.execute("INSERT INTO data VALUES('outcome','task0',?)",(json.dumps(dict(status="algorithm_failure")),))
        write(out/"held/h.json",dict(task_id="task1",status="held_technical"))
        bytes_before=(out/"checkpoint.sqlite3").read_bytes()
        with patch.object(m,"OUT",out),patch.object(m,"p",fakep),patch.object(m,"sha",lambda _:m.PROTOCOL),\
             patch.object(m.full,"authorized",lambda:{}),patch.object(m.full,"expected_identity",lambda:{}):
            state=m.status();assert state["attempted"]==2 and state["remaining"]==358 and state["in_flight"]==0
        assert (out/"checkpoint.sqlite3").read_bytes()==bytes_before
        checks.append("readonly_default_status_counts_algorithm_and_held_without_scores_or_mutation")

        # No real snapshot is invoked: test snapshot's real code only on this
        # synthetic temporary namespace, with injected closure and file writers.
        for name in ("REMOTE_JOB_ID.json","REMOTE_GPU_READY.json","ALLOCATION_CLOCK.json","REMOTE_SUBMISSION_ATTEMPT.json","ENGINEERING_GATE.json"):
            write(out/name,{"fixture":name})
        closed_path=root/"closure.json";write(closed_path,{"fixture":True})
        package=root/"package";write(package/"config.json",dict(budget=dict(ledger=str(ledger))))
        fakep=SimpleNamespace(PACKAGE=package,atomic_json=write,read=json_read,sha=file_sha)
        checks_value=dict(metadata=dict(remaining=358,in_flight=0),scheduler=dict(closed=True))
        primary=(out/"checkpoint.sqlite3").read_bytes()
        with patch.object(m,"ROOT",root),patch.object(m,"OUT",out),patch.object(m,"CONT",cont),\
             patch.object(m,"SNAPSHOT",cont/"PREDECESSOR_SNAPSHOT.json"),patch.object(m,"AUTH",root/"absentAUTH"),\
             patch.object(m,"p",fakep),patch.object(m,"status",lambda:dict(all_attempted=False)),\
             patch.object(m,"closure_checks",lambda _:checks_value):
            result=m.snapshot(closed_path);saved=json.loads((cont/"PREDECESSOR_SNAPSHOT.json").read_text())
            assert result["remaining"]==358 and m.sha(root/saved["backup_path"])==saved["backup_sha256"]
        assert (out/"checkpoint.sqlite3").read_bytes()==primary
        checks.append("explicit_snapshot_uses_temporary_sqlite_backup_locks_and_preserves_original_bytes")

        # Real file locking, synthetic output only.
        with m.run_lock(root/"lock_fixture"):
            try:
                with m.run_lock(root/"lock_fixture"):raise AssertionError("Duplicate lock acquired")
            except (RuntimeError,OSError):pass
        checks.append("exclusive_lock_rejects_concurrent_controller")

        fake_priority=SimpleNamespace(priority_status=lambda:dict(finished=True,reference_complete=False))
        marker_parent=cont/"executetest";marker_parent.mkdir()
        fakefull=SimpleNamespace(authorized=lambda:dict(approved=True),run_with_bridge=None)
        auth=dict(script_sha256="fake_script",snapshot_sha256="fake_snapshot")
        for scenario in ("success","startup_failure"):
            local=marker_parent/scenario;events=[]
            original=lambda:dict(finished=False)
            fakepre=SimpleNamespace(status=original)
            @contextmanager
            def locked(path):events.append("lock:"+Path(path).name);yield;events.append("unlock:"+Path(path).name)
            class Bridge:
                def __init__(self,resources,output,authorization):assert output==local;events.append("bridge_constructed")
                def start(self):
                    events.append("fake_start")
                    if scenario=="startup_failure":raise RuntimeError("fake startup failure")
                def close(self):events.append("fake_close")
            def controller(bridge):
                assert fakepre.status()["finished"] and not fakepre.status().get("reference_complete")
                events.append("unchanged_controller");return dict(fake=True)
            fakefull.run_with_bridge=controller
            fakep=SimpleNamespace(HERE=root,atomic_json=write)
            with ExitStack() as stack:
                replacements=dict(OUT=out,CONT=local,p=fakep,full=fakefull,predecessors=fakepre,
                    status=lambda:dict(all_attempted=False),authorized=lambda:auth,run_lock=locked,
                    priority_module=lambda:fake_priority,bridge_class=lambda:Bridge,read=lambda _:dict(resources=True))
                for name,value in replacements.items():stack.enter_context(patch.object(m,name,value))
                try:result=m.run()
                except RuntimeError:assert scenario=="startup_failure"
                else:assert scenario=="success" and result["fake"]
                assert fakepre.status is original and "fake_close" in events
                assert events.index("bridge_constructed")>events.index("lock:original")
            assert (local/"EXECUTION_STARTED.json").exists()
        checks.append("fake_service_entry_locks_new_output_only_finally_closes_and_restores_priority_gate")

        with patch.object(m,"status",lambda:dict(all_attempted=True)),\
             patch.object(m,"authorized",side_effect=AssertionError("must_not_authorize_or_start")):
            assert m.run()["new_API_SSH_GPU_requests"]==0
            assert m.snapshot(closed_path)["snapshot_created"] is False
        checks.append("all360_attempted_means_no_snapshot_no_AUTH_no_services")
        with patch.object(m,"status",lambda:dict(all_attempted=False)),\
             patch.object(m,"authorized",side_effect=AssertionError("badAUTH")),\
             patch.object(m,"bridge_class",side_effect=AssertionError("service_reached")):
            try:m.run()
            except AssertionError as exc:assert str(exc)=="badAUTH"
            else:raise AssertionError("Missing AUTH accepted")
        checks.append("invalid_AUTH_rejected_before_any_bridge_or_network")

    print(json.dumps(dict(passed=True,checks=checks,script_sha256=m.sha(m.SELF),
        production_snapshot_AUTH_or_runtime_writes=0,new_API_SSH_GPU_requests=0,
        temporary_synthetic_sqlite_and_fake_services_only=True),indent=2))


if __name__=="__main__":main()
