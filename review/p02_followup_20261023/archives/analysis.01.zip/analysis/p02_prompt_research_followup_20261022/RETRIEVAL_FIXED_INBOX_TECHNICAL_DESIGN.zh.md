# 固定inbox的技术续跑候选：仅设计，未执行

前提是现有远端mtime/边界观测确认请求侧目录扫描的可见性延迟。当前worker、桥和运行不作更改。本方案只尝试减少文件传输等待，查询文本、qid、BGE/索引资源、精确排序、k、缓存键和response契约全部保持；不作为新的方法效果或正式时延实验。

## 最小交换流程

1. 新技术续跑目录在worker启动前预建固定`INBOX`文件并登记身份；不通过每次rename替换它。每次仍先完整写入不可变`requests/<request_id>.json`并rename到最终位置。
2. 客户端用同一inode、offset 0覆盖写入固定长度的64位小写hex ID加换行，flush并关闭。严格保持现有单请求在途：收到匹配response前，不发布下一ID。
3. worker重复open该固定文件，只接受完整一行；按ID直接读取已有request文件，不依赖requests目录glob。**指针只是通知**：仍逐字段验证request identity、允许qid、resource identity和请求文件内容hash，走原检索器并写原不可变response。
4. 重复通知已有ID只返回原精确response，不重做成功检索。回执仍须与当前request ID及完整identity一致；未知、临时不可读的指针不构造空packet、不改变查询、不触发LLM。

## 必须保留的风险与边界

- **只解决可能的请求发现延迟。** 客户端目前在response产生前轮询不存在路径，响应侧也可能负缓存约30秒；单INBOX不能保证解决它。应先用真实mtime判断延迟落点；若响应侧也存在，需另行审查固定OUTBOX通知后再直接读不可变response，不能把单INBOX宣称完整修复。
- **既有inode也可能缓存内容。** close/open和flush不等于跨节点立即可见；共享存储的close-to-open语义/属性缓存尚未实证。同inode覆写绕过新目录项发现，但不能保证消除底层数据可见性延迟。
- **覆写不是跨节点原子消息。** 即使64hex长度正确，读者仍可能见到新旧混合字节。不能仅凭正则就执行；必须先成功读取同hash、已完整提交的不可变request并验证契约。无此文件或读到未完成行时，仅继续有限轮询。重复读取稳定值有助防抖，但本身不能证明原子性。
- **持久化顺序与崩溃恢复。** 指针更新必须晚于不可变请求提交；崩溃可能留下旧指针，重连只能恢复同ID/同request，不能自动新分配GPU、改写unknown账务或重发有返回迹象的API。单在途约束防止正常运行中覆盖未完成请求。
- **停止与资源身份不放宽。** 原STOP、worker错误/FINISHED、超时挂起、部署锁、owned job验证、源hash及检索packet校验照常；固定文件不能允许路径注入或扩大qid白名单。跨SSH仍只有query/资源与文档，不引入LLM凭据、答案提示或gold。

如root决定实施，应先在完整条件边界保留checkpoint与账务、关闭原worker，记录独立技术续跑的源码/授权/原allocation闭合；不热改冻结文件。离线最小合同只需验证：同inode发布、部分/混合指针无执行、重复ID精确复用、错误identity拒绝、单在途、STOP和closed worker不自动重投。随后同请求的packet内容/排序逐字对照，工程时间另记，科学配置不变。

以上是可行性候选，未写新worker、未上传、未开SSH/API/GPU，未承诺提速。当前运行继续。
