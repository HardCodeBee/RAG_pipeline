# 对responses父目录强制statx同步：可行性核查，未执行

**有机制依据，可作有限技术探针；不是已验证修复。** `AT_STATX_FORCE_SYNC`同步目标属性，不能理解为通用清除全部dentry的命令。应对原SFTP所在login节点、同一挂载中的现有`responses`目录调用；在另一节点刷新不会保证原controller同步受益。

## 官方接口与NFS实现

- Linux man-pages规定FORCE_SYNC强制属性与server同步，并提醒网络文件系统为准确时间戳可能触发writeback；statx自Linux4.11/glibc2.28提供。普通pathname查询需要沿途目录search权限，不要求root。[statx(2)](https://man7.org/linux/man-pages/man2/statx.2.html)
- NFS说明：客户端保存正/负LOOKUP结果，通过父目录mtime识别目录项变化；发现变化后丢弃该目录缓存的LOOKUP，但mtime本身也会缓存。这正是“子文件已创建、重复stat仍暂报不存在”的一种机制。[nfs(5)，Directory entry caching](https://man7.org/linux/man-pages/man5/nfs.5.html)
- 核对固定Linux v6.6源：`nfs_getattr`在请求MTIME/CTIME等可变属性并带FORCE_SYNC时调用`__nfs_revalidate_inode`；它发getattr并刷新inode。目录change_attr变化可调用`nfs_force_lookup_revalidate`。同文件中仅regular-file进入所示数据writeback分支，目录不走该分支。[inode.c:785–852、1121–1168、2018–2034](https://github.com/torvalds/linux/blob/v6.6/fs/nfs/inode.c#L785-L852)
- 负dentry验证依父目录change verifier；父目录变化时需要重新lookup。因此“强制取父目录新属性→发现变化→原controller下一次lookup重验”有具体路径依据，但仍是对本环境待验证的推论。[dir.c:1397–1428、1494–1518](https://github.com/torvalds/linux/blob/v6.6/fs/nfs/dir.c#L1397-L1518)

以上v6.6源用于核机制，未确认远端实际内核/文件系统恰是此版本与实现。

## 最小调用形态与现成工具

接口设计：`statx(AT_FDCWD, responses_dir, AT_STATX_FORCE_SYNC, STATX_MTIME | STATX_CTIME | STATX_INO, &buf)`，之后让原controller照常stat并读同一不可变response。**mask不能只用INO/TYPE**：所核NFS实现对此类不可变字段会在强制revalidate之前早退。也不要对尚不存在的child本身调用后以ENOENT推断已刷新其父目录。

如远端GNU工具及构建支持statx，现成设计用法是：

```sh
env stat --cached=never --format='%y|%z|%i' -- '<owned responses directory>'
```

这只是候选命令，未执行。GNU官方将never定义为同步最新属性；v9.5代码将%y/%z映射到MTIME/CTIME，并将force选项传为AT_STATX_FORCE_SYNC。不要用`-f`切换成statfs，也不要只打印%i。[GNU说明](https://www.gnu.org/s/coreutils/manual/html_node/stat-invocation.html)，[v9.5实现:1279–1337](https://github.com/coreutils/coreutils/blob/v9.5/src/stat.c#L1279-L1337)。仅工具返回0不证明实际发了NFS RPC；旧构建可能走非statx实现，须如实记录版本/支持边界。

## 能验证与不能保证的事

建议仅在已确认server端response存在时，记录原stat=ENOENT、父目录强制同步返回属性/耗时/errno、原controller后续自然可见时间。若同步后明显提前且父目录属性确有变化，支持此技术路径；一次改善不能排除恰好碰上缓存到期，应留存逐次时间而非宣布提速率。一次在response生成前的刷新可能只得到旧目录状态，不能证明方案无效。

若服务端目录属性不变/粒度不足、文件系统非NFS、挂载/内核行为不同或仍有其他缓存层，强制同步可能无效。同步会增加元数据RPC，并可能因网络故障阻塞；不宜无界或高频执行。它不要求touch/chmod/remount/drop_caches，不替代controller的response identity/hash/资源验证，不读质量或改分数。

属于主动影响缓存可见性的**运行工程辅助**，须登记时间与适用范围；不得混入正式组件时延/TTFT。当前未实现helper、未开新SSH/API/GPU、未修改冻结worker/桥、未执行候选命令或更换job。
