"""Read Slurm limits over SSH; no remote writes or job submission."""
import getpass
import argparse
import ipaddress
import json
import shlex
import socket
from datetime import datetime, timezone
from pathlib import Path

import paramiko

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/query_decomposition/p02_reference_binding_priority_fixed90_v1_20261022"
COMMAND = """import json,subprocess
results={}
for name,args in [('partitions',['sinfo','-h','-o','%P|%l|%a|%G']),('own_jobs',['squeue','-h','-u','u7830488','-o','%i|%j|%T|%l|%L|%N'])]:
 p=subprocess.run(args,capture_output=True,text=True,timeout=15)
 results[name]={'code':p.returncode,'stdout':p.stdout[:12000],'stderr':p.stderr[:1000]}
print(json.dumps(results))
"""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verified-address", help="Address independently verified by current DNS; SSH still checks the original hostname key")
    args = parser.parse_args()
    if args.verified_address:
        ipaddress.ip_address(args.verified_address)
    password = getpass.getpass("Remote password: ")
    client = paramiko.SSHClient()
    client.load_system_host_keys()
    client.set_missing_host_key_policy(paramiko.RejectPolicy())
    try:
        connection = socket.create_connection((args.verified_address, 22), timeout=15) if args.verified_address else None
        client.connect("cluster1.comp.anu.edu.au", username="u7830488", password=password,
                       sock=connection, look_for_keys=False, allow_agent=False, timeout=15, auth_timeout=20, banner_timeout=15)
        password = None
        _, stdout, stderr = client.exec_command("python3 -c " + shlex.quote(COMMAND), timeout=40)
        result = json.loads(stdout.read().decode("utf8"))
        assert stdout.channel.recv_exit_status() == 0
        result.update(connected=True, read_only=True, new_jobs=0, new_model_requests=0,
                      verified_address=args.verified_address, host_key_policy="RejectPolicy/original hostname")
    finally:
        password = None
        client.close()
    result["utc"] = datetime.now(timezone.utc).isoformat()
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "REMOTE_PARTITION_PREFLIGHT.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
