"""Read final file mtimes for the three completed bounded-probe samples."""
from pathlib import Path
from datetime import datetime, timezone
import getpass
import hashlib
import json
import shlex
import socket
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/query_decomposition/p02_local_cot_fixed90_v1_20261022"
DEST = OUT / "READONLY_FORCE_STAT_RESPONSE_MTIMES.json"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def main():
    import paramiko
    probe = read(OUT / "READONLY_DIRECTORY_FORCE_STAT_PROBE.json"); job = read(OUT / "REMOTE_JOB_ID.json")
    assert job == probe["job"] and job["job_id"] == "161325"
    assert job["directory"] == "/home/projects/u7830488/p02_prompt_small_evals_20261022/cot90_222de9cd4f7dca85"
    assert len(probe["records"]) <= 5 and not DEST.exists()
    settings = read(ROOT / "experiments/query_decomposition/p02_local_cot_fixed90_v1_20261022/EXECUTION_SETTINGS.json")
    assert read(ROOT / settings["partition_preflight"])["verified_address"] == settings["verified_host_address"]
    client=paramiko.SSHClient();client.load_system_host_keys();client.set_missing_host_key_policy(paramiko.RejectPolicy())
    password=getpass.getpass("Remote password: ");connection=None
    try:
        connection=socket.create_connection((settings["verified_host_address"],22),timeout=15)
        client.connect("cluster1.comp.anu.edu.au",username="u7830488",password=password,sock=connection,
            look_for_keys=False,allow_agent=False,timeout=15,auth_timeout=20,banner_timeout=15)
        password=None;commands=[]
        for argv in (["hostname"],["date","+%s.%N"]):
            before=time.time();_,stdout,stderr=client.exec_command(shlex.join(argv),timeout=10)
            output,error=stdout.read().decode(),stderr.read().decode();code=stdout.channel.recv_exit_status();after=time.time()
            assert code==0 and not error.strip()
            commands.append(dict(argv=argv,code=code,stdout=output,stderr=error,local_before_epoch=before,local_after_epoch=after))
        records=[]
        with client.open_sftp() as sftp:
            for row in probe["records"]:
                rid=row["request_id"];assert len(rid)==64 and all(char in "0123456789abcdef" for char in rid)
                request=sftp.stat(job["directory"]+"/requests/"+rid+".json")
                response=sftp.stat(job["directory"]+"/responses/"+rid+".json")
                force_epoch=datetime.fromisoformat(row["forced_directory_stat"]["started_utc"]).timestamp()
                records.append(dict(request_id=rid,request_mtime_epoch=request.st_mtime,response_mtime_epoch=response.st_mtime,
                    force_started_utc=row["forced_directory_stat"]["started_utc"],
                    response_mtime_minus_force_seconds=response.st_mtime-force_epoch,
                    request_to_response_mtime_seconds=response.st_mtime-request.st_mtime))
        receipts={}
        for line in (OUT/"REMOTE_EVENTS.jsonl").open(encoding="utf8"):
            event=json.loads(line)
            if event.get("event")=="actual_retrieval_or_exact_worker_reuse":receipts[event["request_id"]]=event["utc"]
        for row in records:row["controller_receipt_utc"]=receipts.get(row["request_id"])
        clock=commands[1];remote_epoch=float(clock["stdout"].strip())
        result=dict(utc=datetime.now(timezone.utc).isoformat(),job=job,probe_sha256=hashlib.sha256((OUT/"READONLY_DIRECTORY_FORCE_STAT_PROBE.json").read_bytes()).hexdigest(),
            connected_peer=connection.getpeername(),commands=commands,records=records,
            login_clock_offset_bounds_seconds=[remote_epoch-clock["local_after_epoch"],remote_epoch-clock["local_before_epoch"]],
            remote_writes=0,additional_force_stats=0,new_LLM_requests=0,new_GPU_jobs=0,
            limitation="File mtime survives temporary-file rename; it is not proof of final-path publication time. Login-clock comparison does not independently calibrate worker or filesystem-server clocks.")
        with DEST.open("x",encoding="utf8") as stream:json.dump(result,stream,indent=2);stream.write("\n")
        print(json.dumps(dict(host=commands[0]["stdout"].strip(),clock_offset_bounds=result["login_clock_offset_bounds_seconds"],records=records,additional_force_stats=0)),flush=True)
    finally:
        password=None;client.close()
        if connection:connection.close()
if __name__=="__main__":main()
