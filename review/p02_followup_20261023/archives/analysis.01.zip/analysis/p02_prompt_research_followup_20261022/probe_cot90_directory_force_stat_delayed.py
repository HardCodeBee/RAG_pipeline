"""Approved bounded delayed GNU-stat visibility probe; original controller unchanged."""
from pathlib import Path
from datetime import datetime, timezone
import getpass
import hashlib
import json
import re
import shlex
import socket
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/query_decomposition/p02_local_cot_fixed90_v1_20261022"
DEST = OUT / "READONLY_DIRECTORY_FORCE_STAT_DELAYED_PROBE.json"
DIRECTORY = "/home/projects/u7830488/p02_prompt_small_evals_20261022/cot90_222de9cd4f7dca85"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def utc(): return datetime.now(timezone.utc).isoformat()
def receipts():
    found = {}
    for line in (OUT / "REMOTE_EVENTS.jsonl").open(encoding="utf8"):
        event = json.loads(line)
        if event.get("event") == "actual_retrieval_or_exact_worker_reuse": found[event["request_id"]] = event["utc"]
    return found

def main():
    import paramiko
    auth = ROOT / "analysis/p02_prompt_research_followup_20261022/COT90_PRIORITY_EXECUTION_AUTHORIZATION.json"
    assert hashlib.sha256(auth.read_bytes()).hexdigest() == "f8f4c307ed00263e00bcd04b18c32093f2afb32fe1d1187cc76c2fdebe3d535a"
    job = read(OUT / "REMOTE_JOB_ID.json")
    assert job["job_id"] == "161325" and job["directory"] == DIRECTORY
    assert job["protocol_sha256"] == "222de9cd4f7dca8509ab6bf1e391a27634536d2cf0b0cdf0f0e42e9dcd256702"
    assert not DEST.exists()
    settings = read(ROOT / "experiments/query_decomposition/p02_local_cot_fixed90_v1_20261022/EXECUTION_SETTINGS.json")
    assert read(ROOT / settings["partition_preflight"])["verified_address"] == settings["verified_host_address"]
    client = paramiko.SSHClient(); client.load_system_host_keys(); client.set_missing_host_key_policy(paramiko.RejectPolicy())
    password = getpass.getpass("Remote password: "); connection = None
    try:
        connection = socket.create_connection((settings["verified_host_address"], 22), timeout=15)
        client.connect("cluster1.comp.anu.edu.au", username="u7830488", password=password, sock=connection,
            look_for_keys=False, allow_agent=False, timeout=15, auth_timeout=20, banner_timeout=15)
        password = None; started = time.monotonic(); started_utc = utc(); deadline = started+150
        commands = []
        def command(argv):
            assert time.monotonic() < deadline
            timeout = min(5, max(.1, deadline-time.monotonic()))
            before = utc(); _, stdout, stderr = client.exec_command(shlex.join(argv), timeout=timeout)
            output, error = stdout.read().decode(), stderr.read().decode(); code = stdout.channel.recv_exit_status()
            value = dict(argv=argv, started_utc=before, completed_utc=utc(), code=code, stdout=output, stderr=error)
            commands.append(value); return value
        hostname = command(["hostname"])
        version = command(["stat", "--version"])
        help_result = command(["stat", "--help"])
        supported = version["code"] == 0 and help_result["code"] == 0 and "--cached" in help_result["stdout"] and "never" in help_result["stdout"]
        # Keep compact help evidence; version and exact executed directory-stat commands remain raw.
        help_result["stdout"] = "\n".join(line for line in help_result["stdout"].splitlines() if "--cached" in line or "never" in line)
        records, examined, errors, pending_since = [], set(), [], {}
        if supported:
            with client.open_sftp() as sftp:
                sftp.get_channel().settimeout(2.0)
                while time.monotonic() < deadline and len(records) < 3:
                    iteration = time.monotonic()
                    try:
                        delivered = receipts()
                        candidates = sorted((item for item in sftp.listdir_attr(DIRECTORY+"/requests")
                            if re.fullmatch(r"[0-9a-f]{64}\.json", item.filename)), key=lambda item: (item.st_mtime,item.filename), reverse=True)
                        for item in candidates:
                            rid = item.filename[:-5]
                            if rid in examined or rid in delivered: continue
                            response = DIRECTORY+"/responses/"+item.filename; before_utc = utc()
                            try:
                                sftp.stat(response); examined.add(rid); continue
                            except FileNotFoundError: pass
                            first_pending, first_pending_utc = pending_since.setdefault(rid, (time.monotonic(), utc()))
                            pending_seconds = time.monotonic()-first_pending
                            if pending_seconds < 20.0: continue
                            row = dict(request_id=rid, request_mtime_epoch=item.st_mtime, before_stat_utc=before_utc,
                                before_stat_found=False, controller_receipt_present_before=False,
                                first_pending_observed_utc=first_pending_utc, pending_seconds_before_force=pending_seconds)
                            # Exactly one forced MTIME/CTIME directory stat for this already submitted request.
                            forced = command(["stat", "--cached=never", "--format=%y|%z|%i", "--", DIRECTORY+"/responses"])
                            row["forced_directory_stat"] = forced; row["after_stat_utc"] = utc()
                            try:
                                after = sftp.stat(response); row["after_stat_found"] = True; row["response_mtime_epoch"] = after.st_mtime
                            except FileNotFoundError: row["after_stat_found"] = False
                            row["controller_receipt_utc_immediately_after"] = receipts().get(rid)
                            records.append(row); examined.add(rid)
                            print(json.dumps(dict(event="directory_force_stat_sample", request_id=rid, after_stat_found=row["after_stat_found"], stat_exit_code=forced["code"])), flush=True)
                            if forced["code"] != 0: errors.append(dict(error_type="forced_stat_nonzero"))
                            break
                    except (OSError, TimeoutError) as error:
                        errors.append(dict(utc=utc(),error_type=type(error).__name__)); break
                    if errors: break
                    time.sleep(max(0,min(deadline-time.monotonic(),1.0-(time.monotonic()-iteration))))
        observed_seconds = time.monotonic()-started; assert observed_seconds < 180
        delivered = receipts()
        for row in records: row["controller_receipt_utc_at_probe_end"] = delivered.get(row["request_id"])
        result = dict(started_utc=started_utc,completed_utc=utc(),observed_seconds=observed_seconds,job=job,
            connected_peer=connection.getpeername(),verified_original_hostname="cluster1.comp.anu.edu.au",
            server_hostname=hostname["stdout"].strip() if hostname["code"]==0 else None,
            host_key_sha256=hashlib.sha256(client.get_transport().get_remote_server_key().asbytes()).hexdigest(),
            gnu_cached_never_supported=supported,commands=commands,records=records,errors=errors,
            maximum_forced_directory_stats=3,minimum_pending_seconds_before_force=20,maximum_poll_hz=1,remote_writes=0,new_LLM_requests=0,new_GPU_jobs=0,
            original_controller_unchanged=True,probe_does_not_validate_packet_content=True,
            interpretation="Before/after visibility observations only; concurrent response completion and clock offsets remain possible. No mount options or cache-drop operations are used.")
        with DEST.open("x",encoding="utf8") as stream:json.dump(result,stream,indent=2);stream.write("\n")
        print(json.dumps(dict(probe_complete=True,supported=supported,server_hostname=result["server_hostname"],observed_seconds=observed_seconds,
            samples=len(records),missing_before_found_after=sum(row["after_stat_found"] for row in records),errors=errors,artifact=str(DEST.relative_to(ROOT)))),flush=True)
    finally:
        password=None;client.close()
        if connection:connection.close()

if __name__=="__main__":main()
