"""Run unchanged CoT90 after a documented partial-reference scheduling pause.

This is solely an execution-order supplement. The reference experiment is
not declared complete and its predictions/scores are never consulted here.
"""
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from experiments.query_decomposition.p02_local_cot_fixed90_v1_20261022 import run as full
from experiments.query_decomposition.p02_local_cot_fixed90_v1_20261022 import preparation as p
from experiments.query_decomposition.p02_local_cot_fixed90_v1_20261022 import predecessors

HERE = Path(__file__).resolve().parent
REFOUT = ROOT / "outputs/query_decomposition" / p.REFERENCE.name
PAUSE = REFOUT / "pauses/cot90_priority_20261022"
SNAPSHOT = PAUSE / "PAUSED_STATE.json"
AUTH = HERE / "COT90_PRIORITY_EXECUTION_AUTHORIZATION.json"
PAUSE_AUTH = HERE / "COT90_PRIORITY_PAUSE_AUTHORIZATION.json"
DECISION = "P02_COT90_PRIORITY_SCHEDULING_EXECUTION_20261022"


def utc(): return datetime.now(timezone.utc).isoformat()


def database_state():
    """Fingerprint the frozen partial namespace without examining predictions."""
    with closing(p.ro(REFOUT / "checkpoint.sqlite3")) as db:
        db.execute("BEGIN")
        meta = json.loads(db.execute("SELECT value FROM data WHERE kind='meta' AND key='identity'").fetchone()[0])
        expected = dict(protocol_sha256=p.sha(p.REFERENCE / "PROTOCOL.frozen.json"),
            inputs_sha256=p.sha(p.REFERENCE / "INPUTS90.jsonl"), order_sha256=p.sha(p.REFERENCE / "ORDER360.jsonl"),
            resources=p.read(p.REFERENCE / "RESOURCE_CONTRACTS.json"), no_historical_LLM_seed=True)
        assert meta == expected
        fingerprints = {}
        tables = list(db.execute("SELECT name,sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"))
        assert {name for name, _ in tables} >= {"data", "requests", "request_stages"}
        for table, schema in tables:
            h = hashlib.sha256(); count = 0
            # Hash complete raw rows; never parse question text, answers or F1.
            quoted = '"' + table.replace('"', '""') + '"'
            columns = [r[1] for r in db.execute("PRAGMA table_info(" + quoted + ")")]
            sort = ",".join(str(i + 1) for i in range(len(columns)))
            for record in db.execute("SELECT * FROM " + quoted + " ORDER BY " + sort):
                h.update((json.dumps(record, ensure_ascii=True, separators=(",", ":")) + "\n").encode())
                count += 1
            fingerprints[table] = dict(schema=schema, columns=columns, rows=count, sha256=h.hexdigest())
        status = dict(db.execute("SELECT status,count(*) FROM requests GROUP BY status"))
        terminal = dict(db.execute("SELECT key,json_extract(value,'$.status') FROM data WHERE kind='outcome'"))
    held = {p.rel(f): p.sha(f) for f in sorted((REFOUT / "held").glob("*.json"))}
    namespace = "p02_prompt_research_v1_20261022/" + str(REFOUT.resolve())
    with closing(p.ro(p.read(p.PACKAGE / "config.json")["budget"]["ledger"])) as db:
        charges = list(db.execute("SELECT id,actual,reserved,status FROM charges WHERE namespace=? ORDER BY id", (namespace,)))
    return dict(identity=meta, tables=fingerprints, request_statuses=status, outcomes=terminal, held_files=held,
        namespace_charge_sha256=hashlib.sha256(json.dumps(charges, ensure_ascii=True, separators=(",", ":")).encode()).hexdigest(),
        namespace_charge_rows=len(charges), in_flight=status.get("in_flight", 0))


def base_pause_checks():
    full.authorized()
    auth = p.read(PAUSE_AUTH)
    assert auth["approved"] is True and auth["experiment"] == p.HERE.name
    assert auth["id"] == "P02_COT90_PRIORITY_CONDITION_BOUNDARY_PAUSE_20261022"
    assert auth["old_job_id"] == "161046" and auth["reference_experiment"] == p.REFERENCE.name
    assert auth["reference_protocol_sha256"] == p.sha(p.REFERENCE / "PROTOCOL.frozen.json")
    matching = [r for r in p.rows(p.PLAN / "DECISIONS.jsonl") if r.get("id") == auth["id"]]
    assert len(matching) == 1 and matching[0]["approved"] is True
    assert matching[0]["authorization_sha256"] == p.sha(PAUSE_AUTH)
    assert auth["protocol_sha256"] == p.sha(p.PROTOCOL)
    assert not (REFOUT / "continuations/recovery01/ALLOCATION_CLOCK.json").exists()
    assert p.sha(ROOT / auth["clock_destination"]) == auth["clock_sha256"]
    assert (REFOUT / "STOP_REQUESTED").is_file()
    operation = p.read(PAUSE / "OPERATION.json")
    assert operation["decision_id"] == auth["id"] and operation["job_id"] == "161046"
    assert operation["old_waiter_exited"] is True and operation["old_waiter_service_requests"] == 0
    assert operation["reference_controller_exited"] is True and operation["reference_exit_code"] != 0
    assert operation["intentional_boundary_abort"] is True and operation["error_type"] == "FileNotFoundError"
    failure = p.read(REFOUT / "continuations/recovery01/LAUNCH_OR_RUNTIME_FAILURE.json")
    assert failure["error_type"] == "FileNotFoundError" and failure["protocol_sha256"] == auth["reference_protocol_sha256"]
    engineering = p.read(REFOUT / "ENGINEERING_GATE.json")
    assert engineering["passed"] is True and engineering["planned_conditions"] == 24
    assert engineering["quality_or_predictions_inspected"] is False
    stage = predecessors.metadata(p.STAGE, stage=True)
    assert stage["finished"] and stage["in_flight"] == 0
    reference = predecessors.metadata(p.REFERENCE)
    assert 24 <= reference["attempted"] < 360 and reference["in_flight"] == 0
    workers = predecessors.reference_workers_closed()
    assert workers["closed"] is True
    job = p.read(REFOUT / "continuations/recovery01/REMOTE_JOB_ID.json")
    scheduler = p.read(REFOUT / "continuations/recovery01/SCHEDULER_TERMINAL.json")
    verified = predecessors.scheduler_closed(job, scheduler)
    assert verified["closed"] is True and verified["job_id"] == "161046"
    return dict(ordinary_stage=stage, reference90=reference, reference_workers=workers,
        current_reference_scheduler=verified)


def snapshot():
    assert not SNAPSHOT.exists() and not AUTH.exists()
    assert not (p.OUT / "checkpoint.sqlite3").exists() and not (p.OUT / "REMOTE_JOB_ID.json").exists()
    assert not (p.OUT / "REMOTE_SUBMISSION_ATTEMPT.json").exists()
    checks = base_pause_checks()
    from p02_multigrain_timing_cachefix_v1.core.cache import run_lock
    with run_lock(REFOUT / "remote_deployment_lock"), run_lock(REFOUT):
        state = database_state()
        assert state["in_flight"] == 0
        backup = PAUSE / "reference_checkpoint.paused.sqlite3"
        assert not backup.exists()
        with closing(p.ro(REFOUT / "checkpoint.sqlite3")) as source, closing(sqlite3.connect(backup)) as target:
            source.backup(target)
        assert state == database_state()
    paths = [PAUSE_AUTH, PAUSE / "OPERATION.json", PAUSE / "ALLOCATION_CLOCK.original.json",
        REFOUT / "STOP_REQUESTED", REFOUT / "ENGINEERING_GATE.json",
        REFOUT / "continuations/recovery01/STOP_REQUESTED",
        REFOUT / "continuations/recovery01/LAUNCH_OR_RUNTIME_FAILURE.json",
        REFOUT / "continuations/recovery01/REMOTE_GPU_FINISHED.json",
        REFOUT / "continuations/recovery01/SCHEDULER_TERMINAL.json"]
    p.atomic_json(SNAPSHOT, dict(utc=utc(), state="reference_partial_paused_for_cot", original_all360_barrier_satisfied=False,
        metadata=checks, database=state, pins={p.rel(path): p.sha(path) for path in paths},
        backup_path=p.rel(backup), backup_sha256=p.sha(backup), no_quality_selection=True))
    return dict(snapshot=p.rel(SNAPSHOT), sha256=p.sha(SNAPSHOT), metadata=checks)


def authorized():
    full.authorized()
    auth = p.read(AUTH)
    assert auth["approved"] is True and auth["decision_id"] == DECISION
    assert auth["script_sha256"] == p.sha(__file__) and auth["protocol_sha256"] == p.sha(p.PROTOCOL)
    assert auth["pause_snapshot_sha256"] == p.sha(SNAPSHOT)
    assert auth["scheduler_only"] is True and auth["approved_conditions"] == 360
    matching = [r for r in p.rows(p.PLAN / "DECISIONS.jsonl") if r.get("id") == DECISION]
    assert len(matching) == 1 and matching[0]["approved"] is True
    assert matching[0]["authorization_sha256"] == p.sha(AUTH)
    assert matching[0]["script_sha256"] == auth["script_sha256"]
    return auth


def priority_status():
    authorized(); snapshot = p.read(SNAPSHOT)
    for path, expected in snapshot["pins"].items(): assert p.sha(ROOT / path) == expected, path
    assert p.sha(ROOT / snapshot["backup_path"]) == snapshot["backup_sha256"]
    checks = base_pause_checks()
    assert checks == snapshot["metadata"]
    assert database_state() == snapshot["database"], "Paused reference namespace changed"
    # `finished` is the existing controller's gate-ready field, not a claim
    # that reference360 is complete. The unchanged nested metadata says false.
    return dict(finished=True, ready_for_cot=True, barrier_mode="approved_partial_reference_scheduling_pause",
        original_all360_barrier_satisfied=False, reference_state="reference_partial_paused_for_cot", **checks)


def run():
    auth = authorized(); state = priority_status()
    original = predecessors.status
    p.atomic_json(p.OUT / "SCHEDULING_EXECUTION.json", dict(utc=utc(), authorization=p.rel(AUTH),
        authorization_sha256=p.sha(AUTH), script_sha256=auth["script_sha256"], initial_gate=state,
        changed_only_execution_order=True, main_evaluation_resumed=False))
    try:
        predecessors.status = priority_status
        return full.run(wait=False)
    finally:
        predecessors.status = original


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("snapshot", "status", "run"))
    result = {"snapshot": snapshot, "status": priority_status, "run": run}[parser.parse_args().action]()
    print(json.dumps(result, ensure_ascii=True), flush=True)
