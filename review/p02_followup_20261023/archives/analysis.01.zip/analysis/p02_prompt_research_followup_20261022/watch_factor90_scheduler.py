"""Independent metadata-only factor90 Slurm watcher; never submits or replays work."""
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
import argparse
import getpass
import hashlib
import json
import shlex
import socket
import sqlite3
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
NAME = "p02_reference_binding_priority_fixed90_v1_20261022"
EXPERIMENT = ROOT / "experiments/query_decomposition" / NAME
OUTPUT = ROOT / "outputs/query_decomposition" / NAME
PLAN = ROOT / "experiments/query_decomposition/unified_rag_eval_v1_20261021"
HOST = "cluster1.comp.anu.edu.au"
REMOTE_PARENT = "/home/projects/u7830488/p02_prompt_small_evals_20261022"
DECISION = "P02_FACTOR90_SCHEDULER_WATCH_APPROVED_20261022"
TERMINAL = {"COMPLETED", "TIMEOUT", "CANCELLED", "FAILED", "OUT_OF_MEMORY", "NODE_FAIL", "PREEMPTED", "BOOT_FAIL", "DEADLINE", "REVOKED"}


def read(path): return json.loads(Path(path).read_text(encoding="utf-8-sig"))
def rows(path): return [json.loads(line) for line in Path(path).read_text(encoding="utf-8-sig").splitlines() if line.strip()]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def utc(): return datetime.now(timezone.utc).isoformat()


def write(path, value):
    path = Path(path)
    assert path.parent.resolve() == OUTPUT.resolve(), "Watcher writes only its fixed output directory"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".watcher.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    temporary.replace(path)


def decision_template():
    return dict(id=DECISION, approved=False, experiment=NAME, script_sha256=sha(__file__),
        protocol_sha256=sha(EXPERIMENT / "PROTOCOL.frozen.json"), read_only_remote=True,
        allowed_local_mutations=["SCHEDULER_WATCH_HEARTBEAT.json", "SCHEDULER_TERMINAL.json", "STOP_REQUESTED"],
        new_jobs=False, API_requests=False, automatic_restarts_or_replays=False)


def authorized():
    row = next(r for r in rows(PLAN / "DECISIONS.jsonl") if r.get("id") == DECISION)
    assert row.get("approved") is True and row.get("experiment") == NAME
    assert row.get("script_sha256") == sha(__file__) and row.get("protocol_sha256") == sha(EXPERIMENT / "PROTOCOL.frozen.json")
    assert row.get("read_only_remote") is True
    assert row.get("new_jobs") is False and row.get("API_requests") is False and row.get("automatic_restarts_or_replays") is False
    assert set(row.get("allowed_local_mutations", [])) == {"SCHEDULER_WATCH_HEARTBEAT.json", "SCHEDULER_TERMINAL.json", "STOP_REQUESTED"}
    protocol = read(EXPERIMENT / "PROTOCOL.frozen.json")
    assert protocol["experiment"] == NAME and protocol["planned_conditions"] == 360
    for name in ("EXECUTION_SETTINGS.json", "INPUTS90.jsonl", "ORDER360.jsonl", "RESOURCE_CONTRACTS.json"):
        path = EXPERIMENT / name
        assert protocol["pins"][str(path.relative_to(ROOT)).replace("\\", "/")] == sha(path)
    preflight = read(EXPERIMENT / "EXECUTION_SETTINGS.json")["partition_preflight"]
    assert protocol["pins"][preflight] == sha(ROOT / preflight)
    assert read(PLAN / "PLAN.json")["execution_approval"]["approved"] is False
    return row


def local_identity():
    protocol = sha(EXPERIMENT / "PROTOCOL.frozen.json")
    job = read(OUTPUT / "REMOTE_JOB_ID.json")
    assert isinstance(job["job_id"], str) and job["job_id"].isdigit()
    assert job["protocol_sha256"] == protocol and job["directory"] == REMOTE_PARENT + "/factor90_" + protocol[:16]
    ready_path = OUTPUT / "REMOTE_GPU_READY.json"
    ready_available = ready_path.exists()
    if ready_available:
        ready = read(ready_path)
        assert ready["job_id"] == job["job_id"] and ready["protocol_sha256"] == protocol and ready["status"] == "ready"
        assert ready["no_LLM_credentials_or_requests"] is True and "A6000" in ready["gpu"]
        resources = read(EXPERIMENT / "RESOURCE_CONTRACTS.json")
        assert {ds: row["identity"] for ds, row in ready["resources"].items()} == {ds: row["identity"] for ds, row in resources.items()}
    return dict(**job, ready_available=ready_available)


def progress():
    """Only IDs, identity and request statuses; no prediction, prompt or gold reads."""
    tasks = rows(EXPERIMENT / "ORDER360.jsonl"); planned = {task["task_id"] for task in tasks}
    assert len(tasks) == len(planned) == 360
    path = OUTPUT / "checkpoint.sqlite3"
    if not path.exists():
        return dict(valid=True, attempted=0, planned=360, in_flight=0, complete=False, checkpoint_available=False)
    try:
        with closing(sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)) as db:
            db.execute("BEGIN")
            identity_row = db.execute("SELECT value FROM data WHERE kind='meta' AND key='identity'").fetchone()
            identity = json.loads(identity_row[0]) if identity_row else {}
            done = {row[0] for row in db.execute("SELECT key FROM data WHERE kind='outcome'")}
            inflight = db.execute("SELECT count(*) FROM requests WHERE status='in_flight'").fetchone()[0]
        expected = dict(protocol_sha256=sha(EXPERIMENT / "PROTOCOL.frozen.json"), inputs_sha256=sha(EXPERIMENT / "INPUTS90.jsonl"),
            order_sha256=sha(EXPERIMENT / "ORDER360.jsonl"), resources=read(EXPERIMENT / "RESOURCE_CONTRACTS.json"), no_historical_LLM_seed=True)
        held = {read(path)["task_id"] for path in (OUTPUT / "held").glob("*.json")}
        assert identity == expected and done <= planned and held <= planned
        return dict(valid=True, attempted=len(done | held), planned=360, in_flight=inflight,
                    complete=done | held == planned, checkpoint_available=True)
    except (OSError, sqlite3.Error, AssertionError, ValueError, KeyError, TypeError):
        return dict(valid=False, complete=False, reason="checkpoint_metadata_unconfirmed")


def command(client, argv):
    _, stdout, stderr = client.exec_command(shlex.join(argv), timeout=20)
    return dict(argv=argv, code=stdout.channel.recv_exit_status(), stdout=stdout.read().decode(), stderr=stderr.read().decode())


def validate_terminal(job, commands):
    jid = job["job_id"]
    expected = dict(squeue=["squeue", "-h", "-j", jid, "-o", "%i|%T|%j"],
        sacct=["sacct", "-n", "-P", "-j", jid, "--format=JobIDRaw,JobName,State,ExitCode,Start,End,Timelimit,NodeList"],
        scontrol=["scontrol", "show", "job", "-o", jid])
    for name, argv in expected.items():
        record = commands[name]
        assert record["argv"] == argv and record["code"] == 0 and not record["stderr"].strip()
    assert not commands["squeue"]["stdout"].strip()
    accounting = [line.split("|") for line in commands["sacct"]["stdout"].splitlines() if line.strip()]
    assert accounting and all(len(row) == 8 for row in accounting)
    parents = [row for row in accounting if row[0] == jid]
    assert len(parents) == 1
    parent = parents[0]; state = parent[2].split()[0]
    assert parent[1] == "p02-factor90" and state in TERMINAL
    assert datetime.fromisoformat(parent[5]) >= datetime.fromisoformat(parent[4])
    assert all((row[0] == jid or row[0].startswith(jid + ".")) and row[2].split()[0] in TERMINAL for row in accounting)
    control = dict(field.split("=", 1) for field in commands["scontrol"]["stdout"].split() if "=" in field)
    for key, value in dict(JobId=jid, JobName="p02-factor90", UserId="u7830488(7830488)", Account="db4ai", QOS="db4ai",
                            WorkDir=job["directory"], JobState=state).items():
        assert control.get(key) == value, key
    assert control.get("EndTime") == parent[5] and control.get("StartTime") == parent[4]
    return dict(verified=True, job_id=jid, state=state, remote_directory=job["directory"],
                scheduler_end_time=parent[5], scheduler_timestamp_scope="remote local clock; not relabelled UTC")


def record_terminal(job, commands, terminal, counts):
    """Called only after exact-owned scheduler termination; never alters checkpoint."""
    assert terminal["verified"] and terminal["job_id"] == job["job_id"] and counts["valid"]
    path = OUTPUT / "SCHEDULER_TERMINAL.json"
    receipt = dict(utc=utc(), experiment=NAME, protocol_sha256=job["protocol_sha256"], job_id=job["job_id"],
        remote_directory=job["directory"], host=HOST, read_only_remote=True, new_jobs=0, API_requests=0,
        commands=commands, terminal=terminal, progress=counts, graceful_worker_FINISHED_receipt=False)
    if path.exists():
        previous = read(path)
        assert previous["job_id"] == job["job_id"] and previous["protocol_sha256"] == job["protocol_sha256"]
    else:
        write(path, receipt)
    stopped = False
    if not counts["complete"]:
        stop = OUTPUT / "STOP_REQUESTED"
        try:
            with stop.open("x", encoding="utf8") as stream:
                stream.write("Verified scheduler terminal state for factor90 job " + job["job_id"] + "; preserve partial work and do not dispatch further conditions.\n")
            stopped = True
        except FileExistsError:
            pass
    return dict(stop_written=stopped, stop_exists=(OUTPUT / "STOP_REQUESTED").exists(), terminal_receipt_recorded=True)


def heartbeat(**fields):
    write(OUTPUT / "SCHEDULER_WATCH_HEARTBEAT.json", dict(utc=utc(), experiment=NAME, watcher_script_sha256=sha(__file__), **fields))


def watch():
    authorized()
    while not (OUTPUT / "REMOTE_JOB_ID.json").exists():
        if (OUTPUT / "STOP_REQUESTED").exists():
            heartbeat(state="stopped_before_job", connected=False); return dict(state="stopped_before_job")
        heartbeat(state="waiting_for_local_job", connected=False, credential_requested=False)
        time.sleep(30)
    job = local_identity(); settings = read(EXPERIMENT / "EXECUTION_SETTINGS.json")
    preflight = read(ROOT / settings["partition_preflight"])
    assert preflight["verified_address"] == settings["verified_host_address"] and preflight["read_only"] is True
    import paramiko
    client = paramiko.SSHClient(); client.load_system_host_keys(); client.set_missing_host_key_policy(paramiko.RejectPolicy())
    password = getpass.getpass("Remote password: ")
    connection = None
    try:
        connection = socket.create_connection((settings["verified_host_address"], 22), timeout=15)
        client.connect(HOST, username="u7830488", password=password, sock=connection,
                       look_for_keys=False, allow_agent=False, timeout=15, auth_timeout=20, banner_timeout=15)
    except BaseException:
        if connection: connection.close()
        client.close(); raise
    finally:
        password = None
    client.get_transport().set_keepalive(25)
    try:
        while True:
            try:
                current = local_identity()
                assert all(current[key] == job[key] for key in ("job_id", "protocol_sha256", "directory"))
                job = current; counts = progress()
                queue = command(client, ["squeue", "-h", "-j", job["job_id"], "-o", "%i|%T|%j"])
                if queue["code"] != 0 or queue["stderr"].strip():
                    heartbeat(state="scheduler_read_unconfirmed", job_id=job["job_id"], connected=True, stop_written=False)
                elif queue["stdout"].strip():
                    live = [line.split("|") for line in queue["stdout"].splitlines() if line.strip()]
                    assert all(len(row) == 3 and row[0] == job["job_id"] and row[2] == "p02-factor90" for row in live)
                    heartbeat(state="all_conditions_attempted_waiting_worker" if counts.get("complete") else "watching",
                        job_id=job["job_id"], scheduler_states=[row[1] for row in live], progress=counts, connected=True, stop_written=False)
                else:
                    commands = dict(squeue=queue,
                        sacct=command(client, ["sacct", "-n", "-P", "-j", job["job_id"], "--format=JobIDRaw,JobName,State,ExitCode,Start,End,Timelimit,NodeList"]),
                        scontrol=command(client, ["scontrol", "show", "job", "-o", job["job_id"]]))
                    terminal = validate_terminal(job, commands)
                    # Refresh local metadata immediately before the only stop-write path.
                    counts = progress()
                    if counts["valid"]:
                        result = record_terminal(job, commands, terminal, counts)
                        heartbeat(state="terminal_verified", job_id=job["job_id"], terminal_state=terminal["state"], progress=counts, connected=True, **result)
                        return dict(state="terminal_verified", **result)
                    heartbeat(state="terminal_local_metadata_unconfirmed", job_id=job["job_id"], connected=True, stop_written=False)
            except (AssertionError, OSError, ValueError, KeyError, TypeError, EOFError, paramiko.SSHException) as error:
                heartbeat(state="watch_unconfirmed_no_stop", job_id=job["job_id"], error_type=type(error).__name__, connected=bool(client.get_transport() and client.get_transport().is_active()), stop_written=False)
                if not client.get_transport() or not client.get_transport().is_active():
                    raise RuntimeError("Watcher SSH connection ended; no stop decision inferred") from None
            time.sleep(30)
    finally:
        client.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("decision-template", "check", "watch"))
    args = parser.parse_args()
    if args.action == "decision-template": result = decision_template()
    elif args.action == "check": result = dict(identity=local_identity() if (OUTPUT / "REMOTE_JOB_ID.json").exists() else None, progress=progress(), new_API_SSH_GPU=0)
    else: result = watch()
    print(json.dumps(result, ensure_ascii=True), flush=True)


if __name__ == "__main__": main()
