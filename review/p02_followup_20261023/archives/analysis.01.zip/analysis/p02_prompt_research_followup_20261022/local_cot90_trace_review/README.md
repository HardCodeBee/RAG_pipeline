# Fixed90 exact trace review packet

Scores and paired deltas are copied from the experiment's official DETAILS/PAIRED artifacts. Technical holds remain missing; algorithm failures retain official zero. All90 and ordinary-present84 are separate.

INDEX.jsonl lists every frozen query, the R256 versus fresh N128 change, and its case file. Every case includes all four arms and N128-to-N256, N128-to-F256, N128-to-R256, F256-to-R256 comparisons. Exact prompt strings and full document text are in each case's prompts/documents catalogs; refs are content hashes, not truncations.

Review every F1/EM-changed case and prediction-changed tie. Read the first ordinary accepted-answer difference, its actual reader evidence, later rewrite/candidate/reader differences, goal evidence, and final prompt/prediction. A raw Support change that never changes accepted Answer is separate from downstream propagation. Failed uncommitted candidates and unsuccessful request receipts are retained. Missing nodes are not fabricated.

The final_surface_case_space_punctuation_only field is only a conservative character-level check. final_prediction_changed_under_identical_final_input means accepted nodes and the exact final prompt agree; raw Support can still differ and it does not establish semantic formatting equivalence. All semantic review fields remain pending. Local scoring references may themselves need semantic review and are not independent truth. No automatic causal label, arm selection, extra model evaluation or publication is performed.
