"""Root-requested initial32 contract/accounting review; no quality readout.

Only SQLite mode=ro is opened. Frozen templates are rendered locally to verify
payload binding; answer strings remain in memory and are never printed/saved.
"""
from collections import Counter,defaultdict
from contextlib import closing
from pathlib import Path
import hashlib,json,sys,time

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/"src"))
from experiments.query_decomposition.p02_reference_binding_priority_probe_v1_20261022 import run as app,templates
from experiments.query_decomposition.p02_shared_context_fixed90_v1_20261022.native_ask import integrity,stage_success,terminal_reason,any_returned


def audit():
    order=app.rows(app.ORDER)[:32];task_ids={row["task_id"]for row in order}
    assert len(task_ids)==32 and all(row["is_stress"]for row in order)
    started=app.utc();protocol=app.check();config=app.read(app.PACKAGE/"config.json");model=config["generation"]["model"]
    items={row["probe_id"]:row for row in app.rows(app.INPUTS)}
    with closing(app.ro(app.OUT/"checkpoint.sqlite3"))as db:
        db.execute("BEGIN")
        data={(kind,key):json.loads(value)for kind,key,value in db.execute("SELECT kind,key,value FROM data")}
        def requests(table):
            return[dict(id=rid,payload=payload,status=status,result=json.loads(raw)if raw else{})
                for rid,payload,status,raw in db.execute("SELECT id,payload,status,result FROM "+table)]
        current,retired=requests("requests"),requests("retired_requests")
        uses=list(db.execute("SELECT request_id,stage FROM request_stages"))
        olduses=list(db.execute("SELECT request_id,stage FROM retired_request_stages"))
    assert data["meta","identity"]==dict(protocol_sha256=app.sha(app.PROTOCOL),inputs_sha256=app.sha(app.INPUTS),
        order_sha256=app.sha(app.ORDER),historical_seed=None)
    completed={key:data["outcome",key]for key in task_ids if("outcome",key)in data}
    held={row["task_id"]:row for row in app.held_outcomes()if row["task_id"]in task_ids-completed.keys()}
    assert set(completed)|set(held)==task_ids,"Initial32 not all attempted"
    results={**completed,**held};by_id={row["id"]:row for row in current};usemap=defaultdict(set)
    for rid,stage in uses:usemap[rid].add(stage)
    prefixes=tuple("full8/"+key+"/"for key in task_ids)
    request_ids={rid for rid,stage in uses+olduses if stage.startswith(prefixes)}
    initial_current=[row for row in current if row["id"]in request_ids]
    initial_retired=[row for row in retired if row["id"]in request_ids]
    assert not any(row["status"]=="in_flight"for row in initial_current)
    assert len(request_ids)==len(initial_current)+len(initial_retired)
    namespace="p02_prompt_research_v1_20261022/"+str(app.OUT.resolve())
    with closing(app.ro(Path(config["budget"]["ledger"])))as db:
        db.execute("BEGIN")
        charges={rid:dict(reserved=reserve,actual=actual,status=status)
            for rid,reserve,actual,status in db.execute("SELECT id,reserved,actual,status FROM charges WHERE namespace=?",(namespace,))}
    assert request_ids<=charges.keys()
    tokens=Counter();qa_tokens=Counter();fmt_tokens=Counter();logical=Counter();finishes=Counter();models=set();fmt_count=0
    for task in order:
        key=task["task_id"];result=results[key];item=items[task["probe_id"]]
        assert result["arm"]==task["arm"]and result["probe_id"]==task["probe_id"]and result["is_stress"]is True
        assert result["actual_child_prompt"]==templates.prompt(item,task["arm"])
        assert result["raw_current_question"]==item["current_question"]and result["actual_reader_packet"]==item["reader_packet"]
        assert result["candidate_bindings"]==(templates.bindings(item)if task["arm"]=="B1"else[])
        stages=result["stages"];qa="legacy/answer/"+str(item["step_id"]);fmt="legacy/sentence_format/"+str(item["step_id"])
        assert len(stages)<=2
        if stages:assert stages[0]["stage"]==qa
        if len(stages)==2:assert stages[1]["stage"]==fmt
        if result["formatter_triggered"]:
            fmt_count+=1;assert result["initial_answer"]is not None and templates.needs_formatter(result["initial_answer"])
        if result["status"]=="success":assert len(stages)==1+int(result["formatter_triggered"])
        for stage in stages:
            stage_key=key+"/"+stage["stage"];assert data["stage",stage_key]==stage
            prompt=result["actual_child_prompt"]if stage["stage"]==qa else templates.formatter_prompt(item,result["initial_answer"])
            payload=app.build_payload(config["generation"],prompt,128);encoded=app.canonical(payload)
            assert stage["payload_sha256"]==hashlib.sha256(encoded.encode()).hexdigest()
            rid=stage["request_id"];row=by_id[rid];assert row["payload"]==encoded
            assert "full8/"+stage_key in usemap[rid]
            receipt={**row["result"],"status":row["status"]}
            assert integrity(receipt,model)
            assert stage_success(receipt,model,stage["stage"])or terminal_reason(receipt,model)==stage["terminal_reason"]
            assert receipt["usage"]==stage["usage"]and receipt["finish_reason"]==stage["finish_reason"]
            assert payload["max_tokens"]==128 and payload["model"]==model
            usage={name:stage["usage"][name]for name in("prompt_tokens","completion_tokens","total_tokens")}
            assert all(type(value)is int and value>=0 for value in usage.values())
            assert usage["total_tokens"]==usage["prompt_tokens"]+usage["completion_tokens"]
            tokens.update(usage);(qa_tokens if stage["stage"]==qa else fmt_tokens).update(usage)
            logical[rid]+=1;finishes[stage["finish_reason"]]+=1;models.add(receipt["returned_model"])
        for name in("prompt_tokens","completion_tokens","total_tokens"):
            assert result["usage"][name]==sum(stage["usage"][name]for stage in stages)
    attempts=Counter(row["payload"]for row in initial_current+initial_retired)
    assert max(attempts.values(),default=0)<=5
    for row in initial_current+initial_retired:
        charge=charges[row["id"]];payload=json.loads(row["payload"])
        expected=sum(len(message["content"].encode("utf8"))for message in payload["messages"])*app.INPUT_RATE+128*app.OUTPUT_RATE
        assert abs(charge["reserved"]-expected)<1e-10
        usage=row["result"].get("usage")
        if usage and "prompt_tokens"in usage and "completion_tokens"in usage:
            assert charge["status"]=="returned_usage"and abs(charge["actual"]-app.cost(usage))<1e-10
        else:assert charge["actual"]is None
    for row in initial_retired:assert not any_returned(row["result"])and charges[row["id"]]["actual"]is None
    selected=[charges[rid]for rid in request_ids]
    value=dict(passed=True,scope="Initial32 runtime contracts/accounting only; no answers, semantic labels or F1 readout",
        started_utc=started,finished_utc=app.utc(),protocol_sha256=app.sha(app.PROTOCOL),
        frozen_pins_checked=len(protocol["pins"]),protected_holds_checked=len(protocol["protected_holds"]),
        planned_initial_conditions=32,attempted=32,quality_terminal=len(completed),technical_held=len(held),
        outcome_statuses=dict(Counter(row["status"]for row in results.values())),logical_stage_uses=sum(logical.values()),
        formatter_triggered=fmt_count,current_distinct_requests=len(initial_current),retired_attempts=len(initial_retired),
        max_attempts_per_exact_payload=max(attempts.values(),default=0),initial_in_flight=0,
        requested_returned_models_exact=sorted(models),native_output_cap=128,stage_finish_reasons=dict(finishes),
        full_payload_and_request_stage_bindings_exact=True,fresh_seed_none=True,
        same_run_reuse_additional_logical_uses=sum(count-1 for count in logical.values()),
        logical_tokens=dict(tokens),QA_logical_tokens=dict(qa_tokens),formatter_logical_tokens=dict(fmt_tokens),
        actual_distinct_attempt_estimate_CNY=sum(row["actual"]or 0. for row in selected),
        unresolved_reserved_CNY=sum(row["reserved"]for row in selected if row["actual"]is None),
        retained_unknown_liabilities=sum(row["actual"]is None for row in selected),ledger_one_row_per_distinct_attempt=True,
        namespace_charge_rows_outside_initial_scope=len(charges.keys()-request_ids),
        read_mode="Separate SQLite read-only transactions; initial32 attempted/no initial in-flight. No cross-DB atomic snapshot claim.",
        real_API_SSH_GPU_requests_by_audit=0,live_checkpoint_or_ledger_writes=0,answers_or_quality_labels_emitted=False)
    app.atomic_json(app.OUT/"ROOT_RUNTIME_AUDIT_INITIAL32.json",value)
    print(json.dumps(value,ensure_ascii=True));print("AUDIT_SHA256",app.sha(app.OUT/"ROOT_RUNTIME_AUDIT_INITIAL32.json"))
    return value


if __name__=="__main__":
    for index in range(60):
        with closing(app.ro(app.OUT/"checkpoint.sqlite3"))as db:
            completed={key for key, in db.execute("SELECT key FROM data WHERE kind='outcome'")}
        held={row["task_id"]for row in app.held_outcomes()}
        initial={row["task_id"]for row in app.rows(app.ORDER)[:32]}
        attempted=len((completed|held)&initial)
        print(json.dumps(dict(event="initial32_readonly_wait",attempted=attempted,planned=32)),flush=True)
        if attempted==32:audit();break
        time.sleep(30)
    else:raise RuntimeError("Initial32 audit waiting limit reached; no live mutation")
