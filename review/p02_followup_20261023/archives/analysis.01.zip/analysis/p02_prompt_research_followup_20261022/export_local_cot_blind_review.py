"""Read-only, method-masked ordinary CoT review export after the whole batch is attempted.

Never opens a writable experiment checkpoint, provider, key, SSH or GPU.
The identity map is kept outside the review packet and must remain closed until
labels are locked. Treatment format remains visible; this is not perfect blinding.
"""
from contextlib import closing
from pathlib import Path
import argparse
import hashlib
import hmac
import json
import secrets
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "src"))
from experiments.query_decomposition.p02_local_cot_stage38_v1_20261022 import run as experiment

OUT = experiment.OUT
REVIEW = OUT / "root_blind_review"
read, rows, sha = experiment.read, experiment.rows, experiment.sha


def snapshot():
    """Obtain only task status/identity first. No future candidate output is read."""
    experiment.authorized()
    path = OUT / "checkpoint.sqlite3"
    if not path.is_file(): return dict(state="not_started", attempted=set(), statuses={})
    with closing(experiment.ro(path)) as db:
        db.execute("BEGIN")
        identity_row = db.execute("SELECT value FROM data WHERE kind='meta' AND key='identity'").fetchone()
        assert identity_row and json.loads(identity_row[0]) == experiment.identity()
        statuses = dict(db.execute("SELECT key,json_extract(value,'$.status') FROM data WHERE kind='outcome'"))
        active = db.execute("SELECT count(*) FROM requests WHERE status='in_flight'").fetchone()[0]
    held = {read(p)["task_id"]: p for p in (OUT / "held").glob("*.json")}
    assert not set(statuses).intersection(held)
    planned = {r["task_id"] for r in rows(experiment.ORDER)}
    assert set(statuses) <= planned and set(held) <= planned
    assert set(statuses.values()) <= {"success", "algorithm_failure"}
    return dict(state="available", attempted=set(statuses) | set(held), statuses=statuses, held=held, in_flight=active)


INSTRUCTIONS = """# Method-masked ordinary-answer review

Review only the current subquestion, prior QA, frozen retrieved passages and
candidate outputs in this packet. Do not open the private identity mapping,
other experiment scores or method-specific outputs until labels are locked.
Candidate order and IDs are randomized. Response structure remains visible,
so method masking cannot provide perfect blinding.

Three axes are separate:

1. complete_raw_response_correctness: assess every factual assertion and
   relation/operation in the raw response, including Support. A correct Answer
   does not make false Support correct. Allowed working values are correct,
   incorrect, pending, or no_response. Pending is an unresolved work item, not
   a new truth category. Explain the exact incorrect statement or open fact.
2. accepted_answer_correctness: judge the actual answer that would be handed
   onward after the native formatter, independently from Support. Values are
   correct, incorrect, pending, or no_accepted_answer. A returned format or
   length failure has no accepted answer; do not invent one from a plausible
   substring. Raw and parsed text remain available for diagnosis.
3. accepted_information: sufficient_for_current_question, useful_partial,
   no_useful_information, misleading, pending, or no_accepted_answer. State
   which necessary entity, directed relation, attribute, qualifier, condition
   or operation the inputs establish and whether the accepted answer retains
   it. True but incomplete answers or reasonable abstentions may be correct
   on axis 2 while transmitting little useful information on axis 3.

Apply the previously agreed correctness rules: judge full statements, not
just an answer entity; a correct relevant factual answer stays correct even
if retrieval was weak; an incomplete list is acceptable if its stated facts
are correct and responsive; true background that does not answer the question
is incorrect. A reasonable abstention can be correct when the supplied facts
are insufficient. Do not infer absence from missing evidence. Evaluate time-
sensitive facts in the dataset/frozen-material setting. Resolve facts from
these materials first; outside verification is reserved for genuine missing
or conflicting facts and must be recorded with its source.

Inputs are exposed development cases, not a new holdout. No final-answer F1 is
measured here. Formatter output is shown separately: it may repair a short
response or introduce a new error. The first axis concerns raw emitted text;
the second and third concern accepted_answer, not the unforwarded Support.

Fill REVIEW_LABELS.jsonl, keeping candidate IDs unchanged. Give concrete local
evidence and uncertainty notes. Lock that file's SHA256 before using the private
identity map. Do not replace a held/algorithm-failed outcome with a historical
answer or silently count missing outputs as factually incorrect.
"""


def export(batch):
    assert batch in ("initial8", "supplemental30")
    state = snapshot()
    inputs = rows(experiment.INPUTS)
    selected = inputs[:8] if batch == "initial8" else inputs[8:]
    node_ids = {r["probe_id"] for r in selected}
    tasks = [r for r in rows(experiment.ORDER) if r["probe_id"] in node_ids]
    wanted = {r["task_id"] for r in tasks}
    assert len(wanted) == len(selected) * 4
    if not wanted <= state["attempted"]:
        return dict(state="waiting_whole_batch", batch=batch, planned=len(wanted),
            attempted=len(wanted.intersection(state["attempted"])), new_API_SSH_GPU_requests=0)
    destination = REVIEW / batch
    if destination.exists():
        manifest = read(destination / "MANIFEST.json")
        assert manifest["protocol_sha256"] == sha(experiment.PROTOCOL)
        assert all(sha(destination / name) == expected for name, expected in manifest["packet_hashes"].items())
        return dict(state="already_exported", batch=batch, cases=len(selected), candidates=len(wanted), review=str(destination))
    # Now, and only now, fetch this fully attempted batch's output text.
    values = {}
    with closing(experiment.ro(OUT / "checkpoint.sqlite3")) as db:
        for key in wanted:
            row = db.execute("SELECT value FROM data WHERE kind='outcome' AND key=?", (key,)).fetchone()
            values[key] = json.loads(row[0]) if row else read(state["held"][key])
    secret = secrets.token_bytes(32)
    def token(key): return hmac.new(secret, key.encode("utf8"), hashlib.sha256).hexdigest()
    mapping = []; packets = []; labels = []
    for index, item in enumerate(selected):
        candidates = []
        local_tasks = sorted((r for r in tasks if r["probe_id"] == item["probe_id"]), key=lambda r: token(r["task_id"]))
        case_token = "case-" + token(item["probe_id"])[:16]
        for task in local_tasks:
            value = values[task["task_id"]]; candidate_id = "candidate-" + token("candidate/" + task["task_id"])[:20]
            assert value["task_id"] == task["task_id"] and value["probe_id"] == item["probe_id"]
            assert value["raw_current_question"] == item["current_question"] and value["actual_reader_packet"] == item["reader_packet"]
            candidates.append(dict(candidate_id=candidate_id, execution_status=value["status"],
                raw_response=value["raw_output"], support=value["support"], parsed_answer=value["parsed_answer"],
                accepted_answer=value["accepted_answer"], formatter_output=value["formatted_answer"]))
            labels.append(dict(case_id=case_token, candidate_id=candidate_id,
                complete_raw_response_correctness=None, accepted_answer_correctness=None, accepted_information=None,
                necessary_information_established_in_inputs=None, exact_error_or_missing_information=None,
                evidence=None, pending_fact=None, external_verification=None))
            mapping.append(dict(candidate_id=candidate_id, case_id=case_token, task_id=task["task_id"], arm=task["arm"],
                source_probe_id=item["probe_id"], source_case_id=item["case_id"], source_outcome_sha256=experiment.digest(value)))
        packets.append(dict(case_id=case_token, dataset=item["dataset"], current_question=item["current_question"],
            original_question=item["original_question"], prior_question_answers=item["history"],
            retrieved_passages=[dict(rank=d.get("rank"), source=d.get("source"), block=d["block"])
                                for d in item["reader_packet"]["docs"]], candidates=candidates))
    destination.mkdir(parents=True)
    experiment.jsonl(destination / "REVIEW_PACKET.jsonl", packets)
    experiment.jsonl(destination / "REVIEW_LABELS.jsonl", labels)
    (destination / "README.md").write_text(INSTRUCTIONS, encoding="utf8")
    # Separate private folder is excluded from the packet manifest and review paths.
    private = REVIEW / "private_identity"; private.mkdir(exist_ok=True)
    experiment.atomic_json(private / (batch + ".json"), dict(protocol_sha256=sha(experiment.PROTOCOL),
        review_packet_sha256=sha(destination / "REVIEW_PACKET.jsonl"), labels_must_be_locked_before_join=True,
        nonce=secret.hex(), records=mapping))
    experiment.atomic_json(destination / "MANIFEST.json", dict(batch=batch, protocol_sha256=sha(experiment.PROTOCOL),
        inputs_sha256=sha(experiment.INPUTS), nodes=len(selected), candidates=len(wanted),
        statuses=dict(__import__("collections").Counter(v["status"] for v in values.values())),
        method_names_gold_and_metrics_excluded=True, format_is_visible_imperfect_blinding=True,
        packet_hashes={name: sha(destination / name) for name in ("REVIEW_PACKET.jsonl", "README.md")},
        new_API_SSH_GPU_requests=0, production_checkpoint_or_ledger_writes=0))
    return dict(state="exported", batch=batch, cases=len(selected), candidates=len(wanted),
        review=str(destination), new_API_SSH_GPU_requests=0)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("batch", choices=("initial8", "supplemental30", "status"))
    args = parser.parse_args()
    if args.batch == "status":
        value = snapshot(); value = dict(state=value["state"], attempted=len(value["attempted"]),
            in_flight=value.get("in_flight", 0), new_API_SSH_GPU_requests=0)
    else: value = export(args.batch)
    print(json.dumps(value, ensure_ascii=True))


if __name__ == "__main__": main()
