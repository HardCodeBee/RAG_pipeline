"""Offline masked review of the frozen reference-factor QA probe.

Export does not expose arm labels, prompt variants, gold or native final scores.
Review labels are locked before joining methods. No provider is imported here.
"""
from pathlib import Path
from contextlib import closing
import argparse
import hashlib
import json
import random
import sqlite3

ROOT = Path(__file__).resolve().parents[2]
NAME = "p02_reference_binding_priority_probe_v1_20261022"
EXP = ROOT / "experiments/query_decomposition" / NAME
OUT = ROOT / "outputs/query_decomposition" / NAME
ARMS = ("C0", "S1", "B1", "P1")
FIELDS = ("factual_correct", "addresses_actual_question", "necessary_information_retained", "entity_role_or_scope_error")


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def rows(path):
    return [json.loads(x) for x in path.read_text(encoding="utf-8-sig").splitlines() if x.strip()]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8")


def export(batch, cohort):
    folder = OUT / "root_blind_review" / batch
    assert not folder.exists(), "Choose a fresh immutable batch"
    inputs = rows(EXP / "INPUTS.frozen.jsonl")
    with closing(sqlite3.connect((OUT / "checkpoint.sqlite3").resolve().as_uri() + "?mode=ro", uri=True)) as db:
        db.execute("BEGIN")
        outcomes = [json.loads(v) for v, in db.execute("SELECT value FROM data WHERE kind='outcome'")]
    index = {(x["probe_id"], x["arm"]): x for x in outcomes}
    previous = {x["case_id"] for p in (OUT / "root_blind_review").glob("*/PACKET.json") for x in read(p)["cases"]}
    cases, key = [], []
    rng = random.Random(2026102207)
    for item in inputs:
        ident = item["probe_id"]
        if ident in previous or (cohort == "stress") != bool(item["is_stress"]):
            continue
        if not all((ident, a) in index for a in ARMS):
            continue
        order = list(ARMS)
        rng.shuffle(order)
        candidates = []
        for arm in order:
            result = index[ident, arm]
            cid = "c" + digest([batch, ident, arm, "fixed-reference-factors"])[:12]
            text = result.get("answer", "")
            candidates.append(dict(candidate_id=cid, text=text, initial_answer=result.get("initial_answer"),
                                   formatter_triggered=result["formatter_triggered"], complete_output=result["status"] == "success"))
            key.append(dict(case_id=ident, candidate_id=cid, arm=arm, outcome_sha256=digest(result),
                            text_sha256=hashlib.sha256(text.encode()).hexdigest(), usage=result["usage"]))
        cases.append(dict(case_id=ident, dataset=item["dataset"], original_question=item["original_question"],
                          current_question=item["current_question"], previous_QA=item["history"],
                          retrieved_passages=item["reader_packet"], candidates=candidates))
    assert cases, "No new complete four-arm nodes"
    packet = dict(scope="Component-only, method-masked review; exposed development nodes, not independent human gold or final F1.",
                  constraints="Read this PACKET only. Do not open METHOD_KEY, checkpoint, output REPORT, provenance answers or final scores until labels locked. Disclose prior case exposure; unresolved facts remain pending work items.",
                  truth_rule="Judge raw Current. All stated facts must be correct; true incomplete relevant facts may be correct. Correct entity in a false full statement is wrong. True off-target background is an answer error. Reasonable evidence-insufficient abstention can be correct but required information may be missing. Unsupported is not automatically false.",
                  fields=["case_id", "candidate_id", *FIELDS, "reason_with_input_evidence", "pending_work_items", "reviewer_exposure_disclosure"],
                  cases=cases)
    write(folder / "PACKET.json", packet)
    write(folder / "METHOD_KEY.local.json", key)
    lock = dict(cohort=cohort, nodes=len(cases), candidates=len(key), packet_sha256=sha(folder / "PACKET.json"),
                method_key_sha256=sha(folder / "METHOD_KEY.local.json"), input_sha256=sha(EXP / "INPUTS.frozen.jsonl"))
    write(folder / "PACKET_LOCK.json", lock)
    return dict(folder=str(folder.relative_to(ROOT)), **lock)


def lock_join(batch, expected_sha):
    folder = OUT / "root_blind_review" / batch
    packet, initial_lock = read(folder / "PACKET.json"), read(folder / "PACKET_LOCK.json")
    assert sha(folder / "PACKET.json") == initial_lock["packet_sha256"]
    review_path = folder / "SEMANTIC_REVIEWS.blinded.jsonl"
    assert sha(review_path) == expected_sha
    reviews = rows(review_path)
    candidates = {(x["case_id"], c["candidate_id"]): c for x in packet["cases"] for c in x["candidates"]}
    assert len(reviews) == len(candidates) and {(x["case_id"], x["candidate_id"]) for x in reviews} == set(candidates)
    for x in reviews:
        assert all(x[k] is None or type(x[k]) is bool for k in FIELDS)
        assert x["reason_with_input_evidence"] and x["reviewer_exposure_disclosure"]
        if any(x[k] is None for k in FIELDS):
            assert x["pending_work_items"]
    lock = dict(review_sha256=expected_sha, packet_sha256=initial_lock["packet_sha256"], records=len(reviews),
                labels_locked_before_method_join=True, independent_human_gold=False)
    lock_path = folder / "ROOT_REVIEW_LOCK.json"
    if lock_path.exists():
        assert read(lock_path) == lock
    else:
        write(lock_path, lock)
    assert sha(folder / "METHOD_KEY.local.json") == initial_lock["method_key_sha256"]
    methods = {(x["case_id"], x["candidate_id"]): x for x in read(folder / "METHOD_KEY.local.json")}
    joined = []
    for x in reviews:
        m = methods[x["case_id"], x["candidate_id"]]
        assert hashlib.sha256(candidates[x["case_id"], x["candidate_id"]]["text"].encode()).hexdigest() == m["text_sha256"]
        joined.append({**x, **m})
    summary = {}
    for arm in ARMS:
        subset = [x for x in joined if x["arm"] == arm]
        summary[arm] = dict(nodes=len(subset), factual_correct=sum(x["factual_correct"] is True for x in subset),
                            factual_adjudicated=sum(x["factual_correct"] is not None for x in subset),
                            answer_correct=sum(x["factual_correct"] is True and x["addresses_actual_question"] is True for x in subset),
                            answer_adjudicated=sum(x["factual_correct"] is not None and x["addresses_actual_question"] is not None for x in subset),
                            necessary_information_retained=sum(x["necessary_information_retained"] is True for x in subset),
                            information_adjudicated=sum(x["necessary_information_retained"] is not None for x in subset),
                            pending=sum(any(x[k] is None for k in FIELDS) for x in subset),
                            logical_prompt_tokens=sum(x["usage"]["prompt_tokens"] for x in subset),
                            logical_completion_tokens=sum(x["usage"]["completion_tokens"] for x in subset))
    indexed = {(x["case_id"], x["arm"]): x for x in joined}
    paired = {}
    for arm in ARMS[1:]:
        changes = {"gain": [], "tie": [], "harm": [], "pending": []}
        for case in packet["cases"]:
            ident = case["case_id"]
            control, candidate = indexed[ident, "C0"], indexed[ident, arm]
            if any(x[k] is None for x in (control, candidate) for k in ("factual_correct", "addresses_actual_question")):
                changes["pending"].append(ident)
                continue
            before = control["factual_correct"] and control["addresses_actual_question"]
            after = candidate["factual_correct"] and candidate["addresses_actual_question"]
            changes["gain" if after > before else "harm" if after < before else "tie"].append(ident)
        paired[arm] = {"counts": {k: len(v) for k, v in changes.items()}, "case_ids": changes}
    result = dict(scope="Exposed fixed-reader component comparison; no full-RAG F1/EM or population claim", review_lock=lock,
                  summary=summary, paired_answer_correct_vs_C0=paired, records=joined)
    write(folder / "SEMANTIC_JOIN.json", result)
    return dict(scope=result["scope"], summary=summary, paired=paired, joined_sha256=sha(folder / "SEMANTIC_JOIN.json"))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("export", "lock-join"))
    parser.add_argument("--batch", required=True)
    parser.add_argument("--cohort", choices=("stress", "supplemental"), default="stress")
    parser.add_argument("--review-sha")
    args = parser.parse_args()
    result = export(args.batch, args.cohort) if args.action == "export" else lock_join(args.batch, args.review_sha)
    print(json.dumps(result, ensure_ascii=True))
