"""Root-authorized post-lock matched89 native/token summary; local read-only inputs."""
from collections import Counter
from contextlib import closing
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "src"))
from experiments.query_decomposition.p02_shared_context_fixed90_v1_20261022 import source_inputs
from experiments.query_decomposition.p02_shared_context_fixed90_v1_20261022.native_ask import integrity, any_returned
from experiments.query_decomposition.comprehensive_eval_v1_20261015.scoring import metric
from p02_multigrain_timing_cachefix_v1.core.cache import utc

BASE = source_inputs.HERE
OUT = ROOT / "outputs/query_decomposition" / BASE.name
ARMS = ("historical", "reset", "flat", "chat")
DATASETS = ("hotpotqa", "2wiki", "musique")
UKEYS = ("prompt_tokens", "completion_tokens", "total_tokens")
COMPARISONS = (("flat", "reset"), ("chat", "reset"), ("chat", "flat"),
               ("reset", "historical"), ("flat", "historical"), ("chat", "historical"))


def read(path): return json.loads(Path(path).read_text(encoding="utf-8-sig"))
def rows(path): return [json.loads(s) for s in Path(path).read_text(encoding="utf-8-sig").splitlines() if s.strip()]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def ro(path): return sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True)
def rel(path): return str(Path(path).resolve().relative_to(ROOT)).replace("\\", "/")

import sqlite3


def summarize(records, dataset=None):
    selected = [r for r in records if dataset is None or r["dataset"] == dataset]
    arms = {}
    for arm in ARMS:
        found = [r for r in selected if r["arm"] == arm]; n = len(found)
        summed = {key: sum(r["usage"][key] for r in found) for key in UKEYS}
        arms[arm] = dict(n=n, F1=sum(r["F1"] for r in found) / n,
            EM=sum(r["EM"] for r in found) / n,
            native_full_correct=sum(r["F1"] == 1. or r["EM"] == 1. for r in found),
            logical_tokens_sum=summed, mean_tokens={key: summed[key] / n for key in UKEYS})
    for arm, value in arms.items():
        value["token_ratios"] = {reference: {key: value["mean_tokens"][key] / arms[reference]["mean_tokens"][key]
            for key in UKEYS} for reference in ("reset", "historical")}
    paired = {}
    for candidate, reference in COMPARISONS:
        left = {r["id"]: r for r in selected if r["arm"] == candidate}
        right = {r["id"]: r for r in selected if r["arm"] == reference}
        changes = [left[i]["F1"] - right[i]["F1"] for i in left]
        paired[candidate + "_minus_" + reference] = dict(n=len(changes),
            delta_F1=sum(changes) / len(changes), delta_EM=arms[candidate]["EM"] - arms[reference]["EM"],
            gain=sum(v > 0 for v in changes), tie=sum(v == 0 for v in changes), harm=sum(v < 0 for v in changes))
    return dict(arms=arms, paired_F1=paired)


def runtime_metadata(report):
    config = read(source_inputs.PACKAGE / "config.json"); model = config["generation"]["model"]
    with closing(ro(OUT / "checkpoint.sqlite3")) as db:
        db.execute("BEGIN")
        current = [dict(id=i, stage=s, payload=json.loads(p), encoded=p, status=t, result=json.loads(r) if r else {})
            for i, s, p, t, r in db.execute("SELECT id,stage,payload,status,result FROM requests")]
        retired = [dict(id=i, encoded=p, status=t, result=json.loads(r) if r else {})
            for i, p, t, r in db.execute("SELECT id,payload,status,result FROM retired_requests")]
    namespace = "p02_prompt_research_v1_20261022/" + str(OUT.resolve())
    with closing(ro(config["budget"]["ledger"])) as db:
        db.execute("BEGIN")
        charges = {i: dict(actual=a, reserved=r, status=s) for i, a, r, s in db.execute(
            "SELECT id,actual,reserved,status FROM charges WHERE namespace=?", (namespace,))}
    assert len(charges) == len(current) + len(retired)
    assert {r["id"] for r in current + retired} == charges.keys()
    caps, finishes, failures, guard_units = Counter(), Counter(), [], []
    for row in current:
        payload = row["payload"]; kind = row["stage"].split("/legacy/", 1)[1].split("/", 1)[0]
        cap = 64 if kind == "final" else 256 if kind == "rewrite" else 128
        assert kind in ("final", "rewrite", "answer", "sentence_format")
        assert payload["max_tokens"] == cap and payload["model"] == model
        units = sum(len(m["content"].encode("utf8")) + 64 for m in payload["messages"]) + cap
        assert units <= 128000
        guard_units.append(units); caps[kind + ":" + str(cap)] += 1
        receipt = {**row["result"], "status": row["status"]}; charge = charges[row["id"]]
        if row["status"] == "success":
            assert integrity(receipt, model) and receipt["finish_reason"] == "stop"
            assert receipt["answer"].strip() and not receipt.get("refusal")
            expected_cost = receipt["usage"]["prompt_tokens"] * .8e-6 + receipt["usage"]["completion_tokens"] * 2e-6
            assert abs(charge["actual"] - expected_cost) < 1e-10
            finishes[receipt["finish_reason"]] += 1
        else:
            assert row["status"] == "failed" and receipt.get("http_status") == 400 and charge["actual"] is None
            failures.append(dict(status="failed", http_status=400, usage_present=receipt.get("usage") is not None))
    for row in retired:
        assert row["status"] == "unknown" and not any_returned(row["result"])
        assert charges[row["id"]]["actual"] is None
    attempts = Counter(r["encoded"] for r in current + retired); maximum = max(attempts.values())
    assert maximum <= 5
    actual = sum(c["actual"] or 0. for c in charges.values())
    reserve = sum(c["reserved"] for c in charges.values() if c["actual"] is None)
    assert abs(actual - report["actual_new_returned_usage_CNY"]) < 1e-9
    assert abs(actual - 2.6786148) < 1e-9 and abs(reserve - .8173232) < 1e-9
    protocol = read(BASE / "PROTOCOL.frozen.json")
    preexec = read(ROOT / "analysis/p02_prompt_research_followup_20261022/SHARED_CONTEXT_FIXED90_PREEXECUTION_INDEPENDENT_REVIEW.json")
    for path, expected in {**protocol["pins"], **protocol["protected_holds"], **preexec["additional_review_bound_dependencies"]}.items():
        assert sha(ROOT / path) == expected, path
    assert read(ROOT / "experiments/query_decomposition/unified_rag_eval_v1_20261021/PLAN.json")["execution_approval"]["approved"] is False
    return dict(passed=True, successful_request_receipts=len(current) - len(failures),
        held_request_receipts=failures, retired_returnless_unknown=len(retired), maximum_attempts_per_exact_payload=maximum,
        requested_returned_model=model, success_finishes=dict(finishes), native_caps_by_request_kind=dict(caps),
        maximum_context_guard_units=max(guard_units), in_flight=0, pins_checked=len(protocol["pins"]),
        protected_holds_checked=len(protocol["protected_holds"]), additional_scorer_dependencies_checked=5,
        actual_estimated_CNY=actual, unresolved_reserved_CNY=reserve,
        scope="Receipt/model/three-usage/cap/attempt/ledger metadata only; not another full trajectory replay")


def main():
    report = read(OUT / "REPORT.json"); details = rows(OUT / "DETAILS.jsonl")
    old = {r["id"]: r for r in rows(source_inputs.CONTROL)}
    history = {r["id"]: r for r in rows(BASE / "HISTORICAL_REFERENCES90.local.jsonl")}
    refs = {r["id"]: r for r in rows(BASE / "references90.local.jsonl")}
    index = {(r["id"], r["arm"]): r for r in details}
    common = sorted(i for i in refs if all((i, arm) in index for arm in ARMS[1:]))
    counts = dict(Counter(refs[i]["dataset"] for i in common))
    assert len(common) == 89 and counts == dict(hotpotqa=30, **{"2wiki": 29}, musique=30)
    assert (report["quality_terminal"], report["held_technical_tasks"], report["not_started_tasks"]) == (269, 1, 0)
    scorers = {ds: metric(ds) for ds in DATASETS}; records = []
    for ident in common:
        ds = refs[ident]["dataset"]; assert history[ident]["historical_quality_available"]
        for arm in ARMS:
            value = old[ident] if arm == "historical" else index[ident, arm]
            stages = value["calls"] if arm == "historical" else value["stages"]
            native = scorers[ds](value["prediction"], refs[ident]) if value["status"] != "algorithm_failure" else dict(f1=0., em=0.)
            usage = {key: sum(s["usage"][key] for s in stages) for key in UKEYS}
            if arm != "historical":
                assert abs(native["f1"] - value["f1"]) < 1e-12 and native["em"] == value["em"]
                assert usage == value["full_flow_logical_usage"]
            records.append(dict(id=ident, dataset=ds, arm=arm, F1=native["f1"], EM=native["em"], usage=usage))
    audit = runtime_metadata(report)
    window = [r for r in report["per_query_new_paid_attribution"] if r["eligible_for_complete_paid_query_trend"]][-20:]
    rolling = sum(r["actual_new_returned_usage_CNY"] for r in window) / sum(r["historical_complete_query_CNY"] for r in window)
    value = dict(created_utc=utc(), common_query_n=89, dataset_counts=counts,
        common_ids_sha256=hashlib.sha256(json.dumps(common, separators=(",", ":")).encode()).hexdigest(),
        excluded_query_ids=sorted(set(refs) - set(common)),
        scope="Final exposed fixed90 development comparison, matched89 only; historical nonconcurrent, reset same-period control; not formal500.",
        missing_policy="One flat HTTP400 is technical held, not quality zero. Omit that query from all4 matched arms. Semantic pending facts do not filter native denominator.",
        overall=summarize(records), by_dataset={ds: summarize(records, ds) for ds in DATASETS},
        token_definition="Full-flow LOGICAL usage sums accepted rewrite,ordinaryQA,goalQA,optionalformatter,final. Shared receipts counted for each logical condition; actual paid-once and unknown liability separate.",
        execution=dict(planned=270, success=269, technical_held=1, not_started=0, held_task_ids=report["held_task_ids"],
            GPU_job="159533 TIMEOUT at4h; last local LLM flow completed using available retrieval; real scheduler closure saved; no successor"),
        namespace_paid_once=dict(actual_estimated_CNY=audit["actual_estimated_CNY"], unresolved_reserved_CNY=audit["unresolved_reserved_CNY"],
            scope="Entire270-condition namespace, including unmatched query and retired unknowns; not cold-run arm costs or invoice"),
        expense_alert=dict(latest_rolling20_ratio=rolling, complete_paid_query_window=len(window), threshold=1.5,
            user_already_notified=True, note="First-owner shared-prefix attribution is a same-period variant proxy; repeated rolling alerts not independent incidents"),
        runtime_metadata_audit=audit, scorer_factory_calls_once_per_dataset=3,
        sources={rel(p): sha(p) for p in [OUT / "REPORT.json", OUT / "DETAILS.jsonl", OUT / "PAIRED.jsonl", source_inputs.CONTROL,
            BASE / "references90.local.jsonl", BASE / "HISTORICAL_REFERENCES90.local.jsonl", OUT / "SCHEDULER_CLOSURE.json"]},
        interpretation_limits=["Native F1 gain/tie/harm are endpoint changes, not established factual repairs.",
            "Semantic pending facts do not reduce89 denominator.", "Historical-vs-reset may drift under nonconcurrent repetition.",
            "Full prior child prompts/readers/fewshots carried; do not generalize to every multi-turn/context design."],
        main_evaluation_remains_paused=True, candidate_promoted=False, new_API_SSH_GPU_requests=0)
    value["overall_aggregation"] = "Query-equal mean over89: HotpotQA30/89,2Wiki29/89,MuSiQue30/89. Not equal-dataset macro."
    value["equal_dataset_macro_native_secondary"] = {arm: {
        key: sum(value["by_dataset"][ds]["arms"][arm][key] for ds in DATASETS) / 3
        for key in ("F1", "EM")} for arm in ARMS}
    json_path, md_path = OUT / "ROOT_FINAL_RESULTS.json", OUT / "ROOT_FINAL_RESULTS.md"
    assert not json_path.exists() and not md_path.exists(), "Preserve prior versions"
    with json_path.open("x", encoding="utf8") as handle: json.dump(value, handle, ensure_ascii=False, indent=2)
    write_markdown(value, md_path)
    print(json.dumps(dict(JSON_sha256=sha(json_path), MD_sha256=sha(md_path), overall=value["overall"],
        by_dataset_native={ds: {a: {k: v[k] for k in ("n", "F1", "EM")} for a, v in s["arms"].items()}
            for ds, s in value["by_dataset"].items()}, runtime_metadata_audit=audit, latest_rolling20_ratio=rolling), ensure_ascii=True, indent=2))


def write_markdown(v, path):
    labels = dict(historical="历史P02（非同期）", reset="reset", flat="flat（单user拼接）", chat="chat（多轮messages）")
    lines = ["# 固定90题共享上下文：最终同题89题比较", "",
        "三个新条件共有89题可比：HotpotQA30、2Wiki29、MuSiQue30。全270条件已尝试，269成功；1条flat因HTTP400技术挂起，其原题从四组同题比较同时扣除，未计质量0。历史P02为非同期参考，reset为本轮控制。", "",
        "总表按89题逐题等权，数据集权重为30/89、29/89、30/89；不是三个数据集等权macro。", "",
        "| 条件 | F1 | EM | 平均输入tokens | 平均输出tokens | 平均总tokens |", "|---|---:|---:|---:|---:|---:|"]
    for arm, r in v["overall"]["arms"].items():
        u = r["mean_tokens"]
        lines.append(f"| {labels[arm]} | {100*r['F1']:.2f}% | {100*r['EM']:.2f}% | {u['prompt_tokens']:.1f} | {u['completion_tokens']:.1f} | {u['total_tokens']:.1f} |")
    lines += ["", "完整流程逻辑用量包括改写、普通QA、goal、可选formatter、final。精确共享请求在每个逻辑流程中计入，实际新增费用另列。", "",
        "| 条件 | 输入/reset | 输出/reset | 总量/reset | 输入/历史 | 输出/历史 | 总量/历史 |", "|---|---:|---:|---:|---:|---:|---:|"]
    for arm, r in v["overall"]["arms"].items():
        a, b = r["token_ratios"]["reset"], r["token_ratios"]["historical"]
        cells = [f"{ref[k]:.3f}x" for ref in (a, b) for k in UKEYS]
        lines.append("| " + labels[arm] + " | " + " | ".join(cells) + " |")
    lines += ["", "## 各数据集及配对变化", "", "| 数据集 | n | 历史F1/EM | reset F1/EM | flat F1/EM | chat F1/EM |", "|---|---:|---:|---:|---:|---:|"]
    for ds, s in v["by_dataset"].items():
        a = s["arms"]; cells = [" / ".join(f"{100*a[arm][k]:.2f}%" for k in ("F1", "EM")) for arm in ARMS]
        lines.append(f"| {ds} | {a['reset']['n']} | " + " | ".join(cells) + " |")
    lines += ["", "配对增/平/减按逐题native F1计算，不等同于事实修复。", "", "| 比较 | 全部89 | HotpotQA30 | 2Wiki29 | MuSiQue30 |", "|---|---:|---:|---:|---:|"]
    for candidate, reference in COMPARISONS:
        key = candidate + "_minus_" + reference
        summaries = [v["overall"], *(v["by_dataset"][ds] for ds in DATASETS)]
        cells = [" / ".join(str(s["paired_F1"][key][k]) for k in ("gain", "tie", "harm")) for s in summaries]
        lines.append("| " + candidate + " vs " + reference + " | " + " | ".join(cells) + " |")
    paid, audit = v["namespace_paid_once"], v["runtime_metadata_audit"]
    lines += ["", "flat和chat在共同89题上均低于同期reset，且输入用量增加。本版本未验证共享上下文的整体质量收益；不能外推为所有多轮设计都无效。历史与reset差异属于非同期重复差异。", "",
        f"整个270条件namespace新增用量估费{paid['actual_estimated_CNY']:.7f}元；另保留{paid['unresolved_reserved_CNY']:.7f}元未决预留，后者不是已确认支出。最近20个合格完整付费query费用比为{v['expense_alert']['latest_rolling20_ratio']:.4f}，超过1.5阈值，用户已获提醒。逻辑tokens与首次提交归属的实际费用不可混为一项。", "",
        "GPU159533达到4小时TIMEOUT；最后一个本地LLM流程利用已有检索材料完成。真实scheduler closure已留存，未创建后继GPU作业。主评估仍暂停，不晋级候选。", "",
        f"运行元数据复核：{audit['successful_request_receipts']}成功请求均为指定模型、完整三项usage及stop结束；1条HTTP400保留技术挂起。44条无返回unknown及其预留保留；相同payload最多{audit['maximum_attempts_per_exact_payload']}次技术attempt。QA/formatter128、rewrite256、final64及312pins/3暂停标记/5评分依赖匹配。此处是元数据复核，不声称新完成全轨迹回放。", "",
        "13题39条文本差异候选已完成方法遮蔽首轮复核；事实待核工作不改变native89题分母。native词面增益不能直接解释为确定的事实或因果修复。", "",
        "来源：[原始REPORT](REPORT.json)、[DETAILS](DETAILS.jsonl)、[本报告JSON](ROOT_FINAL_RESULTS.json)。原中期快照与报告均保留。", "",
        "次要口径（三集等权macro，仍限同一89题）：" + "；".join(
            f"{labels[arm]} F1/EM={100*v['equal_dataset_macro_native_secondary'][arm]['F1']:.2f}%/{100*v['equal_dataset_macro_native_secondary'][arm]['EM']:.2f}%"
            for arm in ARMS) + "。不替换上方逐题等权主表。"]
    with path.open("x", encoding="utf8") as handle: handle.write("\n".join(lines) + "\n")


if __name__ == "__main__": main()
