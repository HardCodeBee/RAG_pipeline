"""Prepared independent directory-attribute helper; no network without exact AUTH.

Only forces GNU-stat attributes on the fixed owned responses directory. It never
reads response bodies, changes the controller/worker, or allocates a GPU.
"""
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import os
import shlex
import socket
import time

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve()
OUT = ROOT / "outputs/query_decomposition/p02_local_cot_fixed90_v1_20261022"
PROTOCOL = "222de9cd4f7dca8509ab6bf1e391a27634536d2cf0b0cdf0f0e42e9dcd256702"
DIRECTORY = "/home/projects/u7830488/p02_prompt_small_evals_20261022/cot90_222de9cd4f7dca85"
JOB, USER = "161325", "u7830488"
HOST, ADDRESS, NODE = "cluster1.comp.anu.edu.au", "150.203.213.5", "cluster1-login-1"
HOST_KEY = "0dc62a1133b5b76310fff5bcaa77e9d99903217240a6d61eb7a5fb485ffcc58b"
CLOCK = OUT / "ALLOCATION_CLOCK.json"
BASE_AUTH = ROOT / "analysis/p02_prompt_research_followup_20261022/COT90_PRIORITY_EXECUTION_AUTHORIZATION.json"
PROBE = OUT / "READONLY_DIRECTORY_FORCE_STAT_DELAYED_PROBE.json"


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text(encoding="utf-8-sig"))
def utc(): return datetime.now(timezone.utc).isoformat()


# Executed only by --run, in one foreground SSH channel; no remote files created.
REMOTE = r'''
import hashlib,json,os,select,shutil,socket,subprocess,sys,time
from pathlib import Path
from datetime import datetime,timezone
CFG=__CONFIG__
class Stop(Exception): pass
FS_READ="""import json,sys
from pathlib import Path
p=Path(sys.argv[1]);mode=sys.argv[2]
v={'markers':[n for n in ('FINISHED.json','STOP_REQUESTED','WORKER_ERROR.json') if (p/n).exists()]}
if mode=='preflight':
 c=json.loads((p/'REMOTE_JOB.frozen.json').read_text());r=json.loads((p/'READY.json').read_text())
 v.update(responses_is_dir=(p/'responses').is_dir(),directory=c['remote_directory'],protocol=c['protocol_sha256'],ready_job=r['job_id'],ready_protocol=r['protocol_sha256'],ready_status=r['status'])
print(json.dumps(v))
"""
def emit(event,**fields):
 print(json.dumps(dict(event=event,utc=datetime.now(timezone.utc).isoformat(),**fields)),flush=True)
def expiration(now,last_ping,deadline,parent_alive=True,eof=False):
 if eof:return 'stdin_eof'
 if not parent_alive:return 'remote_parent_exited'
 if now>=deadline:return 'hard_deadline'
 if now-last_ping>=15:return 'stdin_lease_expired'
 return None
def queue_fields(text):
 lines=[x.split('|') for x in text.splitlines() if x.strip()]
 if len(lines)!=1 or lines[0] != [CFG['job'],'RUNNING',CFG['user'],CFG['directory'],'p02-cot90']:
  raise Stop('owned_job_not_running_or_identity_mismatch')
 return lines[0]
def child_command(args,guard):
 guard();started=time.monotonic()
 proc=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 try:
  while proc.poll() is None:
   guard()
   if time.monotonic()-started>=5:raise Stop('readonly_command_timeout')
   time.sleep(.05)
  guard();out,err=proc.communicate()
  if proc.returncode:
   emit('readonly_command_nonzero',program=Path(args[0]).name,returncode=proc.returncode,
        stderr_sha256=hashlib.sha256(err).hexdigest())
   raise Stop('readonly_command_nonzero')
  return out.decode('utf8')
 except BaseException:
  if proc.poll() is None:
   proc.kill()
   emit('command_kill_requested',program=Path(args[0]).name,pid=proc.pid,
        kernel_exit_may_be_delayed=proc.poll() is None)
  raise
def main():
 start=time.monotonic();parent=os.getppid();last_ping=start;buffer=b'';count=0;last_hash=None
 remaining=CFG['allocation_expires_epoch']-time.time()
 deadline=start+max(0,min(21600,CFG['maximum_seconds'],remaining))
 os.set_blocking(sys.stdin.fileno(),False)
 def guard():
  nonlocal last_ping,buffer
  while select.select([sys.stdin],[],[],0)[0]:
   chunk=os.read(sys.stdin.fileno(),4096)
   if not chunk:raise Stop('stdin_eof')
   buffer+=chunk
   if len(buffer)>4096:raise Stop('bad_control_input')
   while b'\n' in buffer:
    line,buffer=buffer.split(b'\n',1)
    if line==b'STOP':raise Stop('stdin_stop')
    if line!=b'PING':raise Stop('bad_control_input')
    last_ping=time.monotonic()
  reason=expiration(time.monotonic(),last_ping,deadline,os.getppid()==parent)
  if reason:raise Stop(reason)
 def command(args):
  return child_command(args,guard)
 try:
  if socket.gethostname()!=CFG['node']:raise Stop('unexpected_login_hostname')
  stat=shutil.which('stat');squeue=shutil.which('squeue');scontrol=shutil.which('scontrol')
  if not all((stat,squeue,scontrol)):raise Stop('missing_readonly_program')
  version=command([stat,'--version']);help_text=command([stat,'--help'])
  if not version.startswith('stat (GNU coreutils)') or '--cached' not in help_text or 'never' not in help_text:
   raise Stop('gnu_cached_never_unavailable')
  folder=Path(CFG['directory']);responses=folder/'responses'
  metadata=json.loads(command([sys.executable,'-B','-c',FS_READ,str(folder),'preflight']))
  if not metadata['responses_is_dir']:raise Stop('responses_directory_missing')
  if metadata['directory']!=CFG['directory'] or metadata['protocol']!=CFG['protocol']:
   raise Stop('worker_config_identity_mismatch')
  if metadata['ready_job']!=CFG['job'] or metadata['ready_protocol']!=CFG['protocol'] or metadata['ready_status']!='ready':
   raise Stop('worker_ready_identity_mismatch')
  if metadata['markers']:raise Stop('owned_worker_stop_marker')
  queue=['-h','-j',CFG['job'],'-o','%i|%T|%u|%Z|%j']
  queue_fields(command([squeue,*queue]))
  detail=command([scontrol,'show','job','-o',CFG['job']])
  parts=dict(x.split('=',1) for x in detail.split() if '=' in x)
  if parts.get('JobId')!=CFG['job'] or parts.get('UserId','').split('(')[0]!=CFG['user'] or parts.get('WorkDir')!=CFG['directory'] or parts.get('JobName')!='p02-cot90':
   raise Stop('scheduler_owner_or_path_mismatch')
  emit('started',job=CFG['job'],hostname=socket.gethostname(),protocol=CFG['protocol'],
       GNU_version=version.splitlines()[0],maximum_seconds=deadline-start,interval_seconds=2,
       lifecycle_check_seconds=30,lease_seconds=15)
  next_beat=time.monotonic()+30;next_lifecycle=time.monotonic()+30
  while True:
   tick=time.monotonic();guard()
   if time.monotonic()>=next_lifecycle:
    metadata=json.loads(command([sys.executable,'-B','-c',FS_READ,str(folder),'markers']))
    if metadata['markers']:raise Stop('owned_worker_stop_marker')
    queue_fields(command([squeue,*queue]));next_lifecycle=time.monotonic()+30
   value=command([stat,'--cached=never','--format=%y|%z|%i','--',str(responses)])
   count+=1;last_hash=hashlib.sha256(value.encode()).hexdigest()
   if time.monotonic()>=next_beat:
    emit('heartbeat',successful_directory_stats=count,last_returncode=0,attributes_sha256=last_hash)
    next_beat=time.monotonic()+30
   while time.monotonic()-tick<2:
    guard();time.sleep(.05)
 except Stop as exc:
  emit('stopped',reason=str(exc),successful_directory_stats=count,last_attributes_sha256=last_hash)
  return 0
 except BaseException as exc:
  emit('failed',error_type=type(exc).__name__,successful_directory_stats=count)
  return 1
if __name__=='__main__':sys.exit(main())
'''


def plan():
    job = read(OUT / "REMOTE_JOB_ID.json"); clock = read(CLOCK)
    assert job == dict(job_id=JOB, directory=DIRECTORY, protocol_sha256=PROTOCOL)
    assert clock["job_time_limit_seconds"] == 21600
    expires = datetime.fromisoformat(clock["submission_started_utc"]).timestamp() + 21600
    return dict(job=JOB, user=USER, protocol=PROTOCOL, directory=DIRECTORY, node=NODE,
                allocation_expires_epoch=expires, maximum_seconds=21600)


def remote_code(): return REMOTE.replace("__CONFIG__", repr(plan()))


def authorization_template():
    return dict(approved=False, purpose="cot90_directory_visibility_auxiliary", script_sha256=sha(HERE),
                remote_code_sha256=hashlib.sha256(remote_code().encode()).hexdigest(), job_id=JOB,
                protocol_sha256=PROTOCOL, directory=DIRECTORY, hostname=NODE, address=ADDRESS,
                clock_sha256=sha(CLOCK), base_authorization_sha256=sha(BASE_AUTH),
                supporting_probe_sha256=sha(PROBE), supporting_probe_accepted=False,
                allocation_expires_epoch=plan()["allocation_expires_epoch"], maximum_seconds=21600,
                query_or_model_changes=False, new_retrieval_or_GPU_jobs=False)


def authorized(path):
    actual = read(path); expected = authorization_template()
    for key,value in expected.items():
        if key not in ("approved", "supporting_probe_accepted"): assert actual.get(key) == value, key
    assert actual.get("approved") is True and actual.get("supporting_probe_accepted") is True
    assert read(BASE_AUTH).get("approved") is True
    assert plan()["allocation_expires_epoch"] > time.time(), "Original allocation deadline passed"
    return actual


def parent_check():
    """Bind automatic remote PING to this client's original launcher lifetime."""
    pid = os.getppid()
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes
        api = ctypes.WinDLL("kernel32", use_last_error=True)
        api.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
        api.OpenProcess.restype = wintypes.HANDLE
        api.WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
        api.CloseHandle.argtypes = (wintypes.HANDLE,)
        handle = api.OpenProcess(0x00100000, False, pid)
        assert handle, "Cannot monitor original parent"
        return lambda: api.WaitForSingleObject(handle, 0) == 0x102, lambda: api.CloseHandle(handle)
    def alive():
        try: os.kill(pid, 0); return os.getppid() == pid
        except OSError: return False
    return alive, lambda: None


def run(auth_path):
    auth = authorized(auth_path)  # Always before getpass, SSH imports or network.
    import getpass
    import paramiko
    assert "RAG_EVAL_REMOTE_PASSWORD" not in os.environ, "Use ephemeral getpass"
    parent_alive, close_parent = parent_check()
    assert parent_alive()
    logdir = OUT / "directory_visibility_auxiliary"
    logdir.mkdir(exist_ok=True)
    stem = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S_%f") + "_" + str(os.getpid())
    destination = logdir / (stem + ".jsonl")
    client = paramiko.SSHClient(); connection = channel = None; password = None; code = None
    seen, stopped, reason = 0, False, "local_exception"
    with destination.open("x", encoding="utf8") as log:
        def record(event, **fields):
            value=dict(utc=utc(),event=event,**fields)
            log.write(json.dumps(value,ensure_ascii=False)+"\n"); log.flush()
            print(json.dumps(value,ensure_ascii=False),flush=True)
        record("local_started",script_sha256=sha(HERE),authorization_sha256=sha(auth_path),
               remote_code_sha256=auth["remote_code_sha256"],job_id=JOB,allocation_expires_epoch=plan()["allocation_expires_epoch"])
        try:
            client.load_system_host_keys(); client.set_missing_host_key_policy(paramiko.RejectPolicy())
            password=getpass.getpass("Remote password: ")
            connection=socket.create_connection((ADDRESS,22),timeout=15)
            client.connect(HOST,username=USER,password=password,sock=connection,look_for_keys=False,
                           allow_agent=False,timeout=15,auth_timeout=20,banner_timeout=15)
            password=None
            transport=client.get_transport()
            assert hashlib.sha256(transport.get_remote_server_key().asbytes()).hexdigest()==HOST_KEY
            authorized(auth_path); assert parent_alive()
            channel=transport.open_session(timeout=5); channel.settimeout(5)
            channel.exec_command("exec python3 -B -u -c "+shlex.quote(remote_code()))
            next_ping=0;buffer=b'';deadline=plan()["allocation_expires_epoch"]
            while True:
                if not parent_alive(): reason="local_parent_exited";break
                if time.time()>=deadline: reason="allocation_deadline";break
                if time.monotonic()>=next_ping:
                    channel.sendall(b"PING\n");next_ping=time.monotonic()+5
                if channel.recv_ready():
                    chunk=channel.recv(65536)
                    if not chunk:reason="channel_eof";break
                    buffer+=chunk
                    while b'\n' in buffer:
                        line,buffer=buffer.split(b'\n',1)
                        row=json.loads(line);seen+=1;record("remote_metadata",metadata=row)
                        if row.get("event") in ("stopped","failed"): stopped=True
                if channel.recv_stderr_ready():
                    error=channel.recv_stderr(8192)
                    record("remote_stderr_hash",sha256=hashlib.sha256(error).hexdigest(),bytes=len(error))
                if channel.exit_status_ready() and not channel.recv_ready():
                    code=channel.recv_exit_status();reason="remote_exited";break
                time.sleep(.1)
        except KeyboardInterrupt: reason="local_interrupted"
        except Exception as exc: record("local_error",error_type=type(exc).__name__)
        finally:
            password=None
            if channel is not None:
                try:channel.sendall(b"STOP\n");channel.shutdown_write()
                except Exception:pass
                channel.close()
            client.close()
            if connection is not None:connection.close()
            close_parent()
            record("local_stopped",reason=reason,remote_returncode=code,remote_records=seen,
                   remote_terminal_record_seen=stopped,reconnects=0,response_bodies_read=0)
    print(json.dumps(dict(log=str(destination),sha256=sha(destination)),ensure_ascii=False),flush=True)


def self_test():
    code=remote_code();compile(code,"remote_directory_visibility_auxiliary","exec")
    ns={"__name__":"offline_contracts"};exec(code,ns)
    expected=f"{JOB}|RUNNING|{USER}|{DIRECTORY}|p02-cot90\n"
    assert ns["queue_fields"](expected)[0]==JOB
    for bad in (expected.replace(USER,"other"),expected.replace(DIRECTORY,"/other"),expected.replace("RUNNING","COMPLETED"),""):
        try:ns["queue_fields"](bad)
        except ns["Stop"]:pass
        else:raise AssertionError("foreign/closed scheduler accepted")
    expiry=ns["expiration"]
    assert expiry(14.9,0,100) is None and expiry(15,0,100)=="stdin_lease_expired"
    assert expiry(10,9,10)=="hard_deadline" and expiry(1,0,10,False)=="remote_parent_exited"
    assert expiry(1,0,10,eof=True)=="stdin_eof"
    assert "--cached=never" in code and "--format=%y|%z|%i" in code
    from types import SimpleNamespace
    class Clock:
        def __init__(self): self.now=0
        def monotonic(self): return self.now
        def sleep(self,value): self.now+=value
    for boundary in ("lease", "command_timeout"):
        clock=Clock();calls=[]
        class Busy:
            pid=123;returncode=None;killed=False
            def __init__(self,*args,**kwargs): calls.append(self)
            def poll(self): return None
            def kill(self): self.killed=True
        ns["time"]=clock;ns["emit"]=lambda *a,**k:None
        ns["subprocess"]=SimpleNamespace(Popen=Busy,DEVNULL=-3,PIPE=-1)
        def guard():
            if boundary=="lease" and clock.now>=1: raise ns["Stop"]("stdin_lease_expired")
        try:ns["child_command"](["stat","fixed-directory"],guard)
        except ns["Stop"] as exc:
            assert str(exc)==("stdin_lease_expired" if boundary=="lease" else "readonly_command_timeout")
        else:raise AssertionError("busy command did not terminate")
        assert len(calls)==1 and calls[0].killed
    assert "sys.executable,'-B'" in code and "next_lifecycle=time.monotonic()+30" in code
    print(json.dumps(dict(passed=True,contracts=10,network_calls=0,services_started=0,
                         remote_code_sha256=hashlib.sha256(code.encode()).hexdigest())))


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group()
    group.add_argument("--run",action="store_true");group.add_argument("--self-test",action="store_true")
    group.add_argument("--dry-run",action="store_true")
    parser.add_argument("--authorization",type=Path);args=parser.parse_args()
    if args.run:
        if args.authorization is None:parser.error("--run requires exact independent --authorization")
        run(args.authorization)
    elif args.self_test:self_test()
    else:print(json.dumps(dict(prepared_only=True,authorization_template=authorization_template()),indent=2))
