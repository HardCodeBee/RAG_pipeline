"""Record an operational, condition-boundary pause; no method or score change."""
from datetime import datetime, timezone
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from experiments.query_decomposition.p02_local_cot_fixed90_v1_20261022 import preparation as p


def main():
    p.check()
    oldout = ROOT / "outputs/query_decomposition" / p.REFERENCE.name
    clock = oldout / "continuations/recovery01/ALLOCATION_CLOCK.json"
    destination = oldout / "pauses/cot90_priority_20261022/ALLOCATION_CLOCK.original.json"
    assert p.sha(clock) == "c898b49a0a20ba7618e4731e2671549bd0d9f567eb7275ecfb8c7f9c7b5a459d"
    assert not destination.exists() and destination.resolve().is_relative_to(oldout.resolve())
    assert p.read(oldout / "ENGINEERING_GATE.json")["passed"] is True
    job = p.read(oldout / "continuations/recovery01/REMOTE_JOB_ID.json")
    assert job["job_id"] == "161046"
    key = "P02_COT90_PRIORITY_CONDITION_BOUNDARY_PAUSE_20261022"
    decisions = p.PLAN / "DECISIONS.jsonl"
    assert not any(row.get("id") == key for row in p.rows(decisions))
    value = dict(id=key, approved=True, utc=datetime.now(timezone.utc).isoformat(),
        authority="User requests autonomous completion of CoT90 and stage attribution; standing autonomous small-research approval",
        experiment=p.HERE.name, protocol_sha256=p.sha(p.PROTOCOL),
        reference_experiment=p.REFERENCE.name, reference_protocol_sha256=p.sha(p.REFERENCE / "PROTOCOL.frozen.json"),
        old_job_id=job["job_id"], old_remote_directory=job["directory"],
        allowed_actions=["cancel metadata-only old CoT waiting PTY", "atomically preserve and withdraw the reference continuation dispatch clock at the exact paths", "allow current reference condition to finish before next dispatch boundary abort", "capture real worker and scheduler closure", "snapshot preserved partial reference state"],
        clock_source=p.rel(clock), clock_destination=p.rel(destination), clock_sha256=p.sha(clock),
        boundary_mechanism="Clock is consumed only by can_start_condition outside the condition handler. Its absence intentionally raises FileNotFoundError before dispatch; finally closes the owned worker. This is an explicit operational boundary abort, not a native graceful pause or model failure.",
        maximum_additional_complete_conditions=1,
        no_quality_or_predictions_used=True, no_active_request_killed=True,
        no_clock_timestamp_fabrication=True, preserve_all_cache_receipts_and_unknown_liabilities=True,
        no_checkpoint_ledger_or_held_edits=True, no_frozen_scientific_source_edits=True,
        main_evaluation_resumed=False, new_GPU_jobs=0, new_LLM_requests_by_pause_tool=0,
        cot_restart_requires_separate_exact_wrapper_review_and_authorization=True)
    target = Path(__file__).with_name("COT90_PRIORITY_PAUSE_AUTHORIZATION.json")
    assert not target.exists()
    p.atomic_json(target, value)
    with decisions.open("a", encoding="utf8") as stream:
        stream.write(json.dumps(dict(value, authorization_sha256=p.sha(target)), ensure_ascii=False) + "\n")
    print(json.dumps(dict(approved=True, authorization_path=p.rel(target), sha256=p.sha(target)), ensure_ascii=True))


if __name__ == "__main__": main()
