# CoT90 HotpotQA逐题复核

覆盖全部3条N128→R256计分变化和2条最终文本变化但计分持平的题。复核已知原生分数，属于非盲的冻结轨迹证据分析；未调用评审模型、未重跑RAG、未联网。逐题证据和原始路径见同名JSONL。

3条下降分别为：

- Kieft's War：正确的Pound Ridge段落已在候选中、却被Top10合并丢掉；F/R随后把goal检索限定改为Kieft下令袭击，丢掉最高伤亡条件，goal错误人物传给final。N128也缺该reader证据，但goal生成了正确人物。不是普通回答由明确正确变明确错误的简单链。
- Le Rêve：最终同一个演出O，Unicode弯引号造成原生F1/EM从1变0；这是词面计分下降，不能称事实退步。原生计分未改。
- Essence与Alt for Damerne：分解混淆印量与出版频率。R的Support保留正确weekly事实并区分issues/copies，但Answer只剩弃答；goal/final仍直接看到weekly/monthly材料，却未纠正历史任务偏移。合理的局部弃答与最终求解信息流失并存。

2条持平文本变化分别是Emma Gramatica的出生地指代未解析，以及Tabernaemontana/Crinum没有识别共同上位类别plants；均无最终计分改善。第一题不把缺少同名town材料当作不存在的证据，保留未核改名年份说明。

这些是多环节共同变化的轨迹定位，不是单独干预后确定的唯一因果贡献。没有证据支持本轮普通CoT在HotpotQA带来最终F1收益。
