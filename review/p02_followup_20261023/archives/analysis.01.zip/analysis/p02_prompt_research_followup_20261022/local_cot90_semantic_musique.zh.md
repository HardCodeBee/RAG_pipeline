# 普通子问CoT完整90题：MuSiQue变化案例复核

覆盖N128→R256所有F1或EM变化的7题，以及另2题final文本变化但分数持平的补查；共9题、36条完整流程、128个普通/goal节点。四臂raw、Support、解析Answer、accepted、后继改写、候选/reader、goal及final/root已检查。全部9题四臂都成功、未触发formatter；此处没有技术缺失或算法终止，也未改原生分数/分母。MuSiQue另一个F256技术held不在这些N/R变化题中，仍保留在全批技术缺失记录。

这是模型协助的证据复核，不是独立人工金标准，也不是完全盲审。初读将四臂按每题哈希置换为A/B/C/D，但定位INDEX时已看到部分分数方向；此前也参与过模板和相关已曝光事实审阅。先形成逐题事实判断，再合并方法和原生分数。原始导出未修改；[逐题JSONL](local_cot90_semantic_musique.jsonl)保留全部四臂文本、source SHA、21处逐字证据定位及待核项。

7题为2升5降。两次升分中，一次只是final答案长度/词面变化；一次有真实所问信息改善，但变化首次出现在goal保留河口地点，普通桥接事实没有实质改善。五次降分中，不能把五题都解释成“正确最终答案被CoT改错”：至少两个N原先终点也错，Clara身份关系待核，Nanny须另计goal的婚姻时态问题。

| 题号（MuSiQue） | N128→R256 F1 / EM | 事实与信息流证据 | 保守归因 |
|---|---|---|---|
| 2hop__289517_139339（After Hours） | .1905→0 / 0→0 | 四臂保留Griffin Dunne；goal改写、reader完全相同。reader rank2明确Duke of Groove的Academy提名，goal却加入“因After Hours角色”限定并断言未获提名。R final改弃答。 | 两者均未答对，下降含错误否定句的词面分消失；没有证实正确最终事实被改坏。 |
| 2hop__104095_40501（Clara Peeters） | 1→0 / 1→0 | N把Dutch Republic活动地断言为公民身份；F/R合理区分后弃答。N据实体化改写取得75,000–100,000；F/R未取得同一数量段。冻结传记明确生平文献不确定。 | 参考路径桥接丢失；具体公民身份待核，不能用满分给N断言背书。 |
| 2hop__557411_652060（Nanny Reunion） | 1→0 / 1→0 | N的special creator Fran Drescher有特定节目credit支持；F/R reader只有在其家举行/主演资料，材料范围弃答合理，但creator实体不再进入后继。goal未恢复。 | 真实creator及参考历史配偶实体丢失。N goal“is married to Peter”另与本地数据集离婚材料冲突，不能称整条N QA全正确。 |
| 3hop1__857_846_7770（Yongle/Nanjing） | .7368→.8750 / 0→0 | F/R首问忽略reader rank4的edict→Karmapa，误要求edict由Yongle颁发；次问独立检索恢复Nanjing。四臂goal reader及goal答案逐字相同，final只是完整句变方位短语。 | 仅词面增分；不是事实修复。反而局部首问有过度弃答，但被下游恢复。 |
| 3hop1__635099_131926_89261（Mississippi） | .8→1 / 0→1 | 普通两步均正确给Minneapolis→Mississippi；各阶段reader及goal改写相同。goal reader已有Delta。R goal才明确河口地点Delta，N只说流入Gulf，final错抽河流名。F256也未改善。 | 有真实最终所问属性改善；位置是goal事实保留＋final抽取，不能声称普通CoT已修复关系或是唯一原因。 |
| 3hop1__702699_792411_51423（Jane Siberry） | 1→0 / 1→0 | N的Toronto出生地事实真实但当前reader未写；F/R合理弃答后不再向goal改写传Toronto。N goal reader rank8有Casa Loma；F/R候选、reader和root均无该城堡，未独立恢复。 | 可明确“正确final事实→未回答”；轨迹支持真桥接信息丢失后检索覆盖下降，仍非唯一因果证明。 |
| 4hop3__129456_29339_508306_70744（大学比较） | .5714→0 / 0→0 | N/F错绑Kansas；Edwards初选州应为South Carolina，raw第4问省略此约束且rewrite还丢without。R拒绝Kansas，但Support过度声称无非Georgia州立大学。所有goal reader已含Clemson5/USC10比较表（N rank4、R rank8），仍未补足。 | N的部分分来自错误University of Kansas的词面重叠。R局部拒绝坏绑定有价值，但goal材料使用仍失败，两者均未给出正确终点。 |

N128与N256在以上7题的最终事实/分数一致。F256在Clara、Nanny、Jane同样弃答，在Yongle同样有短语增分；只有R256在Mississippi补出了Delta。因此不能把所有N→R差异归为“多128 tokens”或“必要组合操作”本身；格式、示例、证据约束、措辞与后续生成也在变化。Support并未直接进入历史，能传给下游的是accepted Answer。

补查的两道持平题也不是“没有变化”：

| 题号 | N128→R256 | 关键证据与限制 |
|---|---|---|
| 3hop2__326964_265410_7713（Anhua Gao/Yaxing） | F1=EM均0；never叙述→弃答 | 普通地点都正确，R只增加省/国粒度。N/R goal reader实际含“Nanjing曾为历史Yangzhou区域首府约400年”的段落（R rank10），却按现代城市关系否定；F中该段只在候选rank7、被merge排除。须区分时代/行政层级与候选丢失，不归为普通实体识别未成功。 |
| 4hop3__524186_219173_548463_72134（Poor Boob/Springfield） | F1=EM均0；Never→弃答 | writer reader明确列三名作者，N/F保留；R强加唯一作者和未来出生地要求，accepted丢掉名字，后继不再检到Mayo的Illinois出生段。真实局部信息损害被终点0分掩盖。另公司源明确Springfield, Ohio，参考1839对应另一Springfield/Illinois路径；不能为对gold删Ohio，最终唯一语义正解保留源冲突待核。 |

必须保留三个区别：合理弃答可以事实正确但信息不足；错误答案的部分F1不表示正确事实；goal/root可独立恢复或忽略已到位证据，最早ordinary差异不等于唯一原因。这组变化题是按终点变化选出的案例集合，不能据此估计全MuSiQue或全部90题的失效发生率，也不改变完整N/R原生分母。

具体缺证事实核验：After Hours的无提名断言还被[金球奖官方记录](https://goldenglobes.com/person/griffin-dunne/)直接反驳。Clara身份待核依据[Prado史料说明](https://www.museodelprado.es/en/the-collection/artist/clara-peeters/c5fd7572-797d-4e5b-a20b-333b47099012)，其对生平不确定性的说明不证明她“从未”具某公民身份。Jane出生地以[Jason Ankeny传记](https://www.allmusic.com/artist/jane-siberry-mn0000208303/biography)的具体Toronto记录补核（本轮搜索索引可见，直接open为403）。Nanny核的是[reunion special本页的Creator credit](https://en.wikipedia.org/wiki/The_Nanny_Reunion%3A_A_Nosh_to_Remember)，不是原剧creator；沿用此前已锁历史页核验，并本轮以特定special页面和同源DBpedia交叉检查，未伪称独立史料或本轮成功读取固定oldid全文。
