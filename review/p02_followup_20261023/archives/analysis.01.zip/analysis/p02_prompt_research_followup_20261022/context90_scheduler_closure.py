"""Operational supplement for context90 job159533 TIMEOUT; no frozen files change.

No API, SSH, GPU, credential or writable checkpoint is opened by status/auth-template.
The stage/full90 entrypoints retain their own exact authorization and all guards.
"""
from contextlib import closing
from datetime import datetime
from pathlib import Path
import argparse
import hashlib
import json
import sqlite3
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "src"))
CONTEXT = ROOT / "experiments/query_decomposition/p02_shared_context_fixed90_v1_20261022"
OUTPUT = ROOT / "outputs/query_decomposition/p02_shared_context_fixed90_v1_20261022"
PLAN = ROOT / "experiments/query_decomposition/unified_rag_eval_v1_20261021"
AUTHORIZATION = HERE / "CONTEXT90_SCHEDULER_CLOSURE_AUTHORIZATION.json"
RECEIPT = OUTPUT / "SCHEDULER_CLOSURE.json"
JOB = "159533"
CONTEXT_SHA = "0630afaf6e7b992675085022189e93b9de3af6cdbec9b1542c88856fe9b0630e"
DIRECTORY = "/home/projects/u7830488/p02_prompt_small_evals_20261022/context90_0630afaf6e7b9926"
TARGETS = dict(stage="p02_reference_binding_priority_probe_v1_20261022",
               full90="p02_reference_binding_priority_fixed90_v1_20261022")
COMMANDS = dict(squeue=["squeue", "-h", "-j", JOB, "-o", "%i|%T"],
    sacct=["sacct", "-n", "-P", "-j", JOB, "--format=JobIDRaw,JobName,State,ExitCode,Start,End,Timelimit,NodeList"],
    scontrol=["scontrol", "show", "job", "-o", JOB])


def read(path): return json.loads(Path(path).read_text(encoding="utf-8-sig"))
def rows(path): return [json.loads(line) for line in Path(path).read_text(encoding="utf-8-sig").splitlines() if line.strip()]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def rel(path): return str(Path(path).resolve().relative_to(ROOT)).replace("\\", "/")


def context_pins():
    return {rel(path): sha(path) for path in (CONTEXT / "PROTOCOL.frozen.json", CONTEXT / "INPUTS90.jsonl",
        CONTEXT / "ORDER270.jsonl", OUTPUT / "REMOTE_JOB_ID.json", OUTPUT / "REMOTE_GPU_READY.json")}


def authorization_template():
    return dict(approved=False, decision_id="CONTEXT90_SCHEDULER_TIMEOUT_CLOSURE_SUPPLEMENT_20261022",
        scope="Operational predecessor closure only; no scientific protocol/cache/retry/fee change or FINISHED fabrication",
        script_sha256=sha(__file__), scheduler_receipt_sha256=sha(RECEIPT),
        expected_job_id=JOB, expected_context_protocol_sha256=CONTEXT_SHA, context_pins=context_pins(),
        targets={name: sha(ROOT / "experiments/query_decomposition" / folder / "PROTOCOL.frozen.json") for name, folder in TARGETS.items()},
        main_evaluation_resumed=False, historical_unknown_reissues=False, new_GPU_submission_by_supplement=False)


def authorized(target):
    assert target in TARGETS
    auth = read(AUTHORIZATION)
    assert auth.get("approved") is True
    assert auth["script_sha256"] == sha(__file__) and auth["scheduler_receipt_sha256"] == sha(RECEIPT)
    assert auth["expected_job_id"] == JOB and auth["expected_context_protocol_sha256"] == CONTEXT_SHA
    assert auth["context_pins"] == context_pins()
    assert auth["targets"][target] == sha(ROOT / "experiments/query_decomposition" / TARGETS[target] / "PROTOCOL.frozen.json")
    assert auth.get("main_evaluation_resumed") is False and auth.get("historical_unknown_reissues") is False
    assert auth.get("new_GPU_submission_by_supplement") is False
    decision = next(row for row in rows(PLAN / "DECISIONS.jsonl") if row.get("id") == auth["decision_id"])
    assert decision.get("approved") is True
    assert decision.get("script_sha256") == auth["script_sha256"]
    assert decision.get("scheduler_receipt_sha256") == auth["scheduler_receipt_sha256"]
    assert read(PLAN / "PLAN.json")["execution_approval"]["approved"] is False
    return auth


def validate_scheduler_receipt(receipt):
    assert receipt["job_id"] == JOB and receipt["protocol_sha256"] == CONTEXT_SHA
    assert receipt["remote_directory"] == DIRECTORY and receipt["host"] == "cluster1.comp.anu.edu.au"
    assert receipt["read_only"] is True and receipt["new_jobs"] == receipt["new_model_requests"] == 0
    assert datetime.fromisoformat(receipt["utc"]).tzinfo is not None
    for name, argv in COMMANDS.items():
        command = receipt["commands"][name]
        assert command["argv"] == argv and command["code"] == 0 and not command["stderr"].strip()
    assert not receipt["commands"]["squeue"]["stdout"].strip()
    accounting = [line.split("|") for line in receipt["commands"]["sacct"]["stdout"].splitlines() if line.strip()]
    assert accounting and all(len(row) == 8 for row in accounting)
    parents = [row for row in accounting if row[0] == JOB]
    assert len(parents) == 1
    job = parents[0]
    assert job[1] == "p02-context90" and job[2] == "TIMEOUT" and job[6] in ("04:00:00", "4:00:00")
    assert datetime.fromisoformat(job[5]) > datetime.fromisoformat(job[4])
    terminal = {"TIMEOUT", "COMPLETED", "CANCELLED", "FAILED", "OUT_OF_MEMORY", "NODE_FAIL", "PREEMPTED", "BOOT_FAIL", "DEADLINE", "REVOKED"}
    assert all((row[0] == JOB or row[0].startswith(JOB + ".")) and row[2].split()[0] in terminal for row in accounting)
    control = dict(field.split("=", 1) for field in receipt["commands"]["scontrol"]["stdout"].split() if "=" in field)
    for key, value in dict(JobId=JOB, JobName="p02-context90", UserId="u7830488(7830488)", Account="db4ai", QOS="db4ai",
        JobState="TIMEOUT", Restarts="0", WorkDir=DIRECTORY, TimeLimit="04:00:00").items():
        assert control.get(key) == value, key
    assert control.get("EndTime") == job[5] and control.get("StartTime") == job[4]
    return dict(kind="scheduler_timeout", job_id=JOB, state="TIMEOUT", scheduler_end_time=job[5],
        scheduler_time_zone="remote scheduler local timestamp; not relabelled UTC", captured_utc=receipt["utc"],
        graceful_worker_FINISHED_receipt=False, squeue_empty=True, scheduler_parent_and_steps_terminal=True)


def validate_checkpoint_closure(context=CONTEXT, output=OUTPUT):
    """Same predecessor identity/denominator guards, with no fake worker receipt."""
    assert not (output / "REMOTE_GPU_FINISHED.json").exists(), "Existing FINISHED must use the original guard"
    required = [context / "PROTOCOL.frozen.json", context / "INPUTS90.jsonl", context / "ORDER270.jsonl",
                output / "checkpoint.sqlite3", output / "REMOTE_JOB_ID.json", output / "REMOTE_GPU_READY.json"]
    assert all(path.is_file() for path in required)
    assert not list(output.glob("*CONTINUATION*.json")), "A continuation allocation requires a different audited closure"
    assert sha(context / "PROTOCOL.frozen.json") == CONTEXT_SHA
    expected = dict(protocol_sha256=CONTEXT_SHA, inputs_sha256=sha(context / "INPUTS90.jsonl"), order_sha256=sha(context / "ORDER270.jsonl"))
    ordered = rows(context / "ORDER270.jsonl"); planned = {r["task_id"] for r in ordered}
    assert len(ordered) == len(planned) == 270
    with closing(sqlite3.connect((output / "checkpoint.sqlite3").resolve().as_uri() + "?mode=ro", uri=True)) as db:
        db.execute("BEGIN")
        stored = db.execute("SELECT value FROM data WHERE kind='meta' AND key='identity'").fetchone()
        identity = json.loads(stored[0]) if stored else {}
        done = {row[0] for row in db.execute("SELECT key FROM data WHERE kind='outcome'")}
        inflight = db.execute("SELECT count(*) FROM requests WHERE status='in_flight'").fetchone()[0]
    assert all(identity.get(key) == value for key, value in expected.items())
    held = {read(path)["task_id"] for path in (output / "held").glob("*.json")}
    assert done <= planned and held <= planned and done | held == planned and inflight == 0
    job = read(output / "REMOTE_JOB_ID.json"); ready = read(output / "REMOTE_GPU_READY.json")
    assert job == dict(job_id=JOB, directory=DIRECTORY, protocol_sha256=CONTEXT_SHA)
    assert ready["job_id"] == JOB and ready["protocol_sha256"] == CONTEXT_SHA and ready["status"] == "ready"
    assert ready["no_LLM_credentials_or_requests"] is True and "A6000" in ready["gpu"]
    return dict(planned=270, attempted=len(done | held), quality_terminal=len(done), held_technical=len(held-done),
                in_flight=0, protocol_sha256=CONTEXT_SHA, job_id=JOB)


def completion_status(original_guard, target):
    original = original_guard()
    if original.get("finished"):
        return original
    if original.get("reason") != "missing_predecessor_completion_artifact":
        return original
    if (OUTPUT / "REMOTE_GPU_FINISHED.json").exists():
        return original
    try:
        authorized(target)
        local = validate_checkpoint_closure()
        closure = validate_scheduler_receipt(read(RECEIPT))
        return dict(finished=True, reason="complete_with_authorized_scheduler_timeout_closure", **local,
                    closure_evidence=closure, supplement_script_sha256=sha(__file__), scheduler_receipt_sha256=sha(RECEIPT))
    except (AssertionError, KeyError, TypeError, ValueError, OSError, sqlite3.Error, StopIteration) as error:
        return dict(finished=False, reason="scheduler_closure_supplement_not_validated", error_type=type(error).__name__,
                    original_guard=original)


def launch(target, wait=False):
    authorized(target)
    from experiments.query_decomposition.p02_reference_binding_priority_probe_v1_20261022 import run as stage
    original = stage.context90_completion_status
    stage.context90_completion_status = lambda: completion_status(original, target)
    try:
        if target == "stage":
            return stage.run(deferred=True, wait_for_guard=wait)
        from experiments.query_decomposition.p02_reference_binding_priority_fixed90_v1_20261022 import run as full90
        return full90.run(wait=wait)
    finally:
        stage.context90_completion_status = original


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("auth-template", "status", "stage", "full90"))
    parser.add_argument("--wait", action="store_true")
    parser.add_argument("--target", choices=tuple(TARGETS), default="stage")
    args = parser.parse_args()
    if args.wait and args.action not in TARGETS: parser.error("--wait applies only to stage/full90")
    if args.action == "auth-template": result = authorization_template()
    elif args.action == "status":
        from experiments.query_decomposition.p02_reference_binding_priority_probe_v1_20261022.run import context90_completion_status
        result = completion_status(context90_completion_status, args.target)
    else: result = launch(args.action, args.wait)
    print(json.dumps(result, ensure_ascii=True), flush=True)


if __name__ == "__main__": main()
