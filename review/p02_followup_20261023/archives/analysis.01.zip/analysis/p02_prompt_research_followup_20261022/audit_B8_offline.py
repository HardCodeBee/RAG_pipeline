"""Independent post-lock B8 interpretation/audit; no provider or scorer."""
from pathlib import Path
from contextlib import closing
from collections import Counter
from datetime import datetime,timezone
import hashlib,json,sqlite3,sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'src'))
from p02_multigrain_timing_cachefix_v1.core.cache import canonical
from p02_multigrain_timing_cachefix_v1.core.llm import build_payload
from experiments.query_decomposition.p02_failure8_actual_entity_probe_v1_20261022 import templates
P=ROOT/'outputs/query_decomposition/p02_failure8_actual_entity_probe_v1_20261022'
B=ROOT/'experiments/query_decomposition/p02_failure8_actual_entity_probe_v1_20261022'
I=ROOT/'outputs/query_decomposition/p02_ordinary_failure_challenge8_v1_20261022'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def rows(p):return [json.loads(s) for s in p.read_text(encoding='utf-8-sig').splitlines() if s.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(v):return hashlib.sha256(canonical(v).encode('utf8')).hexdigest()
def rel(p):return str(p.relative_to(ROOT)).replace('\\','/')
def normal(r,model):
    u=r.get('usage') or {}
    return (r.get('status')=='success' and r.get('finish_reason')=='stop' and isinstance(r.get('answer'),str) and bool(r['answer'].strip()) and not r.get('refusal') and r.get('requested_model')==r.get('returned_model')==model and all(type(u.get(k)) is int and u[k]>=0 for k in ['prompt_tokens','completion_tokens','total_tokens']) and u['total_tokens']==u['prompt_tokens']+u['completion_tokens'])
def cost(r):return r['usage']['prompt_tokens']*.8e-6+r['usage']['completion_tokens']*2e-6

def main():
    first=P/'root_blind_review/batch001/SEMANTIC_REVIEWS.blinded.jsonl'
    assert sha(first)=='e5468a8d8967d8cd6ba85ec2f2fbc39b446948d85ebba78315129d70cbdf0828'
    paths=[P/'REPORT.json',P/'DETAILS.local.jsonl',P/'root_blind_review/SEMANTIC_JOIN.json',first,
        P/'root_blind_review/batch001/SEMANTIC_REVIEW_LOCK.json',P/'root_blind_review/batch001/METHOD_KEY.local.json',
        B/'INPUTS8.frozen.jsonl',B/'B0_FRESH_I0_RECEIPTS8.local.frozen.json',B/'PROTOCOL.frozen.json',
        I/'root_blind_review/SEMANTIC_JOIN.json',I/'root_blind_review/batch001/SEMANTIC_REVIEWS.blinded.jsonl']
    before={rel(p):sha(p) for p in paths}
    assert sha(paths[-1])=='7dde3e8837ec04427a623854561cd8bf1f52815c0df9a9fdc42e35b104748480'
    data=rows(P/'DETAILS.local.jsonl');index={(r['probe_id'],r['arm']):r for r in data};joined=read(P/'root_blind_review/SEMANTIC_JOIN.json');sem={(r['case_id'],r['arm']):r for r in joined['records']}
    inputs=rows(B/'INPUTS8.frozen.jsonl');items={r['probe_id']:r for r in inputs};report=read(P/'REPORT.json')
    assert len(data)==len(index)==len(sem)==joined['reviewed_records']==24
    assert set(index)==set(sem)=={(i,a) for i in items for a in templates.ARMS}
    config=read(ROOT/'src/p02_multigrain_timing_cachefix_v1/config.json');model=config['generation']['model']
    assert config['generation']==read(B/'GENERATION.frozen.json')
    with closing(sqlite3.connect((P/'checkpoint.sqlite3').resolve().as_uri()+'?mode=ro',uri=True)) as db:
        current={i:dict(payload=p,status=s,result=json.loads(r)) for i,p,s,r in db.execute('SELECT id,payload,status,result FROM requests')}
        retired={i:dict(payload=p,status=s,result=json.loads(r)) for i,p,s,r in db.execute('SELECT id,payload,status,result FROM retired_requests')}
        outcomes=[json.loads(v) for(v,) in db.execute("SELECT value FROM data WHERE kind='outcome'")]
    assert len(current)==13 and len(retired)==1 and len(outcomes)==24
    assert {r['task_id']:r for r in data}=={r['task_id']:r for r in outcomes}
    for rid,r in current.items():assert r['status']=='success' and normal(r['result'],model),rid
    for r in retired.values():
        assert r['status']==r['result']['status']=='unknown' and r['payload'] in {x['payload'] for x in current.values()}
        assert not any(r['result'].get(k) is not None for k in ['response_id','usage','raw_response','returned_model'])
    method=read(P/'root_blind_review/batch001/METHOD_KEY.local.json');original_review={r['candidate_id']:r for r in rows(first)}
    for k in method:
        o=index[k['case_id'],k['arm']]
        assert digest(o)==k['outcome_sha256'] and o['request_id']==k['source_request_id']
        assert sem[k['case_id'],k['arm']]['candidate_id']==k['candidate_id']
        assert all(sem[k['case_id'],k['arm']][f]==original_review[k['candidate_id']][f] for f in ['factual_correct','addresses_actual_question','necessary_information_retained','entity_role_or_scope_error'])
    controls=read(B/'B0_FRESH_I0_RECEIPTS8.local.frozen.json')['controls'];control_index={c['probe_id']:c for c in controls};control_checks=[]
    for c in controls:
        o=index[c['probe_id'],'B0'];assert normal(c['result'],model) and c['result']['answer'].strip()==o['answer'] and c['result']['usage']==o['usage']
        assert c['payload_sha256']==digest(c['source_payload']) and c['source_payload']==items[c['probe_id']]['control_payload']
        assert o['request_id']==c['source_request_id'] and o['actual_new_CNY']==c['B0_new_actual_CNY']==0
        with closing(sqlite3.connect((ROOT/c['source_database']).resolve().as_uri()+'?mode=ro',uri=True)) as db:
            old=db.execute('SELECT payload,status,result FROM requests WHERE id=?',(c['source_request_id'],)).fetchone()
        assert old and old[0]==canonical(c['source_payload']) and old[1]=='success' and json.loads(old[2])==c['result']
        assert abs(cost(c['result'])-c['source_charge']['actual_CNY'])<1e-12
        control_checks.append(dict(probe_id=c['probe_id'],exact_fresh_I0_payload_receipt_charge=True,source_request_id=c['source_request_id'],already_charged_CNY=c['source_charge']['actual_CNY'],new_B0_CNY=0))
    payload_checks=[]
    for item in inputs:
        for arm in templates.ARMS:
            expected=build_payload(config['generation'],templates.prompt(item,arm),128);out=index[item['probe_id'],arm]
            if arm=='B0':receipt=control_index[item['probe_id']]['result'];payload=control_index[item['probe_id']]['source_payload']
            else:receipt=current[out['request_id']]['result'];payload=json.loads(current[out['request_id']]['payload'])
            assert payload==expected and receipt['answer'].strip()==out['answer'] and receipt['usage']==out['usage']
            payload_checks.append(dict(probe_id=item['probe_id'],arm=arm,payload_sha256=digest(payload),full_wire_exact=True,cap128=True,matching_model_stop_all3_usage=True))
    assert len({x['payload_sha256'] for x in payload_checks if x['arm']!='B0'})==13
    for arm in templates.ARMS:
        rr=[r for r in data if r['arm']==arm];section=report['sections'][arm]
        assert len(rr)==8 and all(r['status']=='success' for r in rr)
        assert section['logical_input_tokens']==sum(r['usage']['prompt_tokens'] for r in rr) and section['logical_output_tokens']==sum(r['usage']['completion_tokens'] for r in rr)
    comparisons={}
    for a,b in [('B0','B1'),('B1','B2'),('B0','B2')]:
        value=dict(terminal_pairs=8,changed_text_ids=[i for i in items if index[i,a]['answer']!=index[i,b]['answer']],same_actual_receipt_pairs=sum(index[i,a]['request_id']==index[i,b]['request_id'] for i in items))
        assert value==report['comparisons'][a+'_to_'+b];comparisons[a+'_to_'+b]=value
    with closing(sqlite3.connect(Path(config['budget']['ledger']).resolve().as_uri()+'?mode=ro',uri=True)) as db:
        charges=[dict(id=i,reserved_CNY=r,actual_CNY=a,status=s) for i,r,a,s in db.execute('SELECT id,reserved,actual,status FROM charges WHERE namespace=?',('p02_prompt_research_v1_20261022/'+str(P.resolve()),))]
        for c in controls:
            old=db.execute('SELECT namespace,actual,status FROM charges WHERE id=?',(c['source_request_id'],)).fetchone()
            assert old==(c['source_charge']['namespace'],c['source_charge']['actual_CNY'],'returned_usage')
    assert {c['id'] for c in charges}==set(current)|set(retired) and len(charges)==14
    assert not {c['source_request_id'] for c in controls}&{c['id'] for c in charges}
    actual=sum(c['actual_CNY'] or 0 for c in charges);reserved=sum(c['reserved_CNY'] for c in charges if c['actual_CNY'] is None);oldcost=sum(c['source_charge']['actual_CNY'] for c in controls)
    assert abs(actual-.0283508)<1e-12 and abs(reserved-.0067248)<1e-12 and abs(oldcost-.0164192)<1e-12
    assert abs(actual-report['actual_new_known_returned_usage_CNY'])<1e-12 and abs(reserved-report['unresolved_reserved_CNY'])<1e-12 and abs(oldcost-report['B0_attributed_already_charged_CNY'])<1e-12 and report['B0_new_actual_CNY']==0
    assert sum(r['result']['usage']['prompt_tokens'] for r in current.values())==report['candidate_unique_input_tokens'] and sum(r['result']['usage']['completion_tokens'] for r in current.values())==report['candidate_unique_output_tokens']
    notes={
        '2wiki:a6fd9c120baf11ebab90acde48001122/ordinary/2':'只改was/is、大小写与撇号，仍把Richard II完整说成原题Richard的祖父；当前要求William父亲的父亲。原D多走一代边界保留，不能按命中实体名算关系修复。',
        '2wiki:02f574780baf11ebab90acde48001122/ordinary/2':'B2将描述性对象写为Liu Cong(Emperor Zhaowu)，但仍给Liu Yin。reader已明确Liu Yin是妻父、Liu Yuan是夫父；实体显式化没有修复角色事实。',
        'hotpotqa:5a8512035542992a431d1ace/ordinary/2':'B2删去who hosted从句，主持人身份仍由history/reader承接，但依然将Maury Wills列为投手。缩短不是完整事实修复；Bob正例在本reader未独立核实，必要信息待核口径不改。',
        '2wiki:54bf355508b811ebbd88ac1f6bf848b6/ordinary/4':'B2用显式Alexandre Tsutsunava缩短回答，仍称不能从材料确定卒日；reader已有生命日期终点25 October1955。不当弃答/日期提取问题未解。',
        'hotpotqa:5a893fc855429951533612f0/ordinary/2':'B1/B2增加from Crete，确实有reader支持，但原有群猎缺证并未消除；三臂合理弃答保持正确，也都未提供pack关系。这是背景补充，不是新增修复。'}
    changes=[]
    for pid in comparisons['B0_to_B2']['changed_text_ids']:
        changes.append(dict(probe_id=pid,original_question=items[pid]['original_question'],original_raw_current_question=items[pid]['current_question'],frozen_existing_rewrite=items[pid]['frozen_rewritten_query'],interpretation=notes[pid],arms={a:dict(answer=index[pid,a]['answer'],request_id=index[pid,a]['request_id'],locked_review=sem[pid,a]) for a in templates.ARMS}))
    assert len(changes)==5
    Ijoin=read(I/'root_blind_review/SEMANTIC_JOIN.json')
    for arm in templates.ARMS:assert sum(sem[i,arm]['stage_correct'] is True for i in items)==2 and sum(sem[i,arm]['stage_correct'] is False for i in items)==6
    for arm in ['I0','I1']:assert Ijoin['sections']['all/'+arm]['stage_correct']==2 and Ijoin['sections']['all/'+arm]['stage_wrong']==6
    result=dict(created_utc=datetime.now(timezone.utc).isoformat(),scope='Post-lock interpretation of B8 selected ordinaryQA challenge; no nativeF1 or completeRAG claim',protected_source_hashes=before,first_blind_review_sha256=sha(first),all24_method_joins_match_locked_first_labels=True,stage_sections=joined['sections'],five_text_change_cases=changes,comparisons=comparisons,
        receipt_audit=dict(new_unique_payloads_complete=13,retired_unknown=retired,all24_full_payload_contracts_exact=True,all_current_requested_returned_model_and_three_integer_usage_valid=True,same_payload_B1_B2_receipt_pairs=3,checks=payload_checks),
        cost_audit=dict(new_known_CNY=actual,unknown_reserved_CNY=reserved,B0_already_paid_attribution_CNY=oldcost,B0_new_CNY=0,B0_ids_absent_from_new_namespace=True,no_orphan_charges=True,charges=charges,original_I0_controls=control_checks),
        I16_related_stop_rule=dict(first_I_review_sha256=sha(paths[-1]),locked_sections={a:Ijoin['sections']['all/'+a] for a in ['I0','I1']},interpretation='I0/I1都2正确6错，2正确均为原合理弃答边界，6局部故障没有修复。B0/B1/B2同样未产生语义得失，因此本轮不扩大通用核对句或候选说明块分支；不是断言所有实体绑定策略无效。'),
        limits=['8个暴露、诊断选择的开发节点，非总体准确率；三组共享payload不是独立抽样。','B0为此前fresh I0精确复用，不是B执行时重新同步抽取的控制。B1→B2是同包装下既有候选文本比较。','原raw current始终权威；未修D、未加gold、未重跑检索/goal/final。371多走一代、122原下游恢复均保留。','首审由同一知情Codex执行，已接触I8/病例先验，非独立人工gold。'],
        original_I_B_labels_scripts_reports_unchanged=True,no_L_outputs_read=True,new_API_calls=0,new_network_fact_checks=0,main_evaluation_remains_paused=True)
    assert before=={rel(p):sha(p) for p in paths}
    target=P/'ROOT_PAIRED_INTERPRETATION.json';assert not target.exists();target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print(json.dumps(dict(passed=True,new_complete_payloads=13,retired_unknown=1,new_known_CNY=actual,reserved_CNY=reserved,B0_old_attribution_CNY=oldcost,first_review_preserved=sha(first),json_sha256=sha(target))))

if __name__=='__main__':main()
