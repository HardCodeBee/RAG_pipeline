"""Matched, frozen-snapshot interim statistics; no live report or cache mutation.

Native scoring is gated behind root's snapshot-bound first-review lock.  This is
an uneven, completion-selected development subset, not a final fixed90 estimate.
"""
import argparse
from collections import Counter
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
BASE = ROOT / "experiments/query_decomposition/p02_shared_context_fixed90_v1_20261022"
LIVE = ROOT / "outputs/query_decomposition/p02_shared_context_fixed90_v1_20261022"
PREEXEC = ROOT / "analysis/p02_prompt_research_followup_20261022/SHARED_CONTEXT_FIXED90_PREEXECUTION_INDEPENDENT_REVIEW.json"
CONTROL = ROOT / "outputs/query_decomposition/hotpot_formal_eval_v1/p02_frozen_no_refs_quick90_v1_20261021/control90.jsonl"
ARMS = ("reset", "flat", "chat")
DATASETS = ("hotpotqa", "2wiki", "musique")
UKEYS = ("prompt_tokens", "completion_tokens", "total_tokens")
PREEXEC_SHA = "5065ea1de71fa656dd36795c2e33e155e42b25331e511b3c0aebecc6c2aa8cd7"
PROTOCOL_SHA = "0630afaf6e7b992675085022189e93b9de3af6cdbec9b1542c88856fe9b0630e"


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def rows(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ro(path):
    return sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True)


def usage(stages):
    total = dict.fromkeys(UKEYS, 0)
    for stage in stages:
        value = stage["usage"]
        assert all(type(value[k]) is int and value[k] >= 0 for k in UKEYS)
        assert value["total_tokens"] == value["prompt_tokens"] + value["completion_tokens"]
        for key in UKEYS:
            total[key] += value[key]
    return total


def delta_ratio(candidate, control):
    return dict(ratio=candidate / control if control else None,
                increase_percent=(candidate / control - 1) * 100 if control else None)


def stats(snapshot, scope_lock):
    snapshot = snapshot.resolve()
    assert snapshot.is_relative_to(LIVE.resolve()) and snapshot.name.startswith("SNAPSHOT_")
    manifest_path, common_path = snapshot / "SNAPSHOT_MANIFEST.json", snapshot / "COMMON_QUERY_IDS.json"
    manifest, common, lock = read(manifest_path), read(common_path), read(scope_lock)
    # No outcomes/predictions/reference values are opened before all these gates.
    assert lock["snapshot_manifest_sha256"] == sha(manifest_path)
    assert lock["common_query_ids_sha256"] == sha(common_path)
    assert lock["all_common_text_differences_first_reviews_locked"] is True
    assert manifest["protocol_sha256"] == PROTOCOL_SHA == sha(BASE / "PROTOCOL.frozen.json")
    assert manifest["source_live_output"] == str(LIVE.resolve())
    assert manifest["namespace"] == "p02_prompt_research_v1_20261022/" + str(LIVE.resolve())
    for name, record in manifest["files"].items():
        path = (snapshot / name).resolve()
        assert path.is_relative_to(snapshot) and sha(path) == record["sha256"], name
    assert sha(PREEXEC) == PREEXEC_SHA
    preexec, protocol = read(PREEXEC), read(BASE / "PROTOCOL.frozen.json")
    for path, expected in {**protocol["pins"], **protocol["protected_holds"],
                           **preexec["additional_review_bound_dependencies"]}.items():
        assert sha(ROOT / path) == expected, path
    plan = ROOT / "experiments/query_decomposition/unified_rag_eval_v1_20261021/PLAN.json"
    assert read(plan)["execution_approval"]["approved"] is False
    contract_path = snapshot / "ROOT_CONTEXT90_CONTRACT_AUDIT.json"
    contract = read(contract_path)
    assert contract["passed"] is True and contract["contract_replay_passed"] is True
    assert contract["immutable_source_snapshot"]["manifest_sha256"] == sha(manifest_path)

    ids = common["query_ids"]
    assert len(ids) == len(set(ids)) == common["common_query_count"] == manifest["common_query_count"]
    common_index = {row["id"]: row for row in common["queries"]}
    assert set(ids) == set(common_index)
    refs = {row["id"]: row for row in rows(BASE / "references90.local.jsonl")}
    history = {row["id"]: row for row in rows(BASE / "HISTORICAL_REFERENCES90.local.jsonl")}
    old = {row["id"]: row for row in rows(CONTROL)}
    with closing(ro(snapshot / "checkpoint.sqlite3")) as db:
        outcomes = {key: json.loads(value) for key, value in db.execute("SELECT key,value FROM data WHERE kind='outcome'")}
    # Factory once/dataset, after the review gate, preserving native aliases.
    from experiments.query_decomposition.comprehensive_eval_v1_20261015.scoring import metric
    scorers = {dataset: metric(dataset) for dataset in DATASETS}
    detail = []
    for ident in ids:
        ds = refs[ident]["dataset"]
        assert old[ident]["dataset"] == ds == common_index[ident]["dataset"]
        assert history[ident]["historical_quality_available"] is True
        assert history[ident]["final_prediction_reference_only"] == old[ident]["prediction"]
        for arm in ("old_P02", *ARMS):
            if arm == "old_P02":
                result = old[ident]
                stages = result["calls"]
            else:
                result = outcomes[ident + "/" + arm]
                stages = result["stages"]
                assert result["id"] == ident and result["dataset"] == ds and result["arm"] == arm
                assert result["status"] == common_index[ident]["status_by_arm"][arm]
            assert result["status"] in ("success", "success_truncated", "algorithm_failure")
            native = (scorers[ds](result["prediction"], refs[ident])
                      if result["status"] != "algorithm_failure" else dict(f1=0., em=0.))
            whole = usage(stages)
            qa = usage([stage for stage in stages if stage["stage"].startswith("legacy/answer/")])
            if arm != "old_P02":
                assert whole == common_index[ident]["logical_usage_by_arm"][arm]
                assert qa == common_index[ident]["QA_usage_by_arm"][arm]
            detail.append(dict(id=ident, dataset=ds, arm=arm, status=result["status"],
                F1=native["f1"], EM=native["em"], native_full_correct=native["f1"] == 1 or native["em"] == 1,
                wholeflow_logical_tokens=whole, QA_only_logical_tokens=qa))

    def summary(ds=None):
        selected = [row for row in detail if ds is None or row["dataset"] == ds]
        result = {}
        for arm in ("old_P02", *ARMS):
            found = [row for row in selected if row["arm"] == arm]
            n = len(found)
            result[arm] = dict(n=n, F1=sum(row["F1"] for row in found) / n,
                EM=sum(row["EM"] for row in found) / n,
                native_full_correct_count=sum(row["native_full_correct"] for row in found),
                status_counts=dict(Counter(row["status"] for row in found)))
            for section in ("wholeflow_logical_tokens", "QA_only_logical_tokens"):
                total = {key: sum(row[section][key] for row in found) for key in UKEYS}
                result[arm][section] = dict(sum=total, mean_per_query={key: total[key] / n for key in UKEYS})
            result[arm]["logical_entire_flow_estimated_CNY"] = (
                result[arm]["wholeflow_logical_tokens"]["sum"]["prompt_tokens"] * .8e-6 +
                result[arm]["wholeflow_logical_tokens"]["sum"]["completion_tokens"] * 2e-6)
        comparisons = {}
        for candidate, control in (("flat", "reset"), ("chat", "reset"), ("chat", "flat"), ("reset", "old_P02")):
            ci = {row["id"]: row for row in selected if row["arm"] == candidate}
            ri = {row["id"]: row for row in selected if row["arm"] == control}
            changes = [ci[ident]["F1"] - ri[ident]["F1"] for ident in ci]
            comparisons[candidate + "_minus_" + control] = dict(
                n=len(changes), delta_F1=sum(changes) / len(changes),
                delta_EM=result[candidate]["EM"] - result[control]["EM"],
                improved=sum(v > 0 for v in changes), tied=sum(v == 0 for v in changes), harmed=sum(v < 0 for v in changes))
            for section in ("wholeflow_logical_tokens", "QA_only_logical_tokens"):
                comparisons[candidate + "_minus_" + control][section] = {
                    key: delta_ratio(result[candidate][section]["sum"][key], result[control][section]["sum"][key])
                    for key in UKEYS}
        return dict(arms=result, paired=comparisons)

    # Separate snapshot-wide paid-once expenses from matched-cohort logical use.
    with closing(ro(snapshot / "budget.sqlite3")) as ledger:
        charge_rows = ledger.execute("SELECT id,actual,reserved,status FROM charges WHERE namespace=?", (manifest["namespace"],)).fetchall()
    paid = sum(row[1] for row in charge_rows if row[1] is not None)
    unresolved = {}
    for rid, actual, reserve, status in charge_rows:
        if actual is None:
            unresolved.setdefault(status, dict(count=0, reserved_CNY=0.))
            unresolved[status]["count"] += 1
            unresolved[status]["reserved_CNY"] += reserve
    assert abs(paid - contract["ledger"]["actual_new_returned_usage_CNY"]) < 1e-9
    assert abs(sum(v["reserved_CNY"] for v in unresolved.values()) - contract["ledger"]["unresolved_reserved_CNY"]) < 1e-9
    alerts = [r for r in rows(snapshot / "events.jsonl") if r.get("event") == "expense_alert"]
    reason_counts = Counter(reason for row in alerts for reason in row.get("reasons", []))
    return dict(passed=True, statistics_utc=datetime.now(timezone.utc).isoformat(),
        snapshot=str(snapshot), snapshot_manifest_sha256=sha(manifest_path),
        scope_lock_path=str(scope_lock.resolve()), scope_lock_sha256=sha(scope_lock),
        common_query_ids_sha256=sha(common_path), common_n=len(ids), dataset_counts=common["dataset_counts"],
        freeze_timestamp_utc=manifest["freeze_timestamp_utc"],
        scope="Completion-selected, uneven exposed development subset; same IDs across old historical P02 and all three fresh arms. Not the final fixed90 or formal500 result; old is nonconcurrent.",
        token_definition="Wholeflow sums every accepted logical stage including rewrite, ordinary+goal QA, formatter and final. QA-only includes legacy/answer/ ordinary+goal generation; excludes formatter/rewrite/final. Repeated shared-prefix logical use counted for each condition; unknown attempts excluded from logical tokens and retained separately in paid-once reserves.",
        overall=summary(), by_dataset={ds: summary(ds) for ds in DATASETS if common["dataset_counts"].get(ds, 0)},
        per_query=detail, scorer_factory_calls_once_per_dataset=3,
        namespace_paid_once_snapshot=dict(namespace=manifest["namespace"], actual_returned_usage_estimated_CNY=paid,
            unresolved_reserved_CNY=sum(v["reserved_CNY"] for v in unresolved.values()), unresolved_by_ledger_status=unresolved,
            cost_scope="All namespace requests at the snapshot, including beyond the common subset; not independent cold wholeflow arm cost or actual invoice.",
            cross_database_pin_interval_seconds=manifest["cross_database_pin_interval_seconds"]),
        expense_alert_metadata=dict(records=len(alerts), reason_counts=dict(reason_counts),
            first_utc=alerts[0].get("utc") if alerts else None,
            interpretation="Repeated rolling-window notifications are not independent expense incidents; preserve alert thresholds and unknown reserves."),
        contract_audit_path=str(contract_path), contract_audit_sha256=sha(contract_path),
        no_API_SSH_GPU_or_live_cache_ledger_mutations=True, main_evaluation_remains_paused=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot-directory", type=Path, required=True)
    parser.add_argument("--scope-lock", type=Path, required=True)
    parser.add_argument("--root-confirmed-semantic-lock", action="store_true")
    args = parser.parse_args()
    assert args.root_confirmed_semantic_lock, "Wait for root's snapshot-bound first-review lock"
    result = stats(args.snapshot_directory, args.scope_lock)
    path = args.snapshot_directory / "ROOT_MATCHED_INTERIM_STATISTICS.json"
    encoded = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    assert not path.exists(), "Preserve prior statistics bytes; use a new version if needed"
    path.write_text(encoded, encoding="utf-8")
    print(json.dumps(dict(path=str(path.resolve()), sha256=sha(path), common_n=result["common_n"],
        dataset_counts=result["dataset_counts"], overall=result["overall"], by_dataset=result["by_dataset"],
        namespace_paid_once_snapshot=result["namespace_paid_once_snapshot"], expense_alert_metadata=result["expense_alert_metadata"]), ensure_ascii=True, indent=2))


if __name__ == "__main__":
    main()
