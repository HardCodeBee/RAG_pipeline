"""Post-semantic-lock read-only L180 audit. Never run before root notification.

Only independent ROOT_* audit artifacts are written. No Cache, client, network,
report() or runner invocation is used. Frozen L source/report/labels are preserved.
"""
from collections import Counter
from contextlib import closing
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import random
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))
from p02_multigrain_timing_cachefix_v1.core.cache import canonical
from p02_multigrain_timing_cachefix_v1.core.llm import build_payload
from p02_multigrain_timing_cachefix_v1.core.pipeline import render_final, passages
from experiments.query_decomposition.p02_goal_native_role_fixed90_v1_20261022 import templates
from experiments.query_decomposition.comprehensive_eval_v1_20261015.scoring import metric

B = ROOT / "experiments/query_decomposition/p02_goal_native_role_fixed90_v1_20261022"
P = ROOT / "outputs/query_decomposition" / B.name
PACKAGE = ROOT / "src/p02_multigrain_timing_cachefix_v1"
DS = ("hotpotqa", "2wiki", "musique")
UKEYS = ("prompt_tokens", "completion_tokens", "total_tokens")


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def rows(path):
    return [json.loads(s) for s in Path(path).read_text(encoding="utf-8-sig").splitlines() if s.strip()]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def rel(path):
    return str(Path(path).relative_to(ROOT)).replace("\\", "/")


def ro(path):
    return sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True)


def usage_ok(value):
    u = value.get("usage") or {}
    return (all(type(u.get(k)) is int and u[k] >= 0 for k in UKEYS)
            and u["total_tokens"] == u["prompt_tokens"] + u["completion_tokens"])


def integrity(value, model):
    return (value.get("status") == "success" and usage_ok(value)
            and value.get("requested_model") == value.get("returned_model") == model)


def normal(value, model):
    return (integrity(value, model) and value.get("finish_reason") == "stop"
            and isinstance(value.get("answer"), str) and bool(value["answer"].strip()) and not value.get("refusal"))


def successful(value, model, stage):
    return normal(value, model) or (stage == "final" and integrity(value, model)
        and value.get("finish_reason") == "length" and isinstance(value.get("answer"), str)
        and bool(value["answer"].strip()) and not value.get("refusal"))


def terminal(value, model):
    if not integrity(value, model):
        return None
    if value.get("finish_reason") in ("length", "content_filter"):
        return "terminal_" + value["finish_reason"]
    if value.get("refusal"):
        return "terminal_refusal"
    if isinstance(value.get("answer"), str) and not value["answer"].strip():
        return "terminal_empty"
    return None


def returned(value):
    return (any(value.get(k) is not None for k in ("response_id", "raw_response", "usage", "returned_model", "refusal", "finish_reason"))
            or bool(value.get("answer") or value.get("content")))


def cost(usage):
    return usage["prompt_tokens"] * .8e-6 + usage["completion_tokens"] * 2e-6


def formatter(record, answer):
    return ("Express the candidate answer below as a concise complete factual sentence that names its subject and relation. "
        "Use only the current question, candidate answer, and supplied context. Preserve uncertainty; do not add facts. "
        "If evidence is missing, state the specific unresolved fact in a complete sentence. Return only the sentence.\n\n"
        + "Question:\n" + record["goal_inputs"]["request"] + "\n\nCandidate answer:\n" + answer.strip()
        + "\n\nContext:\n" + passages(record["goal_inputs"]["reader_packet"]))


def final_render(record, answer, config, examples):
    goal = deepcopy(record["goal_inputs"])
    goal["answer"] = answer.strip()
    return render_final(record["question"], deepcopy(record["ordinary_nodes"]) + [goal],
        record["final_root_packet"], config["readout"], examples)


def equal(left, right, label=""):
    if isinstance(right, dict):
        assert isinstance(left, dict) and set(left) == set(right), label
        for k in right:
            equal(left[k], right[k], label + "/" + str(k))
    elif isinstance(right, list):
        assert isinstance(left, list) and len(left) == len(right), label
        for n, (a, b) in enumerate(zip(left, right)):
            equal(a, b, label + "/" + str(n))
    elif type(right) in (float, int) and type(left) in (float, int):
        assert abs(left - right) < 1e-12, (label, left, right)
    else:
        assert left == right, (label, left, right)


def bootstrap(index, data, historical, ordinary_only=False):
    """Paired query bootstrap, stratified by dataset, descriptive exposed cohort."""
    selected = [i for i in data if not ordinary_only or data[i]["supporting_questions"]]
    groups = {ds: [i for i in selected if data[i]["dataset"] == ds] for ds in DS}
    contrasts = (("L1_minus_L0", "L1", "L0"), ("L0_minus_historical", "L0", "historical"), ("L1_minus_historical", "L1", "historical"))
    values = {}
    for name, a, b in contrasts:
        for endpoint in ("f1", "em"):
            def score(i, arm):
                return historical[i][endpoint] if arm == "historical" else index[i, arm][endpoint]
            values[name + "/" + endpoint] = {i: score(i, a) - score(i, b) for i in selected}
    samples = {k: [] for k in values}
    rng = random.Random(20261022)
    for _ in range(10000):
        draw = [i for ds in DS for i in rng.choices(groups[ds], k=len(groups[ds]))]
        for key, delta in values.items():
            samples[key].append(sum(delta[i] for i in draw) / len(selected))
    result = {}
    for key, delta in values.items():
        ordered = sorted(samples[key])
        result[key] = dict(mean_delta=sum(delta.values()) / len(selected), percentile95=[ordered[249], ordered[9749]],
            positive_resample_fraction=sum(v > 0 for v in samples[key]) / 10000)
    return dict(cases=len(selected), per_dataset={d: len(v) for d, v in groups.items()}, seed=20261022,
        resamples=10000, resampling_unit="query pair within dataset; preserve declared stratum sizes",
        contrasts=result, interpretation="Descriptive repeatedly exposed development cohort; historical contrasts nonconcurrent, not independent confirmation or pure variance")


def semantic_coverage(outcomes, details, joined, data, config, examples):
    """Require paired locks only for mechanically different final texts.

    The predeclared semantic scope is changed-final pairs, not all180 outcomes.
    Same-text pairs remain in every native denominator and are not assigned0.
    """
    index = {(r["id"], r["arm"]): r for r in outcomes}
    assert len(index) == len(outcomes) == 180
    case_ids = list(dict.fromkeys(r["id"] for r in outcomes))
    assert len(case_ids) == 90 and set(index) == {(i, a) for i in case_ids for a in templates.ARMS}
    diff_ids = [i for i in case_ids if index[i, "L0"]["answer"] != index[i, "L1"]["answer"]]
    same_ids = [i for i in case_ids if i not in set(diff_ids)]
    expected = {(i, a) for i in diff_ids for a in templates.ARMS}
    semantic = {(r["case_id"], r["arm"]): r for r in joined["records"]}
    assert len(semantic) == len(joined["records"]) and set(semantic) == expected
    detail_index = {(r["id"], r["arm"]): r for r in details}
    covered, locks, checks = set(), [], []
    for batch in sorted((P / "root_blind_review").glob("batch*")):
        lock = read(batch / "ROOT_REVIEW_LOCK.json")
        packet_path, key_path = batch / "PACKET.json", batch / "METHOD_KEY.local.json"
        review_path = batch / "SEMANTIC_REVIEWS.blinded.jsonl"
        packet_sha, key_sha, review_sha = sha(packet_path), sha(key_path), sha(review_path)
        assert packet_sha == lock["packet_sha256"] and review_sha == lock["review_sha256"]
        assert lock["locked_before_root_method_join"]
        if "method_key_sha256" in lock:
            assert key_sha == lock["method_key_sha256"]
        packet, key, reviews = read(packet_path), read(key_path), rows(review_path)
        assert isinstance(key, list)
        candidates = {(c["case_id"], v["candidate_id"]): v for c in packet["cases"] for v in c["candidates"]}
        texts = {k: v["text"] for k, v in candidates.items()}
        methods = {(r["case_id"], r["candidate_id"]): r for r in key}
        review_index = {(r["case_id"], r["candidate_id"]): r for r in reviews}
        assert len(texts) == len(methods) == len(review_index) == len(reviews) == lock["records"]
        assert set(texts) == set(methods) == set(review_index)
        for candidate_key, text in texts.items():
            method, review = methods[candidate_key], review_index[candidate_key]
            pair = (candidate_key[0], method["arm"])
            assert pair in expected and pair not in covered
            outcome = index[pair]
            assert text == outcome["answer"]
            text_sha = hashlib.sha256(text.encode()).hexdigest()
            assert review["packet_sha256"] == packet_sha
            # L's locked reviewer recorded the actual final-context digest,
            # rather than a redundant per-text digest. Bind text by the locked
            # packet + full source outcome, and verify the provided context.
            if "candidate_text_sha256" in review:
                assert review["candidate_text_sha256"] == text_sha
            actual_context = final_render(data[pair[0]], outcome["goal_answer_used"], config, examples)[1]
            assert candidates[candidate_key]["final_visible_context"] == actual_context
            context_sha = hashlib.sha256(actual_context.encode()).hexdigest()
            assert review["final_visible_context_sha256"] == context_sha
            for name, value in review.items():
                assert semantic[pair][name] == value, (pair, name, "first locked label changed")
            assert semantic[pair]["candidate_id"] == candidate_key[1]
            # Bind source digest to a complete original outcome or report detail,
            # never a selected answer string or unverified method name alone.
            possible_digests = {digest(outcome): "checkpoint_outcome", digest(detail_index[pair]): "native_report_detail"}
            source_digest = method.get("outcome_sha256", method.get("source_outcome_sha256"))
            assert source_digest in possible_digests, (pair, "method key must bind full source record")
            if "source_request_id" in method:
                assert method["source_request_id"] == outcome["stages"][-1]["request_id"]
            covered.add(pair)
            checks.append(dict(id=pair[0], arm=pair[1], candidate_id=candidate_key[1], candidate_text_sha256=text_sha,
                final_visible_context_sha256=context_sha, source_digest=source_digest, source_digest_kind=possible_digests[source_digest],
                packet_key_review_join_exact=True))
        locks.append({**lock, "batch": batch.name, "method_key_sha256": key_sha})
    assert covered == expected and sum(r["records"] for r in locks) == 2 * len(diff_ids)
    return dict(predeclared_scope="All mechanically text-different final-answer pairs; two locked arm reviews per pair",
        complete_outcomes=180, complete_pairs=90, text_different_pairs=len(diff_ids), diff_case_ids=diff_ids,
        locked_semantic_records=len(covered), same_text_pairs=len(same_ids), same_text_case_ids=same_ids,
        same_text_pairs_not_duplicated_in_semantic_review=True, native_scoring_keeps_all180_without_missing_review_zero=True,
        locks=locks, checks=checks)


def main(root_notified=False):
    assert root_notified, "Do not open L outputs before root confirms semantic review lock"
    joined = read(P / "root_blind_review/SEMANTIC_JOIN.json")
    protected = [P / "REPORT.json", P / "DETAILS.jsonl", P / "PAIRED.jsonl", P / "root_blind_review/SEMANTIC_JOIN.json",
        B / "PROTOCOL.frozen.json", B / "run.py", B / "templates.py", B / "INPUTS90.frozen.jsonl",
        B / "HISTORICAL_STAGE_RECEIPTS90.local.frozen.jsonl", B / "references90.local.frozen.jsonl"]
    protected += [p for d in (P / "root_blind_review").glob("batch*") for p in d.glob("*.json*")]
    before = {rel(p): sha(p) for p in protected}
    protocol = read(B / "PROTOCOL.frozen.json")
    assert len(protocol["pins"]) == 138
    for path, expected in protocol["pins"].items():
        assert sha(ROOT / path) == expected, path
    config = read(PACKAGE / "config.json")
    model, examples = config["generation"]["model"], read(PACKAGE / "prompts/final_examples.json")
    data = {r["id"]: r for r in rows(B / "INPUTS90.frozen.jsonl")}
    history = {r["id"]: r for r in rows(B / "HISTORICAL_STAGE_RECEIPTS90.local.frozen.jsonl")}
    refs = {r["id"]: r for r in rows(B / "references90.local.frozen.jsonl")}
    assert len(data) == len(history) == len(refs) == 90
    assert Counter(r["dataset"] for r in data.values()) == {ds: 30 for ds in DS}
    assert sum(bool(r["supporting_questions"]) for r in data.values()) == 84
    old_controls = {r["id"]: r for r in rows(ROOT / "outputs/query_decomposition/hotpot_formal_eval_v1/p02_frozen_no_refs_quick90_v1_20261021/control90.jsonl")}
    source_checks = []
    old_stage_ids = set()
    for i, record in data.items():
        assert sha(ROOT / record["source"]) == record["source_sha256"]
        source = read(ROOT / record["source"])
        old = history[i]
        assert source["nodes"][:-1] == record["ordinary_nodes"]
        assert [n["request"] for n in record["ordinary_nodes"]] == record["supporting_questions"]
        goal = source["nodes"][-1]
        assert goal["role"] == "goal" and goal["request"] == record["question"]
        assert build_payload(config["generation"], goal["child_prompt"], 128) == record["original_goal_payload"] == old["goal"]["payload"]
        assert templates.goal_payload(record, "L0") == old["goal"]["payload"]
        l1 = templates.goal_payload(record, "L1")
        reverted = deepcopy(l1)
        reverted["messages"][0]["content"] = reverted["messages"][0]["content"].replace("\n" + templates.ROLE + templates.MARKER, templates.MARKER, 1)
        assert reverted == old["goal"]["payload"] and l1["max_tokens"] == 128
        trigger = len(goal["initial_answer"].strip().split()) < 4
        assert trigger == bool(old["formatter"])
        if trigger:
            assert formatter(record, goal["initial_answer"]) == templates.formatter_prompt(record, goal["initial_answer"])
            assert build_payload(config["generation"], formatter(record, goal["initial_answer"]), 128) == old["formatter"]["payload"]
        prompt, context, helper = final_render(record, goal["answer"], config, examples)
        assert prompt == source["final_prompt"] and context == source["final_context"]
        assert build_payload(config["generation"], prompt, 64) == old["final"]["payload"]
        excluded = {r["request_id"] for r in (old["goal"], old["formatter"], old["final"]) if r}
        old_stage_ids.update(excluded)
        prefix = [r for r in old_controls[i]["calls"] if r["request_id"] not in excluded]
        assert [r["request_id"] for r in prefix] == record["frozen_prefix_request_ids"]
        assert len({r["request_id"] for r in prefix}) == len(prefix)
        assert all(usage_ok(r) for r in prefix)
        assert not excluded.intersection(record["frozen_prefix_request_ids"])
        assert {k: sum(r["usage"][k] for r in prefix) for k in UKEYS} == record["frozen_prefix_usage"]
        for stage in ("goal", "formatter", "final"):
            receipt = old[stage]
            assert record["historical_stage_usage"][stage] == (receipt["result"]["usage"] if receipt else None)
            if receipt:
                result = receipt["result"]
                assert result["status"] == "success" and result["finish_reason"] == "stop" and usage_ok(result)
                assert result["returned_model"] == receipt["payload"]["model"] == model
                assert isinstance(result.get("answer"), str) and result["answer"].strip() and not result.get("refusal")
        source_checks.append(dict(id=i, original_goal128_exact=True, historical_formatter_exact=trigger,
            original_final64_core_renderer_exact=True, prefix_excludes_old_goal_formatter_final=True,
            historical_missing_requested_model_bound_by_full_payload=True, source_sha256=record["source_sha256"]))
    with closing(ro(P / "checkpoint.sqlite3")) as db:
        current = {i: dict(payload=p, status=s, result={**(json.loads(v) if v else {}), "status": s}) for i, p, s, v in db.execute("SELECT id,payload,status,result FROM requests")}
        retired = {i: dict(payload=p, status=s, result={**(json.loads(v) if v else {}), "status": s}) for i, p, s, v in db.execute("SELECT id,payload,status,result FROM retired_requests")}
        outcomes = [json.loads(v) for (v,) in db.execute("SELECT value FROM data WHERE kind='outcome'")]
        saved_stages = {k: json.loads(v) for k, v in db.execute("SELECT key,value FROM data WHERE kind='stage'")}
        identity = json.loads(db.execute("SELECT value FROM data WHERE kind='meta' AND key='identity'").fetchone()[0])
    assert identity == dict(protocol_sha256=sha(B / "PROTOCOL.frozen.json"), inputs_sha256=sha(B / "INPUTS90.frozen.jsonl"), order_sha256=sha(B / "ORDER180.frozen.jsonl"))
    assert len(outcomes) == len({r["task_id"] for r in outcomes}) == 180
    assert not old_stage_ids.intersection(current)
    assert len({r["payload"] for r in current.values()}) == len(current)
    attempts = Counter(r["payload"] for r in list(current.values()) + list(retired.values()))
    assert max(attempts.values()) <= 5
    scorers = {ds: metric(ds) for ds in DS}  # Exactly once per dataset in this independent process.
    native, stage_checks = [], []
    for outcome in outcomes:
        record = data[outcome["id"]]
        task, arm = outcome["task_id"], outcome["arm"]
        assert task == record["id"] + "/" + arm and arm in ("L0", "L1")
        stages = outcome["stages"]
        assert stages and stages[0]["stage"] == "goal"
        gp = templates.goal_payload(record, arm)
        expected = [("goal", gp)]
        initial = stages[0]["answer"].strip()
        goal_result = current[stages[0]["request_id"]]["result"]
        goal_ok = successful(goal_result, model, "goal")
        need_format = goal_ok and len(initial.split()) < 4
        assert outcome["formatter_triggered"] == need_format and outcome["goal_initial_answer"] == stages[0]["answer"]
        formatted = initial
        if need_format:
            assert len(stages) >= 2 and stages[1]["stage"] == "formatter"
            expected.append(("formatter", build_payload(config["generation"], formatter(record, initial), 128)))
            formatted = stages[1]["answer"].strip()
        last_nonfinal = stages[1] if need_format else stages[0]
        if successful(current[last_nonfinal["request_id"]]["result"], model, last_nonfinal["stage"]):
            prompt, context, helper = final_render(record, formatted, config, examples)
            expected.append(("final", build_payload(config["generation"], prompt, 64)))
            assert outcome["goal_answer_used"] == formatted
        assert len(stages) == len(expected)
        failed_reason = None
        for s, (name, payload) in zip(stages, expected):
            receipt = current[s["request_id"]]
            assert s["stage"] == name and receipt["payload"] == canonical(payload)
            assert s["payload_sha256"] == digest(payload) and s["usage"] == receipt["result"]["usage"]
            assert integrity(receipt["result"], model)
            if successful(receipt["result"], model, name):
                assert s["answer"] == receipt["result"]["answer"].strip()
                assert saved_stages[task + "/" + name] == s
            else:
                failed_reason = terminal(receipt["result"], model)
                assert failed_reason and s == stages[-1] and outcome["status"] == "algorithm_failure"
            stage_checks.append(dict(id=record["id"], arm=arm, stage=name, request_id=s["request_id"],
                full_payload_sha256=digest(payload), full_payload_exact=True, strict_model_three_integer_usage=True,
                finish_reason=receipt["result"]["finish_reason"], native_final_length_accepted=(name == "final" and receipt["result"]["finish_reason"] == "length" and successful(receipt["result"], model, name))))
        if failed_reason:
            assert outcome["answer"] == "" and outcome["terminal_reason"] == failed_reason
            scores = dict(f1=0., em=0.)
        else:
            assert outcome["status"] == ("success_truncated" if stages[-1]["finish_reason"] == "length" else "success")
            assert outcome["answer"] == stages[-1]["answer"]
            scores = scorers[record["dataset"]](outcome["answer"], refs[record["id"]])
        usage = {k: record["frozen_prefix_usage"][k] + sum(s["usage"][k] for s in stages) for k in UKEYS}
        native.append({**outcome, **scores, "full_flow_logical_usage": usage,
            "full_flow_logical_estimated_CNY": cost(usage), "new_stages_attributed_CNY": sum(cost(s["usage"]) for s in stages)})
    # Every completed current receipt is accounted by a logical stage; repeated uses share IDs.
    assert {s["request_id"] for r in outcomes for s in r["stages"]} == set(current)
    details = rows(P / "DETAILS.jsonl")
    semantic_scope = semantic_coverage(outcomes, details, joined, data, config, examples)
    assert {r["task_id"] for r in details} == {r["task_id"] for r in native}
    recorded = {r["task_id"]: r for r in details}
    for row in native:
        equal(recorded[row["task_id"]], row, row["task_id"])
    index = {(r["id"], r["arm"]): r for r in native}
    report = read(P / "REPORT.json")
    historical = {i: scorers[data[i]["dataset"]](history[i]["final"]["result"]["answer"].strip(), refs[i]) for i in data}
    def summarize(arm, ds=None, ordinary_only=False):
        planned = {i for i in data if (ds is None or data[i]["dataset"] == ds) and (not ordinary_only or data[i]["supporting_questions"])}
        r = [index[i, arm] for i in data if i in planned]
        n = len(planned)
        f, e = sum(s["f1"] for s in r), sum(s["em"] for s in r)
        return dict(planned=n, quality_terminal=len(r), held_or_unstarted=0,
            algorithm_failures=sum(s["status"] == "algorithm_failure" for s in r), success_truncated=sum(s["status"] == "success_truncated" for s in r),
            F1=f / n, EM=e / n, F1_fixed_denominator_bounds=[f / n, f / n], EM_fixed_denominator_bounds=[e / n, e / n],
            formatter_triggered=sum(s["formatter_triggered"] for s in r),
            full_flow_logical_prompt_tokens=sum(s["full_flow_logical_usage"]["prompt_tokens"] for s in r),
            full_flow_logical_completion_tokens=sum(s["full_flow_logical_usage"]["completion_tokens"] for s in r),
            full_flow_logical_estimated_CNY=sum(s["full_flow_logical_estimated_CNY"] for s in r))
    recomputed = dict(arms={a: summarize(a) for a in templates.ARMS},
        by_dataset={ds: {a: summarize(a, ds) for a in templates.ARMS} for ds in DS},
        ordinary_present_sensitivity=dict(planned_cases=84, arms={a: summarize(a, ordinary_only=True) for a in templates.ARMS},
            by_dataset={ds: {a: summarize(a, ds, True) for a in templates.ARMS} for ds in DS}))
    for key in ("arms", "by_dataset"):
        equal(report[key], recomputed[key], key)
    for key in ("planned_cases", "arms", "by_dataset"):
        equal(report["ordinary_present_sensitivity"][key], recomputed["ordinary_present_sensitivity"][key], "sensitivity/" + key)
    pairs = [dict(id=i, dataset=data[i]["dataset"], L0=index[i, "L0"]["f1"], L1=index[i, "L1"]["f1"],
        delta_F1=index[i, "L1"]["f1"] - index[i, "L0"]["f1"], delta_EM=index[i, "L1"]["em"] - index[i, "L0"]["em"]) for i in data]
    paired = dict(complete_pairs=90, delta_F1=sum(p["delta_F1"] for p in pairs) / 90, delta_EM=sum(p["delta_EM"] for p in pairs) / 90,
        improved=sum(p["delta_F1"] > 0 for p in pairs), tied=sum(p["delta_F1"] == 0 for p in pairs), harmed=sum(p["delta_F1"] < 0 for p in pairs))
    equal(report["paired"], paired, "paired")
    equal(rows(P / "PAIRED.jsonl"), pairs, "paired_details")
    historical_summary = dict(F1=sum(s["f1"] for s in historical.values()) / 90, EM=sum(s["em"] for s in historical.values()) / 90)
    equal(report["historical_P02_reference_only"], historical_summary, "historical")
    assert abs(historical_summary["F1"] - .7668887868810469) < 1e-12
    with closing(ro(config["budget"]["ledger"])) as db:
        charges = [dict(id=i, reserved_CNY=r, actual_CNY=a, status=s) for i, r, a, s in db.execute(
            "SELECT id,reserved,actual,status FROM charges WHERE namespace=?", ("p02_prompt_research_v1_20261022/" + str(P.resolve()),))]
    charged = {c["id"]: c for c in charges}
    assert not old_stage_ids.intersection(charged)
    assert set(current) | set(retired) <= set(charged)
    for rid, value in current.items():
        assert charged[rid]["status"] == "returned_usage" and charged[rid]["actual_CNY"] is not None
        assert abs(charged[rid]["actual_CNY"] - cost(value["result"]["usage"])) < 1e-12
    for rid, value in retired.items():
        assert not returned(value["result"]), "Retired returned evidence needs reconciliation, never silent retry"
        assert charged[rid]["actual_CNY"] is None and charged[rid]["status"] == "reserved"
    actual = sum(c["actual_CNY"] or 0 for c in charges)
    reserved = sum(c["reserved_CNY"] for c in charges if c["actual_CNY"] is None)
    equal(report["actual_new_returned_usage_CNY"], actual, "ledger_actual")
    equal(report["unresolved_reserved_CNY"], reserved, "ledger_reserved")
    orphan = sorted(set(charged) - set(current) - set(retired))
    assert all(charged[i]["actual_CNY"] is None for i in orphan)
    equal(report["request_statuses"], dict(Counter(r["status"] for r in current.values())), "requeststates")
    equal(report["retired_request_statuses"], dict(Counter(r["status"] for r in retired.values())), "retiredstates")
    assert report["status"] == "completed" and report["quality_terminal"] == 180 and report["held_technical_tasks"] == 0
    result = dict(created_utc=datetime.now(timezone.utc).isoformat(), scope="Independent native/payload/receipt/cost recount after semantic lock; no new semantic gold",
        protected_source_hashes=before, original_reports_scripts_labels_unchanged=True,
        semantic_scope=semantic_scope, semantic_locks=semantic_scope["locks"],
        protocol_sha256=sha(B / "PROTOCOL.frozen.json"), frozen_pins_verified=138, source_renderer_checks=source_checks,
        current_unique_receipts=len(current), logical_stage_uses=len(stage_checks), stage_checks=stage_checks,
        stage_contract="goal/formatter stop, original formatter wordcount<4; native final nonempty no-refusal attributable length scored unchanged",
        maximum_durable_attempts_observed=max(attempts.values()), durable_attempt_histogram=dict(Counter(attempts.values())),
        namespace_cost=dict(actual_new_returned_usage_CNY=actual, unresolved_reserved_CNY=reserved,
            retired_unknown=len(retired), reservations_without_cache_record_ids=orphan, source_history_not_newly_charged=True,
            charges=charges, repeated_payload_logical_attribution_not_double_new_charge=True),
        native=dict(scorer_factory_calls=3, details_recounted=180, detail_disagreements=0,
            all_report_groups_match=True, recomputed=recomputed, historical_reference_only=historical_summary, paired=paired),
        stratified_paired_bootstrap90=bootstrap(index, data, historical),
        stratified_paired_bootstrap84=bootstrap(index, data, historical, ordinary_only=True),
        limits=["Same repeatedly exposed fixed90, upstream remains frozen, not independent confirmation or full fresh execution/timing.",
            "Historical comparison is nonconcurrent; no bootstrap removes temporal drift or development exposure.",
            "Native F1 differences and stage semantic changes must be interpreted separately; this audit creates no semantic labels."],
        new_API_calls=0, no_new_retrieval_GPU=True, main_evaluation_remains_paused=True)
    assert before == {rel(p): sha(p) for p in protected}
    target = P / "ROOT_NATIVE_RECEIPT_AUDIT.json"
    assert not target.exists(), "Do not overwrite an audit; version it deliberately"
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    print(json.dumps(dict(path=rel(target), sha256=sha(target), passed=True), ensure_ascii=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root-confirmed-semantic-lock", action="store_true")
    args = parser.parse_args()
    main(root_notified=args.root_confirmed_semantic_lock)
