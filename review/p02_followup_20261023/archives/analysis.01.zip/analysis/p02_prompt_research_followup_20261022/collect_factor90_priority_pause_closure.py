"""Collect the authorized paused job's real worker receipt; remote reads only."""
from pathlib import Path
from datetime import datetime, timezone
import getpass
import hashlib
import json
import socket

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/query_decomposition/p02_reference_binding_priority_fixed90_v1_20261022"
CONT = OUT / "continuations/recovery01"
DEST = OUT / "pauses/cot90_priority_20261022/worker_closure"
AUTH = ROOT / "analysis/p02_prompt_research_followup_20261022/COT90_PRIORITY_PAUSE_AUTHORIZATION.json"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    import paramiko
    assert sha(AUTH) == "7ee40ab6356cb486196bf500df2078123f79e791424dec7c8b53f2ebc854b012"
    auth = read(AUTH); job = read(CONT / "REMOTE_JOB_ID.json")
    assert auth["approved"] is True and job["job_id"] == auth["old_job_id"] == "161046"
    assert job["directory"] == auth["old_remote_directory"] and job["protocol_sha256"] == auth["reference_protocol_sha256"]
    terminal = read(CONT / "SCHEDULER_TERMINAL.json")
    assert terminal["terminal"]["verified"] is True and terminal["job_id"] == job["job_id"]
    assert terminal["remote_directory"] == job["directory"] and terminal["commands"]["squeue"]["stdout"] == ""
    settings = read(ROOT / "experiments/query_decomposition/p02_reference_binding_priority_fixed90_v1_20261022/EXECUTION_SETTINGS.json")
    assert read(ROOT / settings["partition_preflight"])["verified_address"] == settings["verified_host_address"]
    assert not DEST.exists()
    client = paramiko.SSHClient(); client.load_system_host_keys(); client.set_missing_host_key_policy(paramiko.RejectPolicy())
    password = getpass.getpass("Remote password: "); connection = None
    try:
        connection = socket.create_connection((settings["verified_host_address"], 22), timeout=15)
        client.connect("cluster1.comp.anu.edu.au", username="u7830488", password=password, sock=connection,
            look_for_keys=False, allow_agent=False, timeout=15, auth_timeout=20, banner_timeout=15)
        password = None
        files = {}
        with client.open_sftp() as sftp:
            for name in ("REMOTE_JOB.frozen.json", "READY.json", "FINISHED.json", "WORKER_ERROR.json"):
                try:
                    with sftp.open(job["directory"] + "/" + name, "rb") as stream: raw = stream.read()
                except FileNotFoundError:
                    files[name] = dict(present=False); continue
                value = json.loads(raw)
                if name == "REMOTE_JOB.frozen.json":
                    assert value["protocol_sha256"] == job["protocol_sha256"] and value["remote_directory"] == job["directory"]
                if name == "READY.json":
                    assert value["job_id"] == job["job_id"] and value["protocol_sha256"] == job["protocol_sha256"]
                if name == "FINISHED.json": assert value["status"] == "stopped" and value["no_LLM_requests"] is True
                DEST.mkdir(parents=True, exist_ok=True)
                with (DEST / name).open("xb") as stream: stream.write(raw)
                files[name] = dict(present=True, sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
        result = dict(utc=datetime.now(timezone.utc).isoformat(), job_id=job["job_id"], remote_directory=job["directory"],
            protocol_sha256=job["protocol_sha256"], authorization_sha256=sha(AUTH), scheduler_terminal_sha256=sha(CONT / "SCHEDULER_TERMINAL.json"),
            read_only_remote=True, new_jobs=0, API_requests=0, files=files)
        with (DEST / "COLLECTION.json").open("x", encoding="utf8") as stream: json.dump(result, stream, indent=2); stream.write("\n")
        print(json.dumps(dict(job_id=job["job_id"], real_FINISHED_present=files["FINISHED.json"]["present"], new_jobs=0, API_requests=0)), flush=True)
    finally:
        password = None; client.close()
        if connection: connection.close()

if __name__ == "__main__": main()
