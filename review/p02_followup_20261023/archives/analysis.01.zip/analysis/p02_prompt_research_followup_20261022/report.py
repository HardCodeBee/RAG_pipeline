"""Read-only aggregation for delegated prompt research; never opens a live Cache."""
from collections import Counter
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sqlite3

ROOT = Path(__file__).resolve().parents[2]
REVIEW = ROOT / "experiments/query_decomposition/unified_rag_eval_v1_20261021/reviews/20261022_prompt_binding_goal_synthesis"
GOAL = ROOT / "outputs/query_decomposition/p02_goal_synthesis_probe_v1_20261022"
BINDING = ROOT / "outputs/query_decomposition/hotpot_formal_eval_v1/p02_prompt_binding_probe_v1_20261022"
CHALLENGE = ROOT / "outputs/query_decomposition/p02_goal_composition_challenge_v1_20261022/challenge27"


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def rows(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf8").splitlines() if line.strip()]


def save(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8")


def snapshot(directory):
    path = directory / "checkpoint.sqlite3"
    if not path.exists():
        return None
    with closing(sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)) as db:
        tables = {x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        receipt = []
        for table in ("requests", "retired_requests"):
            if table not in tables:
                continue
            receipt += [{"id": rid, "payload": payload, "status": status,
                         "result": json.loads(raw) if raw else {}, "retired": table.startswith("retired")}
                        for rid, payload, status, raw in db.execute(f"SELECT id,payload,status,result FROM {table}")]
        data = [{"kind": kind, "key": key, "value": json.loads(value)}
                for kind, key, value in db.execute("SELECT kind,key,value FROM data")]
    return {"data": data, "receipts": receipt}


def live_status():
    config = read(ROOT / "src/p02_multigrain_timing_cachefix_v1/config.json")
    ledger = Path(config["budget"]["ledger"])
    if not ledger.is_absolute():
        ledger = ROOT / ledger
    directories = {
        "binding": BINDING, "first_node": BINDING / "first_node_followup",
        "goal_synthesis": GOAL / "pilot15", "goal_rewrite_off": GOAL / "rewrite_off",
        "final_goal_none": GOAL / "final_goal_none", "goal_challenge27": CHALLENGE,
    }
    runs = {}
    with closing(sqlite3.connect(ledger.resolve().as_uri() + "?mode=ro", uri=True)) as billing:
        for name, directory in directories.items():
            snap = snapshot(directory)
            if snap is None:
                continue
            receipts = snap["receipts"]
            counts = Counter(r["payload"] for r in receipts)
            assert max(counts.values(), default=0) <= 5, (name, "attempt bound exceeded")
            known = sum((r["result"]["usage"]["prompt_tokens"] * .8e-6 +
                         r["result"]["usage"]["completion_tokens"] * 2e-6)
                        for r in receipts if r["result"].get("usage"))
            namespace = "p02_prompt_research_v1_20261022/" + str(directory.resolve())
            reserved = billing.execute("SELECT COALESCE(SUM(reserved),0) FROM charges WHERE namespace=? AND actual IS NULL",
                                       (namespace,)).fetchone()[0]
            active = [r for r in receipts if not r["retired"]]
            terminal = [r for r in active if r["status"] == "success" and
                        (r["result"].get("finish_reason") != "stop" or not r["result"].get("answer", "").strip()
                         or r["result"].get("refusal"))]
            predictions = [r for r in snap["data"] if r["kind"] in ("prediction", "result", "outcome")]
            runs[name] = {"recorded_condition_outputs": len(predictions), "known_CNY": known,
                          "unknown_or_inflight_reserved_CNY": reserved,
                          "active_returned_algorithm_failures": len(terminal),
                          "maximum_actual_attempts_per_payload": max(counts.values(), default=0),
                          "request_states_for_operations_only": dict(Counter(r["status"] for r in active))}
    value = {"utc": datetime.now(timezone.utc).isoformat(), "runs": runs,
             "known_new_CNY": sum(r["known_CNY"] for r in runs.values()),
             "unknown_or_inflight_reserved_CNY": sum(r["unknown_or_inflight_reserved_CNY"] for r in runs.values()),
             "main_evaluation_resumed": False,
             "expense_scope": "Only the six new research runs; historical quick90 costs remain separately preserved."}
    save(REVIEW / "LIVE_RUNS.json", value)
    return value


def pilot_controls():
    original_reports = {name: hashlib.sha256((GOAL / name / "REPORT.json").read_bytes()).hexdigest()
                        for name in ("pilot15", "rewrite_off", "final_goal_none")}
    pilot = rows(GOAL / "pilot15/DETAILS.scored.local.jsonl")
    off = rows(GOAL / "rewrite_off/DETAILS.scored.local.jsonl")
    none = rows(GOAL / "final_goal_none/DETAILS.scored.local.jsonl")
    # This independently recomputes published paired values; raw run reports stay untouched.
    cohort = {r["id"]: r["dataset"] for r in pilot}
    assert len(cohort) == 15 and len(pilot) == 45 and len(off) == 15 and len(none) == 13
    arms = {a: {r["id"]: r for r in pilot if r["arm"] == a} for a in ("G0", "G1", "G2")}
    arms["rewrite_off"] = {r["id"]: r for r in off}
    arms["final_goal_none"] = {r["id"]: r for r in none}
    missing = sorted(set(cohort) - arms["final_goal_none"].keys())
    snap = snapshot(GOAL / "final_goal_none")
    active = [r for r in snap["receipts"] if not r["retired"]]
    for ident in missing:
        matches = [r for r in active if r["result"].get("finish_reason") == "length"]
        # Confirm the failed payload contains this exact original question, rather than using absence as zero.
        source = next(r for r in rows(ROOT / "experiments/query_decomposition/p02_goal_synthesis_probe_v1_20261022/inputs15.frozen.jsonl")
                      if r["id"] == ident)
        matches = [r for r in matches if source["question"] in json.loads(r["payload"])["messages"][-1]["content"]]
        assert len(matches) == 1 and matches[0]["status"] == "success"
        assert matches[0]["result"].get("usage", {}).get("completion_tokens") == 64
        arms["final_goal_none"][ident] = {"id": ident, "dataset": cohort[ident],
            "native_metrics": {"f1": 0, "em": 0}, "status": "terminal_algorithm_length",
            "request_id": matches[0]["id"], "prediction": None}
    assert len(missing) == 2
    summaries = {}
    for arm, values in arms.items():
        assert set(values) == set(cohort)
        groups = {}
        for ds in ("all", "hotpotqa", "2wiki", "musique"):
            subset = [r for r in values.values() if ds == "all" or r["dataset"] == ds]
            groups[ds] = {"denominator": len(subset),
                          "F1": sum(r["native_metrics"]["f1"] for r in subset) / len(subset),
                          "EM": sum(r["native_metrics"]["em"] for r in subset) / len(subset),
                          "terminal_algorithm_failures": sum(r["status"] != "success" for r in subset)}
        counts = Counter()
        changes = []
        for ident, row in values.items():
            delta = row["native_metrics"]["f1"] - arms["G0"][ident]["native_metrics"]["f1"]
            counts["improved" if delta > 1e-12 else "harmed" if delta < -1e-12 else "tied"] += 1
            if abs(delta) > 1e-12:
                changes.append({"id": ident, "delta_F1": delta})
        summaries[arm] = {"by_dataset": groups, "paired_F1_against_G0": dict(counts), "changes": changes}
    value = {"scope": "Paired fixed15 frozen-prefix development controls, not main/full fresh RAG",
             "metrics": summaries, "raw_report_sha256": original_reports,
             "terminal_review_sha256": hashlib.sha256((GOAL / "final_goal_none/TERMINAL_OUTCOME_REVIEW.json").read_bytes()).hexdigest(),
             "failure_policy": "Returned length outcomes retain the fixed denominator and receive zero; no retries or raw-report edits.",
             "technical_missing": 0, "main_evaluation_remains_paused": True,
             "interpretation": "G0 uses common512/noformatter/neutral packaging and is separate from native historical P02. Final-none is information visibility, not removal of goal computation."}
    assert abs(summaries["final_goal_none"]["by_dataset"]["all"]["F1"] - .6777777777777777) < 1e-12
    assert abs(summaries["rewrite_off"]["by_dataset"]["all"]["F1"] - .7232323232323232) < 1e-12
    save(REVIEW / "PILOT15_CONTROLS.json", value)
    return value


def check_protected():
    initial = read(ROOT / "outputs/query_decomposition/p02_prompt_research_v1_20261022/START_STATE.json")
    result = {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == expected
              for path, expected in initial["protected_files"].items()}
    assert all(result.values()), result
    save(REVIEW / "PROTECTED_FILES_CHECK.json", {"utc": datetime.now(timezone.utc).isoformat(),
         "unchanged": result, "passed": True})


def pilot_cost():
    historical = {r["id"]: r for r in rows(ROOT / "experiments/query_decomposition/p02_goal_synthesis_probe_v1_20261022/historical15.local.jsonl")}
    data = rows(GOAL / "pilot15/DETAILS.scored.local.jsonl")
    results = {}
    single_alerts = []
    for arm in ("G0", "G1", "G2"):
        results[arm] = {}
        for ds in ("all", "hotpotqa", "2wiki", "musique"):
            subset = [r for r in data if r["arm"] == arm and (ds == "all" or r["dataset"] == ds)]
            native = []
            for row in subset:
                usages = [c["usage"] for c in historical[row["id"]]["calls"]]
                cost = sum(u["prompt_tokens"] * .8e-6 + u["completion_tokens"] * 2e-6 for u in usages)
                native.append(cost)
                if ds == "all" and cost and row["estimated_full_flow_logical_CNY"] > cost * 3:
                    single_alerts.append({"arm": arm, "id": row["id"], "ratio": row["estimated_full_flow_logical_CNY"] / cost})
            candidate = sum(r["estimated_full_flow_logical_CNY"] for r in subset) / len(subset)
            old = sum(native) / len(native)
            results[arm][ds] = {"paired_queries": len(subset), "historical_native_mean_CNY": old,
                "candidate_logical_mean_CNY": candidate, "ratio": candidate / old,
                "candidate_mean_input_tokens": sum(r["full_flow_logical_input_tokens"] for r in subset) / len(subset),
                "candidate_mean_output_tokens": sum(r["full_flow_logical_output_tokens"] for r in subset) / len(subset)}
    value = {"scope": "Logical full-flow token expense of pilot15, using frozen historical prefix and newly returned goal/final; not fresh formal500 expense or timing",
             "by_arm_dataset": results, "single_query_above_3x": single_alerts,
             "recent20_fresh_flow_trend": "not applicable:15 frozen-prefix queries per arm",
             "known_new_and_unknown_liability": "LIVE_RUNS.json; preserve both rather than imputing unknown as0"}
    save(REVIEW / "PILOT15_COST_COMPARISON.json", value)


def completed_summary():
    if not (CHALLENGE / "REPORT.json").exists():
        return
    challenge = read(CHALLENGE / "REPORT.json")
    if challenge["status"] != "complete":
        return
    details = rows(CHALLENGE / "DETAILS.scored.local.jsonl")
    assert len(details) == 81
    challenge_all = {}
    for arm in ("G0", "G1", "G2"):
        subset = [r for r in details if r["arm"] == arm]
        assert len(subset) == 27
        groups = challenge["by_arm_dataset"][arm]
        challenge_all[arm] = {"queries": 27,
            "F1": sum(r["native_metrics"]["f1"] for r in subset) / 27,
            "EM": sum(r["native_metrics"]["em"] for r in subset) / 27,
            "dataset_macro_F1": sum(g["F1"] for g in groups.values()) / len(groups),
            "by_dataset": groups}
    info_root = ROOT / "outputs/query_decomposition/p02_information_flow_followup_20261022"
    info_pointer = read(info_root / "CURRENT_REVIEW_VERSION.json")
    info = read(info_root / info_pointer["progress"])
    binding = read(BINDING / "semantic_review/REVIEW_COVERAGE.json")
    controls = read(REVIEW / "PILOT15_CONTROLS.json")
    cost = read(REVIEW / "LIVE_RUNS.json")
    value = {"utc": datetime.now(timezone.utc).isoformat(), "scope": "Completed bounded small-research batch; broader information audit and main evaluation remain separate",
        "main_evaluation_resumed": False, "selected_main_prompt_changed": False,
        "challenge27": {"quality": challenge_all, "paired_F1": challenge["paired_F1"],
                        "selection": challenge["scope"], "historical_final_successes_included": 5},
        "binding_coverage": binding, "information_flow_progress": info,
        "pilot15_quality": {a: r["by_dataset"]["all"] for a, r in controls["metrics"].items()},
        "expense": cost, "followup_design": "NEXT_STAGE_DESIGN.md",
        "source_reports": ["LATEST_COMPLETED_RESULTS.json", "PILOT15_CONTROLS.json",
            "outputs/query_decomposition/p02_goal_composition_challenge_v1_20261022/challenge27/REPORT.json",
            "outputs/query_decomposition/hotpot_formal_eval_v1/p02_prompt_binding_probe_v1_20261022/semantic_review/SUMMARY.md",
            str((info_root / info_pointer["readme"]).relative_to(ROOT))]}
    save(REVIEW / "RESULTS_SUMMARY.json", value)
    text = ["# 本轮P02提示与信息流研究结果", "",
        "本轮属于用户授权的自主小实验。主评、正式计时与发布保持暂停，原P02核心流程、控制结果及暂停文件未改。", "",
        "## 两项新完成的开发90题实验", "",
        "| 条件 | F1 | EM | 相对原版改善/不变/损害 |",
        "|---|---:|---:|---:|",
        "| 冻结原P02 | 76.6889% | 66.6667% | — |",
        "| compact三模板第二套 | 76.0450% | 64.4444% | 7/77/6 |",
        "| ordinary minimal4 | 74.6095% | 64.4444% | 0/86/4 |", "",
        "完整90题报告已替换旧partial状态；没有重跑成功结果。compact较第一套恢复4.3371个百分点，但未证明优于原版。minimal4同时改规则与示例原题，compact同时改三阶段，不能将差值直接归于#或实体指认。", "",
        "## 固定输入指代规则探针", "",
        "有历史30节点、无历史15首节点，90个候选输出全部完整结束；与45个历史控制共135个输出先遮蔽方法审阅、锁定后再解盲。4个节点的12个输出待核。", "",
        "有历史控制24正确/3错误/3待核，两候选各25/2/3；无历史三条件均14/0/1。唯一已确认二元改善是Mississippi河口补出Delta；Araripe真实父名变合理弃答，二元正确不变却丢失必要信息。当前不直接晋级完整流程。历史控制与新调用不同步、缺独立噪声重复，不能把少量变化证明为字符或绑定机制。", "",
        "## goal的15题共同接口对照", "",
        "每集5题，固定普通QA、goal检索和final协议。G0使用共同512上限、无formatter及中性展示包装，与历史原生P02分列。", "",
        "| 条件 | F1 | EM | 改善/不变/损害 |", "|---|---:|---:|---:|"]
    names = {"G0": "简短事实句G0", "G1": "较长事实摘要G1", "G2": "关键事实与必要组合段落G2",
             "rewrite_off": "G0关闭goal改写补充检索", "final_goal_none": "final移除goal候选段"}
    for arm in ("G0", "G1", "G2", "rewrite_off", "final_goal_none"):
        item = controls["metrics"][arm]
        metrics = item["by_dataset"]["all"]
        counts = item["paired_F1_against_G0"]
        change = "—" if arm == "G0" else "/".join(str(counts.get(k, 0)) for k in ("improved", "tied", "harmed"))
        text.append(f"| {names[arm]} | {metrics['F1']*100:.4f}% | {metrics['EM']*100:.4f}% | {change} |")
    text += ["", "final移除组13正常结束、2个64-token length算法失败，固定15分母计0，不重试；原报告与回执保留。G1也实际执行组合，G1/G2会改变事实和结论，所以不是纯粹有无CoT。关闭检索的唯一F1增益是错误否认句的词面重合；Mach出生地、Wang父子关系则真实依赖goal补充通道。这支持保留检索与传递，尚不估计总体收益。", "",
        "## 27题机制挑战", "",
        "全部来自旧诊断普通子答判对、goal判错的记录，2Wiki17、HotpotQA10，包含历史final成功5题；与pilot15无重叠。81条件均完整结束。普通判对允许真实不完整回答/合理弃答，故不能称27个纯组合错。", "",
        "| 条件 | 2Wiki F1/EM | HotpotQA F1/EM | 合计27题 F1/EM | 相对新G0改善/不变/损害 |",
        "|---|---:|---:|---:|---:|"]
    for arm in ("G0", "G1", "G2"):
        r = challenge_all[arm]
        w, h = r["by_dataset"]["2wiki"], r["by_dataset"]["hotpotqa"]
        counts = challenge["paired_F1"].get("G0_to_" + arm, {})
        change = "—" if arm == "G0" else "/".join(str(counts.get(k, 0)) for k in ("improved", "tied", "harmed"))
        text.append(f"| {arm} | {w['F1']*100:.2f}/{w['EM']*100:.2f} | {h['F1']*100:.2f}/{h['EM']*100:.2f} | {r['F1']*100:.2f}/{r['EM']*100:.2f} | {change} |")
    text += ["", "合计按27个原query平均，数据集等权结果另存JSON；不与15题或90题的不同样本均值直接比较。此集已用于诊断，不能称独立泛化或正式成绩。语义复核与分数应结合，不能把长段流畅、表面自洽或旧错到新对直接当因果收益。", "",
        "G2相对G0的五条F1下降不是五条已证实的新事实错误。Hanne Krogh与Jack Spring分别涉及避免未经证实的出生地转换、同名属性转移；Grammy案例的G0否认句虽有0.8词面F1，reader并未确立其否认事实。另一方面，John Grubb题两种goal都错指父亲，G0 final仍纠正为John，而G2 final跟随较长的错误代际论证选Peter；SBS题已确定频道却因未核实的state-run限定而弃答。唯一F1改善是正确执行Turkish-French与French的共有成员判断。结果支持暂不接入本版G2，并针对目标、运算与证据保守性分别测试，不支持笼统断言推理文本使事实能力下降。", "",
        "## 信息流复查与后续", "",
        f"当前V{info_pointer['version']}已亲读{info['material_reviewed_items']}条，声明范围完成{info['followup_semantic_reviews_completed']}条、待核{info['pending_fact_or_interpretation_work_items']}条；其余保持未开始或固定队列状态。这不是全体失败原因占比。原64个诊断文件及旧follow-up版本保留。", "",
        "反复出现的可确认路径包括共同国家被改成全集相等、祖母被母亲覆盖、出生地与国籍混淆、reader已有所问关系却在goal漏传，以及真正目标从未进入候选。应按位置分别修复，不能都归于最终阅读或靠增加推理解决。HP107实际QA仍收到原描述问题，详见独立澄清；对错误改写语义的真命题不保证回答了真实目标。", "",
        "下一步先按已锁语义结论检查本批得失，再独立比较少样例结果引用/完整描述/已知实体、必要时补同步噪声控制；goal方向优先保持原问题的目标、关系角色和运算，不联改全部模板。具体进入条件与冻结边界见NEXT_STAGE_DESIGN.md。没有自动更换主方法或恢复500题评估。", "",
        f"本批六项新研究已确认估算费用{cost['known_new_CNY']:.6f}元，另保留unknown预留{cost['unknown_or_inflight_reserved_CNY']:.6f}元，均列LIVE_RUNS.json。没有新检索或GPU任务，也未声称测得正式TTFT或全流程纯计算时间。", ""]
    (REVIEW / "RESULTS_SUMMARY.md").write_text("\n".join(text), encoding="utf8")


def join_goal_reviews():
    manual = CHALLENGE.parent / "manual_review"
    if not (CHALLENGE / "DETAILS.scored.local.jsonl").exists() or not (manual / "FINAL_BLIND_LOCK.json").exists():
        return
    lock = read(manual / "FINAL_BLIND_LOCK.json")
    review_path = manual / "SEMANTIC_REVIEWS.blinded.jsonl"
    assert hashlib.sha256(review_path.read_bytes()).hexdigest() == lock["review_file_sha256"]
    details = rows(CHALLENGE / "DETAILS.scored.local.jsonl")
    if len(details) != 81:
        return
    index = {(r["id"], r["arm"]): r for r in details}
    reviews, key = rows(review_path), read(manual / "METHOD_KEY.local.json")
    assert len(reviews) == 27
    joined = []
    for review in reviews:
        for code, semantics in review["candidates"].items():
            mapping = key[review["id"]][code]
            record = index[review["id"], mapping["arm"]]
            assert mapping["request_id"] == record["goal_request_id"]
            assert hashlib.sha256(record["goal_text"].encode()).hexdigest() == review["candidate_text_sha256"][code]
            joined.append({"id": record["id"], "dataset": record["dataset"], "arm": record["arm"],
                "blind_code": code, "goal_request_id": record["goal_request_id"],
                "prediction": record["prediction"], "native_metrics": record["native_metrics"],
                "required_facts": review["required_facts"], "necessary_operation": review["necessary_operation"],
                "candidate_semantic_review": semantics, "locked_case_conclusion": review["case_conclusion"]})
    assert len(joined) == len({(r["id"], r["arm"]) for r in joined}) == 81
    save(REVIEW / "CHALLENGE27_JOINED_SEMANTIC_AND_SCORES.json", {
        "joined_utc": datetime.now(timezone.utc).isoformat(), "source_blind_review_sha256": lock["review_file_sha256"],
        "cases": 27, "conditions": 81, "all_text_hashes_and_request_ids_match": True,
        "review_locked_before_score_join": True, "reviews": joined,
        "limitation": "One non-independent Codex reviewer; label/endpoint blinding does not hide paragraph style. Qualitative flags are not automatically converted to new binary truth labels."})


if __name__ == "__main__":
    live = live_status()
    pilot_controls()
    pilot_cost()
    check_protected()
    completed_summary()
    join_goal_reviews()
    print(json.dumps(live, ensure_ascii=False))
