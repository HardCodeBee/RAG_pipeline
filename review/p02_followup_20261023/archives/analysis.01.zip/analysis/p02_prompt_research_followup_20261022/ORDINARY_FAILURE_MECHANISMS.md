# 普通子问题回答的失效机制：V9只读核查

范围：V9已有270条复核，426个ordinary节点；不新增推理、不改旧标签/原生分数。

## 选择与解释规则

- 按V9 review_index顺序查看已确认发现及其原始ordinary输入；每类最多两个最早的明确合格案例，类别可重叠但这里固定单列。
- 纯普通QA挑战要求实际当前reader已含足以纠正所述实体/关系/状态的信息；不要求它已覆盖完整原题所有后续跳。
- 描述绑定类排除只有纠正前驱对象、却缺当前所问完整关系的HP107；保留该排除及其他边界。
- 合理弃答独立作为上游缺证据对照，不能混进reader足够但QA失败类。
- 这是既有270条复核中的机制实例筛选，不是预注册随机样本、错误频率估计或完整因果诊断。
- 实际问题取保存child_prompt的Current subquestion块，不用检索rewritten_query替代；全陈述事实、响应性与必要信息分别判断。

## 机制表

| 类别 | 案例 / ordinary步 | 同reader QA挑战 | 主要机制 |
|---|---|---|---|
| descriptive_binding | 2wiki 371 / step2 | 是（局部纠正） | 当前问题问William父亲的父亲，reader支持Richard II；初答却把主语换成原题Richard之父系祖父，完整关系陈述错一代。 |
| descriptive_binding | 2wiki 506 / step2 | 是（局部纠正） | 历史已给配偶Liu Cong，reader明确夫父Liu Yuan，QA反而抽出妻子自己的父亲Liu Yin并说成夫父。 |
| namesake_or_role | hotpotqa 27 / step1 | 是（局部纠正） | reader相邻两句区分引入者Mobil与开发者Verifone，QA将引入者写成created主体。 |
| namesake_or_role | hotpotqa 31 / step2 | 是（局部纠正） | QA在投手名单中错误加入Maury Wills；实际reader明确其游击手角色。 |
| attribute_date_or_modality | hotpotqa 122 / step1 | 是（局部纠正） | 分解当前题自带成功废黜的错误预设；QA照抄预设，未保留reader明确的失败企图状态。 |
| attribute_date_or_modality | 2wiki 248 / step4 | 是（局部纠正） | reader已有卒年终点1955，QA弃答，日期没有进入历史；goal/final实际可见输入缺少该日。 |
| reasonable_abstention_boundary | hotpotqa 7 / step2 | 否：合理缺证弃答边界 | 正确Doomsday Prophecy在改写路候选rank10，同时含两演员与2011；合并后的实际reader未保留它，因此QA弃答合理。 |
| reasonable_abstention_boundary | hotpotqa 50 / step2 | 否：合理缺证弃答边界 | 当前reader只证明Cretan Hound是猎犬，片段截断且没有群猎关系；QA合理保留不确定。 |

## 2wiki 371 / ordinary step2

原题：Who is Richard, Son Of William The Conqueror's paternal grandfather?

实际当前子问题：**Who is the father of William The Conqueror's father?**

实际reader短引：

- [actual_current_reader] Robert I, Duke of Normandy / doc 040b5e4976f5fc12d5ba2ce48e60961f8fcc5064e256281a724085ab43787ac8 / rank2：He was the son of Richard II

初答：Richard, Son of William the Conqueror's paternal grandfather is Richard II, Duke of Normandy.

formatter后：Richard, Son of William the Conqueror's paternal grandfather is Richard II, Duke of Normandy.

sentence_format_request_id：None（未触发）

现有检索改写：Who is the father of Robert I, Duke of Normandy?

改写能否解决：检索改写已经明确Robert I，其后QA仍混入原题主语；改写未解决。后goal变为Who is Richard II而继续固化。

边界：原分解本就相对原题多走一代；仅修当前陈述不保证原题最终正确。

原始源：`outputs/query_decomposition/hotpot_formal_eval_v1/p02_formal1500_v1_20261021/rounds/r000/cases/2wiki/p02_multigrain_timing_cachefix_v1/a6fd9c120baf11ebab90acde48001122.json`
完整SHA256：`32ed9554aca4c5802910f9c560ae2728465222b271e463c27c906ad6e7eecc87`
读取包：`outputs/query_decomposition/p02_information_flow_followup_20261022/review_packets/2wiki_371.json`（初答行596）

## 2wiki 506 / ordinary step2

原题：Who is the father-in-law of Empress Liu E?

实际当前子问题：**Who is the father of Empress Liu E's spouse?**

实际reader短引：

- [actual_current_reader] Liu Cong (Han Zhao) / doc be98fe779becb88135e978757c376d0cf63145648e6aa4ec98144ac8ce41bdfa / rank2：his father Liu Yuan's reign
- [actual_current_reader] Empress Liu E / doc 79ef236f92d6c60ca8acd13d4a030986d29529c79337a7d4e978066787eb7111 / rank1：Liu E was the daughter of

初答：Liu Yin is the father of Empress Liu E's spouse, Liu Cong.

formatter后：Liu Yin is the father of Empress Liu E's spouse, Liu Cong.

sentence_format_request_id：None（未触发）

现有检索改写：Who is the father of Liu Cong (Emperor Zhaowu)?

改写能否解决：检索改写已明确Liu Cong(Emperor Zhaowu)，未修复QA关系；之后goal问Who is Liu Yin，进一步偏离。

边界：属于reader内已有当前目标父子关系的明确局部QA改进机会；仍需新完整流程验证最终收益。

原始源：`outputs/query_decomposition/hotpot_formal_eval_v1/p02_formal1500_v1_20261021/rounds/r100/cases/2wiki/p02_multigrain_timing_cachefix_v1/02f574780baf11ebab90acde48001122.json`
完整SHA256：`dd1b24201be0c6ec2cb3abac23cfdeef79e362b39e4e1f4c2713b6ea633f8b10`
读取包：`outputs/query_decomposition/p02_information_flow_followup_20261022/review_packets/2wiki_506.json`（初答行596）

## hotpotqa 27 / ordinary step1

原题：The company that created a keychain RFDI device created to allow electronic payment at McDonald's and 400 other Chicago area restaurants is headquartered in what city and state?

实际当前子问题：**What company created the keychain RFDI device designed to allow electronic payment at McDonald's and 400 other Chicago area restaurants?**

实际reader短引：

- [actual_current_reader] Speedpass / doc 1324009 / rank1：introduced in 1997 by Mobil Oil Corp.
- [actual_current_reader] Speedpass / doc 1324009 / rank1：originally developed by Verifone

初答：Mobil Oil Corp. created the keychain RFID device designed to allow electronic payment at McDonald's and 400 other Chicago area restaurants.

formatter后：Mobil Oil Corp. created the keychain RFID device designed to allow electronic payment at McDonald's and 400 other Chicago area restaurants.

sentence_format_request_id：None（未触发）

现有检索改写：What company created the keychain RFDI device designed to allow electronic payment at McDonald's and 400 other Chicago area restaurants?

改写能否解决：当前检索改写保持原问题；后goal绑定Mobil总部，传播错误公司角色。

边界：实际reader足以纠正公司角色，但当时下游没有正确公司的总部资料，不能保证只改QA即可最终正确。

原始源：`outputs/query_decomposition/hotpot_formal_eval_v1/p02_formal1500_v1_20261021/rounds/r000/cases/hotpotqa/p02_multigrain_timing_cachefix_v1/5a83431d5542993344745ff5.json`
完整SHA256：`999be67a3839c0bb645d08f926c47307cf72642a805bb8d01fc3fa2f4d547ff6`
读取包：`outputs/query_decomposition/p02_information_flow_followup_20261022/review_packets/hotpotqa_027.json`（初答行269）

## hotpotqa 31 / ordinary step2

原题：What is the name of the one of the hosts of the Race for the Pennant sports show who is a retired american baseball pitcher?

实际当前子问题：**Which hosts of the Race for the Pennant sports show are retired American baseball pitchers?**

实际reader短引：

- [actual_current_reader] Race for the Pennant / doc 50269726 / rank1：Bob Gibson, Maury Wills
- [actual_current_reader] Maury Wills / doc 515445 / rank8：as a shortstop and switch-hitter

初答：Bob Gibson and Maury Wills are retired American baseball pitchers who hosted the Race for the Pennant sports show.

formatter后：Bob Gibson and Maury Wills are retired American baseball pitchers who hosted the Race for the Pennant sports show.

sentence_format_request_id：None（未触发）

现有检索改写：Which of Len Berman, Tim McCarver, Barry Tompkins, Bob Gibson, and Maury Wills are retired American baseball pitchers?

改写能否解决：改写已经显式列主持人候选供过滤，QA仍错；后goal改成Bob或Maury叫什么，弱化投手条件。

边界：当前reader足以排除错误附加人，但并无Bob Gibson本人投手传记；不声称正例全部证据齐全。

原始源：`outputs/query_decomposition/hotpot_formal_eval_v1/p02_formal1500_v1_20261021/rounds/r000/cases/hotpotqa/p02_multigrain_timing_cachefix_v1/5a8512035542992a431d1ace.json`
完整SHA256：`5df2b11bc2de9513c713ca89ab81fad37464e2629cb23e53981347506f0ff11e`
读取包：`outputs/query_decomposition/p02_information_flow_followup_20261022/review_packets/hotpotqa_031.json`（初答行596）

## hotpotqa 122 / ordinary step1

原题：Butautas tried to depose his uncle who between which years ?

实际当前子问题：**Who was Butautas' uncle who was deposed by Butautas?**

实际reader短引：

- [actual_current_reader] Butautas / doc 1953517 / rank1：attempted to depose his uncle Algirdas
- [actual_current_reader] Butautas / doc 1953517 / rank1：but failed

初答：Butautas' uncle who was deposed by Butautas was Algirdas.

formatter后：Butautas' uncle who was deposed by Butautas was Algirdas.

sentence_format_request_id：None（未触发）

现有检索改写：Who was Butautas' uncle who was deposed by Butautas?

改写能否解决：当前改写未变；后goal恢复tried措辞，并沿用reader的Algirdas在位端点1345/1377。

边界：是局部完整陈述错误，V9下游已恢复企图措辞；在位端点与实际企图日期的范围差异仍保留，不归因最终信息损失。

原始源：`outputs/query_decomposition/hotpot_formal_eval_v1/p02_formal1500_v1_20261021/rounds/r000/cases/hotpotqa/p02_multigrain_timing_cachefix_v1/5a79f37a5542996a35c17045.json`
完整SHA256：`50f5f87ace41fb354650f676be0aab903d67eb87b474e94a08446387bd36199d`
读取包：`outputs/query_decomposition/p02_information_flow_followup_20261022/review_packets/hotpotqa_122.json`（初答行267）

## 2wiki 248 / ordinary step4

原题：Which film has the director died earlier, La Cérémonie or Who Is The Guilty??

实际当前子问题：**When did the director of the film Who Is The Guilty?? die?**

实际reader短引：

- [actual_current_reader] Alexandre Tsutsunava / doc 07ecaf2afb2e71972a34c67684205c316b5c0f39409941d04dfa12bb75b89655 / rank2：25 October 1955

初答：The death date of Alexandre Tsutsunava, the director of *Who Is the Guilty?*, cannot be determined from these passages.

formatter后：The death date of Alexandre Tsutsunava, the director of *Who Is the Guilty?*, cannot be determined from these passages.

sentence_format_request_id：None（未触发）

现有检索改写：When did Alexandre Tsutsunava die?

改写能否解决：现有改写已明确When did Alexandre Tsutsunava die?，仍未提取；后goal仅恢复原比较题。

边界：reader版式为born – 25 October1955，缺失出生日期；V9已用冻结数据材料确认卒日。本表不修改旧标签，也不说最终阅读器忽视了可见1955。

原始源：`outputs/query_decomposition/hotpot_formal_eval_v1/p02_formal1500_v1_20261021/rounds/r000/cases/2wiki/p02_multigrain_timing_cachefix_v1/54bf355508b811ebbd88ac1f6bf848b6.json`
完整SHA256：`af36bfb9cb6ad962b8fcde69f4ad6c172ff614fe8500a79f3b28c66706f95556`
读取包：`outputs/query_decomposition/p02_information_flow_followup_20261022/review_packets/2wiki_248.json`（初答行1263）

## hotpotqa 7 / ordinary step2

原题：The actress that plays Kaylee Frye in the series "Firefly" also stars with Alan Dale in a sci-fi tv film released in what year?

实际当前子问题：**In what sci-fi TV film did the actress who plays Kaylee Frye in the series Firefly star with Alan Dale?**

实际reader短引：

- [rewritten_candidate_not_actual_reader] Doomsday Prophecy / doc 33214212 / rank10：Doomsday Prophecy is a 2011 sci-fi disaster television film by Jason Bourque starring Jewel Staite, Alan Dale and A.J. Buckley.

初答：The sci-fi TV film in which Jewel Staite starred with Alan Dale cannot be determined from these passages.

formatter后：The sci-fi TV film in which Jewel Staite starred with Alan Dale cannot be determined from these passages.

sentence_format_request_id：None（未触发）

现有检索改写：In what sci-fi TV film did Jewel Staite star with Alan Dale?

改写能否解决：改写已把描述对象具体化为Jewel Staite，仍无法避免后续reader合并丢失。

边界：这是候选到reader选择/保留问题；不列入同reader内容已足够的普通QA故障挑战。

原始源：`outputs/query_decomposition/hotpot_formal_eval_v1/p02_formal1500_v1_20261021/rounds/r000/cases/hotpotqa/p02_multigrain_timing_cachefix_v1/5ab3eeb5554299233954fff4.json`
完整SHA256：`61211ef9ef052eff23b9abf666a91015bbfa69eb587e51f8ab95c5b6e1692972`
读取包：`outputs/query_decomposition/p02_information_flow_followup_20261022/review_packets/hotpotqa_007.json`（初答行592）

## hotpotqa 50 / ordinary step2

原题：Are the Chien Français Blanc et Orange and Cretan Hound both used for hunting in packs?

实际当前子问题：**Is the Cretan Hound used for hunting in packs?**

实际reader短引：

- [actual_current_reader] Cretan Hound / doc 6863876 / rank2：is a hunting breed of dog

初答：The Cretan Hound is a hunting breed of dog, but whether it is used for hunting in packs cannot be determined from these passages.

formatter后：The Cretan Hound is a hunting breed of dog, but whether it is used for hunting in packs cannot be determined from these passages.

sentence_format_request_id：None（未触发）

现有检索改写：Is the Cretan Hound used for hunting in packs?

改写能否解决：当前改写保持原问题，goal也未得到pack关系；改写并未自动补足证据。

边界：不能由未见pack措辞推出No；不是QA忽视reader中已证实的群猎事实。

原始源：`outputs/query_decomposition/hotpot_formal_eval_v1/p02_formal1500_v1_20261021/rounds/r000/cases/hotpotqa/p02_multigrain_timing_cachefix_v1/5a893fc855429951533612f0.json`
完整SHA256：`d08666cdeacd24b5d645b32c343bd0a8c556ec606582f0d46ac51f8c4461e2f4`
读取包：`outputs/query_decomposition/p02_information_flow_followup_20261022/review_packets/hotpotqa_050.json`（初答行495）

## 明确排除与保留边界

- hotpotqa 107 step2：更早的描述对象错配：reader有Youngstown Puddlers后来叫Little Giants，但没有Mahoning县关系。可纠正对象，不是同reader足以完成当前县答案的完整阳性挑战。
- hotpotqa 116 step2：当前要求列作品而只给four operas，响应性错误已保留；原最终问题恰问opera数量，所需count仍保留并使用，不能以native非满分推断下游缺信息。
- 2wiki 329 step1：reader有Mozart已有作品被用作soundtrack，但film composer角色解释须谨慎，且无死亡地点关系。可探索保留带限定的桥接事实，不列无歧义完整局部QA阳性挑战。

## 格式化与结论限制

426个ordinary节点中，sentence_format_request_id非空0个，initial_answer到answer文本变化0个。因此这批材料没有可展示的<4word格式化损害实例。

当前实现pipeline.py:157使用原始当前子问题渲染QA；检索改写改变证据路由而不直接替换QA问题。pipeline.py:171为128输出上限，:177为少于4词才格式化的条件。历史判断始终以冻结child_prompt和保存轨迹为准。

- 未新运行RAG、检索、API或GPU；未改变V9事实标签或原生分数。
- 本表不查看E组method key或新输出数据库，也不参与原生评分。
- 局部同reader可修陈述不证明完整RAG F1提高；goal/final可能恢复，也可能仍缺后续关系。
- 无<4word格式化触发案例，只能报告未观察到该机制，不能证明它对其他样本无影响。
