"""Recompute the locked 8+30 node development review; no model or retrieval."""
from collections import Counter
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/query_decomposition/p02_local_cot_stage38_v1_20261022"
ARMS = ("N128", "N256", "F256", "R256")
AXES = ("complete_raw_response_correctness", "accepted_answer_correctness")


def read(p): return json.loads(p.read_text(encoding="utf-8"))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    joined, batches, sources = [], {}, {}
    for name in ("initial8", "supplemental30"):
        folder = OUT / "root_blind_review" / name
        value = read(folder / "SEMANTIC_JOIN.revision002.json")
        labels = folder / "REVIEW_LABELS.revision002.jsonl"
        lock = read(folder / "REVISION002_LOCK.json")
        assert sha(labels) == lock["review_labels_sha256"] == value["summary"]["labels_sha256"]
        joined.extend(value["joined"]); batches[name] = value["summary"]
        sources[name] = dict(labels_sha256=sha(labels), joined_sha256=sha(folder / "SEMANTIC_JOIN.revision002.json"))
    assert len(joined) == 152 and len({r["task_id"] for r in joined}) == 152
    cases = {r["case_id"] for r in joined}; assert len(cases) == 38
    assert len({r["source_case_id"] for r in joined}) == 35
    lookup = {(r["case_id"], r["arm"]): r for r in joined}
    stats = {}
    for arm in ARMS:
        values = [r for r in joined if r["arm"] == arm]; assert len(values) == 38
        stats[arm] = {axis: dict(Counter(r[axis] for r in values)) for axis in (*AXES, "accepted_information")}
    paired = {}
    for left, right in (("N128", "N256"), ("N256", "F256"), ("F256", "R256"), ("N128", "F256"), ("N128", "R256")):
        paired[left + "_to_" + right] = {}
        for axis in AXES:
            pairs = [(lookup[c, left][axis], lookup[c, right][axis]) for c in cases]
            eligible = [(a, b) for a, b in pairs if a in ("correct", "incorrect") and b in ("correct", "incorrect")]
            paired[left + "_to_" + right][axis] = dict(eligible=len(eligible), pending_or_missing=len(pairs)-len(eligible),
                improved=sum(a == "incorrect" and b == "correct" for a, b in eligible),
                harmed=sum(a == "correct" and b == "incorrect" for a, b in eligible), tied=sum(a == b for a, b in eligible))
    runtime = read(OUT / "REPORT.json")
    assert runtime["terminal"] == 152 and runtime["held_technical"] == 0
    value = dict(scope="Exposed fixed-reader ordinary nodes, model-assisted review; not full-RAG F1", nodes=38,
        source_queries=35, adjudicated_nodes_per_arm=37, pending_nodes_per_arm=1,
        source_hashes=sources, by_arm=stats, paired=paired, separate_batches=batches, runtime=runtime,
        main_evaluation_resumed=False, no_provider_calls=True)
    (OUT / "ROOT_FINAL_STATS.json").write_text(json.dumps(value, ensure_ascii=False, indent=2)+"\n", encoding="utf8")
    print(json.dumps(dict(by_arm=stats, paired=paired), ensure_ascii=False))


if __name__ == "__main__": main()
