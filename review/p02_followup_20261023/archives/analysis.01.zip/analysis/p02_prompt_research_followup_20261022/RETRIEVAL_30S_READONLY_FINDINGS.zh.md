# 检索返回间隔约30秒：只读排查

结论：未发现活跃检索路径内固定30秒等待。现有证据更支持login节点与GPU节点之间共享目录的文件可见性/元数据缓存延迟；尚未核查远端挂载参数或请求/响应各边界时间，不能确定具体哪侧或宣布根因。

本页仅分析当前运行的工程开销。文件返回间隔与`batch_seconds`均不作为主评正式时延指标，也不是用户约定的组件处理时间/TTFT补测。

## 已确认的证据

- `REMOTE_EVENTS`是**本地客户端读到response后的时间**，不是GPU实际完成时间（`retrieval_transport.py:179–185`）。指定MuSiQue五个返回时间差为30.258、30.274、30.012、30.320秒；HP与Wiki也反复出现30.0–30.54秒，并非MuSiQue特例。
- 留存JSON的只读SQLite快照包含33个已保存包，`batch_seconds`为：MuSiQue10次0.133–0.154秒，中位0.144；Wiki13次0.335–0.520秒，中位0.373；HP10次12.239–12.647秒，中位12.335。不同规模计算仍有近30秒返回节拍，不能把间隔当成纯BGE/全库扫描时间。
- `_search`计时包括编码、exact搜索和读出文档（`remote_resources.py:555–589`），不包括首次懒加载、队列或文件传输。模型/索引首次加载可以解释额外冷启动，但不能单独解释每次30秒节拍。
- remote worker检查`requests/*.json`，空闲只sleep0.2秒（`remote_worker.py:113–128`）；响应采用临时文件关闭后rename（`:25–29,134`）。PortableRetrieval默认batch等待0.03秒，本次max_batch=1所以不进入凑批等待；`future.result()`没有固定30秒超时（`remote_resources.py:521–524,636–640`）。
- 本地fetch上传请求后以0.5秒轮询response，600秒才技术挂起（`retrieval_transport.py:166–178`）。随后receipt捕获及本地缓存落盘通常约0.04秒，不是30秒。唯一显式30秒是关闭worker时等待FINISHED（`remote_bridge.py:135`），不在活跃fetch循环。

## 假设及证据边界

最有力的候选是：SFTP在login节点创建/检查文件，worker在GPU节点扫描同一`/home/projects/.../requests`与`responses`，跨节点目录属性或负查找缓存令新文件约30秒后才可见。0.2/0.5秒轮询不会保证底层共享文件系统同频刷新。也不能排除文件写入/rename、SFTP服务或底层共享存储的其他延迟；当前没有请求开始、worker发现及worker写完的独立时间戳，无法精确拆分。

之后如获技术观测授权，只需对同一request ID核四个边界：上传rename完成、worker首次读到请求、worker写完响应、客户端首次读到响应，并查看现有挂载信息，即可区分请求侧可见性、计算、响应侧可见性。当前未新增探针/SSH、未改轮询/索引/科学条件、未重启或替换正在运行的程序。

逐包标量、代码SHA及读取时点见`RETRIEVAL_30S_READONLY_FINDINGS.json`。这是实时局部快照，未检查预测、gold或native质量结果。

## 进一步收窄（保留首轮记录）

worker先写`.tmp`再rename，文件mtime可能来自临时文件写入；mtime早于客户端探针**不证明最终`.json`已发布**。`batch_seconds`覆盖编码、exact扫描、`chunks.get_many`读文档和`_doc`组装，但不含懒加载、future/store/deepcopy、`check_packet`、JSON序列化、临时文件关闭、rename及文件发现。因此直接可确认的结论仅是搜索计算较短；要归因可见性还须独立核实发布边界、前后可见性、并发发布和自然缓存过期。若未来独立技术续跑增加日志，可在同进程以monotonic记录retrieve返回、临时文件关闭、rename前后，不含质量内容；本轮未改worker。
