"""Supplement completed native scores with one common four-arm cohort.

No scoring, provider calls, retries, or execution-state writes. The native
REPORT remains unchanged; its complete N128/R256 pairing remains primary.
"""
from collections import Counter
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from experiments.query_decomposition.p02_local_cot_fixed90_v1_20261022 import preparation as p
from experiments.query_decomposition.p02_local_cot_fixed90_v1_20261022.score import ARMS, _section
import export_local_cot90_trace_review as exporter
from local_cot90_paired_intervals import unchanged_sources


def stage_category(stage, item):
    parts = stage.split('/')
    assert parts[0] == 'legacy'
    if parts == ['legacy', 'final']:
        return 'final/final'
    assert len(parts) == 3 and parts[1] in ('answer', 'rewrite', 'sentence_format')
    sid = int(parts[2]); count = len(item['supporting_questions'])
    assert 1 <= sid <= count + 1
    return parts[1] + ('/ordinary' if sid <= count else '/goal')


def goal_signature(trace):
    assert all(n['role'] == 'goal' for n in trace['nodes'])
    return dict(status=trace['status'],
        goal_nodes=[{key: n.get(key) for key in ('actual_prompt_ref', 'output_cap', 'raw_output',
                    'support', 'parsed_answer', 'accepted_answer', 'formatter', 'parser_status', 'committed')}
                    for n in trace['nodes']],
        stage_payloads=[(s['stage'], s['payload_sha256']) for s in trace['stages']],
        final_prompt_ref=trace['final']['prompt_ref'], prediction=trace['final']['prediction'])


def main():
    p.check()
    assert exporter.ready(p.read(p.OUT / 'STATUS.json'))
    manifest = p.read(exporter.EXPORT / 'SUMMARY.json')
    unchanged_sources(manifest['source_hashes'])
    inputs = {r['id']: r for r in p.rows(p.INPUTS)}
    rows = p.rows(p.OUT / 'DETAILS.jsonl')
    index = {(r['id'], r['arm']): r for r in rows}
    assert len(inputs) == 90 and len(rows) == len(index) == 360
    assert set(index) == {(i, a) for i in inputs for a in ARMS}
    assert all(r['status'] != 'unstarted_or_incomplete' for r in rows)
    for r in rows:
        if r['status'] == 'technical_held':
            assert r['f1'] is None and r['em'] is None
        else:
            assert r['status'] in exporter.QUALITY and r['f1'] is not None and r['em'] is not None
    common = {i for i in inputs if all(index[i, a]['f1'] is not None and index[i, a]['em'] is not None for a in ARMS)}
    section, _ = _section(index, inputs, common)
    primary_section, _ = _section(index, inputs, set(inputs), arms=('N128', 'R256'))
    ordinary = {i for i in common if inputs[i]['supporting_questions']}
    ordinary_section, _ = _section(index, inputs, ordinary)
    goal_only = []
    stage_usage = {a: {} for a in ARMS}
    trace_index = p.rows(exporter.EXPORT / 'INDEX.jsonl')
    assert len(trace_index) == len({r['id'] for r in trace_index}) == 90
    assert {r['id'] for r in trace_index} == set(inputs)
    for row in trace_index:
        case = p.read(exporter.EXPORT / row['evidence_file'])
        assert case['id'] == row['id'] and case['dataset'] == row['dataset'] == inputs[row['id']]['dataset']
        assert row['goal_only'] is (not inputs[row['id']]['supporting_questions'])
        if row['goal_only']:
            signatures = []
            for arm in ARMS:
                trace = case['arms'][arm]
                signatures.append(goal_signature(trace))
            terminal = all(case['arms'][a]['status'] in exporter.QUALITY for a in ARMS)
            goal_only.append(dict(id=row['id'], dataset=row['dataset'],
                all_four_quality_terminal=terminal,
                all_four_same=terminal and all(s == signatures[0] for s in signatures),
                signature_by_arm=dict(zip(ARMS, signatures))))
        if row['id'] not in common:
            continue
        for arm in ARMS:
            trace = case['arms'][arm]
            for stage in trace['stages']:
                key = stage_category(stage['stage'], inputs[row['id']])
                sums = stage_usage[arm].setdefault(key,
                    dict(prompt_tokens=0, completion_tokens=0, total_tokens=0))
                assert all(type(stage['usage'].get(k)) is int and stage['usage'][k] >= 0 for k in sums)
                assert stage['usage']['total_tokens'] == stage['usage']['prompt_tokens'] + stage['usage']['completion_tokens']
                for token in sums:
                    sums[token] += stage['usage'][token]
    assert len(goal_only) == 6
    for arm in ARMS:
        for token in ('prompt_tokens', 'completion_tokens', 'total_tokens'):
            expected = sum(index[i, arm]['full_flow_logical_usage'][token] for i in common)
            assert sum(s[token] for s in stage_usage[arm].values()) == expected
    unchanged_sources(manifest['source_hashes'])
    output = dict(
        scope='Completed exposed fixed90; supplementary common-cohort aggregation only',
        source_hashes=manifest['source_hashes'],
        native_report_unchanged=True,
        planned_queries=90, conditions=360,
        statuses=dict(Counter(r['status'] for r in rows)),
        common_four_arm_ids=sorted(common),
        common_four_arm_counts_by_dataset=dict(Counter(inputs[i]['dataset'] for i in common)),
        common_four_arm=section,
        common_four_arm_ordinary_present=ordinary_section,
        primary_N128_R256_planned90=primary_section,
        technical_missing=[r for r in rows if r['f1'] is None],
        goal_only_noop_checks=goal_only,
        common_cohort_stage_logical_usage_totals=stage_usage,
        token_scope='Logical use in matched quality-terminal conditions, including algorithm-terminal prefixes; excludes unknown attempts, GPU and decomposer',
        primary_comparison='Use native REPORT N128_to_R256 over all available paired queries; never silently shrink it to the four-arm cohort')
    path = p.OUT / 'COMMON_COMPLETE_COMPARISON.json'
    assert not path.exists(), 'Supplement already exists; inspect before overwriting'
    p.atomic_json(path, output)
    print(json.dumps(dict(output=str(path), common_queries=len(common),
        statuses=output['statuses'], goal_only_all_same=all(r['all_four_same'] for r in goal_only)), ensure_ascii=False))


if __name__ == '__main__':
    main()
