"""Read-only SSH resource preflight; credential stays in transient memory."""
import getpass
import json
from datetime import datetime, timezone
from pathlib import Path
import shlex

import paramiko

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/query_decomposition/p02_prompt_research_v1_20261022"

CODE = """import os,json,subprocess,hashlib
base='/home/projects/u7830488/robustness_models_retrievers_v1_20261017'
paths={ds:base+'/resources/'+ds+'/manifest.json' for ds in ['hotpotqa','2wiki','musique']}
v={'hostname':os.uname().nodename,'manifests':{},'new_job_submitted':False}
for ds,p in paths.items():
 v['manifests'][ds]={'path':p,'exists':os.path.isfile(p)}
 if os.path.isfile(p):
  b=open(p,'rb').read();v['manifests'][ds].update(sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),manifest=json.loads(b))
for label,args in [('own_jobs',['squeue','-h','-u','u7830488','-o','%i|%j|%T|%N|%b']),('visible_gpu',['nvidia-smi','--query-gpu=index,name,memory.used,memory.total','--format=csv,noheader'])]:
 try:
  p=subprocess.run(args,capture_output=True,text=True,timeout=10);v[label]={'returncode':p.returncode,'stdout':p.stdout[:5000],'stderr':p.stderr[:600]}
 except Exception as e:v[label]={'error_type':type(e).__name__}
print(json.dumps(v))
"""


def main():
    password = getpass.getpass("Remote password: ")
    client = paramiko.SSHClient()
    client.load_system_host_keys()
    client.set_missing_host_key_policy(paramiko.RejectPolicy())
    try:
        client.connect("cluster1.comp.anu.edu.au", username="u7830488", password=password,
                       look_for_keys=False, allow_agent=False, timeout=12, auth_timeout=15, banner_timeout=12)
        password = None
        _, stdout, stderr = client.exec_command("python3 -c " + shlex.quote(CODE), timeout=30)
        value = json.loads(stdout.read().decode())
        assert stdout.channel.recv_exit_status() == 0
        value.update(connected=True, read_only=True, main_evaluation_resumed=False)
    except Exception as error:
        value = dict(connected=False, error_type=type(error).__name__, read_only=True,
                     new_job_submitted=False, main_evaluation_resumed=False)
    finally:
        client.close()
        password = None
    value["utc"] = datetime.now(timezone.utc).isoformat()
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "REMOTE_RETRIEVAL_PREFLIGHT_PASSWORD.json"
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    print(json.dumps({k: v for k, v in value.items() if k != "manifests"}, ensure_ascii=True))


if __name__ == "__main__":
    main()
