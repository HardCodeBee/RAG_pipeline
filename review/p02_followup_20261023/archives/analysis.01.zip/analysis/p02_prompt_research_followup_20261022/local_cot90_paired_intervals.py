"""Exploratory paired intervals from scores already verified by trace export.

No database, scorer, provider or execution state is changed. The completed
trace-export manifest binds REPORT/DETAILS/PAIRED and the frozen inputs; its
stable-snapshot checks are reused rather than implementing another DB audit.
"""
from collections import Counter
from copy import deepcopy
from pathlib import Path
import argparse
import json
import math
import random
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from experiments.query_decomposition.p02_local_cot_fixed90_v1_20261022 import preparation as p
from experiments.query_decomposition.p02_local_cot_fixed90_v1_20261022.score import COMPARISONS, DATASETS


def quantile(values, q):
    values = sorted(values); where = (len(values) - 1) * q
    lo = math.floor(where); hi = math.ceil(where)
    return values[lo] + (values[hi] - values[lo]) * (where - lo)


def interval(groups, metric, repetitions=10000):
    assert groups and all(values for values in groups.values())
    assert type(repetitions) is int and repetitions > 0
    rng = random.Random(20261022)
    arrays = [[r[metric] for r in groups[d]] for d in sorted(groups)]
    assert all(type(v) in (int, float) and math.isfinite(v) and -1 <= v <= 1 for a in arrays for v in a)
    means = [sum(a) / len(a) for a in arrays]
    samples = [sum(sum(rng.choice(a) for _ in a) / len(a) for a in arrays) / len(arrays)
               for _ in range(repetitions)]
    return dict(delta=sum(means) / len(means), percentile95=[quantile(samples, .025), quantile(samples, .975)],
        complete_pairs_by_dataset={d: len(a) for d, a in sorted(groups.items())},
        repetitions=repetitions, seed=20261022, weighting="equal dataset weight; paired queries resampled within dataset",
        percentile_scope="Conditional on available pairs; does not account for technical missingness")


def validate_export_index(manifest, index, inputs, report):
    assert manifest["schema"] == "local_cot90_trace_export_v1"
    assert manifest["experiment"] == p.HERE.name
    assert manifest["queries"] == 90 and manifest["conditions"] == 360 and manifest["goal_only"] == 6
    assert len(inputs) == len(index) == 90 and len({r["id"] for r in index}) == 90
    assert Counter(r["dataset"] for r in inputs.values()) == {d: 30 for d in DATASETS}
    assert sum(not r["supporting_questions"] for r in inputs.values()) == 6
    assert set(inputs) == {r["id"] for r in index}
    for row in index:
        assert row["dataset"] == inputs[row["id"]]["dataset"]
        assert row["goal_only"] is (not inputs[row["id"]]["supporting_questions"])
    assert report["checkpoint_in_flight_at_snapshot"] == 0
    assert report["all_planned"]["planned_queries"] == 90
    assert report["ordinary_present_sensitivity"]["planned_queries"] == 84
    for key, value in manifest["official_report_summary"].items():
        assert report[key] == value, "Official report differs from completed trace export"


def unchanged_sources(sources, root=ROOT):
    assert all(p.sha(root / name) == expected for name, expected in sources.items()), "Score/input files differ from verified trace export"


def summarize_pairs(pairs, inputs, report, repetitions=10000):
    """Pure arithmetic over official paired deltas; no metric factory is called."""
    assert all(r["id"] in inputs and r["dataset"] == inputs[r["id"]]["dataset"] for r in pairs)
    assert all((r["reference_arm"], r["candidate_arm"]) in COMPARISONS for r in pairs)
    results = {}
    for reference, candidate in COMPARISONS:
        comparison = reference + "_to_" + candidate
        selected = [r for r in pairs if r["reference_arm"] == reference and r["candidate_arm"] == candidate]
        assert len({r["id"] for r in selected}) == len(selected)
        assert len(selected) == report["paired_predeclared"][comparison]["complete_pairs"]
        sections = {}
        for section in ("all90", "ordinary_present84"):
            planned_ids = {ident for ident, item in inputs.items() if section == "all90" or item["supporting_questions"]}
            assert len(planned_ids) == (90 if section == "all90" else 84)
            values = [r for r in selected if r["id"] in planned_ids]
            groups = {d: [r for r in values if r["dataset"] == d] for d in DATASETS}
            planned = {d: sum(inputs[ident]["dataset"] == d for ident in planned_ids) for d in DATASETS}
            available = {d: len(groups[d]) for d in DATASETS}
            official = report["all_planned"] if section == "all90" else report["ordinary_present_sensitivity"]
            official_macro = official["paired_equal_weight_dataset_macro"][comparison]
            assert len(values) == official["paired_predeclared"][comparison]["complete_pairs"]
            for d in DATASETS:
                dataset_pair = official["paired_by_dataset"][comparison][d]
                assert dataset_pair["planned"] == planned[d] and dataset_pair["complete_pairs"] == available[d]
                assert dataset_pair["missing_pairs"] == planned[d] - available[d]
            partial = len(values) != len(planned_ids)
            assert official_macro["available_macro_is_partial"] is partial
            macro, by_dataset = {}, {d: {} for d in DATASETS}
            for metric in ("delta_F1", "delta_EM"):
                result = interval(groups, metric, repetitions) if all(groups.values()) else None
                expected = official_macro[metric + "_available"]
                assert (result is None and expected is None) or (result is not None and math.isclose(result["delta"], expected, abs_tol=1e-12))
                if result is not None:
                    result.update(available_macro_is_partial=partial,
                        delta_complete_planned=result["delta"] if not partial else None,
                        fixed_denominator_mean_bounds=[sum(official["paired_by_dataset"][comparison][d][metric + "_fixed_denominator_bounds"][i] for d in DATASETS) / len(DATASETS) for i in (0, 1)])
                macro[metric] = result
                for d, observed in groups.items():
                    result = interval({d: observed}, metric, repetitions) if observed else None
                    expected = official["paired_by_dataset"][comparison][d][metric]
                    assert (result is None and expected is None) or (result is not None and math.isclose(result["delta"], expected, abs_tol=1e-12))
                    if result is not None:
                        result.update(planned_pairs=planned[d], missing_pairs=planned[d] - available[d],
                            delta_complete_planned=result["delta"] if available[d] == planned[d] else None,
                            fixed_denominator_mean_bounds=official["paired_by_dataset"][comparison][d][metric + "_fixed_denominator_bounds"])
                    by_dataset[d][metric] = result
            sections[section] = dict(
                available_pairs=len(values), planned=len(planned_ids), missing_pairs=len(planned_ids) - len(values),
                planned_pairs_by_dataset=planned, available_pairs_by_dataset=available,
                available_pair_estimate_is_partial=partial, complete_planned=not partial,
                scope="Exploratory available-pair estimate; technical missingness is not imputed" if partial else "Exploratory complete planned-cohort paired estimate",
                macro=macro, by_dataset=by_dataset)
        results[comparison] = sections
    return results


def main():
    p.check()
    import export_local_cot90_trace_review as exporter
    # Do not read quality until both operational completion and a successful,
    # stable trace export exist. The exporter already binds DB to all scores.
    assert (p.OUT / "STATUS.json").is_file() and exporter.ready(p.read(p.OUT / "STATUS.json")), "CoT360 is not complete/zero-in-flight"
    manifest_path, index_path = exporter.EXPORT / "SUMMARY.json", exporter.EXPORT / "INDEX.jsonl"
    assert manifest_path.is_file() and index_path.is_file(), "Run the completed trace exporter first"
    manifest_hash, index_hash = p.sha(manifest_path), p.sha(index_path)
    manifest = p.read(manifest_path)
    sources = manifest["source_hashes"]
    required = {p.rel(p.OUT / name) for name in ("STATUS.json", "REPORT.json", "DETAILS.jsonl", "PAIRED.jsonl")}
    required.update(p.rel(path) for path in (p.INPUTS, p.ORDER, p.PROTOCOL))
    assert required <= set(sources), "Trace export lacks required source bindings"
    unchanged_sources(sources)
    report, pairs = p.read(p.OUT / "REPORT.json"), p.rows(p.OUT / "PAIRED.jsonl")
    input_rows = p.rows(p.INPUTS)
    inputs = {r["id"]: r for r in input_rows}
    assert len(inputs) == len(input_rows)
    validate_export_index(manifest, p.rows(index_path), inputs, report)
    for report_key, path in (("protocol_sha256", p.PROTOCOL), ("input_sha256", p.INPUTS), ("order_sha256", p.ORDER)):
        assert report[report_key] == sources[p.rel(path)]
    results = summarize_pairs(pairs, inputs, report)
    assert manifest_hash == p.sha(manifest_path) and index_hash == p.sha(index_path), "Trace manifest/index changed during interval calculation"
    unchanged_sources(sources)
    output = Path(__file__).with_name("LOCAL_COT90_PAIRED_INTERVALS.json")
    p.atomic_json(output, dict(scope="Exploratory exposed-development inference; no multiplicity correction or held-out generalization claim",
        primary_comparison="N128_to_R256", source_hashes=sources, script_sha256=p.sha(__file__),
        verified_trace_export=dict(manifest=p.rel(manifest_path), manifest_sha256=manifest_hash, index_sha256=index_hash,
            sqlite_snapshot_sha256=manifest["sqlite_snapshot_sha256"]),
        algorithm_failures_retain_official_zero=True, technical_missing_never_zero=True,
        sampling_unit="original query", comparisons=results))
    print(json.dumps(dict(output=p.rel(output), primary=results["N128_to_R256"]), ensure_ascii=True))


def self_test():
    groups = {d: [dict(delta_F1=0.25)] * n for d, n in zip(DATASETS, (2, 3, 4))}
    assert interval(groups, "delta_F1", 100)["percentile95"] == [.25, .25]
    opposite = {"a": [dict(delta_F1=-1)] * 9, "b": [dict(delta_F1=1)]}
    assert interval(opposite, "delta_F1", 100)["delta"] == 0
    mixed = {"a": [dict(delta_F1=-1), dict(delta_F1=1)]}
    a = interval(mixed, "delta_F1", 100)
    assert a == interval(mixed, "delta_F1", 100) and a["percentile95"][0] < 0 < a["percentile95"][1]
    assert quantile([0, 1], .5) == .5
    from experiments.query_decomposition.p02_local_cot_fixed90_v1_20261022.score import aggregate_report
    inputs, details = [], []
    # Synthetic goal-only allocation: 0/4/2, ensuring ordinary84 is not 28/28/28.
    for dataset, goal_count in zip(DATASETS, (0, 4, 2)):
        for i in range(30):
            item = dict(id=dataset + ":synthetic" + str(i), dataset=dataset,
                        supporting_questions=[] if i < goal_count else ["Synthetic child?"])
            inputs.append(item)
            for arm in ("N128", "N256", "F256", "R256"):
                score = .4 if arm != "R256" else {DATASETS[0]: .6, DATASETS[1]: .3, DATASETS[2]: .45}[dataset]
                status = "algorithm_failure" if dataset == DATASETS[0] and i == 0 and arm == "N128" else "success"
                if status == "algorithm_failure": score = 0.0
                usage = dict(prompt_tokens=1, completion_tokens=1, total_tokens=2)
                details.append(dict(id=item["id"], dataset=dataset, arm=arm, status=status, f1=score, em=0.0,
                    native_full_correct=False, full_flow_logical_usage=usage, full_flow_logical_estimated_CNY=0.0))
    report, pairs = aggregate_report(details, inputs, [])
    report["checkpoint_in_flight_at_snapshot"] = 0
    mapping = {r["id"]: r for r in inputs}
    results = summarize_pairs(pairs, mapping, report, 30)
    section = results["N128_to_R256"]
    assert section["all90"]["available_pairs"] == 90 and section["ordinary_present84"]["available_pairs"] == 84
    assert section["ordinary_present84"]["planned_pairs_by_dataset"] == dict(zip(DATASETS, (30, 26, 28)))
    assert math.isclose(section["all90"]["macro"]["delta_F1"]["delta"], report["paired_predeclared"]["N128_to_R256"]["delta_F1"], abs_tol=1e-12)
    assert not math.isclose(section["ordinary_present84"]["macro"]["delta_F1"]["delta"], report["ordinary_present_sensitivity"]["paired_predeclared"]["N128_to_R256"]["delta_F1"], abs_tol=1e-12)
    assert any(r["id"] == DATASETS[0] + ":synthetic0" and r["delta_F1"] == .6 for r in pairs if r["reference_arm"] == "N128" and r["candidate_arm"] == "R256")
    # One ordinary and one goal-only technical absence must stay missing.
    for row in details:
        if row["arm"] == "R256" and row["id"] in (DATASETS[1] + ":synthetic5", DATASETS[2] + ":synthetic0"):
            row.update(status="technical_held", f1=None, em=None)
    partial_report, partial_pairs = aggregate_report(details, inputs, [])
    partial = summarize_pairs(partial_pairs, mapping, partial_report, 30)["N128_to_R256"]
    assert partial["all90"]["available_pairs"] == 88 and partial["all90"]["missing_pairs"] == 2
    assert partial["ordinary_present84"]["available_pairs"] == 83 and partial["ordinary_present84"]["missing_pairs"] == 1
    assert partial["all90"]["macro"]["delta_F1"]["delta_complete_planned"] is None
    assert partial["all90"]["macro"]["delta_F1"]["available_macro_is_partial"]
    empty_dataset = deepcopy(details)
    for row in empty_dataset:
        if row["arm"] == "R256" and row["dataset"] == DATASETS[2]:
            row.update(status="technical_held", f1=None, em=None)
    empty_report, empty_pairs = aggregate_report(empty_dataset, inputs, [])
    empty = summarize_pairs(empty_pairs, mapping, empty_report, 5)["N128_to_R256"]["all90"]
    assert empty["macro"]["delta_F1"] is None and empty["by_dataset"][DATASETS[2]]["delta_F1"] is None
    index = [dict(id=r["id"], dataset=r["dataset"], goal_only=not r["supporting_questions"]) for r in inputs]
    manifest = dict(schema="local_cot90_trace_export_v1", experiment=p.HERE.name, queries=90, conditions=360, goal_only=6,
        official_report_summary={k: report[k] for k in ("arms", "by_dataset", "paired_predeclared", "ordinary_present_sensitivity")})
    validate_export_index(manifest, index, mapping, report)
    rejected = []
    for name, operation in (
        ("wrong dataset mapping", lambda: summarize_pairs([{**pairs[0], "dataset": "wrong"}] + pairs[1:], mapping, report, 5)),
        ("stale delta", lambda: summarize_pairs([{**pairs[0], "delta_F1": .9}] + pairs[1:], mapping, report, 5)),
        ("duplicate pair", lambda: summarize_pairs(pairs + [pairs[0]], mapping, report, 5)),
        ("in-flight score snapshot", lambda: validate_export_index(manifest, index, mapping, {**report, "checkpoint_in_flight_at_snapshot": 1})),
        ("stale partial report", lambda: validate_export_index(manifest, index, mapping, {**partial_report, "checkpoint_in_flight_at_snapshot": 0})),
        ("wrong goal-only index", lambda: validate_export_index(manifest, [{**index[0], "goal_only": True}] + index[1:], mapping, report)),
    ):
        try: operation()
        except AssertionError: rejected.append(name)
        else: raise AssertionError("Invalid fixture accepted: " + name)
    with tempfile.TemporaryDirectory(prefix="cot90_interval_synthetic_") as directory:
        root = Path(directory)
        artifact = root / "synthetic_score.json"
        artifact.write_text('{"synthetic":true}', encoding="utf8")
        sources = {artifact.name: p.sha(artifact)}
        unchanged_sources(sources, root)
        artifact.write_text('{"synthetic":false}', encoding="utf8")
        try: unchanged_sources(sources, root)
        except AssertionError: rejected.append("source changed after trace export")
        else: raise AssertionError("Changed verified source accepted")
    return dict(passed=True, checks=["constant paired effect", "macro not query-count weighted", "seed reproducibility and crossing zero", "linear percentile",
        "official aggregate schema with complete90 and ordinary84", "six goal-only kept in primary", "algorithm zero retained",
        "technical missing is available-pair estimate not complete cohort", "empty dataset leaves macro unavailable", *rejected],
        real_quality_or_checkpoint_read=False, API_SSH_GPU_calls=0, frozen_files_changed=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("--self-test", action="store_true")
    if parser.parse_args().self_test: print(json.dumps(self_test()))
    else: main()
