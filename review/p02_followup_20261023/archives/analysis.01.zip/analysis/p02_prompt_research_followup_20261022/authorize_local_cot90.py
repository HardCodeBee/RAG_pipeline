"""Root-reviewed authorization under the user's standing small-experiment scope."""
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from experiments.query_decomposition.p02_local_cot_fixed90_v1_20261022 import preparation as p


def main():
    review_path = Path(__file__).with_name("LOCAL_COT_FIXED90_FINAL_CONTROLLER_REMOTE_SCORING_REVIEW.json")
    review = p.read(review_path)
    assert p.sha(review_path) == "4b1a71b6c98656602504f4dce90bd0f0fb8bc43bef4c6cbc70a595a23b4d1841"
    for name, expected in review["source_and_receipt_sha256"].items():
        assert p.sha(p.HERE / name) == expected, name
    p.check_test_receipts()
    frozen = p.freeze()
    decision_id = "P02_LOCAL_COT_FIXED90_FOUR_ARMS_EXECUTION_APPROVED_20261022"
    decisions_path = p.PLAN / "DECISIONS.jsonl"
    assert not any(row.get("id") == decision_id for row in p.rows(decisions_path))
    assert not (p.HERE / "RUN_AUTHORIZATION.json").exists()
    stamp = datetime.now(timezone.utc).isoformat()
    auth = dict(approved=True, experiment=p.HERE.name, decision_id=decision_id, utc=stamp,
        authority="P02_PROMPT_RESEARCH_AUTONOMOUS_SMALL_EVALUATIONS_APPROVED_20261022; latest request for progressive subquestion CoT",
        protocol_sha256=frozen["protocol_sha256"], approved_conditions=360, approved_queries=90,
        arms=list(p.ARMS), maximum_technical_attempts=5, current_namespace_returnless_recovery_only=True,
        preserve_all_unknown_reservations=True, existing_held_auto_replay=False,
        root_independent_review="Exact native and ordinary-only boundaries, own Answer-driven history, Support isolation, durable retries/ledger, source-pinned tests, production bridge startup and predecessor closure, scorer denominators reviewed; all offline suites passed.",
        independent_review=p.rel(review_path), independent_review_sha256=p.sha(review_path),
        prerequisite="CoT stage152 plus reference360 fully attempted, zero in flight, all original/continuation reference allocations closed",
        initial_engineering_conditions=24, quality_selects_conditions=False,
        remote_gpu="independent A6000 query-only retrieval allocation after predecessor closure",
        automatic_additional_GPU_allocation=False, no_historical_LLM_seed=True,
        support_forwarded=False, frozen_R02_decomposition=True,
        main_evaluation_resumed=False, baselines_or_timing_resumed=False,
        production_method_promoted=False, publication=False)
    p.atomic_json(p.HERE / "RUN_AUTHORIZATION.json", auth)
    decision = dict(auth, id=decision_id, authorization_sha256=p.sha(p.HERE / "RUN_AUTHORIZATION.json"))
    with decisions_path.open("a", encoding="utf8") as stream:
        stream.write(json.dumps(decision, ensure_ascii=False) + "\n")
    from experiments.query_decomposition.p02_local_cot_fixed90_v1_20261022 import run
    run.authorized()
    print(json.dumps(dict(state="frozen_and_authorized_not_started", protocol_sha256=frozen["protocol_sha256"],
        authorization_sha256=p.sha(p.HERE / "RUN_AUTHORIZATION.json"), predecessor=run.predecessors.status()), ensure_ascii=True))


if __name__ == "__main__":
    main()
