# stat→open→stat探针：解释边界与只读辅助风险

背景：owner已报告9个MuSiQue请求的远端request→response mtime差为0或1秒，response mtime至本地回执为11.5–60.6秒。结合包内约0.14秒的搜索计时，可将搜索计算与其余开销分开。**mtime可能继承自临时文件写入，不证明最终response已rename发布**；还不能单凭这些时间将剩余开销全部归入发布后的文件发现。需排除并发发布、时钟/分辨率限制及自然缓存到期。

## 能够验证什么

在**原controller的同一login主机/内核、同一挂载路径**上，对同一个已经生成的不可变response按时间记录：首次stat结果/errno、只读open结果、再stat结果。若先stat=ENOENT，而open读到完整匹配响应，随后stat成功，强烈支持不同lookup操作的缓存重验行为：open可能使负目录项失效或重新查找。不同SSH进程通常仍共享同一内核的文件系统缓存，不要求共用原SFTP对象。

若另一login节点open成功、原节点仍失败，只能证明跨客户端可见性不同；不能证明原controller缓存已刷新。若stat和open都暂时失败，不能排除缓存问题。若同时成功，只说明该时点文件已经可见，不能定位此前延迟。一次open后原controller变快也只是技术路径证据，不能外推所有请求。

POSIX调用名称不规定所有共享文件系统的跨客户端一致性，NFS的close-to-open与负查找重验又受版本、mount及服务器行为影响。未核实实际文件系统前应称“共享文件系统lookup/可见性问题”，不能直接断言NFS的某个30秒参数。

本地已安装Paramiko4.0.0的`SFTPClient.stat`直接发`CMD_STAT`（`sftp_client.py:493`），`open`发`CMD_OPEN`（`:372`）；这两处未见Python端结果缓存。因此若稳定重现差异，应优先查SFTP服务/底层文件系统，不把现有0.5秒Python轮询间隔误当30秒来源。该静态检查未连接远端。

## 持续只读open作为辅助是否改变质量/协议

若只针对当前owned job已登记request ID、只读最终response文件，原controller仍独立读取并通过同一request/identity/resource/k/packet验证，则没有直接改变问题、证据字节、排序、方法提示词、采样或账务的理由。原始响应及成功缓存不覆盖，不新增检索或API，不触碰临时文件或unknown记录。

但这属于**可能主动促成可见性的工程辅助**，不是完全无影响的观察：可能刷新共享内核缓存，减少等待，改变后续调用时序；读操作也可能更新atime。须记录辅助的主机、路径、起止、适用规则、成功/失败计数及未改科学配置，不能混入正式时延/TTFT或宣称纯计算加速。对所有同类新response按固定规则执行，不能依据答案或分数选择。

最小保护：保持≤180秒或root明定的观测窗口与温和轮询；只用`O_RDONLY`/`rb`，不touch、utime、chmod或改mount；半写/未知内容只报告，不替controller提交packet或改变错误处理。不要从另一个线程共用正在交换消息的controller SFTPClient，避免协议流并发混淆；在同host既有观测连接/独立channel上读取即可。保持原STOP、原worker/作业与完成条件，不自动重投或换job。

本页仅解释技术探针与候选辅助；未实现辅助、未开新SSH/API/GPU、未修改冻结worker/桥或运行文件。root需依据真实探针结果决定是否记录并继续此工程措施。
