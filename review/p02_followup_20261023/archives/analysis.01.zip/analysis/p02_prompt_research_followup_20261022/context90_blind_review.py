"""Root-only, read-only outcome projection for the shared-context fixed90.

No Cache, provider, GPU, SSH, scoring or gold/reference loader. Reviewers receive
only PACKET.json and must not open this experiment's method key or endpoints.
This new helper does not import or modify round2.py.
"""
from collections import Counter
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import secrets
import sqlite3

ROOT = Path(__file__).resolve().parents[2]
B = ROOT / "experiments/query_decomposition/p02_shared_context_fixed90_v1_20261022"
P = ROOT / "outputs/query_decomposition" / B.name
ARMS = ("reset", "flat", "chat")
TERMINAL = ("success", "success_truncated", "algorithm_failure")


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def rows(path):
    return [json.loads(s) for s in Path(path).read_text(encoding="utf-8-sig").splitlines() if s.strip()]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def textsha(value):
    return hashlib.sha256(value.encode()).hexdigest() if isinstance(value, str) else None


def utc():
    return datetime.now(timezone.utc).isoformat()


def rel(path):
    return str(Path(path).resolve().relative_to(ROOT)).replace("\\", "/")


def write_new(path, value):
    path = Path(path)
    assert not path.exists(), "Immutable review artifact already exists: " + rel(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def classify(inputs, outcomes):
    """Pure classification; no missing condition is a zero or a text tie."""
    index = {(r["id"], r["arm"]): r for r in outcomes}
    assert len(index) == len(outcomes)
    expected = {(r["id"], a) for r in inputs for a in ARMS}
    assert set(index) <= expected
    assert all(r["status"] in TERMINAL and isinstance(r["prediction"], str) for r in outcomes)
    complete = [r["id"] for r in inputs if all((r["id"], a) in index for a in ARMS)]
    changed = [i for i in complete if len({index[i, a]["prediction"] for a in ARMS}) > 1]
    same = [i for i in complete if i not in set(changed)]
    incomplete = {r["id"]: [a for a in ARMS if (r["id"], a) not in index] for r in inputs if r["id"] not in set(complete)}
    return index, dict(complete_triple_ids=complete, text_different_triple_ids=changed,
        identical_text_triple_ids=same, incomplete_triples_missing_arms=incomplete)


def snapshot():
    inputs = rows(B / "INPUTS90.jsonl")
    assert len(inputs) == len({r["id"] for r in inputs}) == 90
    assert Counter(r["dataset"] for r in inputs) == {ds: 30 for ds in ("hotpotqa", "2wiki", "musique")}
    with closing(sqlite3.connect((P / "checkpoint.sqlite3").resolve().as_uri() + "?mode=ro", uri=True)) as db:
        db.execute("BEGIN")
        outcomes = [json.loads(v) for (v,) in db.execute("SELECT value FROM data WHERE kind='outcome' ORDER BY rowid")]
        db.commit()
    index, scope = classify(inputs, outcomes)
    return inputs, outcomes, index, scope


def prepare(batch, limit=None):
    assert batch.isidentifier() and batch.startswith("batch")
    inputs, outcomes, index, scope = snapshot()
    target = P / "root_blind_review" / batch
    assert not target.exists()
    previous = {r["case_id"] for p in (P / "root_blind_review").glob("batch*/PACKET.json") for r in read(p)["cases"]}
    selected = [i for i in scope["text_different_triple_ids"] if i not in previous]
    if limit is not None:
        assert limit > 0
        selected = selected[:limit]
    assert selected, "No new complete, text-different triples; do not select by F1 or a two-arm partial result"
    data = {r["id"]: r for r in inputs}
    packets, methods = [], []
    rng = secrets.SystemRandom()
    for i in selected:
        order = list(ARMS)
        rng.shuffle(order)
        candidates = []
        for arm in order:
            outcome = index[i, arm]
            context = outcome.get("trajectory", {}).get("final_context")
            if outcome["status"] in ("success", "success_truncated"):
                assert isinstance(context, str)
                assert outcome["trajectory"]["question"] == data[i]["question"]
            else:
                assert context is None, "A stage-terminal flow must not invent a final-visible context"
            opaque = "c" + secrets.token_hex(8)
            candidates.append(dict(candidate_id=opaque, text=outcome["prediction"], final_visible_context=context,
                actual_final_answer_completed=outcome["status"] in ("success", "success_truncated")))
            final_request = next((s["request_id"] for s in outcome.get("stages", []) if s["stage"] == "legacy/final"), None)
            methods.append(dict(case_id=i, candidate_id=opaque, arm=arm, task_id=outcome["task_id"],
                outcome_sha256=digest(outcome), source_request_id=final_request, outcome_status=outcome["status"]))
        packets.append(dict(case_id=i, dataset=data[i]["dataset"], original_question=data[i]["question"], candidates=candidates))
    packet = dict(kind="shared_context90_final_text_different_complete_triples",
        selection="Every completed triple whose three final texts are not all identical; all3 candidates included, independent of native/gold. No output-dependent expansion or model update.",
        context_rule="Only each candidate's actual final_visible_context and original question. Hidden goal/ordinary readers, transcripts and reference answers are not added.",
        truth_rule="Judge the full original-question entity/relation/attribute/conditions. Keep true-but-incomplete lists, responsive answers and reasonable evidence-insufficiency abstentions distinct from necessary information. Unsupported is not proved false; unresolved facts remain concrete pending work items. Official F1/EM is a separate endpoint.",
        reviewer_rule="Disclose prior case/design exposure; not independent human gold. Review only this PACKET. Do not open METHOD_KEY, checkpoint, REPORT, DETAILS, PAIRED, gold or new endpoints. Submit immutable SEMANTIC_REVIEWS.blinded.jsonl and its SHA before root maps arms.",
        required_fields=["case_id", "candidate_id", "packet_sha256", "candidate_text_sha256", "final_visible_context_sha256", "factual_correct", "addresses_actual_question", "necessary_information_retained", "entity_role_or_scope_error", "reason_with_input_evidence", "pending_work_items", "reviewer_exposure_disclosure"],
        partial_triples_not_treated_as_ties=True, cases=packets)
    write_new(target / "PACKET.json", packet)
    write_new(target / "METHOD_KEY.local.json", methods)
    lock = dict(utc=utc(), cases=len(packets), candidates=3 * len(packets),
        packet_sha256=sha(target / "PACKET.json"), method_key_sha256=sha(target / "METHOD_KEY.local.json"),
        no_native_gold_or_method_labels_in_packet=True, all3_included_per_selected_complete_triple=True,
        full_scope_is_provisional_until_runloop_end=True)
    write_new(target / "PACKET_LOCK.json", lock)
    return dict(packet=rel(target / "PACKET.json"), **lock)


def lock_reviews(batch, expected_review_sha):
    """Lock first labels WITHOUT parsing the method key."""
    folder = P / "root_blind_review" / batch
    review_path = folder / "SEMANTIC_REVIEWS.blinded.jsonl"
    packet_path = folder / "PACKET.json"
    packet_lock = read(folder / "PACKET_LOCK.json")
    assert sha(review_path) == expected_review_sha and sha(packet_path) == packet_lock["packet_sha256"]
    packet = read(packet_path)
    candidates = {(r["case_id"], c["candidate_id"]): c for r in packet["cases"] for c in r["candidates"]}
    labels = rows(review_path)
    label_index = {(r["case_id"], r["candidate_id"]): r for r in labels}
    assert len(label_index) == len(labels) == len(candidates) and set(label_index) == set(candidates)
    for k, label in label_index.items():
        assert "arm" not in label and "root_derived_final_fact_and_response_correct" not in label
        c = candidates[k]
        assert label["packet_sha256"] == packet_lock["packet_sha256"]
        assert label["candidate_text_sha256"] == textsha(c["text"])
        assert label["final_visible_context_sha256"] == textsha(c["final_visible_context"])
        assert isinstance(label.get("reason_with_input_evidence"), str) and label["reason_with_input_evidence"].strip()
        disclosure = label.get("reviewer_exposure_disclosure", label.get("reviewer_exposure"))
        assert isinstance(disclosure, str) and disclosure.strip()
        for name in ("factual_correct", "addresses_actual_question", "necessary_information_retained", "entity_role_or_scope_error"):
            assert label[name] is None or type(label[name]) is bool
        if label["factual_correct"] is None:
            assert label.get("pending_work_items"), "Preserve the unresolved fact and concrete work item rather than guessing"
    value = dict(utc=utc(), packet_sha256=sha(packet_path), review_sha256=sha(review_path),
        method_key_sha256=packet_lock["method_key_sha256"], records=len(labels),
        locked_before_root_method_join=True, key_not_parsed_by_lock_function=True,
        first_label_bytes_preserved=True)
    write_new(folder / "ROOT_REVIEW_LOCK.json", value)
    return value


def seal(root_runloop_finished=False, allow_unstarted=False):
    assert root_runloop_finished, "Root must first confirm the runloop stopped; do not seal a live changing population"
    inputs, outcomes, index, scope = snapshot()
    planned = {i["id"] + "/" + arm for i in inputs for arm in ARMS}
    complete_tasks = {r["task_id"] for r in outcomes}
    assert complete_tasks == {i + "/" + arm for i, arm in index}
    holds = [read(f) for f in (P / "held").glob("*.json")]
    held_tasks = {r["task_id"] for r in holds if r["task_id"] not in complete_tasks}
    assert held_tasks <= planned and not complete_tasks.intersection(held_tasks)
    unstarted = planned - complete_tasks - held_tasks
    assert not unstarted or allow_unstarted, "No implicit full90 completion when conditions never started"
    expected = {(i, a) for i in scope["text_different_triple_ids"] for a in ARMS}
    joined, covered, locks = [], set(), []
    folders = sorted((P / "root_blind_review").glob("batch*"))
    # Validate ALL first-review hashes and cohort coverage before parsing ANY key.
    prelocked_cases = set()
    for folder in folders:
        lock = read(folder / "ROOT_REVIEW_LOCK.json")
        assert lock["locked_before_root_method_join"] and lock["first_label_bytes_preserved"]
        assert sha(folder / "PACKET.json") == lock["packet_sha256"]
        assert sha(folder / "SEMANTIC_REVIEWS.blinded.jsonl") == lock["review_sha256"]
        assert sha(folder / "METHOD_KEY.local.json") == lock["method_key_sha256"]
        cases = read(folder / "PACKET.json")["cases"]
        assert all(len(c["candidates"]) == 3 for c in cases)
        case_ids = {c["case_id"] for c in cases}
        assert len(case_ids) == len(cases) and not prelocked_cases.intersection(case_ids)
        assert lock["records"] == 3 * len(cases)
        prelocked_cases.update(case_ids)
    assert prelocked_cases == set(scope["text_different_triple_ids"])
    for folder in folders:
        lock = read(folder / "ROOT_REVIEW_LOCK.json")
        packet_path, key_path = folder / "PACKET.json", folder / "METHOD_KEY.local.json"
        reviews_path = folder / "SEMANTIC_REVIEWS.blinded.jsonl"
        assert sha(packet_path) == lock["packet_sha256"] and sha(reviews_path) == lock["review_sha256"]
        assert sha(key_path) == lock["method_key_sha256"] == read(folder / "PACKET_LOCK.json")["method_key_sha256"]
        assert lock["locked_before_root_method_join"] and lock["first_label_bytes_preserved"]
        candidates = {(c["case_id"], v["candidate_id"]): v for c in read(packet_path)["cases"] for v in c["candidates"]}
        methods = {(r["case_id"], r["candidate_id"]): r for r in read(key_path)}
        labels = {(r["case_id"], r["candidate_id"]): r for r in rows(reviews_path)}
        assert set(candidates) == set(methods) == set(labels) and len(labels) == lock["records"]
        for k, label in labels.items():
            method = methods[k]
            pair = (k[0], method["arm"])
            assert pair in expected and pair not in covered
            outcome = index[pair]
            assert method["outcome_sha256"] == digest(outcome)
            assert candidates[k]["text"] == outcome["prediction"]
            assert candidates[k]["final_visible_context"] == outcome.get("trajectory", {}).get("final_context")
            # Derived interpretation never overwrites any first-review field.
            derived = (False if outcome["status"] == "algorithm_failure" else
                False if label["factual_correct"] is False or label["addresses_actual_question"] is False else
                True if label["factual_correct"] is True and label["addresses_actual_question"] is True else None)
            joined.append({**label, "arm": method["arm"], "outcome_status": outcome["status"],
                "root_derived_final_fact_and_response_correct": derived, "review_batch": folder.name})
            covered.add(pair)
        locks.append(dict(batch=folder.name, **lock))
    assert covered == expected, "Every final-text-different complete triple requires all3 first reviews locked"
    join_value = dict(reviewed_records=len(joined), planned_records=270, reviewed_triples=len(covered) // 3,
        method_difference_scope="Only complete triples whose final texts differ; all3 arms; no truth inferred for identical or missing outputs",
        not_independent_human_gold=True, prior_exposure_must_remain_disclosed=True,
        source_labels_unchanged=True, records=joined)
    seal_value = dict(utc=utc(), protocol_sha256=sha(B / "PROTOCOL.frozen.json"),
        planned_queries=90, planned_conditions=270, quality_terminal=len(outcomes),
        held_technical=len(held_tasks), held_task_ids=sorted(held_tasks), not_started=len(unstarted),
        not_started_task_ids=sorted(unstarted), all270_quality_terminal=len(outcomes) == 270,
        complete_triples=len(scope["complete_triple_ids"]), identical_text_triple_ids=scope["identical_text_triple_ids"],
        text_different_triple_ids=scope["text_different_triple_ids"], incomplete_triples_missing_arms=scope["incomplete_triples_missing_arms"],
        all_text_differences_in_complete_triples_semantically_locked=True, reviewed_records=len(joined),
        semantic_correctness_of_identical_or_missing_outputs_not_inferred=True,
        native_or_gold_used_for_scope_selection=False, locks=locks,
        outcome_digests={r["task_id"]: digest(r) for r in outcomes},
        limits="Final-text scope only, previously exposed90,3arms. Technical missing cannot become ties, zeros or semantic truth. No new model/candidate is selected by this helper.")
    write_new(P / "root_blind_review/SEMANTIC_JOIN.json", join_value)
    seal_value["semantic_join_sha256"] = sha(P / "root_blind_review/SEMANTIC_JOIN.json")
    write_new(P / "root_blind_review/ROOT_FINAL_DIFFERENCE_SCOPE_LOCK.json", seal_value)
    return {k: v for k, v in seal_value.items() if k not in ("locks", "outcome_digests")}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root-only", action="store_true", help="Reviewers must use only PACKET.json, not this root method-key helper")
    sub = parser.add_subparsers(dest="command", required=True)
    prep = sub.add_parser("prepare")
    prep.add_argument("--batch", required=True)
    prep.add_argument("--limit", type=int)
    lock = sub.add_parser("lock")
    lock.add_argument("--batch", required=True)
    lock.add_argument("--review-sha", required=True)
    finish = sub.add_parser("seal")
    finish.add_argument("--root-runloop-finished", action="store_true")
    finish.add_argument("--allow-unstarted", action="store_true", help="Explicit partial cessation only; missing task IDs remain visible, no full90 claim")
    args = parser.parse_args()
    assert args.root_only, "Root-only action; reviewers must never parse this experiment's method key"
    if args.command == "prepare":
        value = prepare(args.batch, args.limit)
    elif args.command == "lock":
        value = lock_reviews(args.batch, args.review_sha)
    else:
        value = seal(args.root_runloop_finished, args.allow_unstarted)
    print(json.dumps(value, ensure_ascii=True))
