"""Authorize the reviewed scheduling supplement only after real pause closure."""
from datetime import datetime, timezone
from pathlib import Path
import json
import cot90_priority_continuation as runtime

p = runtime.p


def main():
    review = Path(__file__).with_name("COT90_PRIORITY_CONTINUATION_INDEPENDENT_FINAL_REVIEW.json")
    assert p.sha(review) == "1c30dc65c05ff47e694c4d54986417c4352876757ef5ca5b390de818cd1a39b1"
    assert p.sha(runtime.__file__) == "82ce03055fc59d2a7a001ef572b62cbc4c5e02c97e40c8ce46b607395c68e41d"
    p.check()
    if not runtime.SNAPSHOT.exists(): runtime.snapshot()
    snapshot = p.read(runtime.SNAPSHOT)
    assert snapshot["metadata"] == runtime.base_pause_checks()
    assert snapshot["database"] == runtime.database_state()
    assert not runtime.AUTH.exists()
    decisions_path = p.PLAN / "DECISIONS.jsonl"
    assert not any(row.get("id") == runtime.DECISION for row in p.rows(decisions_path))
    auth = dict(approved=True, decision_id=runtime.DECISION, experiment=p.HERE.name,
        utc=datetime.now(timezone.utc).isoformat(),
        authority="User explicitly requests autonomous completion of the full90 four-arm CoT comparison and stage attribution",
        script_sha256=p.sha(runtime.__file__), protocol_sha256=p.sha(p.PROTOCOL),
        pause_snapshot_sha256=p.sha(runtime.SNAPSHOT), scheduler_only=True, approved_conditions=360,
        independent_review=p.rel(review), independent_review_sha256=p.sha(review),
        supersedes_only="Requirement to finish unrelated reference360 before CoT; reference remains partial and paused with real closure",
        preserved=["all90 frozen R02 questions", "four arms and ordinary caps", "native goal/rewrite/final", "own new Answer propagation", "max5 durable current-namespace returnless attempts", "all unknown reserves", "scoring and source pins", "one independent A6000 allocation"],
        reference_attempted=snapshot["metadata"]["reference90"]["attempted"], reference_complete=False,
        reference_auto_resume=False, main_evaluation_resumed=False, additional_paid_experiments=False)
    p.atomic_json(runtime.AUTH, auth)
    with decisions_path.open("a", encoding="utf8") as stream:
        stream.write(json.dumps(dict(auth, id=runtime.DECISION, authorization_sha256=p.sha(runtime.AUTH)), ensure_ascii=False) + "\n")
    state = runtime.priority_status()
    print(json.dumps(dict(approved=True, authorization_sha256=p.sha(runtime.AUTH), script_sha256=auth["script_sha256"],
        actual_state=state), ensure_ascii=True))


if __name__ == "__main__": main()
