"""Read-only closure evidence for the existing CoT90 allocation, after all 360 attempts."""
from pathlib import Path
from datetime import datetime, timezone
import getpass
import hashlib
import json
import shlex
import socket
import sqlite3

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/query_decomposition/p02_local_cot_fixed90_v1_20261022"
DEST = OUT / "worker_closure_161325"
AUTH = ROOT / "analysis/p02_prompt_research_followup_20261022/COT90_PRIORITY_EXECUTION_AUTHORIZATION.json"
DIRECTORY = "/home/projects/u7830488/p02_prompt_small_evals_20261022/cot90_222de9cd4f7dca85"
PROTOCOL = "222de9cd4f7dca8509ab6bf1e391a27634536d2cf0b0cdf0f0e42e9dcd256702"

def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def utc(): return datetime.now(timezone.utc).isoformat()

def main():
    import paramiko
    assert sha(AUTH) == "f8f4c307ed00263e00bcd04b18c32093f2afb32fe1d1187cc76c2fdebe3d535a"
    job = read(OUT / "REMOTE_JOB_ID.json")
    assert job["job_id"] == "161325" and job["directory"] == DIRECTORY and job["protocol_sha256"] == PROTOCOL
    assert read(OUT / "CONTROLLER_EXIT.json")["exit_code"] == 0
    with sqlite3.connect((OUT / "checkpoint.sqlite3").as_uri()+"?mode=ro", uri=True) as db:
        terminal = db.execute("SELECT count(*) FROM data WHERE kind='outcome'").fetchone()[0]
        in_flight = db.execute("SELECT count(*) FROM requests WHERE status='in_flight'").fetchone()[0]
    held = len(list((OUT / "held").glob("*.json")))
    assert terminal + held == 360 and in_flight == 0 and not DEST.exists()
    settings = read(ROOT / "experiments/query_decomposition/p02_local_cot_fixed90_v1_20261022/EXECUTION_SETTINGS.json")
    assert read(ROOT / settings["partition_preflight"])["verified_address"] == settings["verified_host_address"]
    client = paramiko.SSHClient(); client.load_system_host_keys(); client.set_missing_host_key_policy(paramiko.RejectPolicy())
    password = getpass.getpass("Remote password: "); connection = None
    try:
        connection = socket.create_connection((settings["verified_host_address"], 22), timeout=15)
        client.connect("cluster1.comp.anu.edu.au", username="u7830488", password=password, sock=connection,
            look_for_keys=False, allow_agent=False, timeout=15, auth_timeout=20, banner_timeout=15)
        password = None
        def command(argv):
            started = utc(); _, stdout, stderr = client.exec_command(shlex.join(argv), timeout=10)
            text, error = stdout.read().decode(), stderr.read().decode()
            return dict(argv=argv, started_utc=started, completed_utc=utc(), code=stdout.channel.recv_exit_status(), stdout=text, stderr=error)
        commands = {
            "squeue": command(["squeue", "-h", "-j", "161325", "-o", "%i|%T|%j"]),
            "sacct": command(["sacct", "-j", "161325", "-n", "-P", "-o", "JobIDRaw,JobName%40,State,User,Elapsed,Timelimit,ExitCode,NodeList"]),
            "scontrol": command(["scontrol", "show", "job", "-o", "161325"]),
        }
        parent = [line.split("|") for line in commands["sacct"]["stdout"].splitlines() if line.split("|", 1)[0] == "161325"]
        allowed_terminal = {"COMPLETED", "FAILED", "TIMEOUT", "CANCELLED", "NODE_FAIL", "OUT_OF_MEMORY", "PREEMPTED", "BOOT_FAIL", "DEADLINE", "REVOKED"}
        identity_ok = len(parent) == 1 and len(parent[0]) >= 8 and parent[0][1] == "p02-cot90" and parent[0][3] == "u7830488"
        state = parent[0][2].split()[0].rstrip("+") if identity_ok else None
        control = commands["scontrol"]["stdout"].split()
        workdir_ok = "WorkDir="+DIRECTORY in control and "JobId=161325" in control and any(v.startswith("UserId=u7830488(") for v in control)
        verified = all(c["code"] == 0 for c in commands.values()) and not commands["squeue"]["stdout"].strip() and identity_ok and workdir_ok and state in allowed_terminal
        DEST.mkdir(parents=True)
        files = {}
        with client.open_sftp() as sftp:
            sftp.get_channel().settimeout(10)
            for name in ("REMOTE_JOB.frozen.json", "READY.json", "FINISHED.json", "WORKER_ERROR.json"):
                try:
                    with sftp.open(DIRECTORY+"/"+name, "rb") as stream: raw = stream.read()
                except FileNotFoundError:
                    files[name] = dict(present=False); continue
                value = json.loads(raw)
                if name == "REMOTE_JOB.frozen.json": assert value["protocol_sha256"] == PROTOCOL and value["remote_directory"] == DIRECTORY
                if name == "READY.json": assert value["job_id"] == "161325" and value["protocol_sha256"] == PROTOCOL
                if name == "FINISHED.json": assert value["status"] == "stopped" and value["no_LLM_requests"] is True
                with (DEST / name).open("xb") as stream: stream.write(raw)
                files[name] = dict(present=True, sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
        result = dict(utc=utc(), job_id="161325", remote_directory=DIRECTORY, protocol_sha256=PROTOCOL,
            authorization_sha256=sha(AUTH), collector_sha256=sha(Path(__file__)), commands=commands,
            scheduler_terminal=dict(verified=verified, state=state, exact_owner_job_name=identity_ok, exact_workdir=workdir_ok),
            local_counts=dict(terminal=terminal, held=held, in_flight=in_flight), files=files,
            read_only_remote=True, remote_writes=0, new_jobs=0, API_requests=0)
        with (DEST / "COLLECTION.json").open("x", encoding="utf8") as stream: json.dump(result, stream, indent=2); stream.write("\n")
        print(json.dumps(dict(job_id="161325", scheduler_terminal=result["scheduler_terminal"], real_FINISHED_present=files["FINISHED.json"]["present"], artifact=str(DEST.relative_to(ROOT) / "COLLECTION.json"))), flush=True)
    finally:
        password = None; client.close()
        if connection: connection.close()

if __name__ == "__main__": main()
