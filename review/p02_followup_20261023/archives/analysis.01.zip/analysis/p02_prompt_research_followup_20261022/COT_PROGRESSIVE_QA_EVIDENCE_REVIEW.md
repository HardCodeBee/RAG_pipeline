# Evidence for a bounded ordinary-QA reasoning probe

Read-only synthesis, 2026-10-22. These are exposed development cohorts; no result below changes the main method or resumes formal evaluation.

| Completed comparison | Matched scope | Finding |
|---|---|---|
| Result-use notes D/B | 38 ordinary nodes, 37 adjudicated; raw answers only | Correct/wrong/pending: D 30/7/1, B 29/8/1. Zero repairs, one harm; necessary-information retention has two harms. No downstream F1 was measured. |
| G0/GF/GO | Same 90 frozen-prefix goal/final regenerations | F1/EM: G0 76.62/65.56, GF 73.76/63.33, GO 70.21/58.89. G0→GO: six gains, thirteen harms, seventy-one ties; −6.41 F1 points, stratified paired 95% interval [−11.50,−1.92]. |
| Earlier G2/I/F | Same 86 scorable questions, dataset-equal means | F1: 68.75/70.14/68.90. I−G2 +1.39 points, F−I −1.24 points; both intervals include zero. Four questions affected by technical holds are excluded, not scored zero. |
| Shared full context | Same 89 complete dynamic-RAG cases | Fresh reset F1/EM 76.43/67.42; flat 69.90/58.43, chat 71.59/60.67. Mean total tokens 9,679.7→17,646.0/17,656.8 (+82.3%/+82.4%). One flat technical hold excludes its matched case. |
| Factual goal plus role constraint | Selected 27 challenge cases | Fresh T0→T1 F1 32.8171→41.4590. Only two of four F1 gains were genuine generation-role fixes; two were answer-boundary/reference anomalies. Not a population estimate. |

Sources: outputs/query_decomposition/p02_result_binding_operator_probe_v1_20261022/{REPORT.md,CASE_NOTES.md,OFFLINE_AUDIT.json}; p02_goal_fewshot_fixed90_v1_20261022/REPORT.md; p02_shared_context_fixed90_v1_20261022/ROOT_FINAL_RESULTS.md; p02_goal_fact_role_probe_v1_20261022/fact27/ROOT_NATIVE_AND_PAIRED_AUDIT.md.

The operator experiment is complete: all 346 conditions returned (76 ordinary, 270 goal). Its G0/GF/GO arms share goal512/final64 and a neutral final wrapper; the historical native P02 reference has a different interface. GF→GO adds operation sentences and demonstration length, so it does not isolate an abstract reasoning mechanism. Goal+final costs/query are CNY 0.003694/0.004503/0.004654; these are logical component costs, not new full-RAG costs.

Useful failure mechanisms recur: adding an unnecessary role-specific condition can reject a valid answer (After Hours nomination); a correct fact in the body can be omitted from the conclusion (Golestan and the Caspian Sea); an explicit operation can select the wrong requested endpoint (river versus river delta). Conversely, deleting goal or its supplementary retrieval loses genuinely new facts. Longer explanations and explicit operations have therefore not established improvement. A correct answer can also coexist with incorrect support, so their correctness must be reviewed separately.

The reference/binding/priority ordinary probe has now attempted all 152 conditions with zero technical holds; the independent runtime audit passed. Its full semantic aggregate is not yet established here. The corresponding 360-flow full-RAG experiment remains separate; its results cannot be inferred from ordinary-stage completion.

The next narrow test changes ordinary QA only, using the same 38 frozen node inputs: native128, native256, factual-support256, and essential-operation-support256. Persist raw output, support, parsed Answer, and the accepted factual answer separately. Only Answer enters the unchanged native short-answer formatter; support never enters another model stage. This distinguishes output allowance, factual support, and local operation support without combining them with new retrieval, shared full-context history, or goal changes. Engineering checks do not select by semantic quality. Component labels, useful-information retention, full-response correctness, accepted-answer correctness, tokens, and costs must precede any claim about final F1. Full-RAG confirmation remains necessary.
