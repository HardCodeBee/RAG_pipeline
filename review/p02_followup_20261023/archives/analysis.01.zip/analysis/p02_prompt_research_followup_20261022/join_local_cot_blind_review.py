"""Join method identities only after the review labels and packet are hash-locked."""
from collections import Counter
from pathlib import Path
import argparse
import json
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "src"))
from experiments.query_decomposition.p02_local_cot_stage38_v1_20261022 import run as experiment


def join(batch, revision=1):
    assert batch in ("initial8", "supplemental30")
    folder = experiment.OUT / "root_blind_review" / batch
    lock = experiment.read(folder / "FIRST_REVIEW_LOCK.json")
    assert lock["method_identity_opened"] is False
    assert lock["review_labels_sha256"] == experiment.sha(folder / "REVIEW_LABELS.jsonl")
    assert lock["packet_sha256"] == experiment.sha(folder / "REVIEW_PACKET.jsonl")
    label_path = folder / "REVIEW_LABELS.jsonl"
    revision_note = None
    if revision == 2:
        revision_note = experiment.read(folder / "REVISION002_LOCK.json")
        label_path = folder / "REVIEW_LABELS.revision002.jsonl"
        assert revision_note.get("parent_review_sha256", revision_note.get("prior_labels_sha256")) == lock["review_labels_sha256"]
        assert revision_note["review_labels_sha256"] == experiment.sha(label_path)
    else: assert revision == 1
    labels = experiment.rows(label_path)
    assert len(labels) == len({r["candidate_id"] for r in labels}) == lock["candidates"]
    axes = ("complete_raw_response_correctness", "accepted_answer_correctness", "accepted_information")
    assert all(all(isinstance(r[k], str) and r[k] for k in axes) for r in labels)
    mapping = experiment.read(experiment.OUT / "root_blind_review/private_identity" / (batch + ".json"))
    assert mapping["protocol_sha256"] == experiment.sha(experiment.PROTOCOL)
    assert mapping["review_packet_sha256"] == lock["packet_sha256"]
    index = {r["candidate_id"]: r for r in mapping["records"]}
    assert set(index) == {r["candidate_id"] for r in labels}
    joined = []
    for label in labels:
        ident = index[label["candidate_id"]]
        assert label["case_id"] == ident["case_id"]
        joined.append({**ident, **label})
    groups = {a: [r for r in joined if r["arm"] == a] for a in experiment.templates.ARMS}
    assert len({len(v) for v in groups.values()}) == 1
    lookup = {(r["case_id"], r["arm"]): r for r in joined}
    cases = {r["case_id"] for r in joined}
    comparisons = {}
    for left, right in (("N128", "N256"), ("N256", "F256"), ("F256", "R256"), ("N128", "F256"), ("N128", "R256")):
        value = {}
        for axis in axes[:2]:
            paired = [(lookup[(c, left)][axis], lookup[(c, right)][axis]) for c in cases]
            eligible = [(a, b) for a, b in paired if a in ("correct", "incorrect") and b in ("correct", "incorrect")]
            value[axis] = dict(eligible=len(eligible), excluded=len(paired) - len(eligible),
                improved=sum(a == "incorrect" and b == "correct" for a, b in eligible),
                harmed=sum(a == "correct" and b == "incorrect" for a, b in eligible), tied=sum(a == b for a, b in eligible))
        value["information_transitions"] = dict(Counter(lookup[(c, left)][axes[2]] + " -> " + lookup[(c, right)][axes[2]] for c in cases))
        comparisons[left + "_to_" + right] = value
    result = dict(batch=batch, cases=len(cases), candidates=len(labels), labels_sha256=experiment.sha(label_path),
        review_revision=revision, revision_note=revision_note,
        packet_sha256=lock["packet_sha256"], protocol_sha256=experiment.sha(experiment.PROTOCOL),
        source="Locked informed model review on exposed ordinary nodes, not independent human gold or complete-RAG F1",
        by_arm={a: {**{axis: dict(Counter(r[axis] for r in values)) for axis in axes},
            "accepted_correct_but_raw_incorrect": sum(r[axes[0]] == "incorrect" and r[axes[1]] == "correct" for r in values)} for a, values in groups.items()},
        paired=comparisons, missing_or_pending_not_forced_incorrect=True, labels_changed=False)
    if revision == 2:
        original = experiment.read(folder / "SUMMARY.revision001.json")
        result["original_first_review_sensitivity"] = dict(labels_sha256=original["labels_sha256"], by_arm=original["by_arm"], paired=original["paired"])
    suffix = "" if revision == 1 else ".revision002"
    experiment.atomic_json(folder / ("SEMANTIC_JOIN" + suffix + ".json"), dict(summary=result, joined=joined))
    experiment.atomic_json(folder / ("SUMMARY" + suffix + ".json"), result)
    assert experiment.sha(folder / "REVIEW_LABELS.jsonl") == lock["review_labels_sha256"]
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("batch", choices=("initial8", "supplemental30"))
    parser.add_argument("--revision", type=int, choices=(1, 2), default=1)
    args = parser.parse_args()
    print(json.dumps(join(args.batch, args.revision), ensure_ascii=True))
