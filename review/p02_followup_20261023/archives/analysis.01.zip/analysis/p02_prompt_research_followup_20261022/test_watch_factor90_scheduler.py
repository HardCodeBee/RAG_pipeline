"""No-service checks for the independent factor90 scheduler watcher."""
from copy import deepcopy
import json
from pathlib import Path
import socket
import subprocess
import tempfile
from unittest.mock import patch
import watch_factor90_scheduler as watcher


def reject(call):
    try: call()
    except (AssertionError, ValueError, KeyError, TypeError): return
    raise AssertionError("Invalid scheduler evidence was accepted")


def blocked(*args, **kwargs):
    raise AssertionError("Offline watcher check attempted a service")


def main():
    job = dict(job_id="987654", protocol_sha256="a"*64, directory=watcher.REMOTE_PARENT + "/factor90_" + "a"*16)
    start, end = "2026-10-22T19:00:00", "2026-10-23T01:00:00"
    commands = dict(
        squeue=dict(argv=["squeue", "-h", "-j", job["job_id"], "-o", "%i|%T|%j"], code=0, stdout="", stderr=""),
        sacct=dict(argv=["sacct", "-n", "-P", "-j", job["job_id"], "--format=JobIDRaw,JobName,State,ExitCode,Start,End,Timelimit,NodeList"],
            code=0, stdout=f"987654|p02-factor90|TIMEOUT|0:0|{start}|{end}|06:00:00|offline\n", stderr=""),
        scontrol=dict(argv=["scontrol", "show", "job", "-o", job["job_id"]], code=0, stderr="",
            stdout=f"JobId=987654 JobName=p02-factor90 UserId=u7830488(7830488) Account=db4ai QOS=db4ai JobState=TIMEOUT WorkDir={job['directory']} StartTime={start} EndTime={end}"))
    with patch.object(socket.socket, "connect", blocked), patch.object(socket, "create_connection", blocked), patch.object(subprocess, "Popen", blocked):
        terminal = watcher.validate_terminal(job, commands)
        for key in commands:
            bad = deepcopy(commands); bad[key]["code"] = 1; reject(lambda: watcher.validate_terminal(job, bad))
            bad = deepcopy(commands); bad[key]["argv"].append("extra"); reject(lambda: watcher.validate_terminal(job, bad))
        for key, output in (("squeue", "987654|RUNNING|p02-factor90\n"),
                            ("sacct", commands["sacct"]["stdout"].replace("TIMEOUT", "RUNNING")),
                            ("scontrol", commands["scontrol"]["stdout"].replace(job["directory"], "/unowned")),
                            ("scontrol", commands["scontrol"]["stdout"].replace("u7830488", "other"))):
            bad = deepcopy(commands); bad[key]["stdout"] = output; reject(lambda: watcher.validate_terminal(job, bad))
        with tempfile.TemporaryDirectory(prefix="_watcher_fake_", dir=watcher.HERE) as directory:
            output = Path(directory)
            with patch.object(watcher, "OUTPUT", output):
                complete = dict(valid=True, attempted=360, planned=360, in_flight=0, complete=True)
                result = watcher.record_terminal(job, commands, terminal, complete)
                assert not result["stop_written"] and not (output / "STOP_REQUESTED").exists()
                partial = dict(valid=True, attempted=17, planned=360, in_flight=1, complete=False)
                result = watcher.record_terminal(job, commands, terminal, partial)
                assert result["stop_written"] and (output / "STOP_REQUESTED").exists()
                prior = (output / "STOP_REQUESTED").read_bytes()
                assert not watcher.record_terminal(job, commands, terminal, partial)["stop_written"]
                assert (output / "STOP_REQUESTED").read_bytes() == prior
                reject(lambda: watcher.record_terminal(job, commands, terminal, dict(valid=False)))
                assert {path.name for path in output.iterdir()} == {"SCHEDULER_TERMINAL.json", "STOP_REQUESTED"}
    result = dict(passed=True, checks=dict(exact_owned_terminal_requires_all_three_successful_commands=True,
        empty_queue_alone_or_scheduler_error_never_accepted=True, foreign_owner_workdir_and_live_state_rejected=True,
        incomplete_verified_terminal_writes_only_target_stop_and_receipt=True, complete360_does_not_write_stop=True,
        existing_stop_preserved=True, invalid_local_metadata_cannot_trigger_stop=True),
        script_sha256=watcher.sha(watcher.__file__), test_sha256=watcher.sha(__file__), new_API_SSH_GPU=0,
        production_outputs_or_frozen_sources_modified=False)
    path = watcher.HERE / "FACTOR90_SCHEDULER_WATCH_OFFLINE_CHECKS.json"
    path.write_text(json.dumps(result, indent=2)+"\n", encoding="utf8")
    print(json.dumps(result))


if __name__ == "__main__": main()
