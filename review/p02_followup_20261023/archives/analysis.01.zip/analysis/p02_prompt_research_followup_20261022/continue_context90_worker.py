"""One dependent retrieval-worker continuation; preserve the active local run."""
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
import getpass
import hashlib
import json
import re
import shlex
import socket
import sqlite3
import sys
import time

import paramiko

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from experiments.query_decomposition.p02_shared_context_fixed90_v1_20261022 import remote_bridge as bridge

OUT = ROOT / "outputs/query_decomposition/p02_shared_context_fixed90_v1_20261022"
EXP = ROOT / "experiments/query_decomposition/p02_shared_context_fixed90_v1_20261022"
SHA = "0630afaf6e7b992675085022189e93b9de3af6cdbec9b1542c88856fe9b0630e"
STATE = OUT / "WORKER_CONTINUATION_20261022.json"


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf8")
    temporary.replace(path)


def all_attempted():
    with closing(sqlite3.connect((OUT / "checkpoint.sqlite3").resolve().as_uri() + "?mode=ro", uri=True)) as db:
        done = {x[0] for x in db.execute("SELECT key FROM data WHERE kind='outcome'")}
    held = {read(p)["task_id"] for p in (OUT / "held").glob("*.json")}
    planned = {json.loads(x)["task_id"] for x in (EXP / "ORDER270.jsonl").read_text(encoding="utf8").splitlines()}
    assert (done | held) <= planned and len(planned) == 270
    return done | held == planned


def main():
    assert hashlib.sha256((EXP / "PROTOCOL.frozen.json").read_bytes()).hexdigest() == SHA
    old = read(OUT / "REMOTE_JOB_ID.json")
    assert old["job_id"] == "159533" and old["protocol_sha256"] == SHA
    assert not STATE.exists(), "Continuation already recorded; inspect it, never resubmit blindly"
    if all_attempted():
        print("All conditions already attempted; no continuation needed")
        return
    password = getpass.getpass("Remote password: ")
    client = paramiko.SSHClient(); client.load_system_host_keys(); client.set_missing_host_key_policy(paramiko.RejectPolicy())
    result = dict(status="preparing", predecessor_job_id="159533", protocol_sha256=SHA,
                  directory=old["directory"], scientific_inputs_changed=False, LLM_requests_by_helper=0)
    try:
        connection = socket.create_connection(("150.203.213.5", 22), timeout=15)
        client.connect("cluster1.comp.anu.edu.au", username="u7830488", password=password, sock=connection,
                       look_for_keys=False, allow_agent=False, timeout=15, auth_timeout=20, banner_timeout=15)
        password = None
        client.get_transport().set_keepalive(25)
        sftp = client.open_sftp(); sftp.get_channel().settimeout(40)

        def command(args):
            _, stdout, stderr = client.exec_command(shlex.join(args), timeout=40)
            text, error = stdout.read().decode(), stderr.read().decode()
            code = stdout.channel.recv_exit_status()
            assert code == 0, error
            return text

        def remote(name):
            try:
                with sftp.open(old["directory"] + "/" + name, "rb") as f:
                    return json.loads(f.read())
            except FileNotFoundError:
                return None

        def stopped():
            try:
                sftp.stat(old["directory"] + "/STOP_REQUESTED")
                return True
            except FileNotFoundError:
                return False

        fields = dict(x.split("=", 1) for x in command(["scontrol", "show", "job", "-o", "159533"]).split() if "=" in x)
        assert fields["UserId"].startswith("u7830488(") and fields["JobName"] == "p02-context90"
        assert fields["WorkDir"] == old["directory"]
        assert fields["JobState"] in {"RUNNING", "TIMEOUT"}, "Inspect unexpected predecessor state before submitting"
        result["verified_predecessor_state"] = fields["JobState"]
        assert remote("REMOTE_JOB.frozen.json")["protocol_sha256"] == SHA
        if stopped() or all_attempted():
            print("Original run closing; no continuation needed")
            return
        python = bridge.BUNDLE + "/.remote_env/robustness_models_retrievers_v1_20261017/venv/bin/python"
        wrapped = shlex.join(["env", "HF_HOME=" + bridge.BUNDLE + "/.remote_cache/huggingface", "HF_HUB_OFFLINE=1",
            "TRANSFORMERS_OFFLINE=1", "TOKENIZERS_PARALLELISM=false", "OMP_NUM_THREADS=4", "MKL_NUM_THREADS=4",
            "OPENBLAS_NUM_THREADS=4", python, old["directory"] + "/remote_worker.py", "--directory", old["directory"]])
        result.update(status="submission_unknown_until_receipt", utc=datetime.now(timezone.utc).isoformat())
        write(STATE, result)
        response = command(["sbatch", "--parsable", "--partition=db4ai", "--account=db4ai", "--qos=db4ai",
            "--dependency=afterany:159533", "--gres=gpu:a6000:1", "--cpus-per-task=4", "--mem=32G", "--time=06:00:00",
            "--export=NONE", "--job-name=p02-context90-cont", "--chdir=" + old["directory"],
            "--output=" + old["directory"] + "/gpu-cont-%j.out", "--error=" + old["directory"] + "/gpu-cont-%j.err", "--wrap=" + wrapped]).strip()
        assert re.fullmatch(r"\d+(;[^\s]+)?", response), "Unknown submission receipt: never retry"
        job_id = response.split(";")[0]
        result.update(status="dependent_job_queued", continuation_job_id=job_id, time_limit="06:00:00")
        write(STATE, result); print(json.dumps(result), flush=True)
        while True:
            ready = remote("READY.json")
            if ready and ready.get("job_id") == job_id:
                assert ready["protocol_sha256"] == SHA and ready["status"] == "ready"
                for name in ("REMOTE_JOB_ID.json", "REMOTE_GPU_READY.json"):
                    source = OUT / name; archive = OUT / (source.stem + ".job159533.json")
                    if source.exists() and not archive.exists():
                        archive.write_bytes(source.read_bytes())
                write(OUT / "REMOTE_JOB_ID.json", {**old, "job_id": job_id, "predecessor_job_id": "159533"})
                write(OUT / "REMOTE_GPU_READY.json", ready)
                result.update(status="continuation_ready", utc=datetime.now(timezone.utc).isoformat())
                write(STATE, result); print(json.dumps(result), flush=True)
                return
            if stopped() or all_attempted():
                command(["scancel", job_id])
                result.update(status="unused_continuation_cancelled", utc=datetime.now(timezone.utc).isoformat())
                write(STATE, result); print(json.dumps(result), flush=True)
                return
            state = command(["squeue", "-h", "-j", job_id, "-o", "%T|%R"]).strip()
            result.update(queue_state=state, heartbeat_utc=datetime.now(timezone.utc).isoformat())
            write(STATE, result)
            if not state:
                raise RuntimeError("Continuation left scheduler without READY; inspect existing receipt, do not resubmit")
            time.sleep(10)
    finally:
        password = None
        client.close()


if __name__ == "__main__":
    main()
