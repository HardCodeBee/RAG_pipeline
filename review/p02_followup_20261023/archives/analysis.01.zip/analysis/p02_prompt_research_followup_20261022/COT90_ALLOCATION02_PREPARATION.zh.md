# allocation02后备入口：已准备，未授权/执行

`cot90_allocation_continuation.py`默认`status`（或`prepare`）仅以mode=ro读取身份与任务状态，输出剩余计数/hash；不调用Cache、report、key、SSH或API。`test_cot90_allocation_continuation.py`仅用临时SQLite与注入服务，14项合同通过；结果见`COT90_ALLOCATION02_OFFLINE_CHECKS.json`。不读取native分数或预测。

仅在原161325真实闭合、controller与可见性helper退出之后，root才考虑以下**尚未执行**的命令：

1. `python -X utf8 -B analysis/p02_prompt_research_followup_20261022/cot90_allocation_continuation.py snapshot --closure <workspace内闭合证据.json>`。证据须含原job/protocol/目录/实验、controller_exited与auxiliary_exited、API_requests/new_jobs=0，以及固定squeue/sacct/scontrol三命令的argv/code/stdout/stderr；具体严格格式见`validate_scheduler_closure`。COMPLETED还要求已有owned FINISHED；异常终止缺FINISHED会如实单列。零在途、原STOP不存在、源pins与24工程门、原reference暂停状态均须通过。
2. `... cot90_allocation_continuation.py auth-template`只打印`approved=false`模板，不创建授权。root审核快照和独立复核后，才另行创建exact SHA授权与matching append decision。
3. 仅root授权后运行`... cot90_allocation_continuation.py run`。独立continuation目录/新remote目录保存新job/clock；原controller、checkpoint、namespace、四臂任务顺序及max5/unknown政策保持。

原outcome/held均跳过，不解除旧held或STOP；任何原STOP存在均挂起，入口不提供删除/绕过命令。若360均已尝试，snapshot/run都零服务返回。不覆盖原allocation文件，不切换全局OUT。若continuation已有EXECUTION_STARTED/submission/job/clock，则一律拒绝自动重启；提交未知或中途故障须另行核查，不能重新sbatch。

运行中若新增原OUT或新continuation的本地STOP，新bridge在下一个条件边界直接拒派；在途LLM不被此检查强行中断。原controller和冻结bridge源码不修改。

快照需取得原deployment与checkpoint锁，备份原完整SQLite；账务指纹仅`charges WHERE namespace=原OUT对应namespace`，并继续原priority门已核定的reference scope，不因r03其他namespace合法变化失败。新代码只是条件性资源接续，当前主评暂停、科学条件不变；原窗口内完成就不使用此入口。
