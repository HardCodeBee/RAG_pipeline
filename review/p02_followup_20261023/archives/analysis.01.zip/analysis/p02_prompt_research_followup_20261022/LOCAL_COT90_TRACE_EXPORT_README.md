# Full90 four-arm trace export

`export_local_cot90_trace_review.py` is a standard-library-only local analysis tool. It imports no experiment runner, provider, scorer, SSH or GPU code. It writes only a new `analysis/p02_prompt_research_followup_20261022/local_cot90_trace_review/` directory and refuses to overwrite an existing export. The frozen experiment sources, checkpoint, ledgers and historical files are read-only.

```powershell
python -X utf8 -B analysis/p02_prompt_research_followup_20261022/export_local_cot90_trace_review.py --self-test
python -X utf8 -B analysis/p02_prompt_research_followup_20261022/export_local_cot90_trace_review.py --check-ready
python -X utf8 -B analysis/p02_prompt_research_followup_20261022/export_local_cot90_trace_review.py --export
```

`--check-ready` reads operational STATUS only and checks score-file existence. `--export` requires all360 CoT conditions attempted, no in-flight requests, official REPORT/DETAILS/PAIRED, matching frozen identity, matching outcome predictions and statuses, and two identical logical SQLite snapshots. Technical holds remain missing and algorithm failures retain the official zero. The exporter does not invoke a metric; metric values and paired deltas come from the experiment's own scoring artifacts. Arithmetic checks only detect stale/inconsistent artifacts. It does not require predecessor reference360 completion. An optional `SCHEDULING_EXECUTION.json` is preserved in provenance with its actual barrier field.

The resulting INDEX covers all90 queries including six goal-only cases. Each case contains all four traces and all four predeclared comparisons. Prompts and documents use per-case exact-content catalogs to avoid repeating full reader text. They retain every prompt string and every original/rewritten/reader document's full text, identity, rank and metadata. Raw output, Support, parsed Answer, post-formatter Answer, accepted rewrite, own-answer history, goal evidence, final prompt, final prediction and failed/held request receipts remain distinct.

The first ordinary output change, first ordinary accepted-answer change, and later retrieval/goal/final changes are mechanical observations. A case/space/punctuation-only final difference is only a character-level diagnostic; semantic formatting equivalence and factual cause remain pending. All semantic-review fields start empty. Local gold/aliases support review but do not establish independent semantic truth. No fresh evaluation, causal labeling, new experiment selection, publication or bootstrap interval is performed by this tool.

The synthetic checks cover incomplete/in-flight rejection, SQLite read-only enforcement and unchanged source bytes, stale predictions, algorithm failure versus technical absence, Support-only differences, accepted-answer propagation, final-output surface changes, goal-only absence of ordinary nodes, formatter acceptance, exact prompt/document resolution, frozen decomposition mismatch and uncommitted parser failure.
