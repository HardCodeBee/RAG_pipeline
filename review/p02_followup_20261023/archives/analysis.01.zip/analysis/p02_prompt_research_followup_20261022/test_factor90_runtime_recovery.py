"""Offline fault-path regression. Real frozen cache/retry classes, fake provider only."""
from contextlib import contextmanager, nullcontext
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import json
import socket
import sqlite3
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import factor90_runtime_recovery as recovery
from p02_multigrain_timing_cachefix_v1.core.cache import Cache, canonical
from experiments.query_decomposition.p02_shared_context_fixed90_v1_20261022 import message_transport
from experiments.query_decomposition.p02_shared_context_fixed90_v1_20261022.native_ask import SubmissionAwareStrictAsk


def blocked(*args, **kwargs): raise AssertionError("Offline tests attempted a service")


class Budget:
    def __init__(self):
        self.db = sqlite3.connect(":memory:")
        self.db.execute("CREATE TABLE charges(id TEXT,actual REAL,reserved REAL,status TEXT)")
    def reserve(self, rid, payload):
        self.db.execute("INSERT INTO charges VALUES(?,NULL,0.01,'reserved')", (rid,)); self.db.commit()
    def finish(self, rid, result):
        if result.get("usage"):
            self.db.execute("UPDATE charges SET actual=0.001,status='returned_usage' WHERE id=?", (rid,)); self.db.commit()


class Client:
    def __init__(self, replies): self.replies, self.payloads = list(replies), []
    def request_once(self, payload):
        self.payloads.append(deepcopy(payload)); return deepcopy(self.replies.pop(0))
    def close(self): pass


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="factor90_recovery_fake_", dir=recovery.HERE)
        self.path = Path(self.tmp.name)
        self.config = recovery.read(recovery.full.PACKAGE / "config.json")
        self.cache = Cache(self.path / "checkpoint.sqlite3"); self.budget = Budget()
        self.patches = [patch.object(socket, "create_connection", blocked), patch.object(subprocess, "Popen", blocked),
            patch.object(message_transport, "provider_gate", lambda *a, **k: nullcontext()),
            patch.object(message_transport.time, "sleep", lambda *a: None)]
        for p in self.patches: p.start()
    def tearDown(self):
        for p in reversed(self.patches): p.stop()
        self.cache.close(); self.budget.db.close(); self.tmp.cleanup()
    def unknown(self): return dict(status="unknown", requested_model=self.config["generation"]["model"], error="Request timed out.")
    def success(self): return dict(status="success", answer="Fixture fact.", finish_reason="stop", response_id="fake_return",
        requested_model=self.config["generation"]["model"], returned_model=self.config["generation"]["model"],
        usage=dict(prompt_tokens=3, completion_tokens=2, total_tokens=5))
    def strict(self, replies):
        obj = SubmissionAwareStrictAsk(self.cache, None, self.config, self.budget,
            lambda value: recovery.safe_event(value, self.path), maximum_attempts=5)
        obj.client = Client(replies); return obj
    def test_supplied_time_held_event_and_restoration(self):
        for event in (dict(event="held_technical", utc="original"), dict(event="other")):
            before = deepcopy(event); recovery.safe_event(event, self.path); self.assertEqual(event, before)
        self.assertEqual(recovery.rows(self.path / "events.jsonl")[0]["utc"], "original")
        old = recovery.full.event
        with self.assertRaises(ValueError):
            with recovery.event_patch():
                self.assertIs(recovery.full.event, recovery.safe_event); raise ValueError("fixture")
        self.assertIs(recovery.full.event, old)
    def test_real_retire_then_one_success_and_exact_reuse(self):
        ask = self.strict([self.unknown(), self.success()])
        first = ask("fixture/stage", "Frozen fixture prompt", 128)
        self.assertEqual(ask("fixture/stage", "Frozen fixture prompt", 128), first)
        self.assertEqual(len(ask.client.payloads), 2)
        self.assertEqual(ask.client.payloads[0], ask.client.payloads[1])
        self.assertEqual(self.cache.db.execute("SELECT count(*) FROM retired_requests").fetchone()[0], 1)
        self.assertEqual(self.budget.db.execute("SELECT count(*) FROM charges WHERE actual IS NULL").fetchone()[0], 1)
        events = recovery.rows(self.path / "events.jsonl")
        self.assertEqual(sum(e["event"] == "bounded_technical_recovery" for e in events), 1)
        self.assertTrue(next(e for e in events if e["event"] == "bounded_technical_recovery")["utc"])
    def test_five_attempts_survive_restart_and_remain_reserved(self):
        ask = self.strict([self.unknown()] * 5)
        with self.assertRaises(RuntimeError): ask("fixture/stage", "Unchanged prompt", 128)
        self.assertEqual(len(ask.client.payloads), 5)
        again = self.strict([])
        with self.assertRaises(RuntimeError): again("fixture/stage", "Unchanged prompt", 128)
        self.assertEqual(again.client.payloads, [])
        self.assertEqual(self.budget.db.execute("SELECT count(*) FROM charges WHERE actual IS NULL").fetchone()[0], 5)
        self.assertEqual(self.cache.db.execute("SELECT count(*) FROM retired_requests").fetchone()[0], 4)
    def test_returned_receipts_and_ledger_never_reissued(self):
        fields = [dict(response_id="returned"), dict(raw_response={}), dict(usage={}), dict(returned_model="m"),
            dict(refusal=""), dict(finish_reason="length"), dict(answer="content")]
        for index, field in enumerate(fields):
            prompt = "returned fixture " + str(index); ask = self.strict([])
            payload = message_transport.build_payload(self.config["generation"], prompt, 128)
            rid, _ = self.cache.begin_request("fixture", payload, before_start=lambda r: self.budget.reserve(r, payload))
            self.cache.finish_request(rid, dict(self.unknown(), **field))
            with self.assertRaises(RuntimeError): ask("fixture", prompt, 128)
            self.assertEqual(ask.client.payloads, [])
            self.assertIsNotNone(self.cache.db.execute("SELECT id FROM requests WHERE id=?", (rid,)).fetchone())
        ask = self.strict([]); payload = message_transport.build_payload(self.config["generation"], "ledger fixture", 128)
        rid, _ = self.cache.begin_request("fixture", payload, before_start=lambda r: self.budget.reserve(r, payload))
        self.cache.finish_request(rid, self.unknown())
        self.budget.db.execute("UPDATE charges SET actual=0.001,status='returned_usage' WHERE id=?", (rid,)); self.budget.db.commit()
        with self.assertRaises(RuntimeError): ask("fixture", "ledger fixture", 128)
        self.assertEqual(ask.client.payloads, [])
    def test_continuation_metadata_isolated_and_cot_blocks_release(self):
        cls = recovery.continuation_bridge_class()
        old = {p: recovery.sha(p) for p in (recovery.OUT / "STOP_REQUESTED", recovery.held_path(), recovery.OUT / "REMOTE_JOB_ID.json")}
        target = self.path / "continuation"
        obj = cls({}, target, recovery.read(recovery.full.HERE / "RUN_AUTHORIZATION.json"))
        self.assertEqual(obj.directory, recovery.REMOTE_DIRECTORY); self.assertEqual(obj.output, target)
        with patch.object(recovery, "cot_status", return_value=dict(finished=False)):
            with self.assertRaises(AssertionError): recovery.release_one_held({})
        self.assertEqual(old, {p: recovery.sha(p) for p in old})
    def test_cot_metadata_barrier_missing_held_inflight_and_identity(self):
        experiment = self.path / "experiments/cot_fixture"; experiment.mkdir(parents=True)
        output = self.path / "outputs/query_decomposition/cot_fixture"; (output / "held").mkdir(parents=True)
        for name in ("PROTOCOL.frozen.json", "INPUTS.frozen.jsonl"): (experiment / name).write_text("{}\n", encoding="utf8")
        (experiment / "TASK_ORDER.frozen.jsonl").write_text("".join(json.dumps(dict(task_id=str(i))) + "\n" for i in range(152)), encoding="utf8")
        expected = dict(protocol_sha256=recovery.sha(experiment / "PROTOCOL.frozen.json"), inputs_sha256=recovery.sha(experiment / "INPUTS.frozen.jsonl"),
            order_sha256=recovery.sha(experiment / "TASK_ORDER.frozen.jsonl"), historical_seed=None)
        db = sqlite3.connect(output / "checkpoint.sqlite3")
        try:
            db.execute("CREATE TABLE data(kind,key,value)"); db.execute("CREATE TABLE requests(status)")
            db.execute("INSERT INTO data VALUES('meta','identity',?)", (json.dumps(expected),))
            db.executemany("INSERT INTO data VALUES('outcome',?,?)", ((str(i), json.dumps(dict(status="success"))) for i in range(151))); db.commit()
            with patch.object(recovery, "ROOT", self.path), patch.object(recovery, "COT", experiment):
                self.assertFalse(recovery.cot_status()["finished"])
                (output / "held/151.json").write_text(json.dumps(dict(task_id="151")), encoding="utf8")
                self.assertTrue(recovery.cot_status()["finished"])
                db.execute("INSERT INTO requests VALUES('in_flight')"); db.commit()
                self.assertFalse(recovery.cot_status()["finished"])
                db.execute("DELETE FROM requests"); db.execute("UPDATE data SET value='{}' WHERE kind='meta'"); db.commit()
                self.assertFalse(recovery.cot_status()["finished"])
        finally: db.close()
    def test_continuation_watcher_receipts_and_stop_destination(self):
        module = recovery.load_sibling("watch_factor90_scheduler")
        main = self.path / "main"; main.mkdir()
        continuation = self.path / "continuation"; continuation.mkdir()
        job = dict(job_id="999999", directory=recovery.REMOTE_DIRECTORY, protocol_sha256=recovery.sha(recovery.full.PROTOCOL))
        (continuation / "REMOTE_JOB_ID.json").write_text(json.dumps(job), encoding="utf8")
        counts = dict(valid=True, attempted=24, planned=360, in_flight=0, complete=False)
        terminal = dict(verified=True, job_id=job["job_id"], state="NODE_FAIL")
        def exercise():
            self.assertEqual(module.local_identity()["job_id"], "999999")
            result = module.record_terminal(job, {}, terminal, counts)
            self.assertTrue(result["stop_written"])
            self.assertTrue((main / "STOP_REQUESTED").exists())
            self.assertFalse((continuation / "STOP_REQUESTED").exists())
            self.assertEqual(recovery.read(continuation / "SCHEDULER_TERMINAL.json")["progress"], counts)
            (main / "STOP_REQUESTED").unlink()
            result = module.record_terminal(job, {}, terminal, dict(counts, attempted=360, complete=True))
            self.assertFalse(result["stop_written"]); self.assertFalse((main / "STOP_REQUESTED").exists())
            return dict(passed=True)
        module.watch = exercise
        with patch.object(recovery, "OUT", main), patch.object(recovery, "CONTINUATION", continuation), \
                patch.object(recovery, "authorized", return_value={}), patch.object(recovery, "load_sibling", return_value=module):
            self.assertTrue(recovery.watch()["passed"])
    def test_launch_partial_release_and_runtime_failures_close_and_stop(self):
        from experiments.query_decomposition.p02_reference_binding_priority_probe_v1_20261022 import run as stage
        original_guard, original_event = stage.context90_completion_status, recovery.full.event
        for failure in ("partial_release", "start", "runtime"):
            main = self.path / failure; main.mkdir()
            continuation = main / "continuation"; continuation.mkdir()
            stopped = main / "STOP_REQUESTED"; stopped.write_text("original stop", encoding="utf8")
            observed = []
            class Bridge:
                def __init__(self, *args): pass
                def start(self):
                    observed.append("start")
                    if failure == "start": raise RuntimeError("synthetic start failure")
                def close(self): observed.append("close")
            def release(auth):
                stopped.rename(continuation / "old_STOP_REQUESTED")
                if failure == "partial_release": raise RuntimeError("synthetic partial release failure")
            def fail_runtime(bridge):
                self.assertIs(recovery.full.event, recovery.safe_event)
                raise RuntimeError("synthetic runtime failure")
            with patch.object(recovery, "OUT", main), patch.object(recovery, "CONTINUATION", continuation), \
                    patch.object(recovery, "authorized", return_value={}), patch.object(recovery, "cot_status", return_value=dict(finished=True)), \
                    patch.object(recovery, "release_one_held", side_effect=release), patch.object(recovery, "continuation_bridge_class", return_value=Bridge), \
                    patch.object(recovery, "load_sibling", return_value=SimpleNamespace(completion_status=lambda *a: dict(finished=True))), \
                    patch.object(recovery.full, "predecessor_status", return_value=dict(finished=True)), patch.object(recovery.full, "authorized", return_value={}), \
                    patch.object(recovery.full, "run_with_bridge", side_effect=fail_runtime):
                with self.assertRaises(RuntimeError): recovery.run()
            self.assertTrue(stopped.exists()); self.assertTrue((continuation / "STOP_REQUESTED").exists())
            self.assertEqual((continuation / "old_STOP_REQUESTED").read_text(encoding="utf8"), "original stop")
            self.assertTrue((continuation / "LAUNCH_OR_RUNTIME_FAILURE.json").exists())
            self.assertEqual(observed, [] if failure == "partial_release" else ["start", "close"])
            self.assertIs(stage.context90_completion_status, original_guard); self.assertIs(recovery.full.event, original_event)
    def test_competing_deployment_or_checkpoint_lock_never_stops_owner(self):
        for fail_at in (1, 2):
            main = self.path / ("lock_" + str(fail_at)); main.mkdir()
            continuation = main / "continuation"; calls = []
            @contextmanager
            def contended(path):
                calls.append(path)
                if len(calls) == fail_at: raise RuntimeError("fixture lock owned by another controller")
                yield
            with patch.object(recovery, "OUT", main), patch.object(recovery, "CONTINUATION", continuation), \
                    patch.object(recovery, "authorized", return_value={}), patch.object(recovery, "cot_status", return_value=dict(finished=True)), \
                    patch.object(recovery, "run_lock", contended), patch.object(recovery, "release_one_held", side_effect=blocked), \
                    patch.object(recovery, "load_sibling", return_value=SimpleNamespace(completion_status=lambda *a: dict(finished=True))), \
                    patch.object(recovery.full, "predecessor_status", return_value=dict(finished=True)):
                with self.assertRaises(RuntimeError): recovery.run()
            self.assertEqual(len(calls), fail_at)
            self.assertFalse((main / "STOP_REQUESTED").exists()); self.assertFalse(continuation.exists())


if __name__ == "__main__": unittest.main(verbosity=2)
