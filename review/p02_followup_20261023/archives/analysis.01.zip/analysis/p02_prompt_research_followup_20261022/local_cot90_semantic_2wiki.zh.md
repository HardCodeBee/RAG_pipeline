# CoT固定90题：2Wiki变化案例语义复核

覆盖2Wiki中N128→R256全部4个F1或EM变化案例，另列全部2个预测改变但分数持平案例。4个主变化均降分：两题最终由真实答案变成材料限定弃答，一题祖父答错一代，一题保留正确祖父但增加真实头衔而失分。这个分类区分了目标信息、事实真值与原生评分，不把合理弃答标成捏造事实。

4题先隐藏方法标签和分数读取匿名候选及本地reader，再揭示四臂轨迹与分数。任务已给变化题名单，输出样式及既有诊断也可能透露方法，故不称完全盲审。两道ties随后带标签核查。分数直接复制官方导出，不重算、不改原生标签；24个被审阅臂均success，没有技术缺失或算法终止。整体实验的MuSiQue/F256技术held不在本数据集，不在这里补0。

| ID | N128 F1/EM | R256 F1/EM | 审阅结果 |
|---|---:|---:|---|
| f37818400bd911eba7f7acde48001122 | 1 / 1 | 0 / 0 | 丈夫仍正确；goal增加缺证限定，final弃答死亡地 |
| 923b15ba0bb011ebab90acde48001122 | 0.5 / 0 | 0 / 0 | 真实父亲桥接被合理弃答替换，祖父实体最终丢失 |
| 6c0c4c1a0bb011ebab90acde48001122 | 1 / 1 | 0.5 / 0 | George祖父错成Marcus曾祖父；剩余F1为词面重叠 |
| 654dbe680bb011ebab90acde48001122 | 1 / 1 | 0.6153846154 / 0 | 同一正确Hermann Georg，额外真实头衔受短名参考惩罚 |

## 逐例说明

**Elisabeth Magdalena的丈夫死亡地**（[完整case](local_cot90_trace_review/cases/fe3c8f67ce66bd40.json)）。四臂丈夫均为Friedrich Kettler。R的普通accepted省掉Duke of Courland，仍回答了所问对象。这个差异进入goal改写；其reader后部两条Frederick William换成Jacob Kettler和Hölderlinturm，但第2条仍为同一Friedrich文档。四臂reader都只把Mitau写作出生地，没有明确死亡地；不能说R丢掉了N本来已读到的死亡证据。

N/N256/F的goal和final答Mitau。R的goal也写Mitau，却附加由出生地、统治经历推出死亡地的无效论证，并明确承认缺少死亡地材料；final改为Cannot be determined。外部[Neue Deutsche Biographie人物条目](https://www.deutsche-biographie.de/gnd104213116.html)确认死亡地Mitau，所以目标信息确实在R的最终输出丢失。但其final与收到的缺证限定及允许弃答的共同提示一致，不能归为普通丈夫答错或已见充分reader却抽错。头衔省略、改写、reader和goal措辞共同改变，没有单独干预可确认唯一原因。

完整raw另保留一个小范围待核：F的Support婚期“14 March 1600”准确转述本地Elisabeth文档，而上述NDB记“4.5.1600”。这不影响丈夫身份和本题死亡地点结论，但F这条附加日期的历史真值不强行判定。R的goal结论虽真实，其完整论证也不能随结论一并判正确。

**Araripe Júnior的祖父**（[完整case](local_cot90_trace_review/cases/bff1f2203d77bba0.json)）。第1步四臂reader相同，Araripe片段仅姓名、生卒和职业，不含父亲。N/N256回答父亲Tristão de Alencar Araripe；F/R正确描述材料缺证并弃答。该父亲事实由[巴西文学院传记](https://www2.academia.org.br/academicos/araripe-junior/biografia)核实，不能因模型当时缺少reader支持就判成假事实。

N第2步用父亲姓名改写，命中标题Tristão de Alencar Araripe、正文却介绍Tristão Gonçalves的片段，并进入reader第2；该片段没有明确的父子关系，不能当完整两跳证明。F/R没有父亲实体，第2步保持泛化father-of-father问句，无额外改写检索包，后续也未补回祖父。N正确祖父传至goal/final，F/R弃答传至goal/final，轨迹支持桥接信息损失路径；N的完整关系仍可能依赖既有知识。

[塞阿拉文学院原始传记首段，PDF第1页](https://academiacearensedeletras.org.br/revista/Colecao_Dolor_Barreira/Luizinha/ACL_Luizinha_05_dados_biobibliograficos_de_t_a_araripe_junior.pdf)明确两代父系：Júnior→Tristão de Alencar Araripe→Tristão Gonçalves de Alencar Araripe。N最终长名与参考短名Tristão Gonçalves指同一祖父，F1只有0.5属名称长度差异；F/R弃答合理但未提供必要实体。F256与R256的目标信息和最终分数相同，不能将此损失归为R特有推理。

**Henry Beresford第3侯爵的祖父**（[完整case](local_cot90_trace_review/cases/dab21d108c71d949.json)）。step1最早accepted差异为“Henry Beresford, 2nd Marquess”缩成“the 2nd Marquess”，仍是正确父亲。真正的代际错误出现在step2：N/N256答George第1侯爵，F/R答George之父Marcus第1伯爵。R的Support显式把爵位先后和父子关系混合，跨错一代；F的Support反而已写“第2侯爵是George的儿子”，Answer却仍答Marcus，完整输出内部矛盾。Support未传递，下游只得到错误accepted。

两路step2 reader都有George→Marcus关系，George由N第9条移到F/R第6条；均缺第2侯爵→George的明确父子句。第二侯爵文档虽进入改写候选（N第9/10、F/R第10），却未进入10条reader，且那些候选片段本身也只说继承爵位，不能把它们当已取得又被合并丢失的充分关系证据。[第二侯爵在线完整传记](https://en.wikipedia.org/wiki/Henry_Beresford,_2nd_Marquess_of_Waterford)补出父亲George并列第3侯爵为其子，确认Marcus实际是曾祖父。

错误Marcus被写入goal历史和改写，goal、final继续重申，传播明确；父亲姓名省略或reader排序是否单独造成该错误仍未定。F/R的accepted、改写、reader、goal和final相同，只有Support论证不同。R剩余F1=0.5是错误答案共享Beresford、1st、of等词，不表示祖父关系部分正确。

**Hermann Otto I的祖父**（[完整case](local_cot90_trace_review/cases/04aa7d92150f2b87.json)）。step1的is/was无事实变化；step2四臂在完全相同的reader上正确得到Hermann Georg。Jobst文档明确父系关系和count of Limburg and Bronckhorst头衔，R把头衔加进accepted，F虽在Support提到却没有放进accepted。R随后改写、goal和final保留这段真实头衔，goal reader仍有必要关系证据。

最终实体及关系没有变错。F1/EM下降来自参考只写短名；这属于真实附加属性及输出长度差异，不能记为事实损害，也不是纯大小写变化。共同final提示要求排除不必要描述，R仍保留了非本问必需的头衔。

## 分数持平的预测变化

| ID | 最终N128→R256 | 实际核查 |
|---|---|---|
| c62ca325089b11ebbd78ac1f6bf848b6 | Main Street **to** Broadway→Main Street **To** Broadway | 两位导演及1894/1931出生年、先后结论都正确；全部候选/reader身份次序相同，仅等价语序和片名大小写 |
| 751bb456084c11ebbd56ac1f6bf848b6 | Carl **von** Linde→Carl **Von** Linde | 1842与1992出生日期和比较结论未变；goal改写候选有机械变化，合并reader身份次序完全相同 |

这两题四臂F1/EM均1，未发现实质目标事实或信息充分性变化。详见[c62ca case](local_cot90_trace_review/cases/b9e42e4c23c9ee04.json)与[751bb case](local_cot90_trace_review/cases/d58991a541bab763.json)。

## 记录与解释边界

[JSONL记录](local_cot90_semantic_2wiki.jsonl)含4条`record_type=score_changed`和2条`record_type=ties`，保留官方四臂分数、实际accepted/改写、语义判断、证据指针、外查来源及待核事项。完整raw、Support、parsed Answer与accepted Answer仍读各case的`arms.<arm>.nodes`；reader全文沿`reader_documents.docs[].document_ref`查`documents[ref].text`；完整实际提示沿`actual_prompt_ref`或`final.prompt_ref`查`prompts[ref]`。本次24条臂轨迹中parsed与accepted均相同，没有发现格式化器另改答案的路径。

4个主变化中N256均与N128的全部accepted、goal和final相同，单纯提高上限没有改变这些结果；F/R在Araripe与Beresford共有损失，R相对F另有死亡地点弃答和真实头衔加长。这是这4题的已观察轨迹，不能推出一般提示机制因果。分解、原始检索和root证据未因四臂改变；后续改写、双路候选、合并reader的变化逐题保留。外查仅补语义审阅缺证，不属于模型生成时所见信息，也不改变原生90题分母或统计。
