"""Observe the isolated full8 allocation and local progress; never resume jobs."""
import getpass
import json
from pathlib import Path
import shlex
import sqlite3
import time
from datetime import datetime, timezone

import paramiko

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/query_decomposition/p02_failure8_dynamic_target_fullrag_draft_20261022"


def main():
    job = json.loads((OUT / "REMOTE_JOB_ID.json").read_text(encoding="utf8"))
    assert job["directory"].startswith("/home/projects/u7830488/p02_prompt_small_evals_20261022/full8_")
    code = '''import json,subprocess
from pathlib import Path
p=Path(DIRECTORY);v={}
for name in ['READY.json','FINISHED.json','WORKER_ERROR.json']:
 if (p/name).is_file():v[name]=json.loads((p/name).read_text())
v['response_files']=len(list((p/'responses').glob('*.json')))
v['request_files']=len(list((p/'requests').glob('*.json')))
for label,args in [('queue',['squeue','-h','-j',JOB,'-o','%T|%R']),('accounting',['sacct','-n','-P','-j',JOB,'-o','JobID,State,Elapsed,AllocTRES'])]:
 r=subprocess.run(args,capture_output=True,text=True,timeout=12);v[label]={'code':r.returncode,'stdout':r.stdout[:5000],'stderr':r.stderr[:500]}
print(json.dumps(v))
'''
    code = "DIRECTORY=" + repr(job["directory"]) + "\nJOB=" + repr(job["job_id"]) + "\n" + code
    client = paramiko.SSHClient()
    client.load_system_host_keys()
    client.set_missing_host_key_policy(paramiko.RejectPolicy())
    password = getpass.getpass("Remote password: ")
    try:
        client.connect("cluster1.comp.anu.edu.au", username="u7830488", password=password,
            allow_agent=False, look_for_keys=False, timeout=15, auth_timeout=20, banner_timeout=15)
        password = None
        client.get_transport().set_keepalive(25)
        previous = None
        while True:
            _, stdout, stderr = client.exec_command("python3 -c " + shlex.quote(code), timeout=45)
            remote = json.loads(stdout.read().decode())
            assert stdout.channel.recv_exit_status() == 0
            with sqlite3.connect((OUT / "checkpoint.sqlite3").resolve().as_uri() + "?mode=ro", uri=True) as db:
                statuses = dict(db.execute("SELECT json_extract(value,'$.status'),count(*) FROM data WHERE kind='outcome' GROUP BY 1"))
            value = dict(utc=datetime.now(timezone.utc).isoformat(), job=job, remote=remote,
                local_outcome_statuses=statuses, planned_conditions=16, read_only=True,
                main_evaluation_resumed=False, new_jobs_or_API_requests_by_monitor=0)
            (OUT / "REMOTE_LIVE_STATUS.json").write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
            for remote_name, local_name in (("READY.json", "REMOTE_GPU_READY.json"), ("FINISHED.json", "REMOTE_GPU_FINISHED.json")):
                if remote_name in remote and not (OUT / local_name).exists():
                    (OUT / local_name).write_text(json.dumps(remote[remote_name], ensure_ascii=False, indent=2) + "\n", encoding="utf8")
            small = dict(local_resolved=sum(statuses.values()), statuses=statuses,
                job_id=job["job_id"], queue=remote["queue"]["stdout"].strip(),
                GPU=remote.get("READY.json", {}).get("gpu"), retrieved_packets=remote["response_files"],
                worker_error=remote.get("WORKER_ERROR.json"), finished=remote.get("FINISHED.json"))
            if small != previous:
                print(json.dumps(small, ensure_ascii=True), flush=True)
                previous = small
            if "FINISHED.json" in remote or "WORKER_ERROR.json" in remote:
                break
            if not remote["queue"]["stdout"].strip() and any(state in remote["accounting"]["stdout"] for state in ("FAILED", "CANCELLED", "TIMEOUT", "OUT_OF_MEMORY")):
                break
            time.sleep(15)
    finally:
        password = None
        client.close()


if __name__ == "__main__":
    main()
