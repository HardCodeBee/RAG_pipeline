"""One bounded, read-only stat/open/stat probe of existing job161325 requests."""
from pathlib import Path
from datetime import datetime, timezone
import getpass
import hashlib
import json
import re
import socket
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/query_decomposition/p02_local_cot_fixed90_v1_20261022"
DEST = OUT / "READONLY_RESPONSE_OPEN_PROBE.json"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def utc(): return datetime.now(timezone.utc).isoformat()

def main():
    import paramiko
    auth = ROOT / "analysis/p02_prompt_research_followup_20261022/COT90_PRIORITY_EXECUTION_AUTHORIZATION.json"
    assert hashlib.sha256(auth.read_bytes()).hexdigest() == "f8f4c307ed00263e00bcd04b18c32093f2afb32fe1d1187cc76c2fdebe3d535a"
    job = read(OUT / "REMOTE_JOB_ID.json")
    assert job["job_id"] == "161325" and job["directory"] == "/home/projects/u7830488/p02_prompt_small_evals_20261022/cot90_222de9cd4f7dca85"
    assert not DEST.exists()
    settings = read(ROOT / "experiments/query_decomposition/p02_local_cot_fixed90_v1_20261022/EXECUTION_SETTINGS.json")
    assert read(ROOT / settings["partition_preflight"])["verified_address"] == settings["verified_host_address"]
    client = paramiko.SSHClient(); client.load_system_host_keys(); client.set_missing_host_key_policy(paramiko.RejectPolicy())
    password = getpass.getpass("Remote password: "); connection = None
    try:
        connection = socket.create_connection((settings["verified_host_address"], 22), timeout=15)
        client.connect("cluster1.comp.anu.edu.au", username="u7830488", password=password, sock=connection,
            look_for_keys=False, allow_agent=False, timeout=15, auth_timeout=20, banner_timeout=15)
        password = None; started = time.monotonic(); started_utc = utc(); deadline = started + 150
        records, completed = [], set(); errors = []
        with client.open_sftp() as sftp:
            sftp.get_channel().settimeout(2.0)
            while time.monotonic() < deadline:
                iteration = time.monotonic()
                try:
                    entries = [item for item in sftp.listdir_attr(job["directory"] + "/requests")
                               if re.fullmatch(r"[0-9a-f]{64}\.json", item.filename)]
                    candidates = sorted(entries, key=lambda item: (item.st_mtime, item.filename), reverse=True)
                    candidate = next((item for item in candidates if item.filename not in completed), None)
                    if candidate is not None:
                        rid = candidate.filename[:-5]; path = job["directory"] + "/responses/" + candidate.filename
                        before_utc = utc()
                        try:
                            before = sftp.stat(path); completed.add(candidate.filename)
                        except FileNotFoundError:
                            row = dict(request_id=rid, request_mtime_epoch=candidate.st_mtime, before_stat_utc=before_utc,
                                before_stat_found=False, open_utc=utc())
                            try:
                                with sftp.open(path, "rb") as stream:
                                    # The single byte is discarded and never logged or saved.
                                    row["open_read_succeeded"] = len(stream.read(1)) == 1
                            except FileNotFoundError: row["open_read_succeeded"] = False
                            row["after_stat_utc"] = utc()
                            try:
                                after = sftp.stat(path); row["after_stat_found"] = True
                                row["response_mtime_epoch"] = after.st_mtime; completed.add(candidate.filename)
                            except FileNotFoundError: row["after_stat_found"] = False
                            records.append(row)
                            if row["open_read_succeeded"]:
                                print(json.dumps(dict(event="stat_missing_open_succeeded", **row)), flush=True)
                except (OSError, TimeoutError) as error:
                    errors.append(dict(utc=utc(), error_type=type(error).__name__))
                    break
                time.sleep(max(0, min(deadline-time.monotonic(), 1.0-(time.monotonic()-iteration))))
        observed_seconds = time.monotonic()-started
        assert observed_seconds < 180
        receipts = {}
        for line in (OUT / "REMOTE_EVENTS.jsonl").open(encoding="utf8"):
            event = json.loads(line)
            if event.get("event") == "actual_retrieval_or_exact_worker_reuse": receipts[event["request_id"]] = event["utc"]
        for row in records: row["controller_receipt_utc_at_probe_end"] = receipts.get(row["request_id"])
        result = dict(started_utc=started_utc, completed_utc=utc(), observed_seconds=observed_seconds, job=job,
            maximum_poll_hz=1, request_or_response_bytes_saved=0, remote_writes=0, LLM_requests=0, GPU_jobs=0,
            records=records, errors=errors, interpretation="This is observational. Stat-missing/open-success alone does not establish NFS caching; response creation may overlap the calls.")
        with DEST.open("x", encoding="utf8") as stream: json.dump(result, stream, indent=2); stream.write("\n")
        print(json.dumps(dict(probe_complete=True, observed_seconds=observed_seconds, missing_stat_samples=len(records),
            stat_missing_open_successes=sum(row["open_read_succeeded"] for row in records), errors=errors,
            artifact=str(DEST.relative_to(ROOT)))), flush=True)
    finally:
        password = None; client.close()
        if connection: connection.close()

if __name__ == "__main__": main()
