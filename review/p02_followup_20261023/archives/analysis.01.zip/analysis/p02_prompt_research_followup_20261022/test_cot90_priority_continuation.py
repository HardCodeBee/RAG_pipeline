"""Synthetic, offline checks of the independent CoT scheduling supplement.

Only temporary SQLite fixtures and this analysis report are written. No Cache,
provider, key, SSH, worker or actual experiment output is constructed/changed.
"""
from contextlib import closing, contextmanager
from copy import deepcopy
from pathlib import Path
from unittest.mock import Mock, patch
import argparse
import hashlib
import importlib.util
import json
import sqlite3
import tempfile

HERE = Path(__file__).resolve().parent
SCRIPT = HERE / "cot90_priority_continuation.py"
spec = importlib.util.spec_from_file_location("reviewed_cot_priority", SCRIPT)
w = importlib.util.module_from_spec(spec)
spec.loader.exec_module(w)


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


@contextmanager
def fixture_db(path):
    # sqlite3.Connection.__exit__ commits but does not close on Windows.
    with closing(sqlite3.connect(path)) as db:
        with db:
            yield db


def rejects(fn):
    try:
        fn()
    except (AssertionError, OSError, ValueError, KeyError):
        return
    raise AssertionError("Expected fail-closed rejection")


def check_database_fingerprints():
    with tempfile.TemporaryDirectory(prefix="cot_priority_ro_fake_") as folder:
        root = Path(folder); source = root / "source"; out = root / "reference"
        package = root / "package"; source.mkdir(); out.mkdir(); package.mkdir()
        (out / "held").mkdir()
        for name in ("PROTOCOL.frozen.json", "INPUTS90.jsonl", "ORDER360.jsonl"):
            (source / name).write_text('{"synthetic":true}\n', encoding="utf8")
        (source / "RESOURCE_CONTRACTS.json").write_text('{"hotpotqa":{"synthetic":true}}', encoding="utf8")
        ledger = root / "ledger.sqlite3"
        (package / "config.json").write_text(json.dumps(dict(budget=dict(ledger=str(ledger)))), encoding="utf8")
        identity = dict(protocol_sha256=sha(source / "PROTOCOL.frozen.json"), inputs_sha256=sha(source / "INPUTS90.jsonl"),
                        order_sha256=sha(source / "ORDER360.jsonl"), resources={"hotpotqa": {"synthetic": True}},
                        no_historical_LLM_seed=True)
        dbpath = out / "checkpoint.sqlite3"
        with fixture_db(dbpath) as db:
            db.execute("CREATE TABLE data(kind TEXT,key TEXT,value TEXT,PRIMARY KEY(kind,key))")
            db.execute("CREATE TABLE requests(id TEXT PRIMARY KEY,payload TEXT,stage TEXT,status TEXT,result TEXT)")
            db.execute("CREATE TABLE request_stages(request_id TEXT,stage TEXT,PRIMARY KEY(request_id,stage))")
            db.execute("CREATE TABLE retired_requests AS SELECT * FROM requests WHERE 0")
            db.execute("CREATE TABLE retired_request_stages AS SELECT * FROM request_stages WHERE 0")
            db.execute("INSERT INTO data VALUES('meta','identity',?)", (json.dumps(identity),))
            db.execute("INSERT INTO data VALUES('outcome','synthetic-task',?)", (json.dumps(dict(status="success", prediction="synthetic-only")),))
            db.execute("INSERT INTO requests VALUES('r1','p1','s1','success','{}')")
            db.execute("INSERT INTO request_stages VALUES('r1','s1')")
            db.execute("INSERT INTO retired_requests VALUES('old','old-p','old-s','unknown','{}')")
            db.execute("INSERT INTO retired_request_stages VALUES('old','old-s')")
        namespace = "p02_prompt_research_v1_20261022/" + str(out.resolve())
        with fixture_db(ledger) as db:
            db.execute("CREATE TABLE charges(id TEXT,namespace TEXT,actual REAL,reserved REAL,status TEXT)")
            db.execute("INSERT INTO charges VALUES('r1',?,0.1,0.2,'returned_usage')", (namespace,))
            db.execute("INSERT INTO charges VALUES('old',?,NULL,0.3,'reserved')", (namespace,))
            db.execute("INSERT INTO charges VALUES('unrelated','other-namespace',0.4,0.5,'returned_usage')")
        with patch.object(w, "ROOT", root), patch.object(w, "REFOUT", out), patch.object(w.p, "ROOT", root), \
             patch.object(w.p, "REFERENCE", source), patch.object(w.p, "PACKAGE", package):
            baseline = w.database_state()
            assert set(baseline["tables"]) >= {"data", "requests", "request_stages", "retired_requests", "retired_request_stages"}
            for table, column, condition in (("data", "value", "kind='outcome'"), ("requests", "result", "id='r1'"),
                    ("request_stages", "stage", "request_id='r1'"), ("retired_requests", "result", "id='old'"),
                    ("retired_request_stages", "stage", "request_id='old'")):
                with fixture_db(dbpath) as db:
                    old = db.execute("SELECT " + column + " FROM " + table + " WHERE " + condition).fetchone()[0]
                    value = json.dumps(dict(status="success", prediction="changed-synthetic")) if table == "data" else "changed"
                    db.execute("UPDATE " + table + " SET " + column + "=? WHERE " + condition, (value,))
                assert w.database_state() != baseline, "Unfingerprinted cache table: " + table
                with fixture_db(dbpath) as db:
                    db.execute("UPDATE " + table + " SET " + column + "=? WHERE " + condition, (old,))
                assert w.database_state() == baseline
            with fixture_db(ledger) as db:
                db.execute("UPDATE charges SET actual=99 WHERE namespace='other-namespace'")
            assert w.database_state() == baseline, "Unrelated global ledger namespace changed paused state"
            with fixture_db(ledger) as db:
                db.execute("UPDATE charges SET reserved=0.9 WHERE id='old' AND namespace=?", (namespace,))
            assert w.database_state() != baseline, "Old unknown reservation drift was missed"
            with fixture_db(ledger) as db:
                db.execute("UPDATE charges SET reserved=0.3 WHERE id='old' AND namespace=?", (namespace,))
            (out / "held" / "synthetic.json").write_text('{"task_id":"synthetic-held"}', encoding="utf8")
            assert w.database_state() != baseline, "Held record drift was missed"


def check_exact_authorization():
    valid = dict(approved=True, decision_id=w.DECISION, script_sha256="script", protocol_sha256="protocol",
                 pause_snapshot_sha256="snapshot", scheduler_only=True, approved_conditions=360)
    decision = dict(id=w.DECISION, approved=True, authorization_sha256="authorization", script_sha256="script")
    def fingerprint(path):
        if Path(path) == SCRIPT: return "script"
        if Path(path) == w.p.PROTOCOL: return "protocol"
        if Path(path) == w.SNAPSHOT: return "snapshot"
        if Path(path) == w.AUTH: return "authorization"
        raise AssertionError("Unexpected fingerprint")
    base = Mock()
    with patch.object(w.full, "authorized", base), patch.object(w.p, "sha", fingerprint):
        for field, value in (("approved", False), ("decision_id", "foreign"), ("script_sha256", "foreign"),
                             ("protocol_sha256", "foreign"), ("pause_snapshot_sha256", "foreign"),
                             ("scheduler_only", False), ("approved_conditions", 359)):
            with patch.object(w.p, "read", return_value={**valid, field: value}), patch.object(w.p, "rows", return_value=[decision]):
                rejects(w.authorized)
        for decisions in ([], [decision, decision], [{**decision, "approved": False}],
                          [{**decision, "authorization_sha256": "foreign"}], [{**decision, "script_sha256": "foreign"}]):
            with patch.object(w.p, "read", return_value=valid), patch.object(w.p, "rows", return_value=decisions):
                rejects(w.authorized)
        with patch.object(w.p, "read", return_value=valid), patch.object(w.p, "rows", return_value=[decision]):
            assert w.authorized() == valid and base.called
    with patch.object(w.full, "authorized", side_effect=AssertionError("Base source/STOP/AUTH failed")), \
         patch.object(w.p, "read", side_effect=AssertionError("No outer read after base failure")):
        rejects(w.authorized)


def check_partial_gate_and_early_drift():
    checks = dict(ordinary_stage=dict(finished=True, attempted=152, in_flight=0),
                  reference90=dict(finished=False, attempted=49, planned=360, in_flight=0),
                  reference_workers=dict(closed=True), current_reference_scheduler=dict(closed=True, job_id="161046"))
    state = dict(tables={"retired_requests": {"sha256": "retained"}}, namespace_charge_sha256="kept", in_flight=0)
    snap = dict(metadata=checks, database=state, pins={"fake.pin": "pin"}, backup_path="backup.sqlite3", backup_sha256="backup")
    def fingerprint(path): return "backup" if Path(path).name == "backup.sqlite3" else "pin"
    with patch.object(w, "authorized", return_value={}), patch.object(w.p, "read", return_value=snap), \
         patch.object(w.p, "sha", side_effect=fingerprint), patch.object(w, "base_pause_checks", return_value=checks), \
         patch.object(w, "database_state", return_value=state):
        result = w.priority_status()
        assert result["finished"] is True and result["ready_for_cot"] is True
        assert result["reference90"]["finished"] is False and result["original_all360_barrier_satisfied"] is False
        assert result["reference_state"] == "reference_partial_paused_for_cot"
        for drift in ({**state, "namespace_charge_sha256": "changed"},
                      {**state, "tables": {"retired_requests": {"sha256": "changed"}}}):
            with patch.object(w, "database_state", return_value=drift): rejects(w.priority_status)
        with patch.object(w, "base_pause_checks", return_value={**checks, "reference90": {**checks["reference90"], "attempted": 50}}):
            rejects(w.priority_status)
        with patch.object(w.p, "sha", return_value="changed"): rejects(w.priority_status)
        with patch.object(w.p, "sha", side_effect=lambda path: "corrupt" if Path(path).name == "backup.sqlite3" else "pin"):
            rejects(w.priority_status)
    service = Mock(side_effect=AssertionError("No service entry after drift")); written = Mock()
    with patch.object(w, "authorized", return_value={}), patch.object(w, "priority_status", side_effect=AssertionError("Drift")), \
         patch.object(w.full, "run", service), patch.object(w.p, "atomic_json", written):
        rejects(w.run)
        assert not service.called and not written.called


def check_local_patch_restoration():
    old = w.predecessors.status
    auth = dict(script_sha256="script")
    with patch.object(w, "authorized", return_value=auth), patch.object(w, "priority_status", return_value=dict(finished=True)), \
         patch.object(w.p, "atomic_json"), patch.object(w.p, "sha", return_value="authorization"):
        def execute(wait):
            assert wait is False and w.predecessors.status is w.priority_status
            return dict(synthetic=True)
        with patch.object(w.full, "run", side_effect=execute): assert w.run()["synthetic"]
        assert w.predecessors.status is old
        def interrupt(wait):
            assert w.predecessors.status is w.priority_status
            raise KeyboardInterrupt("Synthetic only")
        with patch.object(w.full, "run", side_effect=interrupt):
            try: w.run()
            except KeyboardInterrupt: pass
            else: raise AssertionError("Synthetic interrupt was swallowed")
        assert w.predecessors.status is old


def check_pause_authority_and_exact_scheduler():
    with tempfile.TemporaryDirectory(prefix="cot_pause_closure_fake_") as folder:
        out = Path(folder) / "reference"; out.mkdir(); (out / "STOP_REQUESTED").write_text("synthetic", encoding="utf8")
        pause = out / "pause"; pause.mkdir()
        auth = dict(id="P02_COT90_PRIORITY_CONDITION_BOUNDARY_PAUSE_20261022", approved=True,
                    experiment=w.p.HERE.name, reference_experiment=w.p.REFERENCE.name,
                    old_job_id="161046", protocol_sha256="protocol", reference_protocol_sha256="reference",
                    clock_destination="synthetic-clock", clock_sha256="clock")
        operation = dict(decision_id=auth["id"], job_id="161046", old_waiter_exited=True,
                         old_waiter_service_requests=0, reference_controller_exited=True, reference_exit_code=1,
                         intentional_boundary_abort=True, error_type="FileNotFoundError")
        def scheduler(jid):
            directory = "/owned/synthetic-recovery01"
            job = dict(job_id=jid, protocol_sha256="reference", directory=directory)
            receipt = dict(job_id=jid, protocol_sha256="reference", remote_directory=directory,
                           experiment=w.p.REFERENCE.name, read_only_remote=True, API_requests=0, new_jobs=0,
                           terminal=dict(verified=True, job_id=jid, remote_directory=directory, state="COMPLETED"),
                           commands=dict(
                               squeue=dict(argv=["squeue", "-h", "-j", jid, "-o", "%i|%T|%j"], code=0, stdout="", stderr=""),
                               sacct=dict(argv=["sacct", "-n", "-P", "-j", jid, "--format=JobIDRaw,JobName,State,ExitCode,Start,End,Timelimit,NodeList"],
                                          code=0, stdout=jid + "|p02-factor90|COMPLETED|0:0|synthetic-start|synthetic-end|06:00:00|synthetic\n", stderr=""),
                               scontrol=dict(argv=["scontrol", "show", "job", "-o", jid], code=0,
                                             stdout="JobId=" + jid + " JobName=p02-factor90 UserId=u7830488(7830488) WorkDir=" + directory + " JobState=COMPLETED", stderr="")))
            return job, receipt
        job, receipt = scheduler("161046")
        def read(path):
            if Path(path) == w.PAUSE_AUTH: return auth
            return {"OPERATION.json": operation,
                    "LAUNCH_OR_RUNTIME_FAILURE.json": dict(error_type="FileNotFoundError", protocol_sha256="reference"),
                    "ENGINEERING_GATE.json": dict(passed=True, planned_conditions=24, quality_or_predictions_inspected=False),
                    "REMOTE_JOB_ID.json": job, "SCHEDULER_TERMINAL.json": receipt}[Path(path).name]
        def fingerprint(path):
            if Path(path) == w.PAUSE_AUTH: return "pause-auth"
            if Path(path) == w.p.PROTOCOL: return "protocol"
            if Path(path) == w.p.REFERENCE / "PROTOCOL.frozen.json": return "reference"
            return "clock"
        def metadata(folder, stage=False):
            return dict(finished=True, in_flight=0, attempted=152) if stage else dict(finished=False, in_flight=0, attempted=49)
        with patch.object(w, "REFOUT", out), patch.object(w, "PAUSE", pause), patch.object(w.full, "authorized"), \
             patch.object(w.p, "read", side_effect=read), patch.object(w.p, "sha", side_effect=fingerprint), \
             patch.object(w.p, "rows", return_value=[dict(id=auth["id"], approved=True, authorization_sha256="pause-auth")]), \
             patch.object(w.predecessors, "metadata", side_effect=metadata), \
             patch.object(w.predecessors, "reference_workers_closed", return_value=dict(closed=True)):
            result = w.base_pause_checks()
            assert result["reference90"]["finished"] is False and result["current_reference_scheduler"]["job_id"] == "161046"
            with patch.object(w.predecessors, "reference_workers_closed", return_value=dict(closed=False)):
                rejects(w.base_pause_checks)
            auth["approved"] = False; rejects(w.base_pause_checks); auth["approved"] = True
            operation["old_waiter_exited"] = False; rejects(w.base_pause_checks); operation["old_waiter_exited"] = True
            job, receipt = scheduler("160987"); rejects(w.base_pause_checks)


def check_snapshot_locks_and_real_temporary_backup():
    import p02_multigrain_timing_cachefix_v1.core.cache as cache_module
    with tempfile.TemporaryDirectory(prefix="cot_snapshot_fake_") as folder:
        root = Path(folder); out = root / "reference"; pause = out / "pause"; cot = root / "cot"
        pause.mkdir(parents=True); cot.mkdir()
        recovery = out / "continuations/recovery01"; recovery.mkdir(parents=True)
        pause_auth = root / "pause-auth.json"; snapshot = pause / "PAUSED_STATE.json"
        for path in (pause_auth, pause / "OPERATION.json", pause / "ALLOCATION_CLOCK.original.json",
                     out / "STOP_REQUESTED", out / "ENGINEERING_GATE.json", recovery / "STOP_REQUESTED",
                     recovery / "LAUNCH_OR_RUNTIME_FAILURE.json", recovery / "REMOTE_GPU_FINISHED.json", recovery / "SCHEDULER_TERMINAL.json"):
            path.write_text('{"synthetic":true}', encoding="utf8")
        source = out / "checkpoint.sqlite3"
        with fixture_db(source) as db:
            db.execute("CREATE TABLE proof(value TEXT)"); db.execute("INSERT INTO proof VALUES('temporary-synthetic-backup')")
        before = sha(source); active = []; order = []
        @contextmanager
        def lock(path):
            active.append(Path(path)); order.append(("enter", Path(path).name))
            try: yield
            finally:
                order.append(("exit", active.pop().name))
        def state():
            assert active == [out / "remote_deployment_lock", out]
            return dict(in_flight=0, synthetic_state="constant")
        def save_metadata(path, value):
            # Test snapshot ordering/backup, not the already audited atomic writer.
            # Sandboxed Windows temporary directories may reject os.replace.
            assert not active
            Path(path).write_text(json.dumps(value), encoding="utf8")
        with patch.object(w, "ROOT", root), patch.object(w.p, "ROOT", root), patch.object(w, "REFOUT", out), \
             patch.object(w, "PAUSE", pause), patch.object(w, "SNAPSHOT", snapshot), patch.object(w, "AUTH", root / "not-authorized.json"), \
             patch.object(w, "PAUSE_AUTH", pause_auth), patch.object(w.p, "OUT", cot), \
             patch.object(w, "base_pause_checks", return_value=dict(synthetic=True)), patch.object(w, "database_state", side_effect=state), \
             patch.object(w.p, "atomic_json", side_effect=save_metadata), \
             patch.object(cache_module, "run_lock", side_effect=lock):
            w.snapshot()
        assert not active and [value[0] for value in order] == ["enter", "enter", "exit", "exit"]
        assert sha(source) == before
        saved = json.loads(snapshot.read_text(encoding="utf8"))
        backup = root / saved["backup_path"]
        assert sha(backup) == saved["backup_sha256"]
        with fixture_db(backup) as db:
            assert db.execute("SELECT value FROM proof").fetchone()[0] == "temporary-synthetic-backup"
        assert saved["original_all360_barrier_satisfied"] is False


def main(output):
    initial_sha = sha(SCRIPT); results = []
    for fn in (check_database_fingerprints, check_exact_authorization, check_partial_gate_and_early_drift,
               check_local_patch_restoration, check_pause_authority_and_exact_scheduler, check_snapshot_locks_and_real_temporary_backup):
        try:
            fn(); results.append(dict(check=fn.__name__, passed=True))
        except Exception as error:
            results.append(dict(check=fn.__name__, passed=False, error_type=type(error).__name__, error=str(error)))
    unchanged = initial_sha == sha(SCRIPT)
    report = dict(passed=all(r["passed"] for r in results) and unchanged, script_sha256=initial_sha,
                  source_unchanged_during_checks=unchanged, test_script_sha256=sha(__file__), checks=results,
                  new_API_SSH_GPU_requests=0, Cache_constructed=False, production_checkpoint_ledger_source_writes=0,
                  actual_predictions_gold_native_scores_or_method_mapping_read=False,
                  temporary_synthetic_SQLite_only=True, real_pause_snapshot_or_execution_not_invoked=True,
                  synthetic_snapshot_function_invoked=True)
    target = Path(output)
    assert target.resolve().is_relative_to(HERE.resolve()) and not target.exists()
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    print(json.dumps(dict(passed=report["passed"], report=str(target), sha256=sha(target), checks=results), ensure_ascii=True))
    if not report["passed"]: raise SystemExit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default=str(HERE / "COT90_PRIORITY_INDEPENDENT_OFFLINE_REVIEW.json"))
    main(parser.parse_args().output)
