"""One authorized read-only file-metadata sample from owned CoT job161325."""
from pathlib import Path
from datetime import datetime, timezone
import getpass
import hashlib
import json
import shlex
import socket

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/query_decomposition/p02_local_cot_fixed90_v1_20261022"
DEST = OUT / "READONLY_RETRIEVAL_FILE_TIMING.json"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))

def main():
    import paramiko
    auth = ROOT / "analysis/p02_prompt_research_followup_20261022/COT90_PRIORITY_EXECUTION_AUTHORIZATION.json"
    assert hashlib.sha256(auth.read_bytes()).hexdigest() == "f8f4c307ed00263e00bcd04b18c32093f2afb32fe1d1187cc76c2fdebe3d535a"
    job = read(OUT / "REMOTE_JOB_ID.json")
    assert job == dict(job_id="161325", directory="/home/projects/u7830488/p02_prompt_small_evals_20261022/cot90_222de9cd4f7dca85",
        protocol_sha256="222de9cd4f7dca8509ab6bf1e391a27634536d2cf0b0cdf0f0e42e9dcd256702")
    assert not DEST.exists()
    events = [json.loads(line) for line in (OUT / "REMOTE_EVENTS.jsonl").open(encoding="utf8")]
    events = [row for row in events if row.get("event") == "actual_retrieval_or_exact_worker_reuse" and row.get("dataset") == "musique"]
    selected = {row["request_id"]: dict(request_id=row["request_id"], local_receipt_utc=row["utc"]) for row in events[:5] + events[-5:]}
    assert selected
    settings = read(ROOT / "experiments/query_decomposition/p02_local_cot_fixed90_v1_20261022/EXECUTION_SETTINGS.json")
    assert read(ROOT / settings["partition_preflight"])["verified_address"] == settings["verified_host_address"]
    client = paramiko.SSHClient(); client.load_system_host_keys(); client.set_missing_host_key_policy(paramiko.RejectPolicy())
    password = getpass.getpass("Remote password: "); connection = None
    try:
        connection = socket.create_connection((settings["verified_host_address"], 22), timeout=15)
        client.connect("cluster1.comp.anu.edu.au", username="u7830488", password=password, sock=connection,
            look_for_keys=False, allow_agent=False, timeout=15, auth_timeout=20, banner_timeout=15)
        password = None; commands = {}
        for name, argv in (("squeue", ["squeue", "-h", "-j", "161325", "-o", "%i|%T|%j"]),
                           ("scontrol", ["scontrol", "show", "job", "-o", "161325"])):
            _, stdout, stderr = client.exec_command(shlex.join(argv), timeout=30)
            text, error = stdout.read().decode(), stderr.read().decode(); code = stdout.channel.recv_exit_status()
            commands[name] = dict(argv=argv, code=code, stdout=text, stderr=error)
            assert code == 0 and not error.strip()
            if name == "scontrol":
                control = dict(part.split("=", 1) for part in text.split() if "=" in part)
                assert control["JobId"] == "161325" and control["UserId"] == "u7830488(7830488)"
                assert control["WorkDir"] == job["directory"] and control["JobState"] == "RUNNING"
        records = []
        with client.open_sftp() as sftp:
            for row in selected.values():
                rid = row["request_id"]
                request = sftp.stat(job["directory"] + "/requests/" + rid + ".json")
                response_path = job["directory"] + "/responses/" + rid + ".json"
                response = sftp.stat(response_path)
                with sftp.open(response_path, "rb") as stream: value = json.loads(stream.read())
                assert value["request_id"] == rid and value["status"] == "success"
                timings = {}
                for prefix, item in (("response", value), ("packet", value.get("packet", {}))):
                    for key, numeric in item.items():
                        if isinstance(numeric, (int, float)) and any(word in key.lower() for word in ("elapsed", "duration", "latency", "seconds", "time")):
                            timings[prefix + "." + key] = numeric
                receipt_epoch = datetime.fromisoformat(row["local_receipt_utc"]).timestamp()
                records.append(dict(**row, request_mtime_epoch=request.st_mtime, response_mtime_epoch=response.st_mtime,
                    request_to_response_file_seconds=response.st_mtime-request.st_mtime,
                    response_file_to_local_receipt_seconds=receipt_epoch-response.st_mtime,
                    response_top_level_keys=sorted(value), packet_top_level_keys=sorted(value.get("packet", {})), numeric_timing_fields=timings))
        result = dict(utc=datetime.now(timezone.utc).isoformat(), job=job, read_only_remote=True, samples=records,
            commands=commands, new_GPU_jobs=0, LLM_requests=0, remote_writes=0,
            limitations="File mtime has integer-second precision. The first interval combines worker visibility/polling and retrieval; the second combines response visibility/transport and local overhead. Cross-host clock offsets are not independently calibrated. No pure GPU timing or NFS cause is proved.")
        with DEST.open("x", encoding="utf8") as stream: json.dump(result, stream, indent=2); stream.write("\n")
        print(json.dumps(dict(samples=len(records), timings=[dict(request_to_response_file_seconds=r["request_to_response_file_seconds"], response_file_to_local_receipt_seconds=round(r["response_file_to_local_receipt_seconds"], 3), numeric_timing_fields=r["numeric_timing_fields"]) for r in records], artifact=str(DEST.relative_to(ROOT)), remote_writes=0, LLM_requests=0)), flush=True)
    finally:
        password = None; client.close()
        if connection: connection.close()

if __name__ == "__main__": main()
