# CoT360剩余条件的allocation接续：仅设计，非授权

当前运行继续；若360条件在原6小时窗口内已全部尝试，本方案不用执行。不修改当前目录、冻结源码或正在运行的程序；以下仅说明未来在root独立技术授权后如何接续。

## 能否直接原CLI续跑

同一个worker仍存活时，现有缓存及原priority wrapper可支持恢复；**原allocation已经关闭后，现有CLI不会自动另投GPU**。`retrieval_transport.RemoteBridge.start`读取原OUT的REMOTE_JOB_ID便复用161325；`CotBridge.can_start_condition`又根据旧job状态、marker和原ALLOCATION_CLOCK拒派。删除旧receipt/clock让它重新提交会破坏证据，不采用。

最小复用是新的分析目录技术wrapper：仅创建`ContinuationBridge(CotBridge)`，将bridge的本地`output`指定为`OUT/continuations/<固定一次性ID>`，remote directory指定为新的`cot90_<原protocol前缀>_<同一次性ID>`。保持worker/resource/检索契约字节不变，调用现成`full.run_with_bridge(new_bridge)`；**不改变full.OUT、checkpoint路径、任务ID或账务namespace**。这沿用已审核factor recovery01的bridge receipts隔离方式，不复制controller，也不需要历史模型seed。

## 必要前置门与新增记录

1. 原controller和可见性辅助进程已退出；旧job161325的真实scheduler终止身份/owner/path及worker闭合证据核实，原remote job不得复活。若TIMEOUT缺FINISHED，须单独记录真实终止证据及异常闭合，不能伪造FINISHED，也不能仅凭队列空认定已关闭。
2. 在原deployment锁与checkpoint锁下只读核零in-flight、exact meta.identity、360任务集合、已终止/held/未开始分区。保留完整SQLite backup、所有unknown/retired/request_stage记录、namespace账务行与原job/clock/closure的hash；禁止拷贝一个漏WAL的裸DB来当主库。此快照须等原运行结束才创建。
3. 新增独立技术AUTH与append decision：绑定新wrapper SHA、原protocol/sourcepins、稳定断点快照、旧closure、新固定local/remote接续目录、仅剩余未开始任务、允许的新allocation最多一次、原max5及unknown政策。记录这只改变执行资源/时序，不改样本、四臂、提示、额度、评分或主评暂停。
4. 原outcome/held集合已覆盖360则返回，不读取凭据、不SSH/提交。否则先核原STOP：若存在，不静默清理/忽略；保持现有停止语义，交root判断是否有明确技术STOP解除授权。用户暂停标记及三个主评STOP不动。本正常关闭路径优先不需要移动任何旧STOP。

## 最小hook及运行边界

- 先执行原`full.authorized()/preparation.check()`及新技术授权、闭合、稳定断点校验，再接触Cache、key或SSH。保留当前已授权的`cot90_priority_continuation.priority_status`作为短生命周期的predecessor gate hook，finally恢复；嵌套reference仍明确partial_paused，不宣称原360已完成。
- 使用同一个原OUT deployment锁防双controller/双allocation；新bridge在独立continuation目录记录新的SUBMISSION_ATTEMPT、JOB_ID、READY、CLOCK、FINISHED和scheduler终止。原父目录的161325 receipt/clock不覆盖。新submission先落durable intent；缺回执或状态不清时挂起，不再sbatch。已记录新job仅允许核实/连接同一job，不再自动新建。
- 新bridge继承原固定IP/knownhost/getpass、资源hash、qid白名单、query-only SSH、正常PENDING→READY、每条件margin以及finally关闭路径。`can_start_condition`自然读取**新bridge.output下的新CLOCK**；worker仍为原字节。不要patch全局OUT来迁移缓存或费用。
- 只调用原`run_with_bridge`：已outcome或held任务继续跳过；未开始条件的阶段/检索精确payload可复用同一原库。模型请求仍走相同全局provider gate，仍可能受r03竞争；不绕gate提速。unknown及预留保留，含initial+retired在内总attempt≤5；仅现有current-namespace无返回且无ledger返回迹象者可按原合同恢复，有返回证据不得重发。旧held条件不因续跑被重新排队。
- 合法算法失败及终止0保留，技术held分列；已完成预测不重抽、不按分数选任务。现有源码sourcepins必须全部通过，新wrapper另行pin；无需修改旧protocol。原可见性辅助固定161325，不自动转向新job；如需另用须新技术授权，不能从本接续方案暗中继承。

最低离线检查只需覆盖：已全部尝试时0服务；旧job未闭合/在途/STOP/快照漂移时服务前失败；只剩余任务被派发；新clock/目录隔离且旧字节不改；重复/未知submission不重投；重启后stage精确复用与max5/账务预留不重置；finally关闭新worker和恢复gate hook。此阶段不实现或运行这些入口。

依据：原`run.py:190`的`run_with_bridge`、`retrieval_transport.py:117`起的旧job复用、`remote_bridge.py:92`起的allocation门；已审核`factor90_runtime_recovery.py`的continuation_bridge_class/run仅作为隔离方式参考，**不复用其解除特定held/STOP或修logger的动作**。当前未启动新任务、SSH/API/GPU，未改任何运行文件。
