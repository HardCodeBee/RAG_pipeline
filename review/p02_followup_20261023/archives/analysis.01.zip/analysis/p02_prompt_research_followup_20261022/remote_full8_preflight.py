"""Read-only verification of the actual full8 remote dependencies and GPU pool."""
import getpass
import hashlib
import json
from pathlib import Path
import shlex
from datetime import datetime, timezone

import paramiko

ROOT = Path(__file__).resolve().parents[2]
HERE = ROOT / "experiments/query_decomposition/p02_failure8_dynamic_target_fullrag_draft_20261022"
OUT = ROOT / "outputs/query_decomposition" / HERE.name
BUNDLE = "/home/projects/u7830488/robustness_models_retrievers_v1_20261017"
DEPS = ("src/indexes/streaming_flat_index.py", "src/embedders/text_embedder.py", "src/persistence/artifact_io.py", "src/provenance.py")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    config = json.loads((ROOT / "src/p02_multigrain_timing_cachefix_v1/config.json").read_text(encoding="utf8"))
    model = config["resources"]["2wiki"]["dense"]["bge"]
    snapshot = Path(model["query_snapshot"])
    names = ("modules.json", "config_sentence_transformers.json", "sentence_bert_config.json", "config.json",
             "model.safetensors", "pytorch_model.bin", "tokenizer.json", "tokenizer_config.json",
             "special_tokens_map.json", "vocab.txt", "1_Pooling/config.json", "2_Normalize/config.json")
    files = {name: sha(snapshot / name) for name in names if (snapshot / name).is_file()}
    assert "modules.json" in files and "tokenizer_config.json" in files
    assert "model.safetensors" in files or "pytorch_model.bin" in files
    query_model = dict(model=model["query_model"], revision=model["query_revision"], files=files)
    file = HERE / "QUERY_MODEL.frozen.json"
    if file.exists():
        assert json.loads(file.read_text(encoding="utf8")) == query_model
    else:
        file.write_text(json.dumps(query_model, indent=2) + "\n", encoding="utf8")
    expected = {name: sha(ROOT / name) for name in DEPS}
    code = '''import json,hashlib,os,subprocess
from pathlib import Path
base=Path(BASE)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
v={'dependencies':{},'resources':{},'new_job_submitted':False}
for rel,expected in EXPECTED.items():
 p=base/rel;v['dependencies'][rel]={'exists':p.is_file(),'expected':expected,'actual':sha(p) if p.is_file() else None}
for ds in ['hotpotqa','2wiki']:
 p=base/'resources'/ds/'manifest.json';m=json.loads(p.read_text());z=json.loads((p.parent/'VALIDATED.json').read_text())
 bad=[]
 for rel,stamp in z['files'].items():
  st=(p.parent/rel).stat()
  if [st.st_size,st.st_mtime_ns]!=stamp:bad.append(rel)
 v['resources'][ds]={'manifest_sha256':sha(p),'fully_verified':z.get('fully_verified'), 'validated_manifest_matches':z.get('manifest_sha256')==sha(p),'stamp_count':len(z['files']),'changed_stamps':bad}
snapshot=base/'.remote_cache/huggingface/hub/models--BAAI--bge-small-en-v1.5/snapshots'/REVISION
v['query_model']={'snapshot':str(snapshot),'files':{}}
for rel,expected in MODEL_FILES.items():
 p=snapshot/rel;v['query_model']['files'][rel]={'exists':p.is_file(),'matches':p.is_file() and sha(p)==expected}
python=base/'.remote_env/robustness_models_retrievers_v1_20261017/venv/bin/python'
v['python_exists']=python.is_file()
for label,args in [('partition',['sinfo','-h','-p','db4ai','-o','%P|%a|%G']),('own_jobs',['squeue','-h','-u','u7830488','-o','%i|%j|%T|%N'])]:
 p=subprocess.run(args,capture_output=True,text=True,timeout=12);v[label]={'returncode':p.returncode,'stdout':p.stdout[:6000],'stderr':p.stderr[:1000]}
print(json.dumps(v))
'''
    preamble = "BASE=" + repr(BUNDLE) + "\nEXPECTED=" + repr(expected) + "\nREVISION=" + repr(model["query_revision"]) + "\nMODEL_FILES=" + repr(files) + "\n"
    client = paramiko.SSHClient()
    client.load_system_host_keys()
    client.set_missing_host_key_policy(paramiko.RejectPolicy())
    password = getpass.getpass("Remote password: ")
    try:
        client.connect("cluster1.comp.anu.edu.au", username="u7830488", password=password,
            allow_agent=False, look_for_keys=False, timeout=15, auth_timeout=20, banner_timeout=15)
        password = None
        _, stdout, stderr = client.exec_command("python3 -c " + shlex.quote(preamble + code), timeout=55)
        value = json.loads(stdout.read().decode())
        assert stdout.channel.recv_exit_status() == 0
        value.update(utc=datetime.now(timezone.utc).isoformat(), read_only=True, main_evaluation_resumed=False)
        OUT.mkdir(parents=True, exist_ok=True)
        (OUT / "REMOTE_READONLY_PREFLIGHT.json").write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
        print(json.dumps(value, ensure_ascii=True))
    finally:
        password = None
        client.close()


if __name__ == "__main__":
    main()
