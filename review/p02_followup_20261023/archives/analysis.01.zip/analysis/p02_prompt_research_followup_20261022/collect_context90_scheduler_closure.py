"""Collect real scheduler termination metadata without changing remote state."""
from pathlib import Path
from datetime import datetime, timezone
import getpass
import json
import shlex
import socket
import paramiko

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/query_decomposition/p02_shared_context_fixed90_v1_20261022'

def main():
    job = json.loads((OUT / 'REMOTE_JOB_ID.json').read_text())
    assert job['job_id'] == '159533'
    destination = OUT / 'SCHEDULER_CLOSURE.json'
    assert not destination.exists(), 'Preserve previous receipt'
    password = getpass.getpass('Remote password: ')
    client = paramiko.SSHClient()
    client.load_system_host_keys()
    client.set_missing_host_key_policy(paramiko.RejectPolicy())
    result = dict(job_id=job['job_id'], protocol_sha256=job['protocol_sha256'],
                  remote_directory=job['directory'], host='cluster1.comp.anu.edu.au',
                  read_only=True, new_jobs=0, new_model_requests=0, commands={})
    try:
        connection = socket.create_connection(('150.203.213.5', 22), timeout=15)
        client.connect(result['host'], username='u7830488', password=password, sock=connection,
                       look_for_keys=False, allow_agent=False, timeout=15, auth_timeout=20, banner_timeout=15)
        password = None
        for name, args in (
            ('squeue', ['squeue', '-h', '-j', '159533', '-o', '%i|%T']),
            ('sacct', ['sacct', '-n', '-P', '-j', '159533', '--format=JobIDRaw,JobName,State,ExitCode,Start,End,Timelimit,NodeList']),
            ('scontrol', ['scontrol', 'show', 'job', '-o', '159533'])):
            _, stdout, stderr = client.exec_command(shlex.join(args), timeout=40)
            text, error = stdout.read().decode(), stderr.read().decode()
            code = stdout.channel.recv_exit_status()
            result['commands'][name] = dict(argv=args, code=code, stdout=text, stderr=error)
            assert code == 0, (name, error)
        assert not result['commands']['squeue']['stdout'].strip()
        lines = [x.split('|') for x in result['commands']['sacct']['stdout'].splitlines()]
        parent = next(x for x in lines if x[0] == '159533')
        assert parent[2] == 'TIMEOUT'
        control = dict(x.split('=', 1) for x in result['commands']['scontrol']['stdout'].split() if '=' in x)
        assert control['UserId'].startswith('u7830488(') and control['WorkDir'] == job['directory']
        assert control['JobState'] == 'TIMEOUT' and control['JobName'] == 'p02-context90'
        result['utc'] = datetime.now(timezone.utc).isoformat()
        destination.write_text(json.dumps(result, indent=2) + '\n', encoding='utf8')
        print(json.dumps(dict(receipt=str(destination), job_id='159533', state=parent[2], new_jobs=0)))
    finally:
        password = None
        client.close()

if __name__ == '__main__':
    main()
