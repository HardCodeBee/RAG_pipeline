"""Read-only operational audit; only compact analysis reports are written."""
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import sqlite3
import time

import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "src"))
from experiments.query_decomposition.p02_local_cot_stage38_v1_20261022 import run as stage

HERE = Path(__file__).resolve().parent
STATUS = HERE / "INDEPENDENT_LOCAL_COT_RUNTIME_STATUS.json"
FINAL = HERE / "INDEPENDENT_LOCAL_COT_RUNTIME_FINAL_AUDIT.json"


def ro(path):
    return sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True)


def write(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    temporary.replace(path)


def audit():
    auth = stage.authorized()
    assert stage.predecessor_status()["finished"]
    assert auth["maximum_technical_attempts"] == 5
    assert auth["current_namespace_returnless_recovery_only"] is True
    planned = {row["task_id"] for row in stage.rows(stage.ORDER)}
    config = stage.read(stage.PACKAGE / "config.json")
    model = config["generation"]["model"]
    expected = dict(protocol_sha256=stage.sha(stage.PROTOCOL), inputs_sha256=stage.sha(stage.INPUTS),
                    order_sha256=stage.sha(stage.ORDER), historical_seed=None)
    with closing(ro(stage.OUT / "checkpoint.sqlite3")) as db:
        db.execute("BEGIN")
        identity = json.loads(db.execute("SELECT value FROM data WHERE kind='meta' AND key='identity'").fetchone()[0])
        assert identity == expected
        done = {row[0] for row in db.execute("SELECT key FROM data WHERE kind='outcome'")}
        arms = dict(db.execute("SELECT json_extract(value,'$.arm'),count(*) FROM data WHERE kind='outcome' GROUP BY 1"))
        states = dict(db.execute("SELECT status,count(*) FROM requests GROUP BY status"))
        active = {row[0] for row in db.execute("SELECT id FROM requests")}
        retired = {row[0] for row in db.execute("SELECT id FROM retired_requests")}
        maximum_attempts = db.execute("SELECT coalesce(max(n),0) FROM (SELECT count(*) n FROM (SELECT payload FROM requests UNION ALL SELECT payload FROM retired_requests) GROUP BY payload)").fetchone()[0]
        invalid_success = db.execute("""SELECT count(*) FROM requests WHERE status='success' AND (
            coalesce(json_extract(result,'$.requested_model'),'') != ? OR coalesce(json_extract(result,'$.returned_model'),'') != ?
            OR coalesce(json_type(result,'$.usage.prompt_tokens'),'') != 'integer'
            OR coalesce(json_type(result,'$.usage.completion_tokens'),'') != 'integer'
            OR coalesce(json_type(result,'$.usage.total_tokens'),'') != 'integer'
            OR json_extract(result,'$.usage.prompt_tokens') < 0 OR json_extract(result,'$.usage.completion_tokens') < 0
            OR json_extract(result,'$.usage.total_tokens') != json_extract(result,'$.usage.prompt_tokens') + json_extract(result,'$.usage.completion_tokens'))""", (model, model)).fetchone()[0]
        retired_with_return = db.execute("""SELECT count(*) FROM retired_requests r WHERE
            EXISTS(SELECT 1 FROM json_each(r.result) WHERE key IN ('response_id','raw_response','usage','returned_model','refusal','finish_reason') AND type != 'null')
            OR length(trim(coalesce(json_extract(r.result,'$.answer'),json_extract(r.result,'$.content'),''))) > 0""").fetchone()[0]
        usage = db.execute("""SELECT coalesce(sum(json_extract(result,'$.usage.prompt_tokens')),0),
            coalesce(sum(json_extract(result,'$.usage.completion_tokens')),0)
            FROM requests WHERE status='success'""").fetchone()
    held = {stage.read(path)["task_id"] for path in (stage.OUT / "held").glob("*.json")}
    assert done <= planned and held <= planned and len(planned) == 152
    namespace = "p02_prompt_research_v1_20261022/" + str(stage.OUT.resolve())
    with closing(ro(config["budget"]["ledger"])) as ledger:
        charges = {row[0]: dict(actual=row[1], reserved=row[2], status=row[3]) for row in ledger.execute(
            "SELECT id,actual,reserved,status FROM charges WHERE namespace=?", (namespace,))}
    issues = []
    if maximum_attempts > 5: issues.append("maximum_attempts_exceeded")
    if invalid_success: issues.append("invalid_success_model_or_usage")
    if retired_with_return: issues.append("retired_returned_receipt")
    if (active | retired) - charges.keys(): issues.append("request_missing_ledger_reservation")
    if any(charges[r]["actual"] is not None or charges[r]["status"] == "returned_usage" for r in retired if r in charges):
        issues.append("retired_request_has_returned_ledger_charge")
    actual = sum(r["actual"] for r in charges.values() if r["actual"] is not None)
    reserved = sum(r["reserved"] for r in charges.values() if r["actual"] is None)
    if done | held == planned and states.get("in_flight", 0) == 0 and charges.keys() - (active | retired):
        issues.append("final_ledger_charge_without_checkpoint_request")
    result = dict(utc=datetime.now(timezone.utc).isoformat(), passed=not issues, issues=issues,
        state="all152_attempted_no_inflight" if done | held == planned and states.get("in_flight", 0) == 0 else "running",
        planned=152, quality_terminal=len(done), held_technical=len(held-done), attempted=len(done | held),
        remaining=152-len(done | held), in_flight=states.get("in_flight", 0), completed_by_arm=arms,
        request_statuses=states, maximum_actual_attempts_per_payload=maximum_attempts, retired_requests=len(retired),
        invalid_success_receipts=invalid_success, retired_returned_receipts=retired_with_return,
        actual_returned_usage_CNY=actual, unresolved_reserved_CNY=reserved,
        actual_success_receipt_input_tokens=usage[0], actual_success_receipt_output_tokens=usage[1],
        token_scope="Distinct actual receipts only; not logical per-arm cost or a quality metric",
        stage_protocol_sha256=expected["protocol_sha256"], stage_AUTH_sha256=stage.sha(stage.HERE / "RUN_AUTHORIZATION.json"),
        factor_pause_authorization_sha256=stage.sha(stage.HERE / "FACTOR_TECHNICAL_PAUSE_AUTHORIZATION.json"),
        main_paused_and_frozen_pins_checked=True, checkpoint_and_ledger_read_only=True,
        predictions_gold_native_scores_not_reviewed=True, new_API_SSH_GPU_requests=0)
    write(STATUS, result)
    if result["state"] == "all152_attempted_no_inflight":
        write(FINAL, result)
        if result["passed"]:
            from export_local_cot_blind_review import export
            export("supplemental30")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("--watch", action="store_true")
    args = parser.parse_args()
    while True:
        result = audit()
        print(json.dumps({key: result[key] for key in ("utc", "passed", "issues", "state", "attempted", "remaining", "in_flight", "actual_returned_usage_CNY", "unresolved_reserved_CNY")}), flush=True)
        if not args.watch or not result["passed"] or result["state"] == "all152_attempted_no_inflight": return
        time.sleep(30)


if __name__ == "__main__": main()
