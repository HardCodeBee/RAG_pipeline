# Factor90 logging-failure recovery01

Prepared offline; execution requires the root's separate hash authorization and completed CoT152 metadata barrier. No new worker or model request has been issued by this supplement.

Job160987 completed after the controller exited. Two conditions completed; the third (first HotpotQA query, B1) is held; 357 conditions have not started. The engineering24 gate has not passed. No quality scores were inspected for recovery.

The frozen logger uses `dict(utc=utc(), **value)`. The frozen retry implementation legitimately passes an existing `utc` in a bounded-recovery event. The duplicate keyword crashes logging, and logging the resulting held record fails again. The new wrapper changes only the in-process `full90.event` callback to copy the event and supply UTC only when absent. Frozen source, payloads, model, prompts, output allowances, order, retrieval and scientific protocol remain unchanged.

The request `898a4a415ca44e6f83bed2c6494308a8` has one retired unknown attempt, no active same-payload request, no returned evidence and no actual ledger charge. Its 0.0054296 CNY unknown reservation remains. This does not prove that the provider did no work. Four successful prefix receipts are retained and exactly reused. The one held task can be released only by the root's explicit list in the supplement authorization; all other held tasks remain skipped. Five total actual attempts including the initial attempt remain the limit.

Original job, READY, STOP, held record, events, scheduler receipt and a SQLite backup are in `outputs/query_decomposition/p02_reference_binding_priority_fixed90_v1_20261022/incidents/job160987_logging_failure/`. Their original files remain untouched during preparation. No local graceful FINISHED receipt was available at snapshot time; the snapshot does not fabricate one.

After CoT reaches all152 attempted with zero in-flight requests, authorized run archives only the exact original STOP and B1 held file into `continuations/recovery01/`. It retains the original checkpoint and charges namespace. New GPU deployment uses a distinct remote directory ending `_recovery01`, with its JOB/READY/FINISHED/clock receipts in that continuation directory. Old160987 metadata remains in place. The remote job keeps the frozen six-hour limit, closes when the controller exits, and does not automatically resubmit. An incomplete/failed launch requires receipt review; the release action is deliberately one-shot.

The paired watcher reads the new job metadata, uses the same owned-job terminal verification as the existing audited watcher, writes new terminal/heartbeat receipts in the continuation directory and sends any verified early-terminal STOP to the original controller output directory. It never changes cache or submits work.

Any exception after release begins records its error type and creates exclusive STOP signals in both the controller and continuation directories, preserving archived markers and holds. This includes partial release, SSH/start failure and runtime failure. A watcher waiting for a job can therefore exit on failed launch. A competing entrypoint that cannot acquire the deployment/checkpoint lock does not disturb the current owner.

Preparation and review commands:

```powershell
python analysis/p02_prompt_research_followup_20261022/test_factor90_runtime_recovery.py
python analysis/p02_prompt_research_followup_20261022/factor90_runtime_recovery.py status
python analysis/p02_prompt_research_followup_20261022/factor90_runtime_recovery.py auth-template
```

After root authorization and independent audit, launch the controller and watcher in separate PTYs:

```powershell
python analysis/p02_prompt_research_followup_20261022/factor90_runtime_recovery.py run --wait
python analysis/p02_prompt_research_followup_20261022/factor90_runtime_recovery.py watch
```

Credentials are entered only at an actual getpass prompt. No credential is saved. Main evaluation remains paused. The first24 engineering gate remains mandatory; no F1 threshold selects continuation or factors.
