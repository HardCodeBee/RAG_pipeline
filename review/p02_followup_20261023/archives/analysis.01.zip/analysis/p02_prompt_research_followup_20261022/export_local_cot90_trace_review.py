"""Read-only, post-completion evidence export for the frozen four-arm fixed90.

No scorer, experiment runner, API, network, GPU, or historical DB is imported.
Scores are copied from official DETAILS/PAIRED. A stable SQLite read transaction
and a second logical snapshot bind the evidence to those score artifacts.
Run --self-test before use; --export fails closed until all360 are attempted.
"""
from collections import Counter
from contextlib import closing
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import math
import sqlite3
import tempfile
import unicodedata

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
EXPERIMENT = "p02_local_cot_fixed90_v1_20261022"
SOURCE = ROOT / "experiments/query_decomposition" / EXPERIMENT
OUTPUT = ROOT / "outputs/query_decomposition" / EXPERIMENT
EXPORT = HERE / "local_cot90_trace_review"
ARMS = ("N128", "N256", "F256", "R256")
PAIRS = (("N128", "N256"), ("N128", "F256"), ("N128", "R256"), ("F256", "R256"))
QUALITY = {"success", "success_truncated", "algorithm_failure"}
CASE_FIELDS = ("id", "qid", "dataset", "question", "supporting_questions")


def require(test, message):
    if not test:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode("utf8")).hexdigest()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def rows(path):
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def index_unique(values, key, title):
    result = {key(row): row for row in values}
    require(len(result) == len(values), "Duplicate " + title)
    return result


def ready(status):
    return (status.get("status") == "all_attempted" and status.get("planned_conditions") == 360
            and status.get("attempted") == 360 and status.get("not_started") == 0
            and status.get("request_statuses", {}).get("in_flight", 0) == 0)


def frozen_pins():
    protocol = read(SOURCE / "PROTOCOL.frozen.json")
    require(protocol["experiment"] == EXPERIMENT and protocol["planned_conditions"] == 360, "Protocol scope")
    for name, expected in {**protocol["pins"], **protocol["protected_holds"]}.items():
        require(sha(ROOT / name) == expected, "Frozen source or pause marker changed: " + name)
    require(read(SOURCE.parent / "unified_rag_eval_v1_20261021/PLAN.json")["execution_approval"]["approved"] is False,
            "Main evaluation must remain paused")


def source_files():
    paths = [OUTPUT / name for name in ("STATUS.json", "REPORT.json", "DETAILS.jsonl", "PAIRED.jsonl")]
    if (OUTPUT / "SCHEDULING_EXECUTION.json").is_file():
        paths.append(OUTPUT / "SCHEDULING_EXECUTION.json")
    paths += sorted((OUTPUT / "held").glob("*.json"))
    paths += [SOURCE / name for name in ("PROTOCOL.frozen.json", "INPUTS90.jsonl", "ORDER360.jsonl",
              "SOURCE_PROVENANCE90.jsonl", "references90.local.jsonl", "RESOURCE_CONTRACTS.json")]
    return {str(path.relative_to(ROOT).as_posix()): sha(path) for path in paths}


def logical_snapshot(db):
    """Transaction snapshot; reading WAL correctly requires mode=ro, not immutable."""
    db.execute("BEGIN")
    try:
        require(db.execute("PRAGMA quick_check").fetchone()[0] == "ok", "SQLite quick_check")
        data = list(db.execute("SELECT kind,key,value FROM data ORDER BY kind,key"))
        requests = list(db.execute("SELECT id,stage,payload,status,started,completed,result FROM requests ORDER BY id"))
        uses = list(db.execute("SELECT request_id,stage FROM request_stages ORDER BY request_id,stage"))
        require(not any(row[3] == "in_flight" for row in requests), "Requests still in flight")
        return dict(data=data, requests=requests, uses=uses)
    finally:
        db.rollback()


def decode_snapshot(raw):
    data = {}
    for kind, key, value in raw["data"]:
        data.setdefault(kind, {})[key] = json.loads(value)
    requests = {row[0]: dict(request_id=row[0], stage=row[1], payload=json.loads(row[2]),
                 status=row[3], result=json.loads(row[6]) if row[6] else None)
                for row in raw["requests"]}
    return dict(data=data, requests=requests, uses=raw["uses"])


def validate_scores(tasks, inputs, outcomes, held, details, paired, report):
    planned = index_unique(tasks, lambda r: r["task_id"], "task")
    require(not set(outcomes).intersection(held), "Held/outcome collision")
    require(set(outcomes) | set(held) == set(planned), "Incomplete or extra conditions")
    scores = index_unique(details, lambda r: r["task_id"], "score")
    require(set(scores) == set(planned), "Official DETAILS coverage")
    for tid, task in planned.items():
        row, value = scores[tid], outcomes.get(tid, held.get(tid))
        require(all(row[k] == value[k] == task[k] for k in ("task_id", "id", "dataset", "arm")), "Score identity mismatch")
        if tid in outcomes:
            require(row["status"] == value["status"] and row["status"] in QUALITY, "Terminal score status mismatch")
            require(row["prediction"] == value["prediction"], "Stale score prediction")
            require(all(type(row[m]) in (int, float) and math.isfinite(row[m]) and 0 <= row[m] <= 1 for m in ("f1", "em")),
                    "Invalid official metric")
            if row["status"] == "algorithm_failure":
                require(row["f1"] == row["em"] == 0, "Algorithm failure must retain official zero")
        else:
            require(row["status"] == "technical_held" and row["prediction"] is None
                    and row["f1"] is None and row["em"] is None, "Technical absence must stay missing")
    pairs = index_unique(paired, lambda r: (r["id"], r["reference_arm"], r["candidate_arm"]), "pair")
    expected = set()
    for item in inputs:
        for ref, cand in PAIRS:
            a, b = scores[item["id"] + "/" + ref], scores[item["id"] + "/" + cand]
            if a["f1"] is None or b["f1"] is None:
                continue
            key = item["id"], ref, cand
            expected.add(key)
            require(key in pairs, "Missing official pair")
            require(pairs[key]["dataset"] == item["dataset"], "Pair dataset mismatch")
            for metric, column in (("f1", "delta_F1"), ("em", "delta_EM")):
                require(math.isclose(pairs[key][column], b[metric] - a[metric], abs_tol=1e-12), "Stale official pair delta")
    require(set(pairs) == expected, "Official PAIRED coverage mismatch")
    require(report["checkpoint_in_flight_at_snapshot"] == 0, "Official scoring occurred in flight")
    require(report["all_planned"]["planned_queries"] == len(inputs), "Official report denominator")
    for arm in ARMS:
        found = [r for r in details if r["arm"] == arm and r["f1"] is not None]
        section = report["arms"][arm]
        require(section["quality_terminal"] == len(found) and section["missing"] == len(inputs) - len(found), "Stale arm coverage")
        for metric, label in (("f1", "F1"), ("em", "EM")):
            available = sum(row[metric] for row in found) / len(found) if found else None
            full = available if len(found) == len(inputs) else None
            for column, expected in ((label, full), (label + "_available", available)):
                actual = section[column]
                require(actual is None if expected is None else type(actual) in (int, float)
                        and math.isclose(actual, expected, abs_tol=1e-12), "Stale official report mean")
    for ref, cand in PAIRS:
        found = [r for r in paired if r["reference_arm"] == ref and r["candidate_arm"] == cand]
        section = report["paired_predeclared"][ref + "_to_" + cand]
        require(section["complete_pairs"] == len(found) and section["missing_pairs"] == len(inputs) - len(found), "Stale pair coverage")
        for column in ("delta_F1", "delta_EM"):
            expected = sum(row[column] for row in found) / len(found) if found else None
            actual = section[column]
            require(actual is None if expected is None else type(actual) in (int, float)
                    and math.isclose(actual, expected, abs_tol=1e-12), "Stale official paired mean")
    return scores, pairs


class Catalog:
    """Exact strings and documents occur once per case, referenced by content hash."""
    def __init__(self):
        self.prompts, self.documents = {}, {}

    def prompt(self, text):
        if text is None:
            return None
        require(isinstance(text, str), "Prompt must be exact text")
        key = digest(text)
        self.prompts[key] = text
        return key

    def packet(self, packet):
        if packet is None:
            return None
        require(len(packet["docs"]) == 10 and len({d["doc_id"] for d in packet["docs"]}) == 10, "Packet must have ten unique documents")
        result = {k: v for k, v in packet.items() if k != "docs"}
        result["docs"] = []
        for doc in packet["docs"]:
            key = digest(doc)
            self.documents[key] = doc
            result["docs"].append(dict(document_ref=key, doc_id=doc["doc_id"], source=doc["source"],
                                       rank=doc["rank"], text_sha256=digest(doc["text"])))
        return result


def request_evidence(row, catalog):
    result = row["result"] or {}
    messages = deepcopy(row["payload"].get("messages", []))
    for message in messages:
        if isinstance(message.get("content"), str):
            message["content_ref"] = catalog.prompt(message.pop("content"))
    return dict(request_id=row["request_id"], status=row["status"], payload_sha256=digest(row["payload"]),
                messages=messages, output_cap=row["payload"].get("max_tokens"),
                model=row["payload"].get("model"), answer=result.get("answer"), finish_reason=result.get("finish_reason"),
                usage=result.get("usage"), refusal=result.get("refusal"), returned_response_id=result.get("response_id"))


def lookup_retrieval(data, resources, case, query):
    request = dict(protocol="p02-dynamic-retrieval-jsonl-draft-v1", resource_identity=resources[case["dataset"]]["identity"],
                   dataset=case["dataset"], qid=case["qid"], query=query, k=10)
    return data.get("retrieval", {}).get(digest(request))


def merged_packet(original, rewritten):
    """Reconstruct the frozen interleave solely to check saved reader identity."""
    if rewritten is None:
        return original
    docs, seen = [], set()
    for rank in range(10):
        for route in (original, rewritten):
            if rank < len(route["docs"]):
                doc = route["docs"][rank]
                if doc["doc_id"] not in seen:
                    seen.add(doc["doc_id"])
                    docs.append(doc)
    docs = [dict(doc, rank=rank, block=f'[Chunk {rank} | source={doc["source"]}, pages=1-1]\n{doc["text"]}')
            for rank, doc in enumerate(docs[:10], 1)]
    return dict(qid=original["qid"], query=original["query"], k=10, docs=docs,
                merge_policy="interleave_original_first_top10")


def compact_arm(case, arm, value, score, snapshot, resources, catalog):
    data = snapshot["data"]
    trajectory = value.get("trajectory")
    nodes = trajectory["nodes"] if trajectory else value.get("partial_nodes", [])
    candidates = value.get("candidate_outputs", [])
    tid = case["id"] + "/" + arm
    if trajectory:
        require(all(trajectory[k] == case[k] for k in CASE_FIELDS), "Frozen decomposition/input mismatch")
        require(len(nodes) == len(case["supporting_questions"]) + 1, "Successful trajectory lacks expected nodes")
    node_map = index_unique(nodes, lambda r: r["step_id"], "node")
    cand_map = index_unique(candidates, lambda r: r["step_id"], "candidate")
    stages = index_unique(value.get("stages", []), lambda r: r["stage"], "stage")
    for stage, receipt in stages.items():
        require(data.get("stage", {}).get(tid + "/" + stage) == receipt, "Persisted stage/outcome disagreement")
        request = snapshot["requests"].get(receipt["request_id"])
        require(request is not None and digest(request["payload"]) == receipt["payload_sha256"], "Stage/exact request mismatch")
        raw_answer = (request["result"] or {}).get("answer")
        require((raw_answer.strip() if isinstance(raw_answer, str) else "") == receipt["answer"], "Stage/raw receipt mismatch")
    node_rows, history = [], []
    for sid in sorted(set(node_map) | set(cand_map)):
        require(1 <= sid <= len(case["supporting_questions"]) + 1, "Unexpected step id")
        node, candidate = node_map.get(sid), cand_map.get(sid)
        require(candidate is not None, "Committed node has no raw candidate")
        role = "ordinary" if sid <= len(case["supporting_questions"]) else "goal"
        question = case["supporting_questions"][sid - 1] if role == "ordinary" else case["question"]
        require(candidate["role"] == role and candidate["current_question"] == question and candidate["arm"] == arm, "Candidate input mismatch")
        require(candidate["prior_complete_answers"] == history, "Candidate history is not own accepted answers")
        require(data.get("candidate_output", {}).get(tid + "/" + str(sid)) == candidate, "Persisted raw candidate mismatch")
        answer_receipt = stages.get("legacy/answer/" + str(sid))
        require(answer_receipt is not None and candidate["raw_output"] == answer_receipt["answer"], "Raw candidate/native answer receipt mismatch")
        rewrite = node["rewritten_query"] if node else candidate["accepted_rewrite"]
        rewritten = node.get("rewritten_retrieval") if node else (lookup_retrieval(data, resources, case, rewrite) if rewrite != question else None)
        if rewrite != question:
            require(rewritten is not None, "Missing exact rewritten candidate packet")
        require(candidate["reader_packet"] == merged_packet(candidate["original_retrieval"], rewritten), "Reader does not match exact candidate routes")
        if role == "goal":
            require(candidate["actual_child_prompt"] == candidate["raw_P02_child_prompt"] and candidate["output_cap"] == 128, "Goal treatment changed")
        fmt = stages.get("legacy/sentence_format/" + str(sid))
        if node:
            require(data.get("node", {}).get(tid + "/" + str(sid)) == node, "Persisted node mismatch")
            require(node["request"] == question and node["role"] == role and node["prior_complete_answers"] == history, "Committed node input/history mismatch")
            local = node["local_cot"]
            require(local["raw_output"] == candidate["raw_output"] and local["support"] == candidate["support"]
                    and local["parsed_answer"] == candidate["parsed_answer"] and local["accepted_answer"] == node["answer"]
                    and local["support_forwarded"] is False, "Raw/Support/Answer boundary mismatch")
            require(node["initial_answer"] == candidate["parsed_answer"] and node["child_prompt"] == candidate["actual_child_prompt"]
                    and node["raw_P02_child_prompt"] == candidate["raw_P02_child_prompt"], "Node/raw prompt or parsed answer mismatch")
            if node["sentence_format_request_id"]:
                require(fmt is not None and fmt["request_id"] == node["sentence_format_request_id"]
                        and node["answer"] == fmt["answer"], "Formatter did not determine accepted answer")
            else:
                require(node["answer"] == candidate["parsed_answer"], "Unformatted accepted answer changed")
        rewrite_stage = stages.get("legacy/rewrite/" + str(sid))
        row = dict(step_id=sid, role=role, question=question, committed=node is not None,
            history_before=history.copy(), raw_output=candidate.get("raw_output"), support=candidate.get("support"),
            parsed_answer=candidate.get("parsed_answer"), accepted_answer=node["answer"] if node else None,
            parser_status=candidate["parser_status"], parser_reason=candidate.get("parser_reason"),
            generation_terminal_reason=candidate.get("generation_terminal_reason"),
            native_prompt_ref=catalog.prompt(candidate["raw_P02_child_prompt"]),
            actual_prompt_ref=catalog.prompt(candidate["actual_child_prompt"]), output_cap=candidate["output_cap"],
            raw_rewrite=node.get("raw_rewrite") if node else (rewrite_stage or {}).get("answer"),
            rewritten_query=rewrite, rewrite_rejection=node.get("rewrite_rejection") if node else None,
            rewrite_prompt_ref=catalog.prompt(node.get("rewrite_prompt")) if node else None,
            original_candidates=catalog.packet(candidate["original_retrieval"]),
            rewritten_candidates=catalog.packet(rewritten), reader_documents=catalog.packet(candidate["reader_packet"]),
            formatter=fmt, rewrite_receipt=rewrite_stage,
            answer_receipt=stages.get("legacy/answer/" + str(sid)),
            rewritten_packet_source="committed node" if node else "same-query current-run exact retrieval cache",
            support_forwarded=False)
        node_rows.append(row)
        if node:
            history.append(dict(step_id=sid, request=question, answer=node["answer"]))
    uses = [(rid, stage.removeprefix("full8/" + tid + "/")) for rid, stage in snapshot["uses"]
            if stage.startswith("full8/" + tid + "/")]
    requests = [dict(logical_stage=stage, **request_evidence(snapshot["requests"][rid], catalog)) for rid, stage in uses]
    final_stage = stages.get("legacy/final")
    final_prompt = trajectory.get("final_prompt") if trajectory else None
    final_requests = [r for r in requests if r["logical_stage"] == "legacy/final"]
    final_prompt_ref = catalog.prompt(final_prompt)
    final_user_refs = {m["content_ref"] for r in final_requests for m in r["messages"]
                       if m.get("role") == "user" and "content_ref" in m}
    if final_prompt_ref is not None:
        require(final_prompt_ref in final_user_refs, "Final prompt/request mismatch")
    elif len(final_user_refs) == 1:
        final_prompt_ref = next(iter(final_user_refs))
    return dict(arm=arm, status=value["status"], score=score, nodes=node_rows,
                decomposition_verified_against_trajectory=trajectory is not None,
                frozen_inputs_verified_for_reached_nodes=True, stages=list(stages.values()), requests=requests,
                terminal_reason=value.get("terminal_reason"), terminal_stage=value.get("terminal_stage"),
                technical_error_type=value.get("error_type"),
                final=dict(prompt_ref=final_prompt_ref, prediction=value.get("prediction"), receipt=final_stage,
                           request_evidence=final_requests, root_original_documents=catalog.packet(trajectory.get("original_retrieval")) if trajectory else None))


def format_skeleton(text):
    """Conservative surface-only flag, not semantic truth or native normalization."""
    return "".join(c for c in (text or "").casefold() if not c.isspace() and not unicodedata.category(c).startswith("P"))


def doc_signature(packet):
    return [(d["doc_id"], d["source"], d["text_sha256"]) for d in (packet or {}).get("docs", [])]


def compare_traces(a, b, pair):
    left, right = ({n["step_id"]: n for n in arm["nodes"]} for arm in (a, b))
    differences = []
    # Order follows runtime dependencies; prompt/cap treatment is deliberately
    # separate from first observed intermediate output or retrieval difference.
    fields = ("history_before", "original_candidates", "raw_rewrite", "rewritten_query", "rewritten_candidates",
              "reader_documents", "native_prompt_ref", "actual_prompt_ref", "output_cap", "raw_output", "support",
              "parsed_answer", "accepted_answer", "parser_status", "generation_terminal_reason", "committed")
    for sid in sorted(set(left) | set(right)):
        x, y = left.get(sid), right.get(sid)
        if x is None or y is None:
            differences.append(dict(step_id=sid, role=(x or y)["role"], field="node_presence", reference=x is not None, candidate=y is not None))
            continue
        for field in fields:
            av, bv = x.get(field), y.get(field)
            if field in ("original_candidates", "rewritten_candidates", "reader_documents"):
                av, bv = doc_signature(av), doc_signature(bv)
            if av != bv:
                differences.append(dict(step_id=sid, role=x["role"], field=field, reference=av, candidate=bv))
    ordinary = [d for d in differences if d["role"] == "ordinary"]
    outputs = [d for d in ordinary if d["field"] in ("raw_output", "support", "parsed_answer", "accepted_answer", "parser_status", "generation_terminal_reason", "node_presence")]
    accepted = [d for d in ordinary if d["field"] == "accepted_answer"]
    all_accepted_equal = (len(left) == len(right) and all(left[sid]["accepted_answer"] == right[sid]["accepted_answer"] for sid in left if sid in right))
    af, bf = a["final"], b["final"]
    final_changed = af["prediction"] != bf["prediction"]
    final_only_observed = (all_accepted_equal and af["prompt_ref"] is not None and af["prompt_ref"] == bf["prompt_ref"] and final_changed)
    surface = (final_changed and isinstance(af["prediction"], str) and isinstance(bf["prediction"], str)
               and format_skeleton(af["prediction"]) == format_skeleton(bf["prediction"]))
    return dict(reference_arm=a["arm"], candidate_arm=b["arm"], official_pair=pair,
        score_status="paired" if pair is not None else "technical_missing_pair_not_scored",
        first_ordinary_observed_output_difference=outputs[0] if outputs else None,
        first_ordinary_accepted_answer_difference=accepted[0] if accepted else None,
        ordinary_accepted_answers_equal=not accepted and not any(d["role"] == "ordinary" and d["field"] == "node_presence" for d in differences),
        differences=differences,
        final_prompt_equal=af["prompt_ref"] == bf["prompt_ref"] if af["prompt_ref"] is not None and bf["prompt_ref"] is not None else None,
        final_prediction_changed=final_changed, final_prediction_reference=af["prediction"], final_prediction_candidate=bf["prediction"],
        final_prediction_changed_under_identical_final_input=final_only_observed,
        final_surface_case_space_punctuation_only=surface,
        semantic_cause="unreviewed; exact differences do not establish factual cause",
        semantic_review=dict(status="pending", first_factual_change=None, evidence_document_refs=[],
                             propagation_explanation=None, final_formatting_only_confirmed=None, unresolved_facts=[]))


def create_packets(inputs, provenance, references, scores, pairs, snapshot, held, resources):
    outcomes = snapshot["data"].get("outcome", {})
    packets, index = [], []
    for case in inputs:
        catalog = Catalog()
        arms = {arm: compact_arm(case, arm, outcomes.get(case["id"] + "/" + arm, held.get(case["id"] + "/" + arm)),
                    scores[case["id"] + "/" + arm], snapshot, resources, catalog) for arm in ARMS}
        comparisons = {ref + "_to_" + cand: compare_traces(arms[ref], arms[cand], pairs.get((case["id"], ref, cand))) for ref, cand in PAIRS}
        primary = comparisons["N128_to_R256"]
        pair = primary["official_pair"]
        delta = pair["delta_F1"] if pair else None
        result = "technical_missing" if delta is None else "improved" if delta > 0 else "harmed" if delta < 0 else "tied"
        filename = hashlib.sha256(case["id"].encode()).hexdigest()[:16] + ".json"
        packet = dict(schema="local_cot90_exact_trace_v1", **{k: case[k] for k in CASE_FIELDS},
            goal_only=not case["supporting_questions"], frozen_decomposition_shared_across_all_arms=True,
            decomposition_provenance=provenance[case["id"]], local_scoring_reference=references[case["id"]],
            scoring_reference_is_not_independent_semantic_truth=True, arms=arms, comparisons=comparisons,
            prompts=catalog.prompts, documents=catalog.documents)
        packets.append((filename, packet))
        index.append(dict(id=case["id"], dataset=case["dataset"], goal_only=packet["goal_only"],
            evidence_file="cases/" + filename, R256_vs_N128_F1=result, delta_F1=delta, delta_EM=pair["delta_EM"] if pair else None,
            prediction_changed=primary["final_prediction_changed"], trace_changed=bool(primary["differences"]),
            first_ordinary_accepted_answer_difference=primary["first_ordinary_accepted_answer_difference"],
            final_prediction_changed_under_identical_final_input=primary["final_prediction_changed_under_identical_final_input"],
            final_surface_case_space_punctuation_only=primary["final_surface_case_space_punctuation_only"],
            statuses={arm: arms[arm]["status"] for arm in ARMS}, semantic_review_status="pending"))
    return packets, index


def write_json(path, value):
    with Path(path).open("x", encoding="utf8", newline="\n") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def export():
    require(not EXPORT.exists(), "Export exists; preserve it and review rather than overwrite")
    require((OUTPUT / "STATUS.json").is_file() and ready(read(OUTPUT / "STATUS.json")), "All360/zero-in-flight completion gate is not met; no quality/trace export")
    require(all((OUTPUT / name).is_file() for name in ("REPORT.json", "DETAILS.jsonl", "PAIRED.jsonl")), "Official completed scoring artifacts are required")
    frozen_pins()
    before = source_files()
    inputs, tasks = rows(SOURCE / "INPUTS90.jsonl"), rows(SOURCE / "ORDER360.jsonl")
    require(len(inputs) == 90 and len(tasks) == 360 and sum(bool(c["supporting_questions"]) for c in inputs) == 84, "Frozen cohort dimensions")
    provenance = index_unique(rows(SOURCE / "SOURCE_PROVENANCE90.jsonl"), lambda r: r["id"], "provenance")
    references = index_unique(rows(SOURCE / "references90.local.jsonl"), lambda r: r["id"], "reference")
    held = index_unique([read(p) for p in sorted((OUTPUT / "held").glob("*.json"))], lambda r: r["task_id"], "held condition")
    report, details, paired = read(OUTPUT / "REPORT.json"), rows(OUTPUT / "DETAILS.jsonl"), rows(OUTPUT / "PAIRED.jsonl")
    uri = (OUTPUT / "checkpoint.sqlite3").resolve().as_uri() + "?mode=ro"
    with closing(sqlite3.connect(uri, uri=True)) as db:
        db.execute("PRAGMA query_only=ON")
        raw = logical_snapshot(db)
        snapshot = decode_snapshot(raw)
        identity = snapshot["data"]["meta"]["identity"]
        for key, name, report_key in (("protocol_sha256", "PROTOCOL.frozen.json", "protocol_sha256"),
                ("inputs_sha256", "INPUTS90.jsonl", "input_sha256"), ("order_sha256", "ORDER360.jsonl", "order_sha256")):
            require(identity[key] == report[report_key] == sha(SOURCE / name), "Checkpoint/score identity mismatch")
        scores, pairs = validate_scores(tasks, inputs, snapshot["data"].get("outcome", {}), held, details, paired, report)
        packets, index = create_packets(inputs, provenance, references, scores, pairs, snapshot, held, read(SOURCE / "RESOURCE_CONTRACTS.json"))
        require(digest(raw) == digest(logical_snapshot(db)), "Database changed during export preparation")
    require(source_files() == before, "Scoring/held/source files changed during export preparation")
    frozen_pins()
    EXPORT.mkdir()
    (EXPORT / "cases").mkdir()
    for filename, packet in packets:
        write_json(EXPORT / "cases" / filename, packet)
    with (EXPORT / "INDEX.jsonl").open("x", encoding="utf8", newline="\n") as stream:
        stream.writelines(json.dumps(row, ensure_ascii=False) + "\n" for row in index)
    summary = dict(schema="local_cot90_trace_export_v1", utc=datetime.now(timezone.utc).isoformat(), experiment=EXPERIMENT,
        queries=len(index), conditions=len(details), goal_only=sum(r["goal_only"] for r in index),
        official_report_summary={key: report[key] for key in ("arms", "by_dataset", "paired_predeclared", "ordinary_present_sensitivity")},
        R256_vs_N128_counts=dict(Counter(r["R256_vs_N128_F1"] for r in index)),
        score_changed_ids=[r["id"] for r in index if r["delta_F1"] not in (None, 0) or r["delta_EM"] not in (None, 0)],
        prediction_changed_ids=[r["id"] for r in index if r["prediction_changed"]],
        semantic_labels_created=0, semantic_review_required=True, source_hashes=before,
        sqlite_snapshot_sha256=digest(raw), sqlite_mode="mode=ro; query_only; explicit transactions; two equal logical snapshots",
        script_sha256=sha(__file__), no_API_SSH_GPU_or_extra_model_evaluation=True, no_checkpoint_ledger_historical_writes=True,
        interpretation="Exposed development cohort. First exact changes locate observations; they do not identify factual correctness or causal mechanisms.")
    scheduling_path = OUTPUT / "SCHEDULING_EXECUTION.json"
    if scheduling_path.is_file():
        scheduling = read(scheduling_path)
        summary["scheduling_execution"] = dict(path=scheduling_path.relative_to(ROOT).as_posix(),
            sha256=before[scheduling_path.relative_to(ROOT).as_posix()],
            original_all360_barrier_satisfied=scheduling.get("original_all360_barrier_satisfied"),
            receipt=scheduling,
            note="Recorded actual scheduling exception. Export gates only the new CoT360 completion and score/trace consistency, not historical predecessor completion.")
    write_json(EXPORT / "SUMMARY.json", summary)
    with (EXPORT / "README.md").open("x", encoding="utf8", newline="\n") as stream:
        stream.write("# Fixed90 exact trace review packet\n\nScores and paired deltas are copied from the experiment's official DETAILS/PAIRED artifacts. Technical holds remain missing; algorithm failures retain official zero. All90 and ordinary-present84 are separate.\n\nINDEX.jsonl lists every frozen query, the R256 versus fresh N128 change, and its case file. Every case includes all four arms and N128-to-N256, N128-to-F256, N128-to-R256, F256-to-R256 comparisons. Exact prompt strings and full document text are in each case's prompts/documents catalogs; refs are content hashes, not truncations.\n\nReview every F1/EM-changed case and prediction-changed tie. Read the first ordinary accepted-answer difference, its actual reader evidence, later rewrite/candidate/reader differences, goal evidence, and final prompt/prediction. A raw Support change that never changes accepted Answer is separate from downstream propagation. Failed uncommitted candidates and unsuccessful request receipts are retained. Missing nodes are not fabricated.\n\nThe final_surface_case_space_punctuation_only field is only a conservative character-level check. final_prediction_changed_under_identical_final_input means accepted nodes and the exact final prompt agree; raw Support can still differ and it does not establish semantic formatting equivalence. All semantic review fields remain pending. Local scoring references may themselves need semantic review and are not independent truth. No automatic causal label, arm selection, extra model evaluation or publication is performed.\n")
    return {key: summary[key] for key in ("queries", "conditions", "goal_only", "R256_vs_N128_counts", "semantic_labels_created")}


def self_test():
    checks = []
    require(not ready(dict(status="partial", attempted=359, planned_conditions=360, not_started=1)), "Partial gate accepted")
    require(not ready(dict(status="all_attempted", attempted=360, planned_conditions=360, not_started=0, request_statuses={"in_flight": 1})), "In-flight gate accepted")
    checks.append("partial_and_in_flight_blocked")
    with tempfile.TemporaryDirectory(prefix="cot90_trace_test_") as folder:
        dbpath = Path(folder) / "synthetic.sqlite3"
        with closing(sqlite3.connect(dbpath)) as db:
            db.executescript("CREATE TABLE data(kind TEXT,key TEXT,value TEXT); CREATE TABLE requests(id TEXT,stage TEXT,payload TEXT,status TEXT,started TEXT,completed TEXT,result TEXT); CREATE TABLE request_stages(request_id TEXT,stage TEXT);")
        before = dbpath.read_bytes()
        with closing(sqlite3.connect(dbpath.as_uri() + "?mode=ro", uri=True)) as db:
            db.execute("PRAGMA query_only=ON")
            require(logical_snapshot(db) == logical_snapshot(db), "Snapshot instability")
            try:
                db.execute("INSERT INTO data VALUES('x','x','{}')")
            except sqlite3.OperationalError:
                pass
            else:
                raise ValueError("Read-only DB accepted write")
        require(dbpath.read_bytes() == before, "Source bytes changed")
    checks.append("read_only_stable_snapshot_preserves_source_bytes")
    inputs = [dict(id="synthetic", dataset="hotpotqa", supporting_questions=[])]
    tasks = [dict(task_id="synthetic/" + a, id="synthetic", dataset="hotpotqa", arm=a) for a in ARMS]
    outcomes = {t["task_id"]: dict(**t, status="algorithm_failure" if t["arm"] == "F256" else "success", prediction="" if t["arm"] == "F256" else "Alpha") for t in tasks if t["arm"] != "R256"}
    held = {"synthetic/R256": dict(**tasks[-1], status="held_technical")}
    details = [dict(**t, status="technical_held" if t["arm"] == "R256" else outcomes[t["task_id"]]["status"], prediction=None if t["arm"] == "R256" else outcomes[t["task_id"]]["prediction"], f1=None if t["arm"] == "R256" else 0 if t["arm"] == "F256" else 1, em=None if t["arm"] == "R256" else 0 if t["arm"] == "F256" else 1) for t in tasks]
    pairs = [dict(id="synthetic", dataset="hotpotqa", reference_arm="N128", candidate_arm=a, delta_F1=-1 if a == "F256" else 0, delta_EM=-1 if a == "F256" else 0) for a in ("N256", "F256")]
    report = dict(checkpoint_in_flight_at_snapshot=0, all_planned=dict(planned_queries=1),
                  arms={a: dict(quality_terminal=int(a != "R256"), missing=int(a == "R256"),
                       **{key: None if a == "R256" else 0 if a == "F256" else 1 for key in ("F1", "EM", "F1_available", "EM_available")}) for a in ARMS},
                  paired_predeclared={r + "_to_" + c: dict(complete_pairs=int(c != "R256"), missing_pairs=int(c == "R256"),
                       delta_F1=None if c == "R256" else -1 if c == "F256" else 0,
                       delta_EM=None if c == "R256" else -1 if c == "F256" else 0) for r, c in PAIRS})
    validate_scores(tasks, inputs, outcomes, held, details, pairs, report)
    bad = deepcopy(details); bad[-1]["f1"] = 0
    try:
        validate_scores(tasks, inputs, outcomes, held, bad, pairs, report)
    except ValueError:
        pass
    else:
        raise ValueError("Technical zero accepted")
    bad = deepcopy(details); bad[0]["prediction"] = "stale"
    try:
        validate_scores(tasks, inputs, outcomes, held, bad, pairs, report)
    except ValueError:
        pass
    else:
        raise ValueError("Stale scoring accepted")
    checks.append("algorithm_zero_technical_missing_stale_scores")
    node = dict(step_id=1, role="ordinary", accepted_answer="Alpha is the answer.", parsed_answer="Alpha is the answer.", raw_output="Alpha is the answer.", support=None)
    a = dict(arm="N128", nodes=[node], final=dict(prompt_ref="same", prediction="Alpha"))
    b = deepcopy(a); b["arm"] = "R256"; b["nodes"][0]["raw_output"] = "Support: fact\nAnswer: Alpha is the answer."; b["nodes"][0]["support"] = "fact"; b["final"]["prediction"] = "Alpha."
    change = compare_traces(a, b, None)
    require(change["first_ordinary_observed_output_difference"] is not None and change["first_ordinary_accepted_answer_difference"] is None, "Support-only propagation confusion")
    require(change["final_prediction_changed_under_identical_final_input"] and change["final_surface_case_space_punctuation_only"], "Final surface diagnostic")
    b["nodes"][0]["accepted_answer"] = "Beta is the answer."
    require(compare_traces(a, b, None)["first_ordinary_accepted_answer_difference"] is not None, "Accepted difference missed")
    require(not compare_traces(a, b, None)["final_prediction_changed_under_identical_final_input"], "Propagated change mislabeled final-only")
    a["nodes"], b["nodes"] = [], []
    require(compare_traces(a, b, None)["first_ordinary_observed_output_difference"] is None, "Goal-only invented ordinary node")
    checks.append("support_acceptance_propagation_final_surface_goal_only")
    # Exercise complete node export and an uncommitted parser failure. This
    # catches schema assumptions that aggregate-only synthetic tests cannot.
    case = dict(id="hotpotqa:synthetic", qid="synthetic", dataset="hotpotqa", question="Who?", supporting_questions=[])
    tid = case["id"] + "/N128"
    packet = dict(qid="synthetic", query="Who?", k=10, docs=[dict(doc_id=str(i), source="Synthetic source",
        rank=i, text="Synthetic text " + str(i), block=f"[Chunk {i} | source=Synthetic source, pages=1-1]\nSynthetic text {i}", score=1 / i) for i in range(1, 11)])
    candidate = dict(step_id=1, role="goal", arm="N128", current_question="Who?", prior_complete_answers=[],
        raw_output="Alpha", support=None, parsed_answer="Alpha", parser_status="parsed", output_cap=128,
        raw_P02_child_prompt="goal prompt", actual_child_prompt="goal prompt", original_retrieval=packet,
        reader_packet=packet, accepted_rewrite="Who?")
    node = dict(step_id=1, role="goal", request="Who?", prior_complete_answers=[], answer="Alpha is the answer.",
        initial_answer="Alpha", child_prompt="goal prompt", raw_P02_child_prompt="goal prompt", rewritten_query="Who?",
        rewritten_retrieval=None, rewrite_prompt=None, raw_rewrite=None, rewrite_rejection=None, sentence_format_request_id="fmt",
        local_cot=dict(raw_output="Alpha", support=None, parsed_answer="Alpha", accepted_answer="Alpha is the answer.", support_forwarded=False))
    values = (("ans", "legacy/answer/1", "goal prompt", "Alpha", 128),
              ("fmt", "legacy/sentence_format/1", "formatter prompt", "Alpha is the answer.", 128),
              ("final", "legacy/final", "final prompt", "Alpha", 64))
    receipts, requests = [], {}
    for rid, stage, prompt, answer, cap in values:
        payload = dict(model="synthetic", max_tokens=cap, messages=[dict(role="user", content=prompt)])
        receipts.append(dict(stage=stage, request_id=rid, payload_sha256=digest(payload), answer=answer,
                             finish_reason="stop", usage=dict(prompt_tokens=1, completion_tokens=1, total_tokens=2), terminal_reason=None))
        requests[rid] = dict(request_id=rid, stage=stage, payload=payload, status="success", result=dict(answer=answer, finish_reason="stop"))
    value = dict(status="success", prediction="Alpha", stages=receipts, candidate_outputs=[candidate],
        trajectory=dict(**case, nodes=[node], final_prompt="final prompt", original_retrieval=packet))
    snapshot = dict(data=dict(stage={tid + "/" + s["stage"]: s for s in receipts},
        candidate_output={tid + "/1": candidate}, node={tid + "/1": node}), requests=requests,
        uses=[(rid, "full8/" + tid + "/" + stage) for rid, stage, _, _, _ in values])
    catalog = Catalog()
    exported = compact_arm(case, "N128", value, {}, snapshot, {}, catalog)
    require(exported["nodes"][0]["accepted_answer"] == "Alpha is the answer." and len(catalog.documents) == 10, "Full node export schema")
    require(catalog.prompts[exported["final"]["prompt_ref"]] == "final prompt", "Final prompt reference missing")
    altered = deepcopy(value); altered["trajectory"]["supporting_questions"] = ["Changed?"]
    try:
        compact_arm(case, "N128", altered, {}, snapshot, {}, Catalog())
    except ValueError:
        pass
    else:
        raise ValueError("Changed decomposition accepted")
    require(all(catalog.documents[d["document_ref"]]["doc_id"] == d["doc_id"] for d in exported["nodes"][0]["reader_documents"]["docs"]), "Document catalog cannot resolve")
    failed_case = {**case, "supporting_questions": ["Who?"]}
    failed_candidate = {**candidate, "role": "ordinary", "arm": "N128", "parsed_answer": None, "parser_status": "format_failure"}
    failed = dict(status="algorithm_failure", prediction="", stages=receipts[:1], partial_nodes=[],
                  candidate_outputs=[failed_candidate], terminal_reason="invalid_support_answer_format", terminal_stage="legacy/answer/1")
    failed_snapshot = deepcopy(snapshot)
    failed_snapshot["data"]["candidate_output"][tid + "/1"] = failed_candidate
    failed_snapshot["data"]["node"] = {}
    failed_snapshot["data"]["stage"] = {tid + "/" + receipts[0]["stage"]: receipts[0]}
    failed_snapshot["uses"] = failed_snapshot["uses"][:1]
    failed_export = compact_arm(failed_case, "N128", failed, {}, failed_snapshot, {}, Catalog())
    require(failed_export["nodes"][0]["accepted_answer"] is None and not failed_export["nodes"][0]["committed"], "Failed candidate silently propagated")
    checks.append("complete_node_formatter_document_prompt_decomposition_and_uncommitted_failure_schema")
    return dict(passed=True, checks=checks, actual_predictions_or_scores_read=False, API_SSH_GPU_calls=0,
                checkpoint_ledger_or_historical_writes=0)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--self-test", action="store_true")
    group.add_argument("--export", action="store_true")
    group.add_argument("--check-ready", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        result = self_test()
    elif args.export:
        result = export()
    else:
        result = dict(operational_complete=(OUTPUT / "STATUS.json").is_file() and ready(read(OUTPUT / "STATUS.json")),
                      official_score_artifacts_present=all((OUTPUT / n).is_file() for n in ("REPORT.json", "DETAILS.jsonl", "PAIRED.jsonl")),
                      actual_predictions_or_scores_read=False)
    print(json.dumps(result, ensure_ascii=False))
