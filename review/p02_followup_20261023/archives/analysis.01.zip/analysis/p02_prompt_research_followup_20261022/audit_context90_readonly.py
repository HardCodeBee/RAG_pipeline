"""Independent contract/cost audit of fixed90 reset/flat/chat, without scores.

Prepare this script before inference. Run only on root's later instruction.
It never opens METHOD_KEY, native REPORT/DETAILS/PAIRED, references or scorers.
Only mode=ro SQLite and pure recorded-response replay through core Pipeline
are used. No Cache object, provider client, SSH, GPU or execution runner.
"""
from collections import Counter,defaultdict
from contextlib import closing
from copy import deepcopy
from datetime import datetime,timezone
from pathlib import Path
import argparse
import hashlib
import json
import sqlite3
import sys
import traceback

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/"src"))
from p02_multigrain_timing_cachefix_v1.core.cache import canonical
from p02_multigrain_timing_cachefix_v1.core.pipeline import Pipeline,safe_case
from experiments.query_decomposition.p02_shared_context_fixed90_v1_20261022.message_transport import build_payload
from experiments.query_decomposition.p02_shared_context_fixed90_v1_20261022.native_ask import (
    AlgorithmTerminal,stage_success,terminal_reason,usage_ok,any_returned,
)
from experiments.query_decomposition.p02_shared_context_fixed90_v1_20261022.retrieval_bridge import identity,key,check_packet

B=ROOT/"experiments/query_decomposition/p02_shared_context_fixed90_v1_20261022"
P=ROOT/"outputs/query_decomposition"/B.name
LIVE_P=P
PACKAGE=ROOT/"src/p02_multigrain_timing_cachefix_v1"
PREEXEC=ROOT/"analysis/p02_prompt_research_followup_20261022/SHARED_CONTEXT_FIXED90_PREEXECUTION_INDEPENDENT_REVIEW.json"
PROTOCOL_SHA="0630afaf6e7b992675085022189e93b9de3af6cdbec9b1542c88856fe9b0630e"
ARMS=("reset","flat","chat")
DATASETS=("hotpotqa","2wiki","musique")
UKEYS=("prompt_tokens","completion_tokens","total_tokens")
SNAPSHOT_TIMES={}


class AuditFailure(RuntimeError):pass


def require(condition,code):
    if not condition:raise AuditFailure(code)


def read(path):return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def rows(path):
    return [json.loads(line)for line in Path(path).read_text(encoding="utf-8-sig").splitlines()if line.strip()]


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):return hashlib.sha256(canonical(value).encode("utf8")).hexdigest()


def ro(path):
    connection=sqlite3.connect(Path(path).resolve().as_uri()+"?mode=ro",uri=True)
    connection.row_factory=sqlite3.Row
    connection.execute("PRAGMA query_only=ON")
    connection.execute("BEGIN")
    # Pin each WAL snapshot now. SQLite cannot make two independently committed
    # databases one atomic writer transaction; the narrow interval is explicit.
    connection.execute("SELECT count(*) FROM sqlite_master").fetchone()
    SNAPSHOT_TIMES[str(Path(path).resolve())]=datetime.now(timezone.utc).isoformat()
    return connection


def complete_log_rows(path):
    text=Path(path).read_text(encoding="utf-8-sig")
    end=text.rfind("\n")+1
    return [json.loads(line)for line in text[:end].splitlines()if line.strip()],bool(text[end:])


def cost(usage):return usage["prompt_tokens"]*.8e-6+usage["completion_tokens"]*2e-6


def cap(stage):
    if stage=="legacy/final":return 64
    if stage.startswith("legacy/rewrite/"):return 256
    if stage.startswith(("legacy/answer/","legacy/sentence_format/")):return 128
    raise AuditFailure("unrecognized_native_stage")


def literal_wire(arm,turns,current):
    if arm=="reset"or not turns:return current
    messages=[dict(role=role,content=value)for turn in turns
        for role,value in(("user",turn["child_prompt"]),("assistant",turn["answer"]))]
    messages.append(dict(role="user",content=current))
    if arm=="chat":return messages
    return "\n\n".join(("User:\n"if row["role"]=="user"else"Assistant:\n")+row["content"]for row in messages)


def turn_manifest(turns):
    return [dict(step_id=n["step_id"],role=n["role"],raw_child_prompt_sha256=digest(n["child_prompt"]),
        accepted_answer_sha256=digest(n["answer"]),answer_request_id=n["answer_request_id"],
        sentence_format_request_id=n["sentence_format_request_id"])for n in turns]


def receipt_value(stage,rid,payload,receipt,model):
    accepted=stage_success(receipt,model,stage)
    reason=None if accepted else terminal_reason(receipt,model)
    require(accepted or reason is not None,"stage_incomplete_receipt_or_model_usage")
    text=receipt.get("answer")
    return dict(stage=stage,request_id=rid,payload_sha256=digest(payload),
        answer=text.strip()if isinstance(text,str)else"",finish_reason=receipt.get("finish_reason"),
        usage=receipt["usage"],terminal_reason=reason)


def check_sources(protocol):
    require(sha(B/"PROTOCOL.frozen.json")==PROTOCOL_SHA,"protocol_identity")
    require(len(protocol["pins"])==312 and len(protocol["protected_holds"])==3,"pin_counts")
    for path,expected in {**protocol["pins"],**protocol["protected_holds"]}.items():
        require(sha(ROOT/path)==expected,"frozen_dependency_changed")
    review=read(PREEXEC)
    require(review["passed"]is True and review["protocol_sha256"]==PROTOCOL_SHA,"preexecution_review_binding")
    for path,expected in review["additional_review_bound_dependencies"].items():
        require(sha(ROOT/path)==expected,"additional_scorer_dependency_changed")
    plan=read(B.parent/"unified_rag_eval_v1_20261021/PLAN.json")
    require(plan["execution_approval"]["approved"]is False,"main_evaluation_must_remain_paused")
    auth=read(B/"RUN_AUTHORIZATION.json")
    require(auth.get("approved")is True and auth.get("experiment")==B.name and auth.get("protocol_sha256")==PROTOCOL_SHA,"execution_authorization_binding")
    require(auth.get("independent_review_sha256")==sha(PREEXEC),"AUTH_independent_review_hash")
    require(auth.get("additional_scorer_dependencies")==review["additional_review_bound_dependencies"],"AUTH_additional_dependency_binding")
    require(any(row.get("id")==auth["decision_id"]for row in rows(B.parent/"unified_rag_eval_v1_20261021/DECISIONS.jsonl")),"authorization_decision_missing")
    data=rows(B/"INPUTS90.jsonl");tasks=rows(B/"ORDER270.jsonl")
    require(len(data)==90 and len({row["id"]for row in data})==90,"fixed90_identity")
    require(Counter(row["dataset"]for row in data)=={ds:30 for ds in DATASETS},"dataset_counts")
    require(sum(len(row["supporting_questions"])for row in data)==176,"ordinary_node_count")
    require(sum(not row["supporting_questions"]for row in data)==6,"goal_only_count")
    require(len(tasks)==270 and len({row["task_id"]for row in tasks})==270,"planned270_identity")
    require({row["task_id"]for row in tasks}=={row["id"]+"/"+arm for row in data for arm in ARMS},"task_matrix")
    for row in data:require(safe_case(row)==row and len(row)==5,"inference_fields_only")
    for path in (B.parent/"p02_goal_native_role_fixed90_v1_20261022/INPUTS90.frozen.jsonl",
                 B.parent/"p02_final_target_check_fixed90_v1_20261022/INPUTS90.frozen.jsonl"):
        old=rows(path)
        projected=[]
        for row in old:
            if not all(field in row for field in data[0]):
                # W stores final-only inputs; its source case holds raw D.
                source=ROOT/row["source"]
                require(sha(source)==row["source_sha256"],"W_source_case_binding")
                row=read(source)
                if"supporting_questions"not in row:
                    row={**row,"supporting_questions":[node["request"]for node in row["nodes"]if node["role"]=="ordinary"]}
            projected.append({field:row[field]for field in data[0]})
        require(projected==data,"actual_R02_arrays_and_IDs_changed")
    resources=read(B/"RESOURCE_CONTRACTS.json")
    require(set(resources)==set(DATASETS),"three_resource_contracts")
    for ds,record in resources.items():
        require(record["contract"]["dataset"]==ds and digest(record["contract"])==record["identity"],"resource_identity")
    return {row["id"]:row for row in data},tasks,resources,sha(PREEXEC)


def replay_one(outcome,case,requests,stage_data,qa_inputs,retrievals,resources,config,stage_links):
    model=config["generation"]["model"];task_id=outcome["task_id"];arm=outcome["arm"]
    seen=[];turns=[];enriched=[];qa_seen=[];retrieval_seen=[]
    def retrieve(query):
        request=identity(resources[case["dataset"]]["identity"],case["dataset"],case["qid"],query,10)
        rid=key(request);require(rid in retrievals,"replay_retrieval_missing")
        packet=check_packet(request,retrievals[rid]);retrieval_seen.append(rid)
        return packet
    def ask(stage,native_prompt,maximum,allow_final_truncation=False):
        require(isinstance(native_prompt,str)and maximum==cap(stage),"native_prompt_or_cap")
        require(bool(allow_final_truncation)==(stage=="legacy/final"),"native_final_truncation_contract")
        wire=literal_wire(arm,turns,native_prompt)if stage.startswith("legacy/answer/")else native_prompt
        if stage.startswith("legacy/answer/"):
            expected=qa_inputs.get(task_id+"/"+stage)
            require(expected is not None,"QA_wire_record_missing")
            require(expected["raw_current_prompt"]==native_prompt and expected["wire_input"]==wire,"QA_native_prompt_or_rebuilt_context_differs")
            messages=[dict(role="user",content=wire)]if isinstance(wire,str)else wire
            require(expected["wire_messages_sha256"]==digest(messages),"QA_wire_hash")
            require(expected["historical_turns"]==len(turns),"QA_turn_isolation")
            qa_seen.append(task_id+"/"+stage)
        payload=build_payload(config["generation"],wire,maximum)
        stored=requests.get(canonical(payload));require(stored is not None,"full_wire_payload_not_found")
        rid,receipt=stored["id"],stored["receipt"]
        require((rid,"full8/"+task_id+"/"+stage)in stage_links,"request_logical_stage_binding")
        value=receipt_value(stage,rid,payload,receipt,model)
        require(stage_data.get(task_id+"/"+stage)==value,"saved_canonical_stage_mismatch")
        seen.append(value)
        if value["terminal_reason"]:raise AlgorithmTerminal(value)
        return rid,value["answer"],value["finish_reason"]
    def record(node):
        node=deepcopy(node);sid=node["step_id"]
        wire=literal_wire(arm,turns,node["child_prompt"])
        messages=[dict(role="user",content=wire)]if isinstance(wire,str)else wire
        node["raw_P02_child_prompt"]=node["child_prompt"]
        node["shared_context"]=dict(arm=arm,historical_turns=len(turns),previous_turn_manifest=turn_manifest(turns),
            wire_input=wire,wire_messages_sha256=digest(messages),
            committed_assistant_answer="accepted_post_optional_formatter",old_wire_never_nested=True)
        expected_nodes=(outcome.get("trajectory")or{}).get("nodes",outcome.get("partial_nodes",[]))
        require(sid<=len(expected_nodes)and node==expected_nodes[sid-1],"node_or_context_commit_mismatch")
        enriched.append(node);turns.append(node)
    try:
        result=Pipeline(config).execute(case,retrieve,ask,record_node=record)
    except AlgorithmTerminal as error:
        require(outcome["status"]=="algorithm_failure","unrecorded_algorithm_terminal")
        require(outcome["terminal_stage"]==error.value["stage"]and outcome["terminal_reason"]==error.value["terminal_reason"],"terminal_outcome_identity")
        require(outcome.get("partial_nodes",[])==enriched,"algorithm_partial_nodes")
    else:
        require(outcome["status"]in("success","success_truncated"),"outcome_status")
        result["nodes"]=enriched
        result.update(context_arm=arm,context_turn_manifest=turn_manifest(turns),
            context_scope="Within one original query; ordinary+goal only; native raw prompts/accepted answers; final independent")
        require(result==outcome["trajectory"],"complete_core_trajectory_replay_mismatch")
    require(seen==outcome["stages"],"full_stage_order_receipts_mismatch")
    return dict(stages=len(seen),QA_contexts=len(qa_seen),retrieval_uses=len(retrieval_seen),
        qa_keys=qa_seen,retrieval_keys=retrieval_seen,
        logical_usage={field:sum(stage["usage"][field]for stage in seen)for field in UKEYS})


def audit_costs(cache,ledger,tasks,config,allow_live=False):
    namespace="p02_prompt_research_v1_20261022/"+str(LIVE_P.resolve())
    charges={row["id"]:dict(row)for row in ledger.execute("SELECT * FROM charges WHERE namespace=?",(namespace,))}
    attempts=defaultdict(list);owners={};retired_count=0;request_states=Counter();active_count=0;windows=[]
    for table in("requests","retired_requests"):
        for raw in cache.execute("SELECT * FROM "+table):
            row=dict(raw);payload=json.loads(row["payload"]);rid=row["id"]
            require(canonical(payload)==row["payload"],"noncanonical_request_identity")
            require(rid not in owners,"duplicate_attempt_request_id")
            matches=[task["task_id"]for task in tasks if row["stage"].startswith("full8/"+task["task_id"]+"/")]
            require(len(matches)==1,"first_paid_owner_not_planned_condition")
            owners[rid]=matches[0]
            receipt=json.loads(row["result"])if row["result"]else{}
            charge=charges.get(rid)
            if charge is None:
                require(allow_live,"request_missing_charge")
                windows.append(dict(request_id=rid,kind="request_without_charge_in_other_snapshot_requires_review"))
                attempts[row["payload"]].append(rid);request_states[row["status"]]+=1
                if table=="retired_requests":
                    require(not any_returned(receipt),"retired_attempt_has_returned_evidence")
                    retired_count+=1
                else:active_count+=1
                continue
            require(charge["reserved"]>=0,"negative_reservation")
            expected_reserve=sum(len(m["content"].encode("utf8"))for m in payload["messages"])*.8e-6+payload["max_tokens"]*2e-6
            require(abs(charge["reserved"]-expected_reserve)<1e-9,"reservation_does_not_cover_complete_prefix")
            if charge["actual"]is not None:
                if not usage_ok(receipt)and allow_live and row["status"]in("in_flight","unknown"):
                    windows.append(dict(request_id=rid,kind="ledger_returned_usage_before_cache_receipt_snapshot"))
                else:
                    require(usage_ok(receipt),"paid_receipt_missing_three_integer_usage")
                    require(abs(charge["actual"]-cost(receipt["usage"]))<1e-9 and charge["status"]=="returned_usage","returned_usage_charge_mismatch")
            elif usage_ok(receipt):
                raise AuditFailure("returned_usage_not_reconciled_to_ledger")
            if table=="retired_requests":
                require(not any_returned(receipt)and charge["actual"]is None,"retired_attempt_has_returned_evidence_or_paid_usage")
                retired_count+=1
            else:active_count+=1
            attempts[row["payload"]].append(rid);request_states[row["status"]]+=1
    extra_charges=set(charges)-set(owners)
    require(allow_live or not extra_charges,"orphan_namespace_ledger_charge")
    for rid in sorted(extra_charges):windows.append(dict(request_id=rid,kind="namespace_charge_not_yet_in_cache_snapshot_requires_review"))
    maximum=max(map(len,attempts.values()),default=0);require(maximum<=5,"durable_actual_attempt_limit_exceeded")
    paid=defaultdict(lambda:dict(actual_new_returned_usage_CNY=0.,unresolved_reserved_CNY=0.))
    unattributed=dict(actual_new_returned_usage_CNY=0.,unresolved_reserved_CNY=0.)
    for rid,row in charges.items():
        dest=paid[owners[rid]]if rid in owners else unattributed
        dest["actual_new_returned_usage_CNY"]+=row["actual"]or 0.
        dest["unresolved_reserved_CNY"]+=row["reserved"]if row["actual"]is None else 0.
    return dict(actual_new_returned_usage_CNY=sum(row["actual"]or 0. for row in charges.values()),
        unresolved_reserved_CNY=sum(row["reserved"]for row in charges.values()if row["actual"]is None),
        first_submitting_condition_attribution=dict(paid),active_requests=active_count,retired_attempts=retired_count,
        maximum_actual_attempts=maximum,orphan_charges=0 if not windows else None,
        unreconciled_cross_snapshot_windows=windows,reconciliation_complete=not windows,
        pending_unattributed_snapshot_charges=unattributed,statuses=dict(request_states),
        logical_full_prefix_cost_not_added_to_actual=True)


def remote_receipts(protocol_sha,resources):
    ready_path=P/"REMOTE_GPU_READY.json";job_path=P/"REMOTE_JOB_ID.json"
    require(ready_path.exists()and job_path.exists(),"remote_READY_or_job_receipt_missing")
    ready,job=read(ready_path),read(job_path)
    require(ready["status"]=="ready"and"A6000"in ready["gpu"]and ready["protocol_sha256"]==protocol_sha,"remote_GPU_identity")
    require(ready["no_LLM_credentials_or_requests"]is True,"remote_query_only_contract")
    require(str(ready["job_id"])==str(job["job_id"])and job["protocol_sha256"]==protocol_sha,"remote_job_binding")
    require(job["directory"].endswith("/context90_"+protocol_sha[:16]),"remote_namespace")
    for ds,record in resources.items():
        actual=ready["resources"][ds]
        require(actual["identity"]==record["identity"]and actual["manifest_sha256"]==record["contract"]["portable_manifest_sha256"],"remote_resource_identity")
        require(actual["verified_file_stamps"]>0 and actual["fresh_full_byte_hash_not_claimed"]is True,"remote_validation_stamps")
    finished_path=P/"REMOTE_GPU_FINISHED.json"
    finished=read(finished_path)if finished_path.exists()else None
    if finished:
        # Existing worker FINISHED is a small leaf without protocol/job fields;
        # its isolated-directory association is supplied by root's observer.
        require(finished.get("status")=="stopped"and"A6000"in finished.get("GPU","")
            and finished.get("no_LLM_requests")is True,"remote_FINISHED_content")
        if"protocol_sha256"in finished:require(finished["protocol_sha256"]==protocol_sha,"remote_FINISHED_protocol")
        if"job_id"in finished:require(str(finished["job_id"])==str(job["job_id"]),"remote_FINISHED_job")
        if"worker_error"in finished:require(finished["worker_error"]is None,"remote_worker_error")
    return dict(job_id=job["job_id"],gpu=ready["gpu"],READY_sha256=sha(ready_path),
        FINISHED_present=finished is not None,FINISHED_sha256=sha(finished_path)if finished else None,
        scope="Recorded local remote receipts only; leaf FINISHED association is observer-supplied; no new SSH/scheduler assertion")


def audit(allow_partial=False,snapshot_directory=None):
    global P
    snapshot_meta=None
    if snapshot_directory is not None:
        P=Path(snapshot_directory).resolve()
        require(P.is_relative_to(LIVE_P.resolve())and P.name.startswith("SNAPSHOT_"),"snapshot_directory_outside_experiment")
        snapshot_meta=read(P/"SNAPSHOT_MANIFEST.json")
        require(snapshot_meta["source_live_output"]==str(LIVE_P.resolve())and snapshot_meta["protocol_sha256"]==PROTOCOL_SHA,"snapshot_source_identity")
        require(snapshot_meta["namespace"]=="p02_prompt_research_v1_20261022/"+str(LIVE_P.resolve()),"snapshot_ledger_namespace")
        for name,record in snapshot_meta["files"].items():
            file=(P/name).resolve()
            require(file.is_relative_to(P)and sha(file)==record["sha256"],"snapshot_artifact_hash")
    protocol=read(B/"PROTOCOL.frozen.json")
    data,tasks,resources,review_sha=check_sources(protocol)
    config=read(PACKAGE/"config.json")
    require((P/"checkpoint.sqlite3").exists(),"checkpoint_not_started")
    ledger_path=P/"budget.sqlite3"if snapshot_meta is not None else Path(config["budget"]["ledger"])
    with closing(ro(P/"checkpoint.sqlite3"))as cache,closing(ro(ledger_path))as ledger:
        contents=defaultdict(dict)
        for row in cache.execute("SELECT kind,key,value FROM data"):contents[row["kind"]][row["key"]]=json.loads(row["value"])
        outcomes=list(contents["outcome"].values());expected={row["task_id"]for row in tasks}
        require(len(outcomes)==len({row["task_id"]for row in outcomes})and set(contents["outcome"])<=expected,"outcome_matrix")
        require(allow_partial or len(outcomes)==270,"complete270_required_not_missing_as_zero")
        requests={}
        for row in cache.execute("SELECT * FROM requests"):
            value=dict(row);receipt=json.loads(value["result"])if value["result"]else{}
            value["receipt"]={**receipt,"status":value["status"]}
            require(value["payload"]not in requests,"duplicate_active_payload")
            requests[value["payload"]]=value
        links={(row["request_id"],row["stage"])for row in cache.execute("SELECT * FROM request_stages")}
        results=[];used_qa=set();used_packets=set()
        task_index={row["task_id"]:row for row in tasks}
        for outcome in outcomes:
            task=task_index[outcome["task_id"]]
            require(all(outcome[k]==v for k,v in task.items()),"outcome_task_identity")
            value=replay_one(outcome,data[outcome["id"]],requests,contents["stage"],contents["qa_input"],
                contents["retrieval"],resources,config,links)
            used_qa.update(value.pop("qa_keys"));used_packets.update(value.pop("retrieval_keys"))
            results.append(dict(task_id=outcome["task_id"],status=outcome["status"],**value))
        if len(outcomes)==270:require(used_qa==set(contents["qa_input"]),"orphan_or_unreplayed_QA_context")
        events,trailing_log_fragment=complete_log_rows(P/"events.jsonl")
        retrieval_events=0;post_snapshot_retrieval_events=0
        for event in events:
            if event.get("event")!="logical_retrieval":continue
            require(event["task_id"]in task_index,"retrieval_log_unknown_task")
            case=data[task_index[event["task_id"]]["id"]]
            request=identity(resources[case["dataset"]]["identity"],case["dataset"],case["qid"],event["query"],10)
            require(all(event.get(k)==v for k,v in request.items())and event["request_id"]==key(request),"retrieval_log_identity")
            if event["request_id"]not in contents["retrieval"]and allow_partial:
                post_snapshot_retrieval_events+=1;continue
            require(event["request_id"]in contents["retrieval"],"retrieval_log_packet_missing")
            check_packet(request,contents["retrieval"][event["request_id"]]);retrieval_events+=1
        for rid,packet in contents["retrieval"].items():
            matches=[identity(resources[case["dataset"]]["identity"],case["dataset"],case["qid"],packet["query"],10)
                for case in data.values()if case["qid"]==packet["qid"]]
            matches=[request for request in matches if key(request)==rid]
            require(len(matches)==1,"cached_packet_not_bound_to_one_allowed_query_and_resource")
            check_packet(matches[0],packet)
        fees=audit_costs(cache,ledger,tasks,config,allow_live=allow_partial)
    gate=read(P/"ENGINEERING_GATE.json")if(P/"ENGINEERING_GATE.json").exists()else None
    if len(outcomes)==270:require(gate and gate["passed"]and gate["quality_or_predictions_inspected"]is False,"engineering_gate_missing_or_quality_gated")
    remote=remote_receipts(PROTOCOL_SHA,resources)
    live_pending=not fees["reconciliation_complete"]or post_snapshot_retrieval_events>0 or trailing_log_fragment
    return dict(passed=not live_pending,contract_replay_passed=True,
        audit_state="contracts_passed_live_snapshot_window_pending"if live_pending else"contract_and_cost_snapshot_passed",
        snapshots=dict(opened_utc_by_database=SNAPSHOT_TIMES,cross_database_atomicity_claimed=False,
            consistent_read_transactions=True,trailing_incomplete_log_line_ignored=trailing_log_fragment,
            complete_future_retrieval_events_after_cache_snapshot=post_snapshot_retrieval_events),
        immutable_source_snapshot=None if snapshot_meta is None else dict(directory=str(P),
            manifest_sha256=sha(P/"SNAPSHOT_MANIFEST.json"),freeze_timestamp_utc=snapshot_meta["freeze_timestamp_utc"],
            source_cross_database_pin_interval_seconds=snapshot_meta["cross_database_pin_interval_seconds"],
            common_query_count=snapshot_meta["common_query_count"]),
        complete_planned270=len(outcomes)==270,quality_terminal=len(outcomes),planned_conditions=270,
        missing_conditions=270-len(outcomes),protocol_sha256=PROTOCOL_SHA,preexecution_review_sha256=review_sha,
        frozen_pins_verified=len(protocol["pins"]),protected_STOP_files_verified=3,
        additional_review_bound_dependencies_verified=5,source_actual_R02_arrays_same90=True,
        status_counts=dict(Counter(row["status"]for row in outcomes)),
        native_core_complete_trajectory_replays=len(outcomes),
        replayed_QA_contexts=sum(row["QA_contexts"]for row in results),replayed_native_stages=sum(row["stages"]for row in results),
        retrieval_log_events_verified=retrieval_events,unique_retrieval_packets_used=len(used_packets),
        per_condition_contracts=results,engineering_gate=gate,ledger=fees,remote=remote,
        no_scoring_or_predictions_or_method_keys_in_output=True,native_reports_and_blind_files_not_opened=True,
        new_API_SSH_GPU_requests=0,main_evaluation_remains_paused=True,
        caveat="Contract/cost audit only; no F1/EM, semantic correctness, scheduler-live-state or generic quality conclusion")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root-approved-contract-audit",action="store_true")
    parser.add_argument("--allow-partial",action="store_true")
    parser.add_argument("--snapshot-directory",type=Path)
    args=parser.parse_args()
    require(args.root_approved_contract_audit,"wait_for_root_contract_audit_instruction")
    try:result=audit(args.allow_partial,args.snapshot_directory)
    except Exception as error:
        # Never serialize arbitrary exception text: an assertion could otherwise
        # expose raw model content or a method association before blind locks.
        result=dict(passed=False,error_type=type(error).__name__,
            error_code=str(error)if isinstance(error,AuditFailure)else"contract_check_failed_no_content_emitted",
            diagnostic_frames=[dict(function=frame.name,line=frame.lineno,
                file=str(Path(frame.filename).resolve().relative_to(ROOT)))
                for frame in traceback.extract_tb(error.__traceback__)
                if Path(frame.filename).resolve().is_relative_to(ROOT)],
            new_API_SSH_GPU_requests=0,no_scores_or_predictions_emitted=True)
    result["audit_utc"]=datetime.now(timezone.utc).isoformat()
    destination=P/"ROOT_CONTEXT90_CONTRACT_AUDIT.json"
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf8")
    summary={k:v for k,v in result.items()if k not in("per_condition_contracts","ledger","remote","engineering_gate")}
    if"ledger"in result:
        summary.update({k:result["ledger"][k]for k in("actual_new_returned_usage_CNY","unresolved_reserved_CNY","maximum_actual_attempts","orphan_charges")})
    print(json.dumps(summary,ensure_ascii=True),flush=True)


if __name__=="__main__":main()
