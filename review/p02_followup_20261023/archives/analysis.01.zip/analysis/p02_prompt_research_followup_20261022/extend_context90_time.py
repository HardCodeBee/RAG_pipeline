"""Bounded operational extension of the already authorized, identified job."""
import getpass
import hashlib
import json
import shlex
import socket
from datetime import datetime, timezone
from pathlib import Path

import paramiko

ROOT = Path(__file__).resolve().parents[2]
NAME = "p02_shared_context_fixed90_v1_20261022"
EXP = ROOT / "experiments/query_decomposition" / NAME
OUT = ROOT / "outputs/query_decomposition" / NAME
EXPECTED = "0630afaf6e7b992675085022189e93b9de3af6cdbec9b1542c88856fe9b0630e"


def main():
    assert hashlib.sha256((EXP / "PROTOCOL.frozen.json").read_bytes()).hexdigest() == EXPECTED
    job = json.loads((OUT / "REMOTE_JOB_ID.json").read_text(encoding="utf8"))
    assert job["job_id"] == "159533" and job["protocol_sha256"] == EXPECTED
    assert job["directory"].endswith("/context90_" + EXPECTED[:16])
    assert json.loads((EXP / "RUN_AUTHORIZATION.json").read_text(encoding="utf8"))["approved"] is True
    password = getpass.getpass("Remote password: ")
    client = paramiko.SSHClient()
    client.load_system_host_keys()
    client.set_missing_host_key_policy(paramiko.RejectPolicy())
    result = dict(job_id="159533", protocol_sha256=EXPECTED, requested_time_limit="05:00:00",
                  reason="Finish already authorized fixed270 conditions without wall-limit interruption; close immediately after completion",
                  scientific_protocol_changed=False, new_job_submitted=False)
    try:
        connection = socket.create_connection(("150.203.213.5", 22), timeout=15)
        client.connect("cluster1.comp.anu.edu.au", username="u7830488", password=password, sock=connection,
                       look_for_keys=False, allow_agent=False, timeout=15, auth_timeout=20, banner_timeout=15)
        password = None

        def command(args):
            _, stdout, stderr = client.exec_command(shlex.join(args), timeout=30)
            text, error = stdout.read().decode(), stderr.read().decode()
            return stdout.channel.recv_exit_status(), text, error

        def status():
            code, text, error = command(["scontrol", "show", "job", "-o", "159533"])
            assert code == 0, error
            fields = dict(x.split("=", 1) for x in text.split() if "=" in x)
            assert fields["JobId"] == "159533" and fields["JobName"] == "p02-context90"
            assert fields["UserId"].startswith("u7830488(") and fields["WorkDir"] == job["directory"]
            return {k: fields[k] for k in ("JobId", "JobName", "UserId", "JobState", "TimeLimit", "RunTime", "WorkDir")}

        result["before"] = status()
        code, text, error = command(["sacctmgr", "-n", "-P", "show", "qos", "db4ai", "format=Name,MaxWall"])
        result["qos_wall_limit_readonly"] = dict(code=code, stdout=text[:1000], stderr=error[:500])
        if result["before"]["JobState"] != "RUNNING":
            result["action"] = "already_not_running_no_change"
        elif result["before"]["TimeLimit"] == "05:00:00":
            result["action"] = "already_extended_no_change"
        else:
            assert result["before"]["TimeLimit"] == "04:00:00"
            code, text, error = command(["scontrol", "update", "JobId=159533", "TimeLimit=05:00:00"])
            result["update"] = dict(code=code, stdout=text[:1000], stderr=error[:1000])
            result["action"] = "extension_requested" if code == 0 else "scheduler_rejected_no_resubmit"
        result["after"] = status()
    finally:
        password = None
        client.close()
    result["utc"] = datetime.now(timezone.utc).isoformat()
    (OUT / "OPERATIONAL_TIME_EXTENSION_20261022.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
