"""Independent post-lock C8 local screen recount; no provider/scorer/mutations."""
from collections import Counter
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))
from p02_multigrain_timing_cachefix_v1.core.cache import canonical
from p02_multigrain_timing_cachefix_v1.core.llm import build_payload
from experiments.query_decomposition.p02_failure8_actual_target_probe_v1_20261022 import templates

B = ROOT / "experiments/query_decomposition/p02_failure8_actual_target_probe_v1_20261022"
P = ROOT / "outputs/query_decomposition" / B.name


def read(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))


def rows(p):
    return [json.loads(s) for s in p.read_text(encoding="utf-8-sig").splitlines() if s.strip()]


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def digest(v):
    return hashlib.sha256(canonical(v).encode()).hexdigest()


def rel(p):
    return str(p.relative_to(ROOT)).replace("\\", "/")


def normal(r, model):
    u = r.get("usage") or {}
    return (r.get("status") == "success" and r.get("finish_reason") == "stop"
        and isinstance(r.get("answer"), str) and bool(r["answer"].strip()) and not r.get("refusal")
        and r.get("requested_model") == r.get("returned_model") == model
        and all(type(u.get(k)) is int and u[k] >= 0 for k in ("prompt_tokens", "completion_tokens", "total_tokens"))
        and u["total_tokens"] == u["prompt_tokens"] + u["completion_tokens"])


def cost(r):
    return r["usage"]["prompt_tokens"] * .8e-6 + r["usage"]["completion_tokens"] * 2e-6


def main():
    batch = P / "root_blind_review/batch001"
    first = batch / "SEMANTIC_REVIEWS.blinded.jsonl"
    assert sha(first) == "4130f5ae3732409323724d3d220e1a5f04df159618698bc11b509ccf7af3582d"
    supplement_path = P / "SUPPLEMENTAL_BOB_GIBSON_FACT_VERIFICATION.local.json"
    paths = [P / "REPORT.json", P / "DETAILS.local.jsonl", P / "root_blind_review/SEMANTIC_JOIN.json", first,
        batch / "SEMANTIC_REVIEW_LOCK.json", batch / "ROOT_REVIEW_LOCK.json", batch / "PACKET.json", batch / "METHOD_KEY.local.json",
        B / "INPUTS8.frozen.jsonl", B / "FRESH_I0_RECEIPTS8.local.frozen.json", B / "PROTOCOL.frozen.json", B / "run.py", B / "templates.py", supplement_path]
    before = {rel(p): sha(p) for p in paths}
    protocol = read(B / "PROTOCOL.frozen.json")
    for path, expected in protocol["pins"].items():
        assert sha(ROOT / path) == expected, path
    report = read(P / "REPORT.json")
    details = rows(P / "DETAILS.local.jsonl")
    index = {(r["probe_id"], r["arm"]): r for r in details}
    inputs = rows(B / "INPUTS8.frozen.jsonl")
    items = {r["probe_id"]: r for r in inputs}
    joined = read(P / "root_blind_review/SEMANTIC_JOIN.json")
    semantic = {(r["case_id"], r["arm"]): r for r in joined["records"]}
    assert len(details) == len(index) == len(semantic) == joined["reviewed_records"] == 16
    assert set(index) == set(semantic) == {(i, a) for i in items for a in templates.ARMS}
    config = read(ROOT / "src/p02_multigrain_timing_cachefix_v1/config.json")
    model = config["generation"]["model"]
    assert config["generation"] == read(B / "GENERATION.frozen.json")
    with closing(sqlite3.connect((P / "checkpoint.sqlite3").resolve().as_uri() + "?mode=ro", uri=True)) as db:
        current = {i: dict(payload=p, status=s, result=json.loads(v)) for i, p, s, v in db.execute("SELECT id,payload,status,result FROM requests")}
        retired = {i: dict(payload=p, status=s, result=json.loads(v)) for i, p, s, v in db.execute("SELECT id,payload,status,result FROM retired_requests")}
        outcomes = [json.loads(v) for (v,) in db.execute("SELECT value FROM data WHERE kind='outcome'")]
    assert len(current) == 5 and len(retired) == 1 and len(outcomes) == 16
    assert {r["task_id"]: r for r in details} == {r["task_id"]: r for r in outcomes}
    for rid, value in current.items():
        assert value["status"] == "success" and normal(value["result"], model), rid
    for value in retired.values():
        assert value["status"] == value["result"]["status"] == "unknown"
        assert value["payload"] in {r["payload"] for r in current.values()}
        assert not any(value["result"].get(k) is not None for k in ("response_id", "usage", "raw_response", "returned_model", "refusal", "finish_reason"))
    attempts = Counter(r["payload"] for r in list(current.values()) + list(retired.values()))
    assert max(attempts.values()) <= 5
    controls = read(B / "FRESH_I0_RECEIPTS8.local.frozen.json")["controls"]
    control_index = {r["probe_id"]: r for r in controls}
    uses = rows(B / "LOGICAL_USES16.frozen.jsonl")
    source_checks = []
    for c in controls:
        assert normal(c["result"], model) and digest(c["source_payload"]) == c["payload_sha256"]
        assert c["source_payload"] == items[c["probe_id"]]["control_payload"]
        with closing(sqlite3.connect((ROOT / c["source_database"]).resolve().as_uri() + "?mode=ro", uri=True)) as db:
            actual = db.execute("SELECT payload,status,result FROM requests WHERE id=?", (c["source_request_id"],)).fetchone()
        assert actual == (canonical(c["source_payload"]), "success", canonical(c["result"])) or (
            actual and actual[0] == canonical(c["source_payload"]) and actual[1] == "success" and json.loads(actual[2]) == c["result"])
        source_checks.append(dict(probe_id=c["probe_id"], source_request_id=c["source_request_id"], full_I0_payload_receipt_exact=True,
            already_paid_CNY=c["source_charge"]["actual_CNY"], new_CNY=0))
    payload_checks = []
    for use in uses:
        item = items[use["probe_id"]]
        row = index[use["probe_id"], use["arm"]]
        expected = build_payload(config["generation"], templates.prompt(item, use["arm"]), 128)
        if use["reuse_already_paid_I0"]:
            control = control_index[use["probe_id"]]
            payload, receipt = control["source_payload"], control["result"]
            assert row["request_id"] == control["source_request_id"] and row["actual_new_CNY"] == 0
        else:
            actual = current[row["request_id"]]
            payload, receipt = json.loads(actual["payload"]), actual["result"]
        assert payload == expected and row["payload_sha256"] == digest(payload)
        assert row["answer"] == receipt["answer"].strip() and row["usage"] == receipt["usage"]
        assert row["original_raw_current_evaluation_target"] == item["current_question"]
        assert row["actual_model_current"] == templates.model_current(item, use["arm"])
        payload_checks.append(dict(probe_id=use["probe_id"], arm=use["arm"], full_wire_exact=True,
            payload_sha256=digest(payload), raw_current_evaluation_target_unchanged=True,
            source_reuse=use["reuse_already_paid_I0"], cap128_matching_model_stop_three_usage=True))
    assert sum(r["source_reuse"] for r in payload_checks) == 11
    for arm in templates.ARMS:
        rr = [r for r in details if r["arm"] == arm]
        assert len(rr) == 8 and all(r["status"] == "success" for r in rr)
        for metric, key in [("logical_input_tokens", "prompt_tokens"), ("logical_output_tokens", "completion_tokens")]:
            assert sum(r["usage"][key] for r in rr) == report["sections"][arm][metric]
    comparison = dict(terminal_pairs=8, changed_text_ids=[i for i in items if index[i, "C0"]["answer"] != index[i, "C1"]["answer"]],
        same_actual_receipt_pairs=sum(index[i, "C0"]["request_id"] == index[i, "C1"]["request_id"] for i in items))
    assert comparison == report["comparison"] and len(comparison["changed_text_ids"]) == 4 and comparison["same_actual_receipt_pairs"] == 3
    first_index = {r["candidate_id"]: r for r in rows(first)}
    for key in read(batch / "METHOD_KEY.local.json"):
        row, review = index[key["case_id"], key["arm"]], first_index[key["candidate_id"]]
        assert digest(row) == key["outcome_sha256"] and row["request_id"] == key["source_request_id"]
        assert semantic[key["case_id"], key["arm"]]["candidate_id"] == key["candidate_id"]
        assert all(semantic[key["case_id"], key["arm"]][k] == v for k, v in review.items())
    lock = read(batch / "ROOT_REVIEW_LOCK.json")
    assert lock["review_sha256"] == sha(first) and lock["packet_sha256"] == sha(batch / "PACKET.json") and lock["locked_before_root_method_join"]
    with closing(sqlite3.connect(Path(config["budget"]["ledger"]).resolve().as_uri() + "?mode=ro", uri=True)) as db:
        charges = [dict(id=i, reserved_CNY=r, actual_CNY=a, status=s) for i, r, a, s in db.execute(
            "SELECT id,reserved,actual,status FROM charges WHERE namespace=?", ("p02_prompt_research_v1_20261022/" + str(P.resolve()),))]
        for c in controls:
            old = db.execute("SELECT namespace,actual,status FROM charges WHERE id=?", (c["source_request_id"],)).fetchone()
            assert old == (c["source_charge"]["namespace"], c["source_charge"]["actual_CNY"], "returned_usage")
    assert len(charges) == 6 and {c["id"] for c in charges} == set(current) | set(retired)
    charge_index = {c["id"]: c for c in charges}
    for rid, value in current.items():
        assert charge_index[rid]["status"] == "returned_usage" and abs(charge_index[rid]["actual_CNY"] - cost(value["result"])) < 1e-12
    for rid in retired:
        assert charge_index[rid]["status"] == "reserved" and charge_index[rid]["actual_CNY"] is None
    assert not {c["source_request_id"] for c in controls}.intersection(charge_index)
    actual = sum(c["actual_CNY"] or 0 for c in charges)
    reserved = sum(c["reserved_CNY"] for c in charges if c["actual_CNY"] is None)
    oldcost = sum(c["source_charge"]["actual_CNY"] for c in controls)
    assert abs(actual - .0113136) < 1e-12 and abs(reserved - .0120712) < 1e-12 and abs(oldcost - .0164192) < 1e-12
    for a, b in [(actual, report["actual_new_known_returned_usage_CNY"]), (reserved, report["unresolved_reserved_CNY"]),
                 (oldcost, report["source_unique_attributed_already_charged_CNY"])]:
        assert abs(a - b) < 1e-12
    assert report["source_new_CNY"] == 0 and not report["reservations_without_cache_record_ids"]
    assert sum(v["result"]["usage"]["prompt_tokens"] for v in current.values()) == report["new_unique_input_tokens"] == 13907
    assert sum(v["result"]["usage"]["completion_tokens"] for v in current.values()) == report["new_unique_output_tokens"] == 94
    supplement = read(supplement_path)
    assert supplement["first_review_sha256"] == sha(first) and supplement["supplemental_factual_correct"] is True
    assert sha(ROOT / supplement["evidence"]["source"]) == supplement["evidence"]["source_sha256"]
    notes = {
        "2wiki:a6fd9c120baf11ebab90acde48001122/ordinary/2": ("grounded_local_relation_repair", "C1完整保留Robert I→父Richard II，修复当前QA关系；原D相对Richard原题多走一代仍在，不能推成root final修复。"),
        "2wiki:02f574780baf11ebab90acde48001122/ordinary/2": ("grounded_local_relation_repair", "C1由妻父Liu Yin纠正为丈夫Liu Cong之父Liu Yuan；reader直接支持，非词面替换。"),
        "hotpotqa:5a8512035542992a431d1ace/ordinary/2": ("local_membership_repair_verified_by_supplement", "C1排除shortstop Maury Wills并保留Bob Gibson。首审Bob正面事实待核，后由同题冻结goal reader rank10证实退休美国投手，补证后完整事实正确；不倒称原ordinaryreader足够。"),
        "2wiki:54bf355508b811ebbd88ac1f6bf848b6/ordinary/4": ("wording_only_unrepaired_abstention", "C1只是缩短人物描述；仍对已可见死亡日期不当弃答，没有真实修复。"),
    }
    changed = [dict(probe_id=i, original_question=items[i]["original_question"], original_raw_current=items[i]["current_question"],
        actual_C1_current=items[i]["frozen_rewritten_query"], classification=notes[i][0], interpretation=notes[i][1],
        C0=dict(answer=index[i, "C0"]["answer"], first_locked_review=semantic[i, "C0"]),
        C1=dict(answer=index[i, "C1"]["answer"], first_locked_review=semantic[i, "C1"])) for i in comparison["changed_text_ids"]]
    result = dict(created_utc=datetime.now(timezone.utc).isoformat(), scope="Post-lock selected C8 ordinaryQA local screen; no causal C benefit or finalRAG F1 claim",
        protected_source_hashes=before, first_blind_review_sha256=sha(first), all16_first_labels_unchanged=True,
        frozen_pins_verified=len(protocol["pins"]), first_locked_stage_sections=joined["sections"],
        supplemental_truth=dict(path=rel(supplement_path), sha256=sha(supplement_path), effective_whole_counts=supplement["effective_whole_correctness_counts"],
            confirmed_local_repairs_after_supplement=3, first_lock_confirmed_repairs=2, necessary_information_first_flags_preserved=True),
        paired_changes=changed, comparison=comparison,
        receipt_audit=dict(new_unique_complete_payloads=5, logical_conditions=16, source_logical_reuses=11,
            source_unique_paid_receipts=8, same_receipt_pairs=3, all_full_payloads_exact=True,
            all_requested_returned_models_stop_three_nonnegative_int_usage_valid=True,
            maximum_durable_attempts_observed=max(attempts.values()), retired_unknown={rid: dict(payload_sha256=digest(json.loads(v["payload"])), status=v["status"], result=v["result"]) for rid, v in retired.items()},
            payload_checks=payload_checks, source_controls=source_checks),
        cost_audit=dict(new_known_CNY=actual, unknown_reserved_CNY=reserved, source_old_unique_attribution_CNY=oldcost, source_new_CNY=0,
            source_ids_absent_from_new_namespace=True, no_orphan_charges=True, charges=charges,
            note="Eight old paid receipts cover11 source logical uses; charge unique source attribution once, not11times. Unknown reserved liability remains despite16terminal conditions."),
        limits=["Nonconcurrent exact I0 reuse and repeatedly exposed eight-case selection support local screening only; any repair requires a fresh synchronous all-eight validation.",
            "Raw current remains the evaluation target; C is an explicit new actual-input variant, not a description of old P02.",
            "Richard original decomposition and downstream recovery boundary remain; no retrieval, formatter, goal or final propagation was evaluated here.",
            "Same informed Codex reviewer designed C and reviewed I/B; first reviews are not independent human gold."],
        original_scripts_reports_first_labels_unchanged=True, no_L_outputs_read=True, new_API_calls=0, new_web_fact_checks=0, main_evaluation_remains_paused=True)
    assert before == {rel(p): sha(p) for p in paths}
    target = P / "ROOT_PAIRED_INTERPRETATION.json"
    assert not target.exists()
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    print(json.dumps(dict(passed=True, path=rel(target), sha256=sha(target), new_known_CNY=actual,
        reserved_CNY=reserved, source_unique_old_attribution_CNY=oldcost, first_review_preserved=sha(first)), ensure_ascii=True))


if __name__ == "__main__":
    main()
