"""Offline adversarial checks for the job159533 closure supplement."""
from contextlib import closing
from copy import deepcopy
import json
from pathlib import Path
import socket
import sqlite3
import subprocess
import tempfile
from unittest.mock import patch
import context90_scheduler_closure as supplement


def reject(call):
    try: call()
    except (AssertionError, KeyError, TypeError, ValueError): return
    raise AssertionError("Invalid closure was accepted")


def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+"\n", encoding="utf8")


def blocked(*args, **kwargs):
    raise AssertionError("No network/process service allowed in this test")


def main():
    checks = {}
    with patch.object(socket.socket, "connect", blocked), patch.object(socket, "create_connection", blocked), patch.object(subprocess, "Popen", blocked):
        real = supplement.read(supplement.RECEIPT)
        assert supplement.validate_scheduler_receipt(real)["kind"] == "scheduler_timeout"
        checks["real_readonly_scheduler_receipt_validates"] = True
        for field, value in (("job_id", "159534"), ("protocol_sha256", "wrong"), ("read_only", False)):
            bad = deepcopy(real); bad[field] = value; reject(lambda: supplement.validate_scheduler_receipt(bad))
        for key in ("squeue", "sacct", "scontrol"):
            bad = deepcopy(real); bad["commands"][key]["code"] = 1; reject(lambda: supplement.validate_scheduler_receipt(bad))
            bad = deepcopy(real); bad["commands"][key]["argv"].append("extra"); reject(lambda: supplement.validate_scheduler_receipt(bad))
        for key, text in (("squeue", "159533|RUNNING\n"), ("sacct", real["commands"]["sacct"]["stdout"].replace("TIMEOUT", "RUNNING")),
                          ("scontrol", real["commands"]["scontrol"]["stdout"].replace("Restarts=0", "Restarts=1"))):
            bad = deepcopy(real); bad["commands"][key]["stdout"] = text; reject(lambda: supplement.validate_scheduler_receipt(bad))
        checks["wrong_job_protocol_command_or_nonterminal_state_rejected"] = True
        with tempfile.TemporaryDirectory(prefix="_closure_fake_", dir=supplement.HERE) as folder:
            root = Path(folder); context = root / "context"; context.mkdir(); output = root / "output"; (output / "held").mkdir(parents=True)
            for name in ("PROTOCOL.frozen.json", "INPUTS90.jsonl", "ORDER270.jsonl"):
                (context / name).write_bytes((supplement.CONTEXT / name).read_bytes())
            for name in ("REMOTE_JOB_ID.json", "REMOTE_GPU_READY.json"):
                (output / name).write_bytes((supplement.OUTPUT / name).read_bytes())
            tasks = supplement.rows(context / "ORDER270.jsonl")
            identity = dict(protocol_sha256=supplement.CONTEXT_SHA, inputs_sha256=supplement.sha(context / "INPUTS90.jsonl"),
                            order_sha256=supplement.sha(context / "ORDER270.jsonl"))
            with closing(sqlite3.connect(output / "checkpoint.sqlite3")) as db:
                db.execute("CREATE TABLE data(kind TEXT,key TEXT,value TEXT)"); db.execute("CREATE TABLE requests(status TEXT)")
                db.execute("INSERT INTO data VALUES('meta','identity',?)", (json.dumps(identity),))
                db.executemany("INSERT INTO data VALUES('outcome',?,'{}')", ((r["task_id"],) for r in tasks[:-1])); db.commit()
            write(output / "held/one.json", dict(task_id=tasks[-1]["task_id"]))
            assert supplement.validate_checkpoint_closure(context, output)["attempted"] == 270
            write(output / "REMOTE_GPU_FINISHED.json", {"status": "invalid"})
            reject(lambda: supplement.validate_checkpoint_closure(context, output)); (output / "REMOTE_GPU_FINISHED.json").unlink()
            with closing(sqlite3.connect(output / "checkpoint.sqlite3")) as db:
                db.execute("INSERT INTO requests VALUES('in_flight')"); db.commit()
            reject(lambda: supplement.validate_checkpoint_closure(context, output))
            with closing(sqlite3.connect(output / "checkpoint.sqlite3")) as db:
                db.execute("DELETE FROM requests"); db.execute("UPDATE data SET value='{}' WHERE kind='meta'"); db.commit()
            reject(lambda: supplement.validate_checkpoint_closure(context, output))
            with closing(sqlite3.connect(output / "checkpoint.sqlite3")) as db:
                db.execute("UPDATE data SET value=? WHERE kind='meta'", (json.dumps(identity),)); db.commit()
            (output / "held/one.json").unlink(); reject(lambda: supplement.validate_checkpoint_closure(context, output))
            checks["all270_plus_held_required_zero_inflight_identity_and_no_fake_finished"] = True
            auth = supplement.authorization_template(); auth["approved"] = True
            authfile = root / "AUTH.json"; plan = root / "plan"; plan.mkdir(); write(plan / "PLAN.json", dict(execution_approval=dict(approved=False)))
            write(plan / "DECISIONS.jsonl", dict(id=auth["decision_id"], approved=True, script_sha256=auth["script_sha256"], scheduler_receipt_sha256=auth["scheduler_receipt_sha256"]))
            write(authfile, auth)
            # JSONL needs one compact object, not the pretty fixture encoding.
            (plan / "DECISIONS.jsonl").write_text(json.dumps(dict(id=auth["decision_id"], approved=True,
                script_sha256=auth["script_sha256"], scheduler_receipt_sha256=auth["scheduler_receipt_sha256"]))+"\n", encoding="utf8")
            with patch.object(supplement, "AUTHORIZATION", authfile), patch.object(supplement, "PLAN", plan):
                supplement.authorized("stage"); supplement.authorized("full90")
                for field in ("script_sha256", "scheduler_receipt_sha256", "expected_job_id"):
                    bad = deepcopy(auth); bad[field] = "wrong"; write(authfile, bad); reject(lambda: supplement.authorized("stage"))
                write(authfile, auth)
            checks["root_auth_and_main_decision_hash_gate_checked"] = True
        for reason in ("invalid_predecessor_worker_finished_leaf", "predecessor_checkpoint_identity_mismatch", "predecessor_pending"):
            original = dict(finished=False, reason=reason)
            with patch.object(supplement, "authorized", side_effect=AssertionError("must not call fallback")):
                assert supplement.completion_status(lambda: original, "stage") == original
        with patch.object(supplement, "authorized", side_effect=AssertionError("unapproved")):
            assert not supplement.completion_status(lambda: dict(finished=False, reason="missing_predecessor_completion_artifact"), "stage")["finished"]
        checks["original_guard_first_only_missing_finished_can_use_authorized_fallback"] = True
        from experiments.query_decomposition.p02_reference_binding_priority_probe_v1_20261022 import run as stage
        from experiments.query_decomposition.p02_reference_binding_priority_fixed90_v1_20261022 import run as full90
        original = stage.context90_completion_status
        def injected(**kwargs): return stage.context90_completion_status()
        with patch.object(supplement, "authorized", return_value={}), patch.object(supplement, "completion_status", return_value={"fixture": True}), \
             patch.object(stage, "run", side_effect=injected), patch.object(full90, "run", side_effect=injected):
            assert supplement.launch("stage", True) == {"fixture": True}
            assert stage.context90_completion_status is original
            assert supplement.launch("full90", True) == {"fixture": True}
            assert stage.context90_completion_status is original
        checks["both_wrappers_replace_only_stage_guard_then_restore"] = True
    result = dict(passed=True, checks=checks, script_sha256=supplement.sha(supplement.__file__),
        test_sha256=supplement.sha(__file__), new_API_SSH_GPU=0, production_checkpoints_or_frozen_files_modified=False)
    write(supplement.HERE / "CONTEXT90_SCHEDULER_CLOSURE_OFFLINE_CHECKS.json", result)
    print(json.dumps(result))


if __name__ == "__main__": main()
