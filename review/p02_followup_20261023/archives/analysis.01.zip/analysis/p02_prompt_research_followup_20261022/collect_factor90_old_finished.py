"""Read job160987 worker closure into a separate supplement; no remote writes."""
from datetime import datetime, timezone
from pathlib import Path
import getpass
import hashlib
import json
import shlex
import socket

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/query_decomposition/p02_reference_binding_priority_fixed90_v1_20261022"
DEST = OUT / "incidents/job160987_logging_failure_supplement"


def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    import paramiko
    job = read(OUT / "REMOTE_JOB_ID.json")
    assert job["job_id"] == "160987" and job["directory"].endswith("/factor90_0988e8eccdc08419")
    settings = read(ROOT / "experiments/query_decomposition/p02_reference_binding_priority_fixed90_v1_20261022/EXECUTION_SETTINGS.json")
    assert read(ROOT / settings["partition_preflight"])["verified_address"] == settings["verified_host_address"]
    assert not (DEST / "COLLECTION.json").exists()
    client = paramiko.SSHClient(); client.load_system_host_keys(); client.set_missing_host_key_policy(paramiko.RejectPolicy())
    password = getpass.getpass("Remote password: ")
    connection = None
    try:
        connection = socket.create_connection((settings["verified_host_address"], 22), timeout=15)
        client.connect("cluster1.comp.anu.edu.au", username="u7830488", password=password, sock=connection,
            look_for_keys=False, allow_agent=False, timeout=15, auth_timeout=20, banner_timeout=15)
        password = None
        result = dict(utc=datetime.now(timezone.utc).isoformat(), job_id=job["job_id"], protocol_sha256=job["protocol_sha256"],
            remote_directory=job["directory"], read_only_remote=True, new_jobs=0, API_requests=0, original_snapshot_unchanged=True,
            files={}, commands={})
        argv = ["scontrol", "show", "job", "-o", job["job_id"]]
        _, stdout, stderr = client.exec_command(shlex.join(argv), timeout=30)
        text, error = stdout.read().decode(), stderr.read().decode(); code = stdout.channel.recv_exit_status()
        result["commands"]["scontrol"] = dict(argv=argv, code=code, stdout=text, stderr=error)
        if code == 0 and not error.strip():
            control = dict(p.split("=", 1) for p in text.split() if "=" in p)
            assert control["JobId"] == job["job_id"] and control["WorkDir"] == job["directory"]
            assert control["UserId"] == "u7830488(7830488)" and control["JobState"] == "COMPLETED"
            result["current_scheduler_identity_available"] = True
        else:
            # Slurm may purge completed jobs from scontrol. Preserve this failure
            # and bind the file read to the already verified terminal receipt.
            previous = OUT / "incidents/job160987_logging_failure/SCHEDULER_TERMINAL.json"
            saved = read(previous)
            assert saved["job_id"] == job["job_id"] and saved["remote_directory"] == job["directory"]
            assert saved["terminal"]["verified"] is True and saved["terminal"]["state"] == "COMPLETED"
            result["current_scheduler_identity_available"] = False
            result["prior_verified_scheduler_receipt_sha256"] = hashlib.sha256(previous.read_bytes()).hexdigest()
        DEST.mkdir(parents=True, exist_ok=True)
        with client.open_sftp() as sftp:
            for name in ("REMOTE_JOB.frozen.json", "READY.json", "FINISHED.json", "WORKER_ERROR.json"):
                try:
                    with sftp.open(job["directory"] + "/" + name, "rb") as stream: raw = stream.read()
                except FileNotFoundError:
                    result["files"][name] = dict(present=False); continue
                value = json.loads(raw)
                if name == "REMOTE_JOB.frozen.json":
                    assert value["protocol_sha256"] == job["protocol_sha256"] and value["remote_directory"] == job["directory"]
                if name == "READY.json": assert value["job_id"] == job["job_id"] and value["protocol_sha256"] == job["protocol_sha256"]
                with (DEST / name).open("xb") as stream: stream.write(raw)
                result["files"][name] = dict(present=True, sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
        with (DEST / "COLLECTION.json").open("x", encoding="utf8") as stream: stream.write(json.dumps(result, indent=2) + "\n")
        print(json.dumps(dict(job_id=job["job_id"], real_FINISHED_present=result["files"]["FINISHED.json"]["present"],
            supplement=str(DEST), new_jobs=0, API_requests=0)), flush=True)
    finally:
        password = None; client.close()
        if connection: connection.close()


if __name__ == "__main__": main()
