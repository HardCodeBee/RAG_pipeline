"""Read-only lineage audit of existing W/E/R and S decomposition inputs.

Writes new audit artifacts only. No source/protocol mutation, provider, model,
retrieval, SSH, job control or evaluation launch is available here.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
E = ROOT / "experiments/query_decomposition"
O = ROOT / "outputs/query_decomposition/hotpot_formal_eval_v1"
OUT = E / "unified_rag_eval_v1_20261021/reviews/20261022_prompt_binding_goal_synthesis/decomposition_lineage_audit/revision002"
QUICK = E / "p02_noformatter_quick90_v1_20261021"
OLD_RAW = O / "decomposition_error_expand60_v1_20261019"
FORMAL = E / "p02_formal1500_v1_20261021"
FORMAL_OUT = O / FORMAL.name
PROMPT_SHA = "508709f217ee58ca53d60ecce6001d5e5b0e6d51a858dd4b95b2d6d311864ee8"
CHECKPOINT_SHA = "728fb4761116debf44ca4c7078a09283939beeb590b35e4a8647e6131a9fce92"


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def rows(path):
    return [json.loads(s) for s in Path(path).read_text(encoding="utf-8-sig").splitlines() if s.strip()]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def objsha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()


def relative(path):
    return str(Path(path).resolve().relative_to(ROOT)).replace("\\", "/")


def ordinary(case):
    return [n["request"] for n in case["nodes"] if n["role"] == "ordinary"]


def key(row):
    return row["dataset"], row.get("qid", row["id"].split(":", 1)[-1])


def save(name, value):
    path = OUT / name
    if path.exists():
        raise FileExistsError("Preserve completed audit; choose a separate revision")
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf8")


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    if (OUT / "SUMMARY.json").exists():
        raise FileExistsError("Audit already frozen")
    runtime = {r["id"]: r for r in rows(QUICK / "runtime90.frozen.jsonl")}
    bindings = rows(QUICK / "SOURCE_BINDINGS.frozen.jsonl")
    provenance = {r["id"]: r for r in rows(E / "complete_pipeline_comparison_v1_20261020/r02_provenance300.frozen.jsonl")}
    manual = {r["id"]: r for r in rows(E / "decomposition_corrected_same60_v1_20261019/runtime60.frozen.jsonl")}
    identity = read(OLD_RAW / "RAW_IDENTITY.json")
    old_plan = read(E / "decomposition_error_expand60_v1_20261019/PLAN_FROZEN.json")
    submission = read(OLD_RAW / "JOB_SUBMISSION.json")
    nominee = read(E / "multigrain_4b_coverage_retrain_v3_20261018/NOMINEE_FROZEN.json")
    package_identity = read(ROOT / "src/p02_multigrain_timing_cachefix_v1/models/DECOMPOSER_IDENTITY.json")
    v12 = (E / "multigrain_4b_coverage_retrain_v3_20261018/v12.txt").read_text(encoding="utf8")
    assert hashlib.sha256(v12.encode()).hexdigest() == PROMPT_SHA
    assert identity["checkpoint_manifest_sha256"] == old_plan["raw_generation"]["checkpoint_sha256"] == CHECKPOINT_SHA
    assert identity["prompt_sha256"] == PROMPT_SHA
    assert nominee["checkpoint_manifest_sha256"] == CHECKPOINT_SHA
    assert nominee["checkpoint"] == old_plan["raw_generation"]["checkpoint"] == package_identity["remote_checkpoint_directory"]
    assert sha(E / "multigrain_4b_coverage_retrain_v3_20261018/score_model.py") == submission["remote_scorer_sha256"]
    assert identity["query_sha256"] == sha(E / "decomposition_error_expand60_v1_20261019/candidates300.query_only.frozen.jsonl")
    archive = OLD_RAW / "returned/snapshot_004.zip"
    w_records, all_checks = [], Counter()
    with zipfile.ZipFile(archive) as z:
        assert json.loads(z.read("IDENTITY.json")) == identity
        state = json.loads(z.read("STATE.json"))
        assert state["status"] == "completed" and state["completed"] == state["planned"] == 300
        for binding in bindings:
            ident = binding["id"]
            source_path = ROOT / binding["source"]
            source = read(source_path)
            prefix_path, parent_path = ROOT / source["source_prefix"], ROOT / source["parent_source"]
            prefix, parent = read(prefix_path), read(parent_path)
            raw_path = ROOT / provenance[ident]["source"]
            raw = read(raw_path)
            array = json.loads(raw["raw_output"])
            frozen = runtime[ident]
            checks = {
                "source_case_sha_exact": sha(source_path) == binding["source_sha256"],
                "runtime_array_equals_source_ordinary": frozen["supporting_questions"] == ordinary(source),
                "source_prefix_array_equals_actual_source": prefix["supporting_questions"] == ordinary(prefix) == ordinary(source),
                "parent_array_equals_actual_source": ordinary(parent) == ordinary(source),
                "raw_file_sha_matches_r02_provenance": sha(raw_path) == provenance[ident]["sha256"],
                "remote_raw_array_equals_runtime_without_edits": array == raw["parsed"] == frozen["supporting_questions"],
                "all_original_query_texts_exact": raw["query"] == frozen["question"] == source["question"] == prefix["question"] == parent["question"],
                "actual_prompt_byte_exact_v12": raw["actual_prompt"] == v12,
                "raw_identity_binds_checkpoint_and_prompt": raw["identity_sha256"] == objsha(identity),
                "remote_raw_all_JSON_fields_exact": json.loads(z.read(raw_path.name)) == raw,
                "remote_raw_serialized_bytes_exact_after_LF_normalization": z.read(raw_path.name).replace(b"\r\n", b"\n") == raw_path.read_bytes().replace(b"\r\n", b"\n"),
                "complete_valid_model_array": raw["format_valid"] and raw["generation_error"] is None and not raw["truncated"],
                "dataset_qid_preserved": source["id"] == prefix["id"] == parent["id"] == raw["id"] == ident and raw["dataset"] == frozen["dataset"],
            }
            for name, passed in checks.items(): all_checks[name + ("_pass" if passed else "_FAIL")] += 1
            corrected = manual.get(ident)
            w_records.append({"id": ident, "dataset": frozen["dataset"], "question": frozen["question"],
                "supporting_questions": frozen["supporting_questions"], "checks": checks,
                "source_case": relative(source_path), "source_case_sha256": sha(source_path),
                "source_prefix": relative(prefix_path), "source_prefix_sha256": sha(prefix_path),
                "parent_source": relative(parent_path), "parent_source_sha256": sha(parent_path),
                "raw_record": relative(raw_path), "raw_sha256": sha(raw_path), "raw_index": raw["index"],
                "raw_output": raw["raw_output"], "raw_identity_sha256": raw["identity_sha256"],
                "actual_prompt_sha256": hashlib.sha256(raw["actual_prompt"].encode()).hexdigest(),
                "checkpoint_manifest_sha256": CHECKPOINT_SHA, "accepted_snapshot": relative(archive),
                "archive_member": raw_path.name,
                "serialization": {"original_bytes_exact": z.read(raw_path.name) == raw_path.read_bytes(),
                    "LF_normalized_bytes_exact": z.read(raw_path.name).replace(b"\r\n", b"\n") == raw_path.read_bytes().replace(b"\r\n", b"\n"),
                    "remote_member_sha256": hashlib.sha256(z.read(raw_path.name)).hexdigest(),
                    "local_raw_sha256": sha(raw_path), "remote_CRLF_count": z.read(raw_path.name).count(b"\r\n"),
                    "local_CRLF_count": raw_path.read_bytes().count(b"\r\n")},
                "same_id_in_manual_corrected60": corrected is not None,
                "manual_corrected60_array": corrected["supporting_questions"] if corrected else None,
                "equals_manual_corrected60": frozen["supporting_questions"] == corrected["supporting_questions"] if corrected else None})
    w_index = {r["id"]: r for r in w_records}
    actual_w = rows(E / "p02_final_target_check_fixed90_v1_20261022/INPUTS90.frozen.jsonl")
    w_binding_exact = len(actual_w) == 90 and all((r["source"].replace("\\", "/"), r["source_sha256"]) ==
        (w_index[r["id"]]["source_case"], w_index[r["id"]]["source_case_sha256"]) for r in actual_w)
    subgroups = {}
    for name, path in (("E30", E / "p02_ordinary_fewshot_probe_v1_20261022/INPUTS.frozen.jsonl"),
                       ("R15", E / "p02_actual_child_binding_probe_v1_20261022/INPUTS15.frozen.jsonl")):
        values = []
        for r in rows(path):
            w = w_index[r["case_id"]]
            source = read(ROOT / r["source"])
            node = next(n for n in source["nodes"] if n["step_id"] == r["step_id"])
            checks = {"source_hash_matches_audited_W_case": r["source_sha256"] == w["source_case_sha256"] == sha(ROOT / r["source"]),
                      "actual_node_equals_unmodified_remote_array_item": node["request"] == r["current_question"] == w["supporting_questions"][r["step_id"] - 1],
                      "original_query_equals_remote_query": r["original_question"] == w["question"],
                      "node_history_reader_and_control_prompt_exact": node["prior_complete_answers"] == r["history"] and node["reader_packet"] == r["reader_packet"] and node["child_prompt"] == r["control_prompt"]}
            if name == "R15":
                checks["recorded_whole_decomposition_equals_remote_array"] = r["original_supporting_questions"] == w["supporting_questions"]
                checks["candidate_rewrite_is_existing_source_output"] = r["frozen_rewritten_query"] == node["rewritten_query"]
            values.append({"probe_id": r["probe_id"], "case_id": r["case_id"], "step_id": r["step_id"], "source": r["source"],
                           "remote_raw_record": w["raw_record"], "checks": checks})
        subgroups[name] = {"nodes": len(values), "unique_cases": len({r["case_id"] for r in values}), "all_checks_passed": all(all(r["checks"].values()) for r in values), "rows": values}
    # Formal generation is a different query cohort and a stronger, newer decode wrapper.
    formal_questions = rows(FORMAL / "questions1500.frozen.jsonl")
    formal_queries = rows(FORMAL / "queries1500.id_query.frozen.jsonl")
    formal_index = {r["id"]: (i, r) for i, r in enumerate(formal_queries, 1)}
    formal_identity = read(FORMAL_OUT / "remote_raw/IDENTITY.json")
    formal_meta = read(FORMAL / "REMOTE_INPUTS.frozen.json")
    assert formal_identity["checkpoint_manifest_sha256"] == CHECKPOINT_SHA
    assert formal_identity["prompt_sha256"] == PROMPT_SHA
    assert formal_identity["query_sha256"] == sha(FORMAL / "queries1500.id_query.frozen.jsonl")
    assert formal_meta["checkpoint"] == nominee["checkpoint"]
    s_records = []
    for r in rows(E / "p02_goal_composition_challenge_v1_20261022/SELECTION.frozen.jsonl"):
        source_path = ROOT / r["source"]
        source = read(source_path)
        i, query = formal_index[r["id"]]
        raw_path = FORMAL_OUT / "remote_raw" / f"{i:03d}.json"
        raw = read(raw_path)
        checks = {"source_sha256_exact": sha(source_path) == r["source_sha256"],
            "supporting_and_ordinary_arrays_equal_remote_raw": source["supporting_questions"] == ordinary(source) == raw["parsed"] == json.loads(raw["raw_output"]),
            "original_query_exact": source["question"] == query["query"] == raw["query"],
            "formal_identity_binds_checkpoint_and_prompt": raw["identity_sha256"] == objsha(formal_identity),
            "actual_prompt_byte_exact_v12": raw["actual_prompt"] == v12,
            "complete_valid_array": raw["format_valid"] and not raw["truncated"] and raw["generation_error"] is None}
        s_records.append({"id": r["id"], "source": relative(source_path), "source_sha256": sha(source_path),
                          "raw_record": relative(raw_path), "raw_sha256": sha(raw_path),
                          "supporting_questions": raw["parsed"], "checks": checks,
                          "identity_sha256": raw["identity_sha256"]})
    wi, fi = {key(r): r for r in runtime.values()}, {key(r): r for r in formal_questions}
    common = set(wi) & set(fi)
    overlap = {"key": "(dataset, original qid), never bare qid across datasets",
        "same_dataset_qid_count": len(common),
        "same_dataset_qid_and_exact_text_count": sum(wi[k]["question"] == fi[k]["question"] for k in common),
        "same_dataset_exact_text_any_id_count": len({(r["dataset"], r["question"]) for r in wi.values()} & {(r["dataset"], r["question"]) for r in fi.values()}),
        "by_dataset": {ds: sum(k[0] == ds for k in common) for ds in ("hotpotqa", "2wiki", "musique")},
        "array_comparison_on_common_queries": "not_applicable_no_common_queries" if not common else "requires explicit comparison"}
    manifest_path = ROOT / package_identity["local_checkpoint_return_manifest"]["path"]
    manifest = read(manifest_path)
    assert objsha(manifest["files"]) == manifest["manifest_sha256"] == CHECKPOINT_SHA
    available = [{"path": r["path"], "sha256_exact": sha(manifest_path.parent / r["path"]) == r["sha256"]} for r in manifest["files"] if (manifest_path.parent / r["path"]).is_file()]
    base_identity = read(manifest_path.parent / "BASE_MODEL_IDENTITY.json")
    for filename, records in (("W90_LINEAGE.jsonl", w_records), ("S27_FORMAL_LINEAGE.jsonl", s_records)):
        path = OUT / filename
        if path.exists(): raise FileExistsError(path)
        path.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in records), encoding="utf8")
    save("E_R_NODE_LINEAGE.json", subgroups)
    pins = [QUICK / "runtime90.frozen.jsonl", QUICK / "SOURCE_BINDINGS.frozen.jsonl", archive,
        OLD_RAW / "RAW_IDENTITY.json", OLD_RAW / "JOB_SUBMISSION.json", OLD_RAW / "GENERATION_AND_COHORT_AUDIT.json",
        E / "decomposition_error_expand60_v1_20261019/PLAN_FROZEN.json",
        E / "decomposition_error_expand60_v1_20261019/candidates300.query_only.frozen.jsonl",
        E / "complete_pipeline_comparison_v1_20261020/r02_provenance300.frozen.jsonl",
        E / "multigrain_4b_coverage_retrain_v3_20261018/score_model.py", E / "multigrain_4b_coverage_retrain_v3_20261018/v12.txt",
        E / "decomposition_corrected_same60_v1_20261019/runtime60.frozen.jsonl", FORMAL / "REMOTE_INPUTS.frozen.json",
        FORMAL / "queries1500.id_query.frozen.jsonl", FORMAL / "questions1500.frozen.jsonl", FORMAL_OUT / "remote_raw/IDENTITY.json", manifest_path]
    summary = {"utc": datetime.now(timezone.utc).isoformat(), "scope": "Read-only local recorded decomposition provenance; no launch, source edit, prompt change, API, GPU, SSH or live weight verification",
        "W90": {"cases": 90, "all_checks_passed": all(all(r["checks"].values()) for r in w_records),
            "counts": dict(all_checks), "actual_W90_bindings_exact": w_binding_exact,
            "source_families": dict(Counter(r["source_case"].split("/rounds/")[1].split("/")[0] for r in w_records)),
            "raw_origin": relative(OLD_RAW / "raw"), "accepted_snapshot_sha256": sha(archive),
            "original_raw_bytes_equal_returned_snapshot_count": sum(r["serialization"]["original_bytes_exact"] for r in w_records),
            "LF_normalized_bytes_equal_returned_snapshot_count": sum(r["serialization"]["LF_normalized_bytes_exact"] for r in w_records),
            "all_remote_JSON_fields_equal_count": sum(r["checks"]["remote_raw_all_JSON_fields_exact"] for r in w_records), "remote_job_id": submission["job_id"],
            "manual_corrected60_same_query_ids": sum(r["same_id_in_manual_corrected60"] for r in w_records),
            "manual_corrected60_equal_arrays_on_overlap": sum(r["equals_manual_corrected60"] is True for r in w_records),
            "manual_array_substitution_detected": False},
        "E_R": {k: {n: v[n] for n in ("nodes", "unique_cases", "all_checks_passed")} for k, v in subgroups.items()},
        "S27": {"cases": 27, "source": "formal1500", "all_checks_passed": all(all(r["checks"].values()) for r in s_records)},
        "W90_formal1500_overlap": overlap,
        "same_frozen_checkpoint_and_prompt": {"checkpoint": nominee["checkpoint"], "checkpoint_manifest_sha256": CHECKPOINT_SHA,
            "prompt": relative(E / "multigrain_4b_coverage_retrain_v3_20261018/v12.txt"), "prompt_sha256": PROMPT_SHA,
            "base_model": base_identity["repo_id"], "base_revision": base_identity["revision"],
            "adapter_sha256_recorded": next(r["sha256"] for r in manifest["files"] if r["path"] == "adapter_model.safetensors")},
        "different_decode_records": {"W90_identity": identity, "formal1500_identity": formal_identity,
            "W90_scorer_sha256": submission["remote_scorer_sha256"], "formal_infer_sha256": formal_meta["source_infer_sha256"],
            "same_generation_batch": False, "same_effective_decode_contract_proved": False,
            "explanation": "Old W90 raw is actual R02/v12 output with recorded do_sample=False, beam1, max1024, seed1729; it predates formal explicit_generation_config_v002 and lacks effective/default-override verification fields. Same weights/prompt does not prove identical effective decoding."},
        "checkpoint_manifest_local_check": {"manifest_files_hash_exact": True, "available_files": available,
            "unavailable_files": [r["path"] for r in manifest["files"] if not (manifest_path.parent / r["path"]).exists()],
            "fresh_remote_weights_checked": False, "limitation": "Local returned checkpoint metadata and raw bytes verified; adapter/base weight bytes are not present/rehashed and no remote connection made."},
        "conclusion": "W/E/R remain valid exposed development controls using unedited historical outputs of the selected frozen R02/v12 checkpoint; no manual corrected60 substitution found. S uses the same recorded checkpoint/prompt but formal1500 different cohort/newer decode wrapper. Do not combine as one generation contract or call this fresh inference. No reason to stop W inferred from this audit.",
        "audit_revision": 2, "supersedes_unpublished_audit": "../SUMMARY.json; original byte-check failure is retained there, but its all_raw_bytes_equal=True and report wording were incorrect. Actual local raw files differ by LF-to-CRLF only; arrays/token IDs/queries and allJSONfields equal.",
        "source_pins": {relative(p): sha(p) for p in pins}, "new_API_requests": 0, "sources_or_protocols_changed": False, "evaluation_state_changed": False}
    save("SUMMARY.json", summary)
    report = f'''# P02 分解输入溯源补充：W90 / E / R 与 S27

W90全部90题均逐字追到冻结R02/v12真实远端输出，没有发现人工corrected60替换。E30的27个独立原题、R15的14个独立原题全部来自这90题，实际子问、历史QA、reader及控制prompt与源节点一致。此结论来自逐条数组和来源核查，并非从此前formal40题外推。

| 来源 | 核查范围 | 真实分解来源 | 结果 |
|---|---:|---|---|
| W90 | 90题 | role_headers → parent/source_prefix B0_legacy_multigrain_R02 → raw300 → returned snapshot_004.zip | 90/90数组、原题、prompt、身份及返回JSON所有字段一致；原bytes因CRLF不等，LF规范化后完全一致 |
| E | 30节点、27独立原题 | W90对应源节点及raw数组项 | 全部一致 |
| R | 15节点、14独立原题 | E同期节点及W90完整raw数组 | 全部一致 |
| S27 | 27题 | formal1500 remote_raw | 27/27数组、原题、prompt及身份一致 |

W90对应远端任务154657，输出目录为`/home/projects/u7830488/decomposition_error_expand60_v1_20261019/results/round1_300`。`expand60`只是原诊断目录名；这里使用的是该次300题全部生成池中的原始数组，不是人工修正60题。W90与人工修正60题有16个相同题目ID，但16/16实际数组均与人工修正版不同，同时90/90实际数组都与远端返回包中raw_output字符串及全部JSON字段完全相同。逐条证据见W90_LINEAGE.jsonl。

两条来源的记录均绑定同一checkpoint：`{nominee['checkpoint']}`，manifest hash `{CHECKPOINT_SHA}`；v12 prompt hash `{PROMPT_SHA}`。基础模型记录为`{base_identity['repo_id']}`，revision `{base_identity['revision']}`。本次复核了本地返回manifest及可用metadata；没有重读远端adapter/base权重，不把这次审查称作实时权重验证。

必须分列生成口径：W90是较早score_model.py产生的真实历史输出，身份记录只有greedy/beam1/max1024/seed1729。formal1500使用更新的`explicit_generation_config_v002`，多记录effective_do_sample/effective_num_beams并显式传入generation_config。相同checkpoint/v12不意味着同一次生成，也不能证明旧批满足formal的新默认覆盖合同。这不影响保留W90作为冻结历史开发对照，但限制跨批的解码一致性表述。

W90与formal1500按`(dataset,qid)`比较交集为{len(common)}；按数据集加原题完整文本比较交集也为{overlap['same_dataset_exact_text_any_id_count']}。因此交集题目的数组一致性比较不适用，不能用裸qid跨数据集拼接。

本次只新增溯源报告，不修改任何输入、历史source、付费W协议或进程状态；不联网、不发API、不运行推理。T分支仍只准备。原始文件bytes并非逐字相同：90/90本地raw使用CRLF，远端zip成员使用LF；规范化换行后90/90文件bytes完全相同，所有JSON字段和tokenIDs均相同。首次审计将此bytes差异标成FAIL的记录仍保留在父目录；其报告中预先写入的bytes一致表述由本revision002明确更正。完整计数、核验hash与限制见SUMMARY.json；E/R逐节点表见E_R_NODE_LINEAGE.json，S27逐条表见S27_FORMAL_LINEAGE.jsonl。
'''
    (OUT / "REPORT.md").write_text(report, encoding="utf8")
    print(json.dumps({"W90_passed": summary["W90"]["all_checks_passed"], "E_R": summary["E_R"],
                      "S27_passed": summary["S27"]["all_checks_passed"], "overlap": overlap,
                      "summary": relative(OUT / "SUMMARY.json"), "new_API_requests": 0}, ensure_ascii=True))


if __name__ == "__main__":
    main()
