"""Read frozen IDs/raw D only; propose20 without opening final outputs/scores."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
B = ROOT / "experiments/query_decomposition/p02_formal1500_v1_20261021"
R = ROOT / "outputs/query_decomposition/hotpot_formal_eval_v1/p02_formal1500_v1_20261021/remote_raw"
OUT = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text(encoding="utf8"))
rows = lambda p: [json.loads(s) for s in p.read_text(encoding="utf8").splitlines() if s.strip()]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
rel = lambda p: str(p.relative_to(ROOT)).replace("\\", "/")

PATHS = [
    "p02_noformatter_quick90_v1_20261021/SOURCE_BINDINGS.frozen.jsonl",
    "p02_final_target_check_fixed90_v1_20261022/INPUTS90.frozen.jsonl",
    "p02_goal_native_role_fixed90_v1_20261022/INPUTS90.frozen.jsonl",
    "p02_prompt_binding_probe_v1_20261022/PROBES.frozen.jsonl",
    "p02_prompt_binding_probe_v1_20261022/first_node_followup/PROBES.frozen.jsonl",
    "p02_goal_synthesis_probe_v1_20261022/inputs15.frozen.jsonl",
    "p02_goal_composition_challenge_v1_20261022/inputs27.frozen.jsonl",
    "p02_goal_scope_role_probe_v1_20261022/inputs27.frozen.jsonl",
    "p02_goal_fact_role_probe_v1_20261022/inputs27.frozen.jsonl",
    "p02_actual_child_binding_probe_v1_20261022/INPUTS15.frozen.jsonl",
    "p02_ordinary_fewshot_probe_v1_20261022/INPUTS.frozen.jsonl",
    "p02_ordinary_failure_challenge8_v1_20261022/INPUTS8.frozen.jsonl",
    "p02_failure8_actual_entity_probe_v1_20261022/INPUTS8.frozen.jsonl",
    "p02_failure8_actual_target_probe_v1_20261022/INPUTS8.frozen.jsonl",
    "p02_failure8_dynamic_target_fullrag_draft_20261022/INPUTS8.jsonl",
]


def main():
    questions_path = B / "questions1500.frozen.jsonl"
    questions = rows(questions_path)
    question_sha = sha(questions_path)
    assert question_sha == read(B / "INPUTS.frozen.json")["input_pins"]["questions1500.frozen.jsonl"]
    by_id = {r["id"]: r for r in questions}
    remote = read(B / "REMOTE_INPUTS.frozen.json")
    prompt = (B / "v12.txt").read_text(encoding="utf8").rstrip()
    index_path = ROOT / "outputs/query_decomposition/p02_information_flow_followup_20261022/REVIEW_INDEX_V9.jsonl"
    info = rows(index_path)
    primary = {r["id"] for r in info if r["selection"] != "historical_case_outside_probability_sample"}
    supplemental = {r["id"] for r in info if r["selection"] == "historical_case_outside_probability_sample"}
    assert len(primary) == 270 and len(supplemental) == 8
    old_path = ROOT / "outputs/query_decomposition/p02_error_propagation_diagnostic_20261021/offline_review_v2/COHORT.jsonl"
    old = rows(old_path)
    old_index = {r["id"]: r for r in old}
    assert len(old_index) == 723
    def top_ids(row):
        result = set()
        for name in ("id", "case_id", "probe_id", "source_case_id"):
            value = row.get(name)
            if isinstance(value, str) and value.split(":", 1)[0] in ("hotpotqa", "2wiki", "musique"):
                result.add(value.split("/", 1)[0])
        if isinstance(row.get("qid"), str) and isinstance(row.get("dataset"), str):
            value = row["dataset"] + ":" + row["qid"]
            if row["dataset"] in ("hotpotqa", "2wiki", "musique"):
                result.add(value)
        return result
    # Prospective correction BEFORE any sample existed: passive reviews are
    # disclosures only. Excluding270 would remove every historical nonfullscore.
    recent, recent_questions = set(), set()
    norm = lambda text: " ".join(text.casefold().split())
    sources = []
    for suffix in PATHS:
        path = ROOT / "experiments/query_decomposition" / suffix
        records = rows(path)
        ids = set().union(*(top_ids(r) for r in records))
        assert ids, (suffix, "No IDs extracted")
        recent |= ids
        for record in records:
            question = record.get("original_question", record.get("question"))
            if isinstance(question, str):
                recent_questions.add(norm(question))
        sources.append(dict(path=rel(path), sha256=sha(path), records=len(records), unique_dataset_query_ids=len(ids),
            current_formal_id_overlap=len(ids.intersection(by_id)),
            per_dataset=dict(Counter(i.split(":", 1)[0] for i in ids))))
    stats = {ds: Counter() for ds in ("hotpotqa", "2wiki")}
    pool = []
    for position, q in enumerate(questions, 1):
        ds = q["dataset"]
        if ds not in stats:
            continue
        count = stats[ds]
        count["formal_questions"] += 1
        raw_path = R / (str(position) + ".json")
        if not raw_path.exists():
            count["missing_raw"] += 1
            continue
        raw = read(raw_path)
        count["raw_exists"] += 1
        assert raw.get("id") == q["id"] and raw.get("query") == q["question"]
        valid = (raw.get("format_valid") and not raw.get("truncated") and not raw.get("generation_error")
            and isinstance(raw.get("parsed"), list) and raw.get("actual_prompt", "").startswith(prompt))
        if not valid:
            count["invalid_raw"] += 1
            continue
        count["raw_valid"] += 1
        if not raw["parsed"]:
            count["goal_only_excluded"] += 1
            continue
        count["ordinary_nonempty"] += 1
        if q["id"] in recent or norm(q["question"]) in recent_questions:
            count["recent_actual_prompt_inference_excluded"] += 1
            continue
        count["available_after_recent_exclusions"] += 1
        count["available_still_prior723_semantic_exposed" if q["id"] in old_index else "available_outside_prior723"] += 1
        pool.append(dict(id=q["id"], qid=q["qid"], dataset=ds, question=q["question"], supporting_questions=raw["parsed"],
            formal_position_one_based=position, question_file=rel(questions_path), question_file_sha256=question_sha,
            raw_file=rel(raw_path), raw_sha256=sha(raw_path), actual_R02_array_exact=True, semantic_repairs_applied=False,
            source_R02_remote_inputs_sha256=sha(B / "REMOTE_INPUTS.frozen.json"),
            source_R02_checkpoint_manifest_sha256=remote["checkpoint_manifest_sha256"],
            prior723_semantic_exposure=q["id"] in old_index, prior723_source_metadata=old_index.get(q["id"]),
            selection_rank_sha256=hashlib.sha256(("p02-fixedD-balanced20-v1|20261022|" + q["id"]).encode()).hexdigest()))
    selected = []
    for ds in ("hotpotqa", "2wiki"):
        candidates = sorted((r for r in pool if r["dataset"] == ds), key=lambda r: (r["selection_rank_sha256"], r["id"]))
        assert len(candidates) >= 10
        selected.extend({**r, "within_dataset_selection_rank": n} for n, r in enumerate(candidates[:10], 1))
    assert len(selected) == 20 and not {r["id"] for r in selected}.intersection(recent)
    assert not {norm(r["question"]) for r in selected}.intersection(recent_questions)
    # Read the type metadata only after the ID-hash list is fixed; never stratify on outcomes.
    types = {ds: dict(Counter(str(by_id[r["id"]].get("type", "not_in_frozen_question_row")) for r in selected if r["dataset"] == ds)) for ds in ("hotpotqa", "2wiki")}
    selected_exposure = {ds: dict(selected=10, prior723_semantically_reviewed=sum(r["prior723_semantic_exposure"] for r in selected if r["dataset"] == ds),
        primary270_information_reviewed=sum(r["id"] in primary for r in selected if r["dataset"] == ds),
        passive_supplement8_prior_finding=sum(r["id"] in supplemental for r in selected if r["dataset"] == ds)) for ds in ("hotpotqa", "2wiki")}
    candidate_path = OUT / "CANDIDATES20.prospective.jsonl"
    assert not candidate_path.exists()
    candidate_path.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in selected), encoding="utf8")
    summary = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "state": "prospective_cohort_proposal_not_execution_authorization",
        "planned_queries": 20, "planned_fresh_flows": 40,
        "selection_rule": "For each dataset10 smallest (SHA256(UTF8(p02-fixedD-balanced20-v1|20261022|+canonical_id)),canonical_id), after valid actual formalR02/v12 raw/nonemptyordinary and pinned actual-recent-prompt/inference ID or normalized-original-question exclusions; passive270/723 never excluded; no score, answer, stage-mechanism or output filtering",
        "selection_used_no_final_or_semantic_values": True,
        "old_full_RAG_or_score_availability_not_a_filter": True,
        "ordinary_minimum": 1, "one_ordinary_cases_allowed": True, "no_rewrite_difference_requirement": True,
        "source_counts": {d: dict(v) for d, v in stats.items()},
        "recent_exclusion_unique_ids": len(recent),
        "recent_exclusion_per_dataset": dict(Counter(i.split(":", 1)[0] for i in recent)),
        "recent_current_formal_id_overlap": dict(Counter(by_id[i]["dataset"] for i in recent.intersection(by_id))),
        "recent_original_question_normalization": "Unicode casefold, split whitespace, join with single spaces; no answer/semantic normalization",
        "passive270_and_supplement8_disclosure_source": {"path": rel(index_path), "sha256": sha(index_path), "not_used_as_exclusion": True},
        "exclusion_sources": sources, "all_recent_excluded_ids": sorted(recent),
        "prior723_cohort": {"path": rel(old_path), "sha256": sha(old_path), "per_dataset": dict(Counter(r["dataset"] for r in old))},
        "selected_prior_exposure": selected_exposure,
        "postselection_type_distribution": types,
        "candidate_file": rel(candidate_path), "candidate_file_sha256": sha(candidate_path),
        "selection_script_sha256": sha(Path(__file__)),
        "scope_limits": [
            "New fixed cohort with no enumerated recent prompt-tuning overlap, not historically unseen/independent confirmation. The prior723 include500Wiki and223Hotpot; exact current-formal ID intersections and selected overlaps must be reported, not assumed identical. Passive270/723 are disclosed, never filtered, to avoid excluding all historical failures.",
            "Formal questions also have prior baseline/quality evaluation and query-only decomposition exposure. Excluding every historical evaluation would exhaust this formal pool. Recent exclusions are explicit, not a repository-wide never-seen proof.",
            "Strictly excluding prior723 as well leaves only2Wiki candidates after recent exclusions, insufficient for10; a balanced10+10 unseen confirmation within current formal500 is impossible.",
            "Apply frozen single candidate once with fresh pairedD0/D1, no withincohort updates or result-based replacement; no ROLE/M4 combination.",
            "Underlying final outcomes/native references/scores were not opened or used for selection. Only frozen input IDs, rawD validity/structure/provenance and prior-exposure membership were read.",
            "Retain selected questions without historical fullRAG; freshD0 is primary. Old quality reference covers actual available cases only; cost proxy from same-dataset/method historical mean is labeled, never a fake zero.",
        ],
        "no_new_inference_API_SSH_GPU": True, "main_evaluation_remains_paused": True,
    }
    target = OUT / "FEASIBILITY.json"
    assert not target.exists()
    target.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf8")
    print(json.dumps(dict(summary_path=rel(target), summary_sha256=sha(target), candidate_path=rel(candidate_path), candidate_sha256=sha(candidate_path),
        counts=summary["source_counts"], selected_prior_exposure=selected_exposure, types=types,
        recent_ids=summary["recent_exclusion_per_dataset"], candidate_ids=[r["id"] for r in selected]), ensure_ascii=True))


if __name__ == "__main__":
    main()
