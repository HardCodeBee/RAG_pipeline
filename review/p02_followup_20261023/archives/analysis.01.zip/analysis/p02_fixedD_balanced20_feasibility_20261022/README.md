# Fixed-D balanced20 feasibility and prospective cohort

There are enough existing actual formal R02/v12 decompositions for a separate **10 HotpotQA + 10 2Wiki** development check, with two fresh full-RAG arms (40 flows). The candidate file is [CANDIDATES20.prospective.jsonl](CANDIDATES20.prospective.jsonl); no inference or execution authorization was created by this inventory.

| Structure/exclusion step | HotpotQA | 2Wiki |
|---|---:|---:|
| Frozen formal questions | 500 | 500 |
| Existing valid actual formal R02 raw outputs | 401 | 500 |
| Nonempty ordinary decomposition | 346 | 487 |
| Excluded actual recent prompt/inference experiment overlap | 11 | 20 |
| Available pool | **335** | **467** |
| Pool outside the actual prior723 semantic-review IDs | 154 | 2 |

The rule excludes only enumerated recent **actual prompt/inference experiment** IDs (W/L90, original small binding pilot and its follow-up, E/R, synthesis/challenge/S/T, I/B/C and dynamic8), plus exact normalized original-question duplicates. Normalization is Unicode casefold plus whitespace collapse. W/L's 90 canonical IDs themselves do not overlap these current formal1500 IDs; their questions remain in the duplicate check. [FEASIBILITY.json](FEASIBILITY.json) lists each frozen input path, SHA, ID count and current-formal overlap.

**Passive270 and prior723 are not exclusion filters.** The earlier unselected draft would have removed all230 known nonfull scores through the270 set, changing the population and creating a ceiling. Root corrected that rule before any candidate file existed. The stopped draft is retained under `archives/preselection_rejected_rule_001`; it produced no candidate list. No old score, final answer, mechanism label, old-full-RAG availability or rewrite-difference test was used to select the current20.

Within each dataset, choose the10 smallest `(SHA256(UTF8("p02-fixedD-balanced20-v1|20261022|" + canonical_id)), canonical_id)` after the structural and recent-experiment exclusions. All raw arrays must match their formal question and actual v12 prefix, be format-valid, nontruncated and free of generation errors; ordinary count must be at least1. One-ordinary cases remain eligible. No manual60 replacement or new decomposition is used.

The20 rows include only question/raw-decomposition provenance and exposure metadata, with five inference fields `id,qid,dataset,question,supporting_questions`. The builder must project those five fields; exposure/source metadata and local references do not enter prompts or remote query requests. Each row binds `questions1500.frozen.jsonl`, its 1-based formal position and `remote_raw/<position>.json` SHA, plus the original R02 checkpoint-manifest SHA. Missing historical complete-RAG results do not remove selected questions: the fresh paired control is primary; old quality covers only available historical cases and a labeled same-dataset/method cost proxy may be used when needed.

Postselection exposure, without filtering:

| Selected exposure | HotpotQA10 | 2Wiki10 |
|---|---:|---:|
| Prior723 semantic review | 7 | 9 |
| Passive270 information-flow review | 4 | 3 |

The actual prior723 file contains **238 HotpotQA + 485 2Wiki**, with dataset fields matching canonical-ID prefixes and all723 IDs in current formal pools. It was constructed from complete existing trajectories with nonempty child decompositions, as shown in `start_offline_review.py:64` and published in `publish_diagnostic.py:11`. The earlier conversational “500/223” shorthand was inaccurate for this file; formal planned500 and the nonempty completed diagnostic denominator are different quantities. This correction changes no selected ID. After the recent exclusions, strictly removing all prior723 would leave154 HotpotQA and only2 Wiki, so10+10 historically unseen confirmation is not feasible here.

Postselection type metadata is HotpotQA **7 bridge / 3 comparison**, 2Wiki **5 compositional / 3 bridge_comparison / 2 comparison**. The20 IDs were already fixed before projecting `qid,type` from the local frozen reference metadata; answer fields and type balancing were not used for selection.

This is a prospective fixed cohort outside recent prompt tuning, with substantial historical exposure. It is not an untouched or independent confirmation set, a formal500 result, or grounds for main-method promotion. Apply the already frozen single candidate once against a fresh same-period full20 control, with no within-cohort updates, score-based replacement or ROLE/M4 combination. The formal evaluation remains paused.
