# M4 Wiki20固定开发队列（仅离线准备）

从正式2Wiki 500题的实际冻结R02/v12输出选择新的固定20题，供单一冻结M4候选与新鲜M0进行完整RAG配对。此文件不授权API、SSH、GPU或恢复主评。

500题的raw D均有效，五个推理字段全部逐字对应先前已公开的formal runtime。按旧balanced20 selector显式PATHS清单，并加真实balanced20、O8、M4 stage8/full8输入排除：canonical ID或casefold/空白规范化原题重复均不纳入；共排除38题，剩余462题。各来源路径、SHA、IDs与依据见FEASIBILITY.json。

按`SHA256('p02-m4-wiki20-v1|20261022|'+canonical_id)`升序取20题，ID为并列顺序键；不读取或筛选旧分数、最终答案、完整流程可用率、局部truth或M4是否改变reader。允许valid空D：500题中有13条，但本次哈希选择碰巧为0条；不为加入或排除空D另换样本。选中20题共44个普通子问。

20个ID先固定后才读被动审阅membership：20/20在旧723语义审阅中出现，4/20在主270信息流审阅中出现，补充8包重叠0。没有排除passive723/270，避免删除旧失败样本而造成上限偏差。正式questions行没有type字段，故仅如实标记缺失，未另外读取答案材料。

这是近期列举的实际提示/推理实验没有重叠的新固定开发队列，仍非独立未见确认。只应用一次已冻结候选、保留所有结果和退步、不在本队列内改规则或按得分换题。旧历史成绩若缺失，由runner另行标注；不会回头影响这20个选择。

产物：`CANDIDATES20.prospective.jsonl`、`FEASIBILITY.json`、`select_prospective.py`和`OFFLINE_SELECTION_VERIFICATION.json`。独立的formal500-ID减38后哈希重排核对已复现相同20个ID；候选文件SHA为`4658c9368ec1f45411c2a1c82e0396c93ce5f3022b8099832d068f6ff9afbe9d`。
