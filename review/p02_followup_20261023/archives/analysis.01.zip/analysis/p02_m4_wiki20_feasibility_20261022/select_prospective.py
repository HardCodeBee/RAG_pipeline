"""Freeze Wiki20 by ID hash using input IDs/text/rawD/publicruntime only.

No historical answer, score, completion status, reader or stage label is used.
Prior passive723/270 membership is joined only after20 IDs are selected.
"""
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import ast,hashlib,json
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).resolve().parent
FORMAL=ROOT/"experiments/query_decomposition/p02_formal1500_v1_20261021"
FORMAL_OUT=ROOT/"outputs/query_decomposition/hotpot_formal_eval_v1/p02_formal1500_v1_20261021"
OLD_SELECTOR=ROOT/"analysis/p02_fixedD_balanced20_feasibility_20261022/select_prospective.py"
PREFIX="p02-m4-wiki20-v1|20261022|"
EXTRA_PATHS=["p02_live_target_balanced20_dev_v1_20261022/INPUTS20.jsonl","p02_ordinary_scope_input_probe8_v1_20261022/INPUTS8.frozen.jsonl","p02_m4_reader_stage_probe8_v1_20261022/INPUTS8.frozen.jsonl","p02_m4_full8_dynamic_v1_20261022/INPUTS8.jsonl"]
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def rows(p):return [json.loads(s)for s in p.read_text(encoding="utf-8-sig").splitlines()if s.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rel(p):return str(p.resolve().relative_to(ROOT)).replace("\\","/")
def norm(s):return" ".join(s.casefold().split())
def top_ids(row):
    found=set()
    for name in("id","case_id","probe_id","source_case_id"):
        value=row.get(name)
        if isinstance(value,str)and value.split(":",1)[0]in("hotpotqa","2wiki","musique"):found.add(value.split("/",1)[0])
    if isinstance(row.get("qid"),str)and row.get("dataset")in("hotpotqa","2wiki","musique"):found.add(row["dataset"]+":"+row["qid"])
    return found

def main():
    original=ast.parse(OLD_SELECTOR.read_text(encoding="utf8"))
    approved_paths=next(ast.literal_eval(n.value)for n in original.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=="PATHS"for t in n.targets))
    assert len(approved_paths)==15
    qpath=FORMAL/"questions1500.frozen.jsonl";qrows=rows(qpath);byid={q["id"]:q for q in qrows}
    assert len(qrows)==len(byid)==1500 and all(q["id"]==q["dataset"]+":"+q["qid"]for q in qrows)
    assert sha(qpath)==read(FORMAL/"INPUTS.frozen.json")["input_pins"][qpath.name]
    queries=rows(FORMAL/"queries1500.id_query.frozen.jsonl")
    assert len(queries)==1500 and all(a["id"]==b["id"]and a["query"]==b["question"]for a,b in zip(queries,qrows))
    remote=read(FORMAL/"REMOTE_INPUTS.frozen.json");prompt=(FORMAL/"v12.txt").read_text(encoding="utf8").rstrip()
    mpath=ROOT/"tmp/p02_review_delivery_20261021/snapshot/review/p02_20261021/SOURCE_MANIFEST.json";mb=mpath.read_bytes()
    blob=hashlib.sha1(f"blob {len(mb)}\0".encode()+mb).hexdigest();assert blob=="06c67be3c2091ef4066366b8c0c87c2b4d1ece17"
    m=json.loads(mb);public={r["source"].replace("\\","/"):r for r in m["source_files"]}
    for archive in m["archives"]:
        for r in archive.get("members",[]):public[r["source"].replace("\\","/")]=r
    assert sha(qpath)==public[rel(qpath)]["sha256"]
    recent=set();recent_questions=set();sources=[]
    for suffix in approved_paths+EXTRA_PATHS:
        path=ROOT/"experiments/query_decomposition"/suffix;records=rows(path);sourceids=set();sourcequestions=set()
        for record in records:
            ids=top_ids(record);sourceids|=ids
            question=record.get("original_question",record.get("question"))
            if isinstance(question,str):sourcequestions.add(norm(question))
            for i in ids:
                if i in byid:sourcequestions.add(norm(byid[i]["question"]))
        assert sourceids,(suffix,"No dataset/query ID extracted")
        recent|=sourceids;recent_questions|=sourcequestions
        sources.append(dict(path=rel(path),sha256=sha(path),records=len(records),unique_ids=len(sourceids),ids=sorted(sourceids),per_dataset=dict(Counter(i.split(":",1)[0]for i in sourceids)),
            formal_Wiki_id_overlap=sum(i in byid and byid[i]["dataset"]=="2wiki"for i in sourceids),normalized_original_questions=len(sourcequestions),
            normalized_question_projection_sha256=hashlib.sha256(json.dumps(sorted(sourcequestions),ensure_ascii=False,separators=(",",":")).encode()).hexdigest(),basis="Explicit prior actualprompt/inference input inventory;only IDs and originalquestion text projections used"))
    counts=Counter();pool=[];excluded=[]
    for pos,q in enumerate(qrows,1):
        if q["dataset"]!="2wiki":continue
        counts["formal_questions"]+=1
        rawpath=FORMAL_OUT/"remote_raw"/(str(pos)+".json")
        if not rawpath.exists():counts["raw_missing"]+=1;continue
        raw=read(rawpath);counts["raw_exists"]+=1
        assert raw["id"]==q["id"]and raw["query"]==q["question"]and raw["index"]==pos
        valid=(raw.get("format_valid")and not raw.get("truncated")and not raw.get("generation_error")and isinstance(raw.get("parsed"),list)and all(isinstance(x,str)for x in raw["parsed"])and raw.get("actual_prompt","").startswith(prompt))
        if not valid:counts["raw_invalid"]+=1;continue
        counts["raw_valid"]+=1;counts["goal_only_valid"if not raw["parsed"]else"ordinary_present_valid"]+=1
        runtime=FORMAL_OUT/"runtime/2wiki"/(q["qid"]+".json")
        inference=dict(id=q["id"],qid=q["qid"],dataset="2wiki",question=q["question"],supporting_questions=raw["parsed"])
        assert read(runtime)==inference and sha(runtime)==public[rel(runtime)]["sha256"]
        counts["public_runtime_exact"]+=1
        id_hit=q["id"]in recent;text_hit=norm(q["question"])in recent_questions
        if id_hit or text_hit:
            counts["recent_excluded"]+=1;counts["excluded_id_and_question"if id_hit and text_hit else"excluded_id_only"if id_hit else"excluded_question_only"]+=1
            excluded.append(dict(id=q["id"],id_match=id_hit,normalized_question_match=text_hit));continue
        counts["eligible_pool"]+=1
        pool.append({**inference,"formal_position_one_based":pos,"question_file":rel(qpath),"question_file_sha256":sha(qpath),"raw_file":rel(rawpath),"raw_sha256":sha(rawpath),"actual_R02_array_exact":True,"semantic_repairs_applied":False,
            "source_R02_remote_inputs_sha256":sha(FORMAL/"REMOTE_INPUTS.frozen.json"),"source_R02_checkpoint_manifest_sha256":remote["checkpoint_manifest_sha256"],"public_runtime":rel(runtime),"public_runtime_sha256":sha(runtime),
            "selection_rank_sha256":hashlib.sha256((PREFIX+q["id"]).encode()).hexdigest()})
    assert counts["formal_questions"]==500 and len(pool)>=20
    ordered=sorted(pool,key=lambda r:(r["selection_rank_sha256"],r["id"]))
    chosen=[{**r,"selection_rank":n}for n,r in enumerate(ordered[:20],1)]
    frozen_selected_ids=tuple(r["id"]for r in chosen)
    assert len(set(frozen_selected_ids))==len({norm(r["question"])for r in chosen})==20
    assert not set(frozen_selected_ids).intersection(recent)and not {norm(r["question"])for r in chosen}.intersection(recent_questions)
    # Only now join passive membership. No truth, native score, answer or
    # previous completion/score availability field is read or used.
    priorpath=ROOT/"outputs/query_decomposition/p02_error_propagation_diagnostic_20261021/offline_review_v2/COHORT.jsonl"
    prior_projection=[{k:r[k]for k in("id","dataset")}for r in rows(priorpath)];prior={r["id"]for r in prior_projection}
    assert len(prior)==723 and all(r["dataset"]==r["id"].split(":",1)[0]for r in prior_projection)
    infopath=ROOT/"outputs/query_decomposition/p02_information_flow_followup_20261022/REVIEW_INDEX_V9.jsonl"
    ip=[{k:r[k]for k in("id","selection")}for r in rows(infopath)]
    primary={r["id"]for r in ip if r["selection"]!="historical_case_outside_probability_sample"};supp={r["id"]for r in ip if r["selection"]=="historical_case_outside_probability_sample"}
    assert len(primary)==270 and len(supp)==8
    for r in chosen:r.update(prior723_semantic_exposure=r["id"]in prior,primary270_review_exposure=r["id"]in primary,supplemental8_exposure=r["id"]in supp)
    assert frozen_selected_ids==tuple(r["id"]for r in chosen)
    path=OUT/"CANDIDATES20.prospective.jsonl";summarypath=OUT/"FEASIBILITY.json"
    summary=dict(created_utc=datetime.now(timezone.utc).isoformat(),state="prospective_fixed_cohort_not_execution_authorization",planned_queries=20,planned_fresh_flows=40,
        selection_rule="20 smallest(SHA256(UTF8(p02-m4-wiki20-v1|20261022|+canonicalid)),canonicalid) among formalWiki500 validactualR02 and exactpublicruntime afterexplicit prioractualexperiment ID/normoriginalquestion exclusion",
        ordinary_minimum=0,valid_empty_D_allowed=True,old_quality_or_completion_or_score_availability_not_a_filter=True,no_reader_change_or_localtruth_filter=True,no_passive723_or270_exclusion=True,
        source_counts=dict(counts),eligible_pool_idhash_sha256=hashlib.sha256(json.dumps([(r["id"],r["selection_rank_sha256"])for r in ordered],separators=(",",":")).encode()).hexdigest(),
        original_PATHS_source=dict(path=rel(OLD_SELECTOR),sha256=sha(OLD_SELECTOR),used_only_AST_PATHS_constant=True),exclusion_sources=sources,recent_unique_ids=len(recent),recent_unique_ids_per_dataset=dict(Counter(i.split(":",1)[0]for i in recent)),
        all_recent_excluded_ids=sorted(recent),formal_Wiki_exclusions=excluded,question_normalization="Unicode casefold+whitespace split/join;no answer/semantic normalization;formal originaltext filled from source IDs where available",
        prior723=dict(path=rel(priorpath),sha256=sha(priorpath),per_dataset=dict(Counter(r["dataset"]for r in prior_projection)),not_used_for_selection=True),passive270_and_supplement8=dict(path=rel(infopath),sha256=sha(infopath),not_used_as_exclusion=True),
        postselection=dict(prior723_overlap=sum(r["prior723_semantic_exposure"]for r in chosen),primary270_overlap=sum(r["primary270_review_exposure"]for r in chosen),supplemental8_overlap=sum(r["supplemental8_exposure"]for r in chosen),
            empty_D=sum(not r["supporting_questions"]for r in chosen),ordinary_nodes=sum(len(r["supporting_questions"])for r in chosen),type_distribution=dict(Counter(str(byid[r["id"]].get("type","not_in_frozen_question_row"))for r in chosen))),
        public_manifest=dict(path=rel(mpath),sha256=sha(mpath),git_blob=blob,prior_verified_publication_only_no_new_network=True),candidate_file=rel(path),selection_script_sha256=sha(Path(__file__)),
        limits=["New fixed development cohort,not independent or historically unseen;priorbaseline/queryonly and passive semantic exposure disclosed","Exactlyone frozenM4 candidate to be evaluated once with freshpaired controls;no withincohort prompt/policy changes or resultbased replacement","Passive723/270 never excluded,avoiding old-failure removal ceilingbias","No historical finalprediction/native score/completion/reader or newstage truth used inselection","Inference/publicruntime eligibility is structural/provenance,not fullRAG answeravailability;missing oldreference must not remove a chosenquery","No API/SSH/GPU or authorization;formal main evaluation remains paused"],new_API_SSH_GPU=0,main_evaluation_remains_paused=True)
    content="".join(json.dumps(r,ensure_ascii=False)+"\n"for r in chosen)
    if path.exists():
        assert path.read_text(encoding="utf8")==content,"Preserve original selected20 bytes;version an authorized rule change"
        frozen=read(summarypath);assert frozen["selection_script_sha256"]==sha(Path(__file__))and frozen["candidate_file_sha256"]==sha(path)
        print(json.dumps(dict(verified_existing=True,candidate_sha256=sha(path),summary_sha256=sha(summarypath)),ensure_ascii=True));return
    assert not summarypath.exists();path.write_text(content,encoding="utf8");summary["candidate_file_sha256"]=sha(path)
    summarypath.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n",encoding="utf8")
    print(json.dumps(dict(candidate=rel(path),candidate_sha256=sha(path),feasibility_sha256=sha(summarypath),counts=dict(counts),postselection=summary["postselection"],selected_ids=list(frozen_selected_ids)),ensure_ascii=True,indent=2))
if __name__=="__main__":main()
