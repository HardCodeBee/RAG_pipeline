# W180 原生指标与同请求重复复核

90个W0实际完整请求body逐字等于冻结历史body，90个W1只增加批准的目标核对句；其余字段、示例、材料、64输出上限均一致。当前180回执均stop、指定模型匹配、三项usage为非负整数且total=输入+输出，原始response与保存回执一致。180条DETAILS、90条PAIRED及REPORT的各数据集/总体/费用聚合均独立重算一致；官方scorer每数据集仅初始化一次。

| 范围 | W0 F1 / EM | W1 F1 / EM |
|---|---:|---:|
| HotpotQA 30 | 0.819920635 / 0.700000000 | 0.819920635 / 0.700000000 |
| 2Wiki 30 | 0.943333333 / 0.900000000 | 0.943333333 / 0.900000000 |
| MuSiQue 30 | 0.520745726 / 0.366666667 | 0.521351786 / 0.366666667 |
| 总体90 | 0.761333231 / 0.655555556 | 0.761535252 / 0.655555556 |

W1对同期W0：1题native F1升、89题同分、0题下降；平均差0.000202020202，EM不变。唯一变化为`musique:2hop__289517_139339`，原题“What was the cast member in After Hours nominated for?”：W0 `Griffin Dunne was not nominated for any award for his role in *After Hours*.` 得F1 0.181818182，W1 `No award` 得 0.200000000，二者EM均0。这是两种否定句之间原生词面匹配分数的微小变化，不能据此声称事实纠错或方法实质改善，语义结论须单独遮蔽审查。

历史参考F1 0.766888786881 / EM 0.666666666667 与fresh W0的全部native漂移仅`musique:4hop3__373866_5189_38229_86687`：历史 `1990` 为F1/EM1/1，W0和W1均 `12 September 1990` 为0.5/0。两次完整body一致（hash `0edd2fec64fedf8c33d556a760dd9f7d157816eb02489d98df29d49ceb69b843`），历史与新控制分别是非同期重复请求；未更改输入。年份与具体日期的词面差异解释了native分数变化；但须同时核对日期属于哪个事件，不能先称它只是语义等价的格式漂移，也不据计分差直接判事实。

按数据集分层、题目成对bootstrap100000次（seed20261022），平均F1差的95%百分位区间为[0.0, 0.0006060606060606063]，EM差区间[0.0, 0.0]。这只是反复暴露开发90题上的描述性重采样，不能作为独立泛化确认，也不覆盖未来API重复波动。

新final输入/输出tokens：W0 246059/540；W1 249389/524。新已返回usage估算费用合计0.3984864元；4条无任何已返回迹象的unknown旧尝试仍保留0.0331792元预留，未作0费用处理。每payload持久attempt最大2，全部未超5。原REPORT的full-flow逻辑费用按每arm重复归属冻结上游使用量，不是本轮新增支出；本次没有重跑上游，不能据此声称完整流程计时。

全部117个冻结pins和六项protected/core/STOP hash均未变，主评估批准仍false。W数据库逻辑内容读前读后hash相同，原DETAILS/PAIRED/REPORT未改。本次仅新增本审计JSON/Markdown及独立审计脚本，0API/0检索/0GPU/0SSH，不读取遮蔽方法key，不改变进程状态。

来源限制另见decomposition_lineage_audit/revision002：W为同冻结R02/v12的历史raw实际分解；旧wrapper不能等同于formal1500更新后的显式generation_config合同，且两批没有同数据集共同原题。本审计的“完整body”指记录的OpenAI兼容请求body，未截取HTTP层原始传输字节或重新验证provider内部实现。

日期题的材料补充

原题全文：A group of nations of which the People's Socialist Republic of Albania was a member was controlled by one country. When did that country agree to a unified Germany inside of the organization Eisenhower would not discuss during the campaign?

问题用“When”，没有要求只答年份，因此不能因为gold/alias含1990便要求删掉正确日期。dataset原生答为May1990、接受alias1990；对应Germanreunification支持段明确：

> Horst Teltschik, Kohl's foreign policy advisor, later recalled that Germany would have paid ``100 billion deutschmarks ''if the Soviets demanded it. The USSR did not make such great demands, however, with Gorbachev stating in February 1990 that`` The Germans must decide for themselves what path they choose to follow''. In May 1990 he repeated his remark in the context of NATO membership while meeting Bush, amazing both the Americans and Germans. This removed the last significant roadblock to Germany being free to choose its international alignments, though Kohl made no secret that he intended for the reunified Germany to inherit West Germany's seats in NATO and the EC.

这段已在goal改写检索rank9（doc_id `a74427e6e1ae1eff573a88f9b826123f83d8c03feeb1d844df1d19766c1ef4f6`）取得，却没有进入goal合并Top10 reader，也没有进入final的十个检索片段。final看到的12September1990只来自goal候选句：

> The Soviet Union agreed to a unified Germany within NATO in 1990, as confirmed by the Two Plus Four Treaty signed on 12 September 1990.

因此1990是材料支持的较粗答案，12September1990并非当前reader已经证明的同一事件的更精确答案；它把“同意统一德国加入NATO”与“后来TwoPlusFourTreaty签署”混在一起的风险需要分开记录。这里既有native年份alias/粒度敏感，也有证据选择及事件日期绑定问题，不能断言只是合法详细日期被扣分。保留原native分数、原历史标签和输出；不为优化分数删事实，不以共享1990自动认定两答案同样正确。本补充仅用既有冻结检索和原数据集材料，0网页/外部评审请求。
