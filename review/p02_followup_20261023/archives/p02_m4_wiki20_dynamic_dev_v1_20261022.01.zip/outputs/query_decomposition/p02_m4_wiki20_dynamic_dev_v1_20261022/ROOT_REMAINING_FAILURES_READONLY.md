这份记录只解释 Wiki20 中指定的两道非 Ferenc 原生零分题。全范围封存、语义首标签锁定和解盲之后，只读实际 checkpoint、冻结输入和原始数据集材料；没有重跑、联网、修改标签或更改官方分数。JSON 附每臂节点、reader 清单、精确短引、请求/输入/材料 SHA。它是事后轨迹解释，不是新盲标或总体因果结论。

| 题目 | 两臂实际最终答案 | 实际关键边界 | M4 为什么没有修复 |
|---|---|---|---|
| Life Marathon / Eason Chan 的国籍 | Hong Konger | 原生目标是 country of citizenship → China；目标正文只明确 Hong Kong singer and actor | 同一 Eason 段已在两臂 goal reader 第2位；去 Jackie 重复、补 Ace 没有增加 Eason 的国家国籍事实 |
| Buster & Chauncey’s Silent Night 导演出生地 | Cannot be determined | 数据集写 place of birth → American/Q30，但被引正文只说 American television producer | 两臂已找到 Buzz，但同一人物段没有出生地点；去重复、补其他人物不能补出这个关系 |

Eason 一题（`2wiki:391186b00bdb11eba7f7acde48001122`）：冻结 rawD 只有“谁演唱这首歌”，普通 QA 正确答 Eason Chan；goal 的实际改写是 “What nationality is Eason Chan?”，没有把实体或关系带偏。两臂实际 goal reader 都保留同一篇 Eason 介绍的 “is a Hong Kong singer and actor”，goal 也都输出这一事实句。M4 只移除第二条 Jackie Chan 近重复、补入 Ace Young，未改变这条目标人物证据。

原始 dev 的 evidence graph 明确把该题的国籍解释为 `country of citizenship → China/Q148`。而叙述中 “China” 出现在 Forbes 榜单名称，不能因此把它当作该人的国籍事实。最终 “Hong Konger” 保留了材料里的地域身份，未转换为基准要求的国家层级答案。Q148 的官方别名包含 China/Chinese 等，不包含 Hong Konger；因此这不是大小写或拼写别名差异。原生零分保留，但不能据此宣称“找错歌手”或“香港地域身份是假的”，也不自动把地域身份当作法律国籍同义词。若需要独立法律国籍真伪结论，仍需另核明确关系；本次没有为此联网。

Buzz 一题（`2wiki:deb8c5dc0bdc11eba7f7acde48001122`）：rawD 正确问电影导演，普通 QA 正确答 Buzz Potamkin，goal 改写正确问其出生地。M0 的 goal reader 第2、4位有两份 Buzz 短介绍；M4 第2位保留首份、去掉重复。两份都只说明出生/死亡日期和 “American television producer”，没有说明在哪出生。M4 新补的 Benjamin Cleary、Christy Cabanne 不是 Buzz 的出生地证据；其他人的出生地也不能移到 Buzz 身上。

原始 dev 的证据本身就是 `[Buzz Potamkin, place of birth, American]`，对应 Q30，而被标 supporting fact 的句子仅支持美国制片人的身份。国籍/职业形容词不蕴含出生地；即便真实出生国碰巧是美国，也不能靠这句话证明。因此可确认的是“提问关系与所给文本支持不一致”，不是已经查明其真实出生地与参考冲突。goal 和 final 的合理弃答缺少所求地点，却没有丢失一个已经可见的正确出生地。不能因为参考词 American 在 reader 中出现，就把合理弃答判作读不懂证据；也不能为了命中参考把 nationality 偷换为 birthplace。实际出生地仍留待核，本次不强判世界事实。

两题的普通 QA 与改写都没有分叉；M4 的 goal reader 改变后，目标段和 goal 答案仍相同。各题两臂的最终 helper、原始 root、完整 final prompt/context 逐字一致，并按既定同 run 精确复用规则各共享同一条 final 回执。这解释了观察到的最终不变，不能当作两次独立 final 生成的重复证明。两题都不是本次 reader 去冗余可以直接解决的“关键目标段被重复挤出”案例；也不能由这两例推断所有 Wiki20、正式500或723条的主因。

完整机器可读证据见 [ROOT_REMAINING_FAILURES_READONLY.json](ROOT_REMAINING_FAILURES_READONLY.json)。官方分数、参考与首版语义标签保持原样；本轮在此收口，不启动新实验。
