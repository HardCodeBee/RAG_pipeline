# Goal 综合试验：材料与组合的盲审

覆盖固定15题的G1/G2，共30段。审阅者只读取原题、冻结普通QA、goal reader材料及已生成goal段落，未查看参考答案、原生分数、历史或本次final答案。数据库始终以`mode=ro`读取；不构造Cache，不改评估记录，不调用外部评审模型。

这是单个Codex审阅者的人工检查，不是独立人工金标。逐条字段见`reviews.jsonl`；两个字段含义的澄清见`review_amendments.jsonl`；覆盖和字数见`SUMMARY.blinded.json`。

15对均保留了审阅者识别出的同一组决定性事实，但完整事实集合、辅助陈述和缺口判断并不相同；这不代表15题都取得了足够信息，更不代表所有段落都正确。

G1至少7/15题显式写了比较、关系组合或冲突推导，违反其“不描述推导过程”的要求。因此当前结果不能解释为干净的“没有推理”对“有推理”。G1平均128.53词，10/15超过120词；G2平均138.33词，13/15超过120词。目标长度相近没有保证实际长度一致。

| 数据集/题目片段 | 关键观察 |
| --- | --- |
| HotpotQA / Mount Stimson的国家公园面积 | 两组都保留Glacier National Park及over 1 million acres。G2明确绑定，却错误地把下界描述为精确面积；两组都虚增NPS官方来源背书，冻结材料无该来源。 |
| HotpotQA / Glen River源山高度 | 两组均保留Slieve Donard、850 m及北爱尔兰最高峰。G2更清楚保留两座源山，使用区域排名代替缺失的逐山数值比较。G1对已有另一源山信息表述较弱。 |
| HotpotQA / Kieft's War的Captain | 都没有取得所问Captain身份。G2把“总督下令”进一步当作“Captain执行被反驳”，混淆下令者与带队者。Captain未知这一结论可由缺证支持，但这段排除论证无效。G1增加了冻结材料中没有的地点、时间和伤亡数。 |
| HotpotQA / Essence与Alt for Damerne | 两组都取得新事实Essence为月刊，修正原普通QA弃答，并正确比较周刊与月刊。G1也写52>12，显示条件分离失败。年化常规频率不等于已核实某年实际期数。 |
| HotpotQA / Guam与意大利春季攻势 | 两组均保留正确战事、参战方及德国投降关系。G2显式选择，G1也有对比推导。Caserta为有效补充，Java Sea潜艇事件及多数日期并非必要。 |
| 2Wiki / Balipeetam与Keep 'Em Rolling导演年龄 | 两组均列1890与1947。G1却写156年及106年差，完整解释内部错误；其候选电影仍由日期顺序支持。G2写1947−1890=57，组合一致。不能在未看final时声称下游改善。 |
| 2Wiki / Sleepers East导演出生更早 | 两组均正确保留1899与1945及导演—电影绑定。G1也显式算日期差。G2较清楚区分出生日期来自历史QA、当前reader只确认导演身份；“没有反证”仍不能算独立核验。 |
| 2Wiki / 两部电影上映时间 | 两组都比较1989与2007并选同一电影。G1也显式推导18年差。G2把同一文章的近重复Chunk2/3称为独立确认，夸大证据独立性。 |
| 2Wiki / Josef Mach出生地 | 两组都保留Prostějov，G2明确区分出生地与去世地Prague。两组额外国家历史限定不同，均超出冻结摘录；这里不联网裁定该附加事实。 |
| 2Wiki / Zhengde父系祖父 | 两组保留Hongzhi→Chenghua链，G2显式父亲的父亲。当前reader未独立核验第二跳。两组均增添未提供的谱系背书；G1另排除Yongle/Hongxi为父系祖先，现有材料不支持这项多余排除。 |
| MuSiQue / 黄太后孩子的孩子 | 两组都取得新事实Wang Jipeng之父为Wang Yanjun，并正确保留别名。G2直接给出三节点链；G1也有Thus组合，另增不必要的继位与政变细节。 |
| MuSiQue / After Hours演员获得什么提名 | reader已给Griffin Dunne的Best Live Action Short Film提名。两组却新增“必须因After Hours被提名”的约束，原题并无此限制。两段仍包含奖项事实，但G2最后明确转向无法确定。来源已足够时，错误解释问题也能制造缺口。 |
| MuSiQue / 新Yankee Stadium首个本垒打者所属球队 | 两组都保留Posada及New York Yankees。reader明确是first Yankee home run，而原普通QA与问题是未限定first home run。两段均注意部分限定，但最终叙述又有所放宽；所选球员的球队绑定本身一致。 |
| MuSiQue / Vasilopita、基督教起源城市与清真寺 | G2注意Greece与Jerusalem两条地域分支冲突，仍直接按Jerusalem分支给Al-Aqsa；原题各约束未获统一解释。两组把共址材料当作对特定旧寺建址关系的独立确认，该具体关系实际来自普通QA。G2另把Rome概括为非城市，增加错误。 |
| MuSiQue / Superior Drill、Springfield与州首府 | 两组都保留Springfield Ohio及Mayo出生Illinois，识别同名城市而没有静默替换为Springfield Illinois。G2冲突谓词更显式，但G1也已识别。两组添加材料中没有的1839年及外部知识，不能说这是本次检索新增事实。 |

这批输出支持继续检查“必要信息是否保留、实体和属性是否绑定、原题约束是否被擅自增加或丢弃”。它尚未证明综合段落能改善最终质量；原生分数需要在这份盲审冻结后另行合并。

下一步机制对照可固定同一份已核实的关键事实清单，再比较简短事实呈现与必要组合呈现，取消强迫凑够词数，记录实际长度；同时明确禁止给原题添加未要求的关系。当前G0/G1/G2协议和结果保持原样。
