# 同一15题的组件配对复核建议

这份独立复核不替换原REPORT。final-goal-none的2条length按冻结15题分母作为算法失败计0；原13条成功报告保留。详见该运行目录的TERMINAL_OUTCOME_REVIEW.json/.md。

| 条件 | 固定题数 | F1 | EM | 对pilot G0的F1改善/持平/损害 |
| --- | ---: | ---: | ---: | --- |
| pilot G0，双路goal+事实句 | 15 | 85.71% | 80.00% | 参照 |
| pilot G1，事实摘要 | 15 | 79.05% | 73.33% | 0/14/1 |
| pilot G2，综合段落 | 15 | 79.05% | 73.33% | 0/14/1 |
| goal仅原路线，G0 | 15 | 72.32% | 66.67% | 1/11/3 |
| final不接收goal候选段 | 15 | 67.78% | 60.00% | 0/11/4 |

关闭goal改写的主要损害有明确的信息通路依据：

- Josef Mach出生地：原goal路线和final root都没有Josef Mach传记，改写“What is the place of birth of Josef Mach?”后双路reader纳入该传记，提供Prostějov。关闭改写或移除goal信息后均弃答。
- 黄太后后代：原goal路线和final root没有Wang Jipeng文章；“Who is the child of Wang Yanjun?”改写后双路reader取得父子关系。关闭改写后弃答；移除goal信息后final只返回前一跳Wang Yanjun，F1由1降至0.5。
- Glacier面积：两种材料都已有Glacier National Park面积，只是排名与周边内容不同；输出从“over 1 million acres”变为“1 million acres”。这更接近限定词/输出差异，不是完全没有检到关键材料。

关闭goal改写唯一的F1增益是After Hours：G0的“Canadian Comedy Awards nomination”原生F1为0，关闭后错误整句“Griffin Dunne was not nominated for any award for his role in After Hours”得到F1约0.1818。它增加了参考词面重合，没有完成事实纠正，EM仍0。不能用这一点声称关改写改善了事实质量。

移除goal信息另损害Kieft题：原G0返回Captain John Underhill，移除后返回Willem Kieft。原reader没有给Underhill；因此这是一条候选消息影响final的观察，不能仅凭计分把G0的来源利用认定为已验证。

两个length算法失败发生在原G0也为0分的After Hours与Springfield题，按0计入不会额外改变上述配对F1改善/损害计数。其provider回执和64个输出tokens费用仍须计入。

后续更合适的方向是保留goal实体化补充检索与其新事实通道，单独研究候选信息怎样呈现、如何维持原题约束及事实组合。此15题不支持删除整个goal模块，也不证明综合段落无效。移除final中的goal段不等于取消goal计算；关闭保存的goal补充路线也不等于完整迭代流程消融。
